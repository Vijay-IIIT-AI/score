"""Application configuration."""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    app_name: str = "SemcoEval"
    debug: bool = False
    api_prefix: str = "/api/v1"

    # Database
    database_url: str = "postgresql+asyncpg://postgres:postgres@db:5432/semcoeval"

    # Redis & Celery
    redis_url: str = "redis://redis:6379/0"
    celery_broker_url: str = "redis://redis:6379/0"
    celery_result_backend: str = "redis://redis:6379/0"

    # MinIO
    minio_endpoint: str = "minio:9000"
    minio_access_key: str = "minioadmin"
    minio_secret_key: str = "minioadmin"
    minio_bucket: str = "semcoeval"
    minio_secure: bool = False

    # SSO
    sso_enabled: bool = True
    sso_issuer: str = ""
    sso_jwks_url: str = ""
    sso_audience: str = "semcoeval"
    sso_dev_mode: bool = False  # MUST be False in production
    sso_dev_user_id: str = "dev-user-001"
    sso_dev_user_email: str = "dev@example.com"

    # Security - MUST change in production
    encryption_key: str = "change-this-32-byte-key-in-prod!"
    jwt_secret: str = "change-this-jwt-secret-in-prod!"
    jwt_algorithm: str = "HS256"
    jwt_expire_hours: int = 24

    # CORS
    allowed_origins: str = "http://localhost:3000,http://localhost:5173"

    # Report LLM Configuration (for AI-powered report analysis)
    # These settings control the LLM used to generate intelligent report analysis
    report_llm_enabled: bool = True  # Enable/disable LLM analysis in reports
    report_llm_provider: str = "openrouter"  # LLM provider
    report_llm_model: str = "google/gemini-flash-1.5"  # Default model (cost-effective)
    report_llm_api_key: str = ""  # System API key for report generation
    report_llm_base_url: str = "https://openrouter.ai/api/v1"
    report_llm_max_tokens: int = 1000
    report_llm_temperature: float = 0.3

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip() for o in self.allowed_origins.split(",")]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
