"""Storage module."""
from app.storage.minio_client import storage, StorageClient

__all__ = ["storage", "StorageClient"]
