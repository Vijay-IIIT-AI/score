"""MinIO storage client for datasets and reports."""
from io import BytesIO
from typing import Optional
from minio import Minio
from minio.error import S3Error

from app.config import settings


class StorageClient:
    def __init__(self):
        self.client = Minio(
            settings.minio_endpoint,
            access_key=settings.minio_access_key,
            secret_key=settings.minio_secret_key,
            secure=settings.minio_secure
        )
        self.bucket = settings.minio_bucket

    def ensure_bucket(self):
        """Create bucket if not exists."""
        if not self.client.bucket_exists(self.bucket):
            self.client.make_bucket(self.bucket)

    def upload_file(self, path: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        """Upload file to storage."""
        self.ensure_bucket()
        self.client.put_object(
            self.bucket, path, BytesIO(data), len(data), content_type=content_type
        )
        return path

    def download_file(self, path: str) -> Optional[bytes]:
        """Download file from storage."""
        response = None
        try:
            response = self.client.get_object(self.bucket, path)
            return response.read()
        except S3Error:
            return None
        finally:
            if response:
                response.close()
                response.release_conn()

    def delete_file(self, path: str) -> bool:
        """Delete file from storage."""
        try:
            self.client.remove_object(self.bucket, path)
            return True
        except S3Error:
            return False

    def get_presigned_url(self, path: str, expires_hours: int = 1) -> str:
        """Get presigned URL for file download."""
        from datetime import timedelta
        return self.client.presigned_get_object(
            self.bucket, path, expires=timedelta(hours=expires_hours)
        )


# Singleton instance
storage = StorageClient()
