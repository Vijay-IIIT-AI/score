"""Base evaluator interface for backend evaluation jobs."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from enum import Enum


class EvalStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class EvalProgress:
    """Progress update for evaluation."""
    current: int = 0
    total: int = 0
    status: EvalStatus = EvalStatus.PENDING
    message: str = ""


@dataclass
class EvalScore:
    """Score for a single model."""
    model_id: str
    provider: str
    overall_score: float = 0.0
    metric_scores: dict[str, float] = field(default_factory=dict)
    passed_tests: int = 0
    failed_tests: int = 0
    total_tests: int = 0
    details: list[dict] = field(default_factory=list)


@dataclass
class EvalResult:
    """Complete evaluation result."""
    evaluation_id: str
    status: EvalStatus
    scores: list[EvalScore] = field(default_factory=list)
    top_model: Optional[str] = None
    top_score: float = 0.0
    summary: dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None


class BaseEvaluator(ABC):
    """Abstract base class for evaluation engines."""

    def __init__(self):
        self._progress_callback: Optional[Callable[[EvalProgress], None]] = None

    def set_progress_callback(self, callback: Callable[[EvalProgress], None]):
        """Set callback for progress updates."""
        self._progress_callback = callback

    def _update_progress(self, current: int, total: int, message: str = ""):
        """Send progress update via callback."""
        if self._progress_callback:
            self._progress_callback(EvalProgress(
                current=current,
                total=total,
                status=EvalStatus.RUNNING,
                message=message
            ))

    @abstractmethod
    def evaluate(
        self,
        dataset_content: dict,
        model_configs: list[dict],
        metrics_config: dict,
        **kwargs
    ) -> EvalResult:
        """
        Run evaluation.

        Args:
            dataset_content: Parsed dataset JSON
            model_configs: List of {"provider": str, "model_id": str, "api_key": str}
            metrics_config: Metrics configuration
            **kwargs: Additional options

        Returns:
            EvalResult with scores for each model
        """
        pass

    @property
    @abstractmethod
    def eval_type(self) -> str:
        """Return the evaluation type this evaluator handles."""
        pass
