"""Agent evaluation engine using SemcoEval framework."""
import sys
import json
import httpx
from pathlib import Path
from typing import List, Dict, Any

# Add semcoeval to path if not installed
SEMCOEVAL_PATH = Path(__file__).parent.parent.parent.parent / "semcoeval"
if SEMCOEVAL_PATH.exists() and str(SEMCOEVAL_PATH.parent) not in sys.path:
    sys.path.insert(0, str(SEMCOEVAL_PATH.parent))

from app.evaluators.base_evaluator import BaseEvaluator, EvalResult, EvalScore, EvalStatus


class AgentEvaluator(BaseEvaluator):
    """Evaluator for agent evaluation datasets - tool calling and workflow accuracy."""

    @property
    def eval_type(self) -> str:
        return "agent"

    def evaluate(
        self,
        dataset_content: dict,
        model_configs: list[dict],
        metrics_config: dict,
        **kwargs
    ) -> EvalResult:
        """Run agent evaluation using SemcoEval framework."""
        try:
            from semcoeval.datasets.golden import GoldenDataset
        except ImportError as e:
            return EvalResult(
                evaluation_id=kwargs.get("evaluation_id", ""),
                status=EvalStatus.FAILED,
                error_message=f"SemcoEval not available: {e}"
            )

        evaluation_id = kwargs.get("evaluation_id", "unknown")
        scores = []

        try:
            questions = dataset_content.get("questions", [])
            total_questions = len(questions)

            if not questions:
                return EvalResult(
                    evaluation_id=evaluation_id,
                    status=EvalStatus.FAILED,
                    error_message="No questions in dataset"
                )

            # Convert agent questions to samples with tool expectations
            samples = []
            for q in questions:
                input_data = q.get("input", {})
                expected = q.get("expected", {})

                sample = {
                    "input": input_data.get("prompt", ""),
                    "expected_output": None,
                    "expected_tools": expected.get("tool_calls", []),
                    "retrieval_context": None,
                    "context": None,
                    "metadata": {
                        "sample_id": q.get("id", ""),
                        "max_tool_calls": expected.get("max_tool_calls"),
                        "available_tools": input_data.get("available_tools", []),
                        "tool_responses": input_data.get("tool_responses", {}),
                        "type": "agent"
                    }
                }
                samples.append(sample)

            # Create dataset using the proper classmethod
            dataset = GoldenDataset.from_dict_list(samples, name="Agent Evaluation")

            # Evaluate each model
            for i, model_config in enumerate(model_configs):
                provider = model_config.get("provider", "openrouter")
                model_id = model_config.get("model_id", "")
                api_key = model_config.get("api_key")

                self._update_progress(
                    current=i,
                    total=len(model_configs),
                    message=f"Evaluating agent {model_id}"
                )

                try:
                    # Evaluate using custom tool-calling scoring
                    test_results = []
                    passed = 0
                    failed = 0
                    total_score = 0.0
                    tool_accuracy_total = 0.0

                    for j, sample in enumerate(samples):
                        prompt = sample["input"]
                        expected_tools = sample["expected_tools"]
                        available_tools = sample["metadata"].get("available_tools", [])

                        # Create a prompt that asks the model to identify which tools to use
                        tool_prompt = self._create_tool_prompt(prompt, available_tools)

                        # Get LLM response
                        actual_output = self._call_llm(model_id, provider, api_key, tool_prompt)

                        # Score tool calling accuracy
                        tool_score, tools_matched = self._score_tool_response(
                            actual_output, expected_tools, available_tools
                        )
                        total_score += tool_score
                        tool_accuracy_total += tool_score

                        item_passed = tool_score >= 0.5
                        if item_passed:
                            passed += 1
                        else:
                            failed += 1

                        test_results.append({
                            "test_id": sample["metadata"].get("sample_id", f"test-{j}"),
                            "input": prompt[:100] + "..." if len(prompt) > 100 else prompt,
                            "output": actual_output[:200] + "..." if len(actual_output) > 200 else actual_output,
                            "expected_tools": [t.get("name") for t in expected_tools],
                            "tools_matched": tools_matched,
                            "passed": item_passed,
                            "score": tool_score
                        })

                    overall_score = total_score / len(samples) if samples else 0.0
                    tool_accuracy = tool_accuracy_total / len(samples) if samples else 0.0

                    score = EvalScore(
                        model_id=model_id,
                        provider=provider,
                        overall_score=overall_score,
                        metric_scores={
                            "accuracy": overall_score,
                            "tool_accuracy": tool_accuracy
                        },
                        passed_tests=passed,
                        failed_tests=failed,
                        total_tests=len(samples),
                        details=test_results
                    )
                    scores.append(score)

                except Exception as model_error:
                    scores.append(EvalScore(
                        model_id=model_id,
                        provider=provider,
                        overall_score=0.0,
                        passed_tests=0,
                        failed_tests=total_questions,
                        total_tests=total_questions,
                        details=[{"error": str(model_error)}]
                    ))

            # Find top model
            top_model = None
            top_score = 0.0
            if scores:
                best = max(scores, key=lambda s: s.overall_score)
                top_model = f"{best.provider}:{best.model_id}"
                top_score = best.overall_score

            return EvalResult(
                evaluation_id=evaluation_id,
                status=EvalStatus.COMPLETED,
                scores=scores,
                top_model=top_model,
                top_score=top_score,
                summary={
                    "total_models": len(model_configs),
                    "total_questions": total_questions,
                    "eval_type": "agent"
                }
            )

        except Exception as e:
            return EvalResult(
                evaluation_id=evaluation_id,
                status=EvalStatus.FAILED,
                error_message=str(e)
            )

    def _create_tool_prompt(self, user_prompt: str, available_tools: List[Dict]) -> str:
        """Create a prompt that asks the model which tools to use."""
        tools_desc = "\n".join([
            f"- {t.get('name')}: {json.dumps(t.get('parameters', {}))}"
            for t in available_tools
        ])

        return f"""You are an AI assistant with access to the following tools:
{tools_desc}

User request: {user_prompt}

Based on the user's request, which tool(s) should be used?
Respond with the tool name(s) that would be most appropriate.
If multiple tools are needed, list them all."""

    def _call_llm(
        self,
        model_id: str,
        provider: str,
        api_key: str,
        prompt: str,
        system_prompt: str = "You are a helpful assistant that identifies which tools to use."
    ) -> str:
        """Call LLM API and return response."""
        base_url = "https://openrouter.ai/api/v1"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://semcoeval.com",
            "X-Title": "SemcoEval"
        }

        payload = {
            "model": model_id,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 500,
            "temperature": 0.1
        }

        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{base_url}/chat/completions",
                headers=headers,
                json=payload
            )
            response.raise_for_status()
            data = response.json()

            choices = data.get("choices", [])
            if choices:
                return choices[0].get("message", {}).get("content", "")
            return ""

    def _score_tool_response(
        self,
        response: str,
        expected_tools: List[Dict],
        available_tools: List[Dict]
    ) -> tuple:
        """Score the model's tool selection response."""
        response_lower = response.lower()

        expected_names = [t.get("name", "").lower() for t in expected_tools]
        available_names = [t.get("name", "").lower() for t in available_tools]

        # Check how many expected tools were mentioned
        matched_tools = []
        for name in expected_names:
            if name and name in response_lower:
                matched_tools.append(name)

        # Calculate score based on matches
        if not expected_names:
            return 1.0, matched_tools

        score = len(matched_tools) / len(expected_names)
        return score, matched_tools
