"""Evaluation engines for different evaluation types."""
from app.evaluators.base_evaluator import (
    BaseEvaluator, EvalResult, EvalScore, EvalStatus, EvalProgress
)
from app.evaluators.model_evaluator import ModelEvaluator
from app.evaluators.agent_evaluator import AgentEvaluator
from app.evaluators.rag_evaluator import RAGEvaluator

# Registry of evaluators by eval_type
EVALUATOR_REGISTRY = {
    "model": ModelEvaluator,
    "agent": AgentEvaluator,
    "rag": RAGEvaluator,
}


def get_evaluator(eval_type: str) -> BaseEvaluator:
    """Get evaluator for evaluation type."""
    evaluator_class = EVALUATOR_REGISTRY.get(eval_type)
    if not evaluator_class:
        raise ValueError(f"Unknown eval_type: {eval_type}")
    return evaluator_class()


__all__ = [
    "BaseEvaluator",
    "EvalResult",
    "EvalScore",
    "EvalStatus",
    "EvalProgress",
    "ModelEvaluator",
    "AgentEvaluator",
    "RAGEvaluator",
    "get_evaluator",
    "EVALUATOR_REGISTRY",
]
