"""RAG evaluation engine using SemcoEval framework."""
import sys
import httpx
from pathlib import Path
from typing import List, Dict, Any

# Add semcoeval to path if not installed
SEMCOEVAL_PATH = Path(__file__).parent.parent.parent.parent / "semcoeval"
if SEMCOEVAL_PATH.exists() and str(SEMCOEVAL_PATH.parent) not in sys.path:
    sys.path.insert(0, str(SEMCOEVAL_PATH.parent))

from app.evaluators.base_evaluator import BaseEvaluator, EvalResult, EvalScore, EvalStatus


class RAGEvaluator(BaseEvaluator):
    """Evaluator for RAG evaluation datasets - faithfulness, hallucination, context relevance."""

    @property
    def eval_type(self) -> str:
        return "rag"

    def evaluate(
        self,
        dataset_content: dict,
        model_configs: list[dict],
        metrics_config: dict,
        **kwargs
    ) -> EvalResult:
        """Run RAG evaluation using SemcoEval framework."""
        try:
            from semcoeval.datasets.golden import GoldenDataset
        except ImportError as e:
            return EvalResult(
                evaluation_id=kwargs.get("evaluation_id", ""),
                status=EvalStatus.FAILED,
                error_message=f"SemcoEval not available: {e}"
            )

        evaluation_id = kwargs.get("evaluation_id", "unknown")
        scores = []

        try:
            questions = dataset_content.get("questions", [])
            total_questions = len(questions)

            if not questions:
                return EvalResult(
                    evaluation_id=evaluation_id,
                    status=EvalStatus.FAILED,
                    error_message="No questions in dataset"
                )

            # Convert RAG questions to samples with context
            samples = []
            for q in questions:
                input_data = q.get("input", {})
                expected = q.get("expected", {})

                # Extract contexts
                contexts = input_data.get("retrieved_contexts", [])
                context_texts = [c.get("content", "") for c in contexts if isinstance(c, dict)]

                sample = {
                    "input": input_data.get("question", ""),
                    "expected_output": expected.get("answer") if isinstance(expected, dict) else expected,
                    "retrieval_context": context_texts,
                    "context": context_texts,
                    "metadata": {
                        "sample_id": q.get("id", ""),
                        "supporting_context_ids": expected.get("supporting_context_ids", []) if isinstance(expected, dict) else [],
                        "forbidden_claims": expected.get("forbidden_claims", []) if isinstance(expected, dict) else [],
                        "type": "rag"
                    }
                }
                samples.append(sample)

            # Create dataset using the proper classmethod
            dataset = GoldenDataset.from_dict_list(samples, name="RAG Evaluation")

            # Evaluate each model
            for i, model_config in enumerate(model_configs):
                provider = model_config.get("provider", "openrouter")
                model_id = model_config.get("model_id", "")
                api_key = model_config.get("api_key")

                self._update_progress(
                    current=i,
                    total=len(model_configs),
                    message=f"Evaluating RAG {model_id}"
                )

                try:
                    # Evaluate using custom RAG scoring
                    test_results = []
                    passed = 0
                    failed = 0
                    total_score = 0.0
                    faithfulness_total = 0.0
                    hallucination_count = 0

                    for j, sample in enumerate(samples):
                        question = sample["input"]
                        expected_answer = sample["expected_output"] or ""
                        contexts = sample["retrieval_context"]
                        forbidden_claims = sample["metadata"].get("forbidden_claims", [])

                        # Create RAG prompt with context
                        rag_prompt = self._create_rag_prompt(question, contexts)

                        # Get LLM response
                        actual_output = self._call_llm(model_id, provider, api_key, rag_prompt)

                        # Score the response
                        answer_score = self._score_answer(actual_output, expected_answer)
                        faithfulness_score = self._score_faithfulness(actual_output, contexts)
                        has_hallucination = self._check_hallucination(actual_output, forbidden_claims)

                        if has_hallucination:
                            hallucination_count += 1

                        # Combined score
                        item_score = (answer_score * 0.5 + faithfulness_score * 0.5)
                        if has_hallucination:
                            item_score *= 0.5  # Penalize hallucinations

                        total_score += item_score
                        faithfulness_total += faithfulness_score

                        item_passed = item_score >= 0.5 and not has_hallucination
                        if item_passed:
                            passed += 1
                        else:
                            failed += 1

                        test_results.append({
                            "test_id": sample["metadata"].get("sample_id", f"test-{j}"),
                            "input": question[:100] + "..." if len(question) > 100 else question,
                            "output": actual_output[:200] + "..." if len(actual_output) > 200 else actual_output,
                            "expected": expected_answer,
                            "passed": item_passed,
                            "score": item_score,
                            "answer_score": answer_score,
                            "faithfulness_score": faithfulness_score,
                            "has_hallucination": has_hallucination
                        })

                    overall_score = total_score / len(samples) if samples else 0.0
                    avg_faithfulness = faithfulness_total / len(samples) if samples else 0.0
                    hallucination_rate = hallucination_count / len(samples) if samples else 0.0

                    score = EvalScore(
                        model_id=model_id,
                        provider=provider,
                        overall_score=overall_score,
                        metric_scores={
                            "accuracy": overall_score,
                            "faithfulness": avg_faithfulness,
                            "hallucination_rate": hallucination_rate
                        },
                        passed_tests=passed,
                        failed_tests=failed,
                        total_tests=len(samples),
                        details=test_results
                    )
                    scores.append(score)

                except Exception as model_error:
                    scores.append(EvalScore(
                        model_id=model_id,
                        provider=provider,
                        overall_score=0.0,
                        passed_tests=0,
                        failed_tests=total_questions,
                        total_tests=total_questions,
                        details=[{"error": str(model_error)}]
                    ))

            # Find top model
            top_model = None
            top_score = 0.0
            if scores:
                best = max(scores, key=lambda s: s.overall_score)
                top_model = f"{best.provider}:{best.model_id}"
                top_score = best.overall_score

            return EvalResult(
                evaluation_id=evaluation_id,
                status=EvalStatus.COMPLETED,
                scores=scores,
                top_model=top_model,
                top_score=top_score,
                summary={
                    "total_models": len(model_configs),
                    "total_questions": total_questions,
                    "eval_type": "rag"
                }
            )

        except Exception as e:
            return EvalResult(
                evaluation_id=evaluation_id,
                status=EvalStatus.FAILED,
                error_message=str(e)
            )

    def _create_rag_prompt(self, question: str, contexts: List[str]) -> str:
        """Create a RAG prompt with retrieved context."""
        context_str = "\n\n".join([f"Context {i+1}: {c}" for i, c in enumerate(contexts)])

        return f"""Based on the following context, answer the question.

{context_str}

Question: {question}

Answer based only on the information provided in the context above."""

    def _call_llm(
        self,
        model_id: str,
        provider: str,
        api_key: str,
        prompt: str,
        system_prompt: str = "You are a helpful assistant that answers questions based on provided context."
    ) -> str:
        """Call LLM API and return response."""
        base_url = "https://openrouter.ai/api/v1"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://semcoeval.com",
            "X-Title": "SemcoEval"
        }

        payload = {
            "model": model_id,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 500,
            "temperature": 0.1
        }

        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{base_url}/chat/completions",
                headers=headers,
                json=payload
            )
            response.raise_for_status()
            data = response.json()

            choices = data.get("choices", [])
            if choices:
                return choices[0].get("message", {}).get("content", "")
            return ""

    def _score_answer(self, response: str, expected_answer: str) -> float:
        """Score the answer against expected."""
        if not expected_answer:
            return 1.0

        response_lower = response.lower().strip()
        expected_lower = expected_answer.lower().strip()

        # Check if expected answer is contained
        if expected_lower in response_lower:
            return 1.0

        # Check word overlap
        expected_words = set(expected_lower.split())
        response_words = set(response_lower.split())
        if expected_words:
            overlap = len(expected_words & response_words) / len(expected_words)
            return overlap

        return 0.0

    def _score_faithfulness(self, response: str, contexts: List[str]) -> float:
        """Score how faithful the response is to the provided context."""
        if not contexts:
            return 1.0

        response_lower = response.lower()
        context_combined = " ".join(contexts).lower()

        # Extract key words from response
        response_words = set(response_lower.split())
        context_words = set(context_combined.split())

        # Check how many response words appear in context
        common_words = {"the", "a", "an", "is", "are", "was", "were", "in", "on", "at", "to", "for", "of", "and", "or"}
        meaningful_response_words = response_words - common_words
        meaningful_context_words = context_words - common_words

        if not meaningful_response_words:
            return 1.0

        grounded_words = meaningful_response_words & meaningful_context_words
        faithfulness = len(grounded_words) / len(meaningful_response_words)

        return min(faithfulness * 1.5, 1.0)  # Boost slightly, cap at 1.0

    def _check_hallucination(self, response: str, forbidden_claims: List[str]) -> bool:
        """Check if response contains forbidden claims (hallucinations)."""
        if not forbidden_claims:
            return False

        response_lower = response.lower()

        for claim in forbidden_claims:
            if claim.lower() in response_lower:
                return True

        return False
