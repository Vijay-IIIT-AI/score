"""Model evaluation engine using SemcoEval framework."""
import sys
from pathlib import Path

# Add semcoeval to path if not installed
SEMCOEVAL_PATH = Path(__file__).parent.parent.parent.parent / "semcoeval"
if SEMCOEVAL_PATH.exists() and str(SEMCOEVAL_PATH.parent) not in sys.path:
    sys.path.insert(0, str(SEMCOEVAL_PATH.parent))

import httpx
from app.evaluators.base_evaluator import BaseEvaluator, EvalResult, EvalScore, EvalStatus


class ModelEvaluator(BaseEvaluator):
    """Evaluator for model evaluation datasets using SemcoEval framework."""

    @property
    def eval_type(self) -> str:
        return "model"

    def evaluate(
        self,
        dataset_content: dict,
        model_configs: list[dict],
        metrics_config: dict,
        **kwargs
    ) -> EvalResult:
        """Run model evaluation using SemcoEval."""
        try:
            from semcoeval import SemcoEvaluator
            from semcoeval.core.evaluator import EvaluationConfig
            from semcoeval.datasets.golden import GoldenDataset
        except ImportError as e:
            return EvalResult(
                evaluation_id=kwargs.get("evaluation_id", ""),
                status=EvalStatus.FAILED,
                error_message=f"SemcoEval not available: {e}"
            )

        evaluation_id = kwargs.get("evaluation_id", "unknown")
        scores = []

        try:
            evaluator = SemcoEvaluator()

            questions = dataset_content.get("questions", [])
            total_questions = len(questions)

            if not questions:
                return EvalResult(
                    evaluation_id=evaluation_id,
                    status=EvalStatus.FAILED,
                    error_message="No questions in dataset"
                )

            # Convert model questions to samples
            samples = []
            for q in questions:
                input_data = q.get("input", {})
                expected = q.get("expected", {})

                # Handle different input formats
                if isinstance(input_data, dict):
                    prompt = input_data.get("prompt", input_data.get("question", ""))
                    system_prompt = input_data.get("system_prompt", "You are a helpful assistant.")
                else:
                    prompt = str(input_data)
                    system_prompt = "You are a helpful assistant."

                # Handle different expected formats
                if isinstance(expected, str):
                    expected_answer = expected
                    keywords = [expected]
                elif isinstance(expected, dict):
                    expected_answer = expected.get("answer", "")
                    keywords = expected.get("keywords_required", [expected_answer] if expected_answer else [])
                else:
                    expected_answer = ""
                    keywords = []

                sample = {
                    "input": prompt,
                    "expected_output": expected_answer,
                    "context": None,
                    "retrieval_context": None,
                    "metadata": {
                        "sample_id": q.get("id", ""),
                        "system_prompt": system_prompt,
                        "keywords_required": keywords,
                        "type": "model"
                    }
                }
                samples.append(sample)

            # Create dataset using the proper classmethod
            dataset = GoldenDataset.from_dict_list(samples, name="Model Evaluation")

            # Model-specific metrics
            default_metrics = ["AnswerRelevancyMetric"]
            metrics = metrics_config.get("metrics", default_metrics)

            # Evaluate each model
            for i, model_config in enumerate(model_configs):
                provider = model_config.get("provider", "openrouter")
                model_id = model_config.get("model_id", "")
                api_key = model_config.get("api_key")

                self._update_progress(
                    current=i,
                    total=len(model_configs),
                    message=f"Evaluating {model_id}"
                )

                try:
                    # Connect provider with API key
                    if api_key:
                        evaluator.connect_provider(provider, api_key=api_key)

                    config = EvaluationConfig(
                        provider=provider,
                        model_id=model_id,
                        metrics=metrics,
                        verbose=False
                    )

                    # Evaluate using custom scoring (keyword/exact match)
                    # DeepEval metrics require another LLM for judging, so we use direct scoring
                    test_results = []
                    passed = 0
                    failed = 0
                    total_score = 0.0

                    for j, sample in enumerate(samples):
                        prompt = sample["input"]
                        expected = sample["expected_output"] or ""
                        keywords = sample["metadata"].get("keywords_required", [])

                        # Get LLM response
                        actual_output = self._call_llm(model_id, provider, api_key, prompt)

                        # Score response
                        item_score, item_passed = self._score_response(actual_output, expected, keywords)
                        total_score += item_score

                        if item_passed:
                            passed += 1
                        else:
                            failed += 1

                        test_results.append({
                            "test_id": sample["metadata"].get("sample_id", f"test-{j}"),
                            "input": prompt[:100] + "..." if len(prompt) > 100 else prompt,
                            "output": actual_output[:200] + "..." if len(actual_output) > 200 else actual_output,
                            "expected": expected,
                            "passed": item_passed,
                            "score": item_score
                        })

                    overall_score = total_score / len(samples) if samples else 0.0

                    score = EvalScore(
                        model_id=model_id,
                        provider=provider,
                        overall_score=overall_score,
                        metric_scores={"accuracy": overall_score},
                        passed_tests=passed,
                        failed_tests=failed,
                        total_tests=len(samples),
                        details=test_results
                    )
                    scores.append(score)

                except Exception as model_error:
                    scores.append(EvalScore(
                        model_id=model_id,
                        provider=provider,
                        overall_score=0.0,
                        passed_tests=0,
                        failed_tests=total_questions,
                        total_tests=total_questions,
                        details=[{"error": str(model_error)}]
                    ))

            # Find top model
            top_model = None
            top_score = 0.0
            if scores:
                best = max(scores, key=lambda s: s.overall_score)
                top_model = f"{best.provider}:{best.model_id}"
                top_score = best.overall_score

            return EvalResult(
                evaluation_id=evaluation_id,
                status=EvalStatus.COMPLETED,
                scores=scores,
                top_model=top_model,
                top_score=top_score,
                summary={
                    "total_models": len(model_configs),
                    "total_questions": total_questions,
                    "eval_type": "model",
                    "metrics_used": metrics
                }
            )

        except Exception as e:
            return EvalResult(
                evaluation_id=evaluation_id,
                status=EvalStatus.FAILED,
                error_message=str(e)
            )

    def _call_llm(
        self,
        model_id: str,
        provider: str,
        api_key: str,
        prompt: str,
        system_prompt: str = "You are a helpful assistant."
    ) -> str:
        """Call LLM API and return response."""
        # Use OpenRouter for all models (it's a unified gateway)
        base_url = "https://openrouter.ai/api/v1"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://semcoeval.com",
            "X-Title": "SemcoEval"
        }

        payload = {
            "model": model_id,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 500,
            "temperature": 0.1
        }

        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{base_url}/chat/completions",
                headers=headers,
                json=payload
            )
            response.raise_for_status()
            data = response.json()

            choices = data.get("choices", [])
            if choices:
                return choices[0].get("message", {}).get("content", "")
            return ""

    def _score_response(
        self,
        response: str,
        expected_answer: str,
        keywords: list
    ) -> tuple:
        """
        Score a response against expected answer using SemcoEval scoring logic.

        Returns (score, passed) where score is 0.0-1.0
        """
        from typing import List

        response_lower = response.lower().strip()
        expected_lower = expected_answer.lower().strip()

        # Check exact match
        if expected_lower and expected_lower in response_lower:
            return 1.0, True

        # Check keywords
        if keywords:
            matched = sum(1 for kw in keywords if kw.lower() in response_lower)
            score = matched / len(keywords)
            return score, score >= 0.5

        # Fuzzy match - check if significant overlap
        if expected_lower:
            expected_words = set(expected_lower.split())
            response_words = set(response_lower.split())
            if expected_words:
                overlap = len(expected_words & response_words) / len(expected_words)
                return overlap, overlap >= 0.5

        return 0.0, False
