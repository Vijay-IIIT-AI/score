"""Dependencies for FastAPI routes."""
from typing import Optional
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.config import settings
from app.database import async_session_maker
from app.models.user import User
from app.services.auth_service import verify_jwt_token

security = HTTPBearer(auto_error=False)


async def get_db():
    """Database session dependency."""
    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_db)
) -> User:
    """Get current user from JWT token."""

    # Dev mode bypass
    if settings.sso_dev_mode and not credentials:
        result = await db.execute(
            select(User).where(User.sso_id == settings.sso_dev_user_id)
        )
        user = result.scalar_one_or_none()
        if not user:
            user = User(
                sso_id=settings.sso_dev_user_id,
                email=settings.sso_dev_user_email,
                name="Dev User"
            )
            db.add(user)
            await db.flush()
        return user

    # Require token
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    # Verify JWT
    payload = verify_jwt_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

    user_id = int(payload.get("sub"))

    # Get user
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

    return user


async def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_db)
) -> Optional[User]:
    """Get user if authenticated, None otherwise."""
    if not credentials and not settings.sso_dev_mode:
        return None
    try:
        return await get_current_user(credentials, db)
    except HTTPException:
        return None
