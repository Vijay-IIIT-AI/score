"""
AI Model entity representing models from various providers.
"""
from datetime import datetime
from typing import TYPE_CHECKING
from enum import Enum as PyEnum

from sqlalchemy import String, DateTime, ForeignKey, Text, Float, Enum, JSON, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.database import Base

if TYPE_CHECKING:
    from app.models.provider import Provider
    from app.models.evaluation import EvaluationResult


class ModelCategory(str, PyEnum):
    """Model category for evaluation type recommendations."""
    MODEL = "model"
    AGENT = "agent"
    RAG = "rag"


class AIModel(Base):
    """AI Model from a provider."""

    __tablename__ = "ai_models"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    provider_id: Mapped[str] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    version: Mapped[str | None] = mapped_column(String(100), nullable=True)
    capabilities: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    context_window: Mapped[int | None] = mapped_column(Integer, nullable=True)
    input_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    output_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    speed_rating: Mapped[str | None] = mapped_column(String(100), nullable=True)
    accuracy_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    agent_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    category: Mapped[ModelCategory] = mapped_column(
        Enum(ModelCategory), default=ModelCategory.MODEL, nullable=False
    )
    selected_by_default: Mapped[bool] = mapped_column(default=False, nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    provider: Mapped["Provider"] = relationship("Provider", back_populates="models")
    evaluation_results: Mapped[list["EvaluationResult"]] = relationship(
        "EvaluationResult", back_populates="model", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<AIModel(id={self.id}, name={self.name}, provider={self.provider_id})>"
