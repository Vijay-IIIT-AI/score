"""
Dataset model for evaluation test suites.
"""
from datetime import datetime
from typing import TYPE_CHECKING
from enum import Enum as PyEnum

from sqlalchemy import String, DateTime, ForeignKey, Text, Integer, Enum, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.database import Base

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.evaluation import Evaluation


class EvalType(str, PyEnum):
    """Evaluation type."""
    MODEL = "model"
    AGENT = "agent"
    RAG = "rag"


class DatasetCategory(str, PyEnum):
    """Dataset category."""
    GENERAL = "General"
    CODING = "Coding"
    FINANCE = "Finance"
    HEALTHCARE = "Healthcare"
    RAG = "RAG"
    AGENTS = "Agents"
    CUSTOM = "Custom"


class Dataset(Base):
    """Dataset for evaluations (test suites)."""

    __tablename__ = "datasets"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    category: Mapped[DatasetCategory] = mapped_column(
        Enum(DatasetCategory), default=DatasetCategory.GENERAL, nullable=False
    )
    eval_type: Mapped[EvalType] = mapped_column(
        Enum(EvalType), default=EvalType.MODEL, nullable=False
    )
    question_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    file_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    schema_version: Mapped[str] = mapped_column(String(20), default="1.0", nullable=False)
    language: Mapped[str | None] = mapped_column(String(100), nullable=True)
    task: Mapped[str | None] = mapped_column(String(255), nullable=True)
    difficulty: Mapped[str | None] = mapped_column(String(50), nullable=True)
    version: Mapped[str | None] = mapped_column(String(50), nullable=True)
    maintainer: Mapped[str | None] = mapped_column(String(255), nullable=True)
    recommended_for: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    featured: Mapped[bool] = mapped_column(default=False, nullable=False)
    is_official: Mapped[bool] = mapped_column(default=False, nullable=False)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    created_by: Mapped["User | None"] = relationship("User", back_populates="datasets")
    evaluations: Mapped[list["Evaluation"]] = relationship(
        "Evaluation", back_populates="dataset", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Dataset(id={self.id}, name={self.name}, eval_type={self.eval_type})>"
