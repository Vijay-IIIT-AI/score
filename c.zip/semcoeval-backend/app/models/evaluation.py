"""
Evaluation and results models.
"""
from datetime import datetime
from typing import TYPE_CHECKING
from enum import Enum as PyEnum

from sqlalchemy import String, DateTime, ForeignKey, Text, Integer, Enum, JSON, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.database import Base

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.dataset import Dataset
    from app.models.ai_model import AIModel
    from app.models.report import Report


class EvaluationStatus(str, PyEnum):
    """Evaluation run status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Evaluation(Base):
    """Evaluation run."""

    __tablename__ = "evaluations"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    eval_type: Mapped[str] = mapped_column(String(50), nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    status: Mapped[EvaluationStatus] = mapped_column(
        Enum(EvaluationStatus), default=EvaluationStatus.PENDING, nullable=False
    )
    progress: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_questions: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    metrics_config: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    model_ids: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    subgroup: Mapped[str | None] = mapped_column(String(100), nullable=True)  # Dataset subgroup filter
    top_model: Mapped[str | None] = mapped_column(String(255), nullable=True)
    top_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    avg_response_time: Mapped[float | None] = mapped_column(Float, nullable=True)
    cost_spent: Mapped[float | None] = mapped_column(Float, nullable=True)
    celery_task_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="evaluations")
    dataset: Mapped["Dataset"] = relationship("Dataset", back_populates="evaluations")
    results: Mapped[list["EvaluationResult"]] = relationship(
        "EvaluationResult", back_populates="evaluation", cascade="all, delete-orphan"
    )
    reports: Mapped[list["Report"]] = relationship(
        "Report", back_populates="evaluation", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Evaluation(id={self.id}, name={self.name}, status={self.status})>"


class EvaluationResult(Base):
    """Results for a specific model in an evaluation."""

    __tablename__ = "evaluation_results"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    evaluation_id: Mapped[str] = mapped_column(ForeignKey("evaluations.id", ondelete="CASCADE"), nullable=False)
    model_id: Mapped[str] = mapped_column(ForeignKey("ai_models.id", ondelete="CASCADE"), nullable=False)
    rank: Mapped[int] = mapped_column(Integer, nullable=False)
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    accuracy: Mapped[float | None] = mapped_column(Float, nullable=True)
    response_time: Mapped[float | None] = mapped_column(Float, nullable=True)
    cost: Mapped[float | None] = mapped_column(Float, nullable=True)
    passed_tests: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failed_tests: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_tests: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    scores: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    details: Mapped[list] = mapped_column(JSON, default=list, nullable=False)  # Per-question results
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    evaluation: Mapped["Evaluation"] = relationship("Evaluation", back_populates="results")
    model: Mapped["AIModel"] = relationship("AIModel", back_populates="evaluation_results")

    def __repr__(self) -> str:
        return f"<EvaluationResult(evaluation_id={self.evaluation_id}, model_id={self.model_id}, rank={self.rank})>"
