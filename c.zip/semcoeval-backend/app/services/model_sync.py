"""Service to sync models from providers."""
import httpx
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete

from app.models.ai_model import AIModel, ModelCategory


async def sync_openrouter_models(
    db: AsyncSession,
    api_key: str,
    provider_id: str = "openrouter"
) -> Dict[str, Any]:
    """
    Fetch and sync models from OpenRouter.

    Returns count of models synced and any errors.
    """
    # Fetch models from OpenRouter API
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(
            "https://openrouter.ai/api/v1/models",
            headers={"Authorization": f"Bearer {api_key}"}
        )
        response.raise_for_status()
        data = response.json()

    models_data = data.get("data", [])
    synced_count = 0
    errors = []

    for m in models_data:
        try:
            model_id = m.get("id", "")
            if not model_id:
                continue

            # Extract pricing
            pricing = m.get("pricing", {})
            input_price = float(pricing.get("prompt", 0)) * 1000000  # Convert to per million
            output_price = float(pricing.get("completion", 0)) * 1000000

            # Extract capabilities
            capabilities = []
            architecture = m.get("architecture", {})

            # Check for vision support
            if architecture.get("modality") == "multimodal" or "vision" in model_id.lower():
                capabilities.append("vision")

            # Check for tool/function calling support
            if m.get("tool_support") or "instruct" in model_id.lower():
                capabilities.append("tools")

            # Get context length
            context_length = m.get("context_length", 4096)

            # Determine category based on capabilities
            category = ModelCategory.MODEL
            if "agent" in model_id.lower() or m.get("tool_support"):
                category = ModelCategory.AGENT

            # Check if model already exists
            result = await db.execute(
                select(AIModel).where(AIModel.id == model_id)
            )
            existing = result.scalar_one_or_none()

            if existing:
                # Update existing model
                existing.name = m.get("name", model_id)
                existing.context_window = context_length
                existing.input_price = input_price
                existing.output_price = output_price
                existing.capabilities = capabilities
                existing.description = m.get("description", "")
            else:
                # Create new model
                new_model = AIModel(
                    id=model_id,
                    name=m.get("name", model_id),
                    provider_id=provider_id,
                    category=category,
                    capabilities=capabilities,
                    context_window=context_length,
                    input_price=input_price,
                    output_price=output_price,
                    description=m.get("description", ""),
                    selected_by_default=False,
                    is_active=True
                )
                db.add(new_model)

            synced_count += 1

        except Exception as e:
            errors.append(f"Error syncing {m.get('id', 'unknown')}: {str(e)}")

    await db.flush()

    return {
        "synced": synced_count,
        "total_available": len(models_data),
        "errors": errors
    }


async def sync_provider_models(
    db: AsyncSession,
    provider_id: str,
    api_key: str
) -> Dict[str, Any]:
    """
    Sync models from a provider based on provider type.
    """
    if provider_id == "openrouter":
        return await sync_openrouter_models(db, api_key, provider_id)

    # Add other providers as needed
    # elif provider_id == "openai":
    #     return await sync_openai_models(db, api_key)
    # elif provider_id == "anthropic":
    #     return await sync_anthropic_models(db, api_key)

    return {"synced": 0, "error": f"Provider {provider_id} does not support auto-sync"}
