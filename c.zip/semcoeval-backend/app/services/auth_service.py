"""Auth service - AES decode + JWT generation."""
import base64
import json
from datetime import datetime, timedelta
from typing import Optional
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from jose import jwt

from app.config import settings

# JWT settings from config
JWT_SECRET = settings.jwt_secret
JWT_ALGORITHM = settings.jwt_algorithm
JWT_EXPIRE_HOURS = settings.jwt_expire_hours


def decode_user_info(aes_key: str, encrypted_info: str) -> Optional[dict]:
    """Decode AES encrypted user info."""
    try:
        # Decode base64
        key = base64.b64decode(aes_key)
        data = base64.b64decode(encrypted_info)

        # Extract IV (first 16 bytes) and ciphertext
        iv = data[:16]
        ciphertext = data[16:]

        # Decrypt
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted = decryptor.update(ciphertext) + decryptor.finalize()

        # Remove padding
        padding_len = decrypted[-1]
        decrypted = decrypted[:-padding_len]

        # Parse JSON
        return json.loads(decrypted.decode('utf-8'))
    except Exception:
        return None


def create_jwt_token(user_id: int, email: str, name: str) -> str:
    """Create JWT token for user."""
    expire = datetime.utcnow() + timedelta(hours=JWT_EXPIRE_HOURS)
    payload = {
        "sub": str(user_id),
        "email": email,
        "name": name,
        "exp": expire,
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def verify_jwt_token(token: str) -> Optional[dict]:
    """Verify and decode JWT token."""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except Exception:
        return None
