"""
LLM-powered report analysis service.

This service generates intelligent analysis for evaluation reports using
a configurable LLM. The LLM configuration is managed by the system admin.
"""
import httpx
import json
from typing import Optional
from dataclasses import dataclass

from app.config import settings


@dataclass
class LLMConfig:
    """LLM configuration for report generation."""
    provider: str = "openrouter"
    model_id: str = "google/gemini-flash-1.5"  # Cost-effective default
    api_key: Optional[str] = None
    base_url: str = "https://openrouter.ai/api/v1"
    max_tokens: int = 1000
    temperature: float = 0.3  # Lower for more consistent analysis


class ReportLLMService:
    """Service for generating LLM-powered report analysis."""

    def __init__(self, config: Optional[LLMConfig] = None):
        """
        Initialize the service with LLM configuration.

        Args:
            config: LLM configuration. If None, uses system defaults from settings.
        """
        self.config = config or self._load_system_config()

    def _load_system_config(self) -> LLMConfig:
        """Load LLM configuration from system settings."""
        return LLMConfig(
            provider=getattr(settings, 'REPORT_LLM_PROVIDER', 'openrouter'),
            model_id=getattr(settings, 'REPORT_LLM_MODEL', 'google/gemini-flash-1.5'),
            api_key=getattr(settings, 'REPORT_LLM_API_KEY', None) or getattr(settings, 'OPENROUTER_API_KEY', None),
            base_url=getattr(settings, 'REPORT_LLM_BASE_URL', 'https://openrouter.ai/api/v1'),
            max_tokens=getattr(settings, 'REPORT_LLM_MAX_TOKENS', 1000),
            temperature=getattr(settings, 'REPORT_LLM_TEMPERATURE', 0.3),
        )

    def _call_llm(self, system_prompt: str, user_prompt: str) -> str:
        """
        Call the configured LLM and return the response.

        Args:
            system_prompt: System instructions for the LLM
            user_prompt: User message with the data to analyze

        Returns:
            LLM response text
        """
        if not self.config.api_key:
            return "[LLM analysis unavailable - API key not configured]"

        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://semcoeval.com",
            "X-Title": "SemcoEval Report Generator"
        }

        payload = {
            "model": self.config.model_id,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "max_tokens": self.config.max_tokens,
            "temperature": self.config.temperature
        }

        try:
            with httpx.Client(timeout=60.0) as client:
                response = client.post(
                    f"{self.config.base_url}/chat/completions",
                    headers=headers,
                    json=payload
                )
                response.raise_for_status()
                data = response.json()

                choices = data.get("choices", [])
                if choices:
                    return choices[0].get("message", {}).get("content", "")
                return ""
        except Exception as e:
            return f"[Analysis generation failed: {str(e)[:100]}]"

    def generate_executive_summary(
        self,
        eval_type: str,
        total_questions: int,
        top_score: float,
        pass_rate: float,
        model_results: list
    ) -> str:
        """
        Generate an AI-powered executive summary.

        Args:
            eval_type: Type of evaluation (model, agent, rag)
            total_questions: Number of questions in evaluation
            top_score: Best score achieved
            pass_rate: Percentage of tests passed
            model_results: List of model results with scores

        Returns:
            Generated executive summary text
        """
        system_prompt = """You are an AI evaluation expert writing executive summaries for technical reports.
Write concise, professional summaries that highlight key findings.
Use clear language suitable for both technical and non-technical readers.
Keep the summary to 2-3 paragraphs maximum.
Do not use markdown formatting - use plain text only."""

        eval_type_names = {
            "model": "Model Capability Evaluation",
            "agent": "AI Agent Tool-Use Evaluation",
            "rag": "RAG (Retrieval-Augmented Generation) Evaluation"
        }

        user_prompt = f"""Generate an executive summary for this {eval_type_names.get(eval_type, eval_type)} report:

Evaluation Type: {eval_type}
Total Test Cases: {total_questions}
Best Overall Score: {top_score:.1%}
Pass Rate: {pass_rate:.1f}%
Number of Models Tested: {len(model_results)}

Model Results:
{json.dumps([{
    'model': r.get('model_id', 'Unknown')[:50],
    'score': r.get('score', 0),
    'passed': r.get('passed_tests', 0),
    'failed': r.get('failed_tests', 0)
} for r in model_results], indent=2)}

Write a professional executive summary covering:
1. What was evaluated and why it matters
2. Key performance highlights
3. Overall assessment of the results"""

        return self._call_llm(system_prompt, user_prompt)

    def generate_methodology_explanation(self, eval_type: str) -> str:
        """
        Generate an AI-powered methodology explanation.

        Args:
            eval_type: Type of evaluation

        Returns:
            Generated methodology explanation
        """
        system_prompt = """You are a technical writer explaining AI evaluation methodologies.
Write clear, educational explanations that help readers understand the evaluation process.
Use numbered steps and bullet points for clarity.
Keep explanations concise but comprehensive.
Do not use markdown formatting - use plain text only."""

        prompts = {
            "model": """Explain the methodology for a Model Capability Evaluation that tests:
- Response accuracy against expected answers
- Keyword matching for required terms
- Semantic similarity analysis
- Overall scoring aggregation

Focus on how the evaluation ensures fair and accurate assessment of model capabilities.""",

            "agent": """Explain the methodology for an AI Agent Tool-Use Evaluation that tests:
- Tool selection accuracy (choosing the right tool for the task)
- Parameter identification (recognizing required inputs)
- Multi-tool workflow sequencing
- Overall tool-use competency scoring

Focus on how this evaluates an AI's ability to correctly use external tools.""",

            "rag": """Explain the methodology for a RAG (Retrieval-Augmented Generation) Evaluation that tests:
- Answer accuracy against ground truth
- Faithfulness to provided context documents
- Hallucination detection (claims not in context)
- Context utilization effectiveness

Focus on how this ensures AI responses are grounded in source material."""
        }

        user_prompt = prompts.get(eval_type, f"Explain the methodology for a {eval_type} evaluation.")

        return self._call_llm(system_prompt, user_prompt)

    def analyze_question_results(
        self,
        eval_type: str,
        question_results: list,
        model_id: str
    ) -> str:
        """
        Generate AI analysis of per-question results.

        Args:
            eval_type: Type of evaluation
            question_results: List of question results with scores
            model_id: ID of the model being analyzed

        Returns:
            Generated analysis of question performance
        """
        system_prompt = """You are an AI evaluation analyst reviewing test results.
Identify patterns in successes and failures.
Provide actionable insights for improvement.
Be specific about what worked well and what didn't.
Keep analysis to 2-3 paragraphs.
Do not use markdown formatting - use plain text only."""

        # Summarize results for the prompt
        passed = [q for q in question_results if q.get("passed")]
        failed = [q for q in question_results if not q.get("passed")]

        failed_summary = []
        for q in failed[:5]:  # Limit to 5 failed questions
            failed_summary.append({
                "question": q.get("input", "")[:100],
                "expected": str(q.get("expected", ""))[:100],
                "got": q.get("output", "")[:100],
                "score": q.get("score", 0)
            })

        user_prompt = f"""Analyze these {eval_type} evaluation results for model: {model_id[:50]}

Total Questions: {len(question_results)}
Passed: {len(passed)}
Failed: {len(failed)}

Failed Question Examples:
{json.dumps(failed_summary, indent=2) if failed_summary else "None - all questions passed!"}

Provide analysis covering:
1. Overall performance patterns
2. Common failure modes (if any)
3. Specific recommendations for improvement"""

        return self._call_llm(system_prompt, user_prompt)

    def generate_recommendations(
        self,
        eval_type: str,
        top_score: float,
        model_results: list,
        question_results: list
    ) -> str:
        """
        Generate AI-powered recommendations based on results.

        Args:
            eval_type: Type of evaluation
            top_score: Best score achieved
            model_results: List of model results
            question_results: All question results

        Returns:
            Generated recommendations
        """
        system_prompt = """You are an AI evaluation consultant providing actionable recommendations.
Based on evaluation results, provide specific, prioritized recommendations.
Focus on practical improvements that can be implemented.
Structure recommendations as a numbered list with clear action items.
Keep to 4-6 key recommendations.
Do not use markdown formatting - use plain text only."""

        # Identify patterns
        all_failed = []
        for r in model_results:
            details = r.get("details", [])
            for q in details:
                if not q.get("passed"):
                    all_failed.append(q)

        user_prompt = f"""Generate recommendations for this {eval_type} evaluation:

Best Score: {top_score:.1%}
Models Tested: {len(model_results)}
Total Questions: {len(question_results) if question_results else 'N/A'}
Total Failures: {len(all_failed)}

Evaluation Type Specifics:
- Model eval: Focus on response accuracy and prompt engineering
- Agent eval: Focus on tool selection and parameter handling
- RAG eval: Focus on context grounding and hallucination reduction

Provide prioritized recommendations for:
1. Immediate improvements to increase scores
2. Long-term strategies for sustained performance
3. Testing and monitoring suggestions"""

        return self._call_llm(system_prompt, user_prompt)

    def generate_comparison_analysis(
        self,
        models: list,
        metrics: dict
    ) -> str:
        """
        Generate AI analysis comparing multiple models.

        Args:
            models: List of model results to compare
            metrics: Dictionary of metric breakdowns

        Returns:
            Generated comparison analysis
        """
        system_prompt = """You are an AI evaluation analyst comparing model performance.
Provide objective, data-driven comparisons.
Highlight strengths and weaknesses of each model.
Recommend best model for different use cases.
Keep analysis professional and balanced.
Do not use markdown formatting - use plain text only."""

        model_summary = []
        for m in models[:10]:  # Limit to 10 models
            model_summary.append({
                "model": m.get("model_id", "Unknown")[:40],
                "score": m.get("score", 0),
                "accuracy": m.get("accuracy", 0),
                "passed": m.get("passed_tests", 0),
                "failed": m.get("failed_tests", 0)
            })

        user_prompt = f"""Compare these AI models based on evaluation results:

Models:
{json.dumps(model_summary, indent=2)}

Metrics Breakdown:
{json.dumps(metrics, indent=2)}

Provide analysis covering:
1. Overall ranking justification
2. Strengths of top performers
3. Trade-offs between models
4. Recommendations for model selection based on use case"""

        return self._call_llm(system_prompt, user_prompt)


# Singleton instance for easy access
_report_llm_service = None

def get_report_llm_service() -> ReportLLMService:
    """Get the singleton ReportLLMService instance."""
    global _report_llm_service
    if _report_llm_service is None:
        _report_llm_service = ReportLLMService()
    return _report_llm_service
