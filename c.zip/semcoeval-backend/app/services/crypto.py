"""Cryptographic utilities for API key encryption."""
import base64
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from app.config import settings


def _get_fernet() -> Fernet:
    """Derive Fernet key from encryption_key setting."""
    key = settings.encryption_key.encode()
    # Use PBKDF2 to derive a proper 32-byte key
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"semcoeval-salt-v1",  # Fixed salt for deterministic key derivation
        iterations=100000,
    )
    derived_key = base64.urlsafe_b64encode(kdf.derive(key))
    return Fernet(derived_key)


def encrypt_api_key(api_key: str) -> str:
    """Encrypt API key for storage."""
    if not api_key:
        return ""
    fernet = _get_fernet()
    encrypted = fernet.encrypt(api_key.encode())
    return base64.urlsafe_b64encode(encrypted).decode()


def decrypt_api_key(encrypted_key: str) -> str:
    """Decrypt API key from storage."""
    if not encrypted_key:
        return ""
    try:
        fernet = _get_fernet()
        encrypted = base64.urlsafe_b64decode(encrypted_key.encode())
        decrypted = fernet.decrypt(encrypted)
        return decrypted.decode()
    except Exception:
        # Return empty on decryption failure (corrupted or invalid key)
        return ""
