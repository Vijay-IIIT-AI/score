"""Admin API routes for system configuration."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from app.dependencies import get_current_user
from app.models.user import User, UserRole

router = APIRouter(prefix="/admin", tags=["admin"])


class ReportLLMConfig(BaseModel):
    """Report LLM configuration schema."""
    enabled: bool = True
    provider: str = "openrouter"
    model_id: str = "google/gemini-flash-1.5"
    api_key: Optional[str] = None  # Optional - will use system default if not provided
    base_url: str = "https://openrouter.ai/api/v1"
    max_tokens: int = 1000
    temperature: float = 0.3


class ReportLLMConfigResponse(BaseModel):
    """Response schema (hides sensitive API key)."""
    enabled: bool
    provider: str
    model_id: str
    api_key_configured: bool
    base_url: str
    max_tokens: int
    temperature: float


# In-memory config storage (in production, use database or env vars)
_llm_config: Optional[ReportLLMConfig] = None


def require_admin(user: User = Depends(get_current_user)) -> User:
    """Require admin role for access."""
    if user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


@router.get("/report-llm-config", response_model=ReportLLMConfigResponse)
async def get_report_llm_config(user: User = Depends(get_current_user)):
    """
    Get current Report LLM configuration.

    Returns the current LLM settings used for AI-powered report analysis.
    API key is masked for security.
    """
    from app.config import settings

    global _llm_config

    if _llm_config:
        return ReportLLMConfigResponse(
            enabled=_llm_config.enabled,
            provider=_llm_config.provider,
            model_id=_llm_config.model_id,
            api_key_configured=bool(_llm_config.api_key),
            base_url=_llm_config.base_url,
            max_tokens=_llm_config.max_tokens,
            temperature=_llm_config.temperature
        )

    # Return from settings
    return ReportLLMConfigResponse(
        enabled=getattr(settings, 'report_llm_enabled', False),
        provider=getattr(settings, 'report_llm_provider', 'openrouter'),
        model_id=getattr(settings, 'report_llm_model', 'google/gemini-flash-1.5'),
        api_key_configured=bool(getattr(settings, 'report_llm_api_key', '')),
        base_url=getattr(settings, 'report_llm_base_url', 'https://openrouter.ai/api/v1'),
        max_tokens=getattr(settings, 'report_llm_max_tokens', 1000),
        temperature=getattr(settings, 'report_llm_temperature', 0.3)
    )


@router.put("/report-llm-config", response_model=ReportLLMConfigResponse)
async def update_report_llm_config(
    config: ReportLLMConfig,
    user: User = Depends(require_admin)
):
    """
    Update Report LLM configuration.

    **Admin only.** Configure the LLM used for generating AI-powered analysis
    in evaluation reports.

    Parameters:
    - **enabled**: Enable/disable AI analysis in reports
    - **provider**: LLM provider (e.g., "openrouter", "openai")
    - **model_id**: Model to use (e.g., "google/gemini-flash-1.5")
    - **api_key**: API key for the provider (optional, uses system default if not set)
    - **base_url**: API base URL
    - **max_tokens**: Maximum tokens for analysis responses
    - **temperature**: LLM temperature (0.0-1.0, lower = more consistent)
    """
    global _llm_config
    _llm_config = config

    # Update the service singleton
    from app.services.report_llm_service import _report_llm_service, LLMConfig, ReportLLMService
    import app.services.report_llm_service as llm_module

    llm_module._report_llm_service = ReportLLMService(LLMConfig(
        provider=config.provider,
        model_id=config.model_id,
        api_key=config.api_key,
        base_url=config.base_url,
        max_tokens=config.max_tokens,
        temperature=config.temperature
    ))

    return ReportLLMConfigResponse(
        enabled=config.enabled,
        provider=config.provider,
        model_id=config.model_id,
        api_key_configured=bool(config.api_key),
        base_url=config.base_url,
        max_tokens=config.max_tokens,
        temperature=config.temperature
    )


@router.post("/report-llm-config/test")
async def test_report_llm(user: User = Depends(get_current_user)):
    """
    Test the Report LLM configuration.

    Sends a test prompt to verify the LLM is working correctly.
    Returns the LLM response or error message.
    """
    from app.services.report_llm_service import get_report_llm_service

    try:
        service = get_report_llm_service()
        test_response = service._call_llm(
            system_prompt="You are a helpful assistant.",
            user_prompt="Say 'LLM configuration test successful!' in exactly those words."
        )

        if "test successful" in test_response.lower() or len(test_response) > 10:
            return {
                "status": "success",
                "message": "LLM is configured and working",
                "response": test_response[:200]
            }
        else:
            return {
                "status": "warning",
                "message": "LLM responded but output may be unexpected",
                "response": test_response[:200]
            }
    except Exception as e:
        return {
            "status": "error",
            "message": f"LLM test failed: {str(e)}"
        }


@router.get("/available-models")
async def get_available_llm_models(user: User = Depends(get_current_user)):
    """
    Get list of recommended LLM models for report generation.

    Returns models that are good for analysis tasks with cost/quality trade-offs.
    """
    return {
        "recommended_models": [
            {
                "id": "google/gemini-flash-1.5",
                "name": "Gemini Flash 1.5",
                "provider": "openrouter",
                "description": "Fast and cost-effective, good for most analysis tasks",
                "cost_tier": "low",
                "recommended": True
            },
            {
                "id": "google/gemini-pro-1.5",
                "name": "Gemini Pro 1.5",
                "provider": "openrouter",
                "description": "Higher quality analysis, moderate cost",
                "cost_tier": "medium",
                "recommended": False
            },
            {
                "id": "anthropic/claude-3-haiku",
                "name": "Claude 3 Haiku",
                "provider": "openrouter",
                "description": "Fast and affordable with good reasoning",
                "cost_tier": "low",
                "recommended": True
            },
            {
                "id": "anthropic/claude-3-sonnet",
                "name": "Claude 3 Sonnet",
                "provider": "openrouter",
                "description": "Excellent analysis quality, higher cost",
                "cost_tier": "high",
                "recommended": False
            },
            {
                "id": "openai/gpt-4o-mini",
                "name": "GPT-4o Mini",
                "provider": "openrouter",
                "description": "Good balance of quality and cost",
                "cost_tier": "medium",
                "recommended": True
            },
            {
                "id": "openai/gpt-4o",
                "name": "GPT-4o",
                "provider": "openrouter",
                "description": "Highest quality analysis, premium cost",
                "cost_tier": "premium",
                "recommended": False
            }
        ],
        "note": "All models accessible via OpenRouter with a single API key"
    }
