"""Jobs API routes for monitoring evaluation jobs."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession
from celery.result import AsyncResult
from typing import Literal

from app.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.evaluation import Evaluation, EvaluationStatus
from app.tasks import celery_app
from app.schemas.job import JobResponse, JobListResponse

router = APIRouter(prefix="/jobs", tags=["jobs"])


@router.get("", response_model=JobListResponse)
async def list_jobs(
    status: Literal["pending", "running", "completed", "failed"] | None = Query(
        None, description="Filter by job status"
    ),
    include_completed: bool = Query(
        True, description="Include completed jobs in the results"
    ),
    limit: int = Query(50, ge=1, le=200, description="Maximum number of jobs to return"),
    offset: int = Query(0, ge=0, description="Number of jobs to skip"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    List all evaluation jobs with optional status filtering.

    Returns job information including:
    - Job ID and evaluation details
    - Current status (pending, running, completed, failed)
    - Progress information (current/total questions)
    - Celery task state
    """
    query = select(Evaluation).where(Evaluation.user_id == user.id)

    # Apply status filter
    if status:
        query = query.where(Evaluation.status == status)
    elif not include_completed:
        # By default, show in-progress jobs (pending and running)
        query = query.where(
            or_(
                Evaluation.status == EvaluationStatus.PENDING,
                Evaluation.status == EvaluationStatus.RUNNING
            )
        )

    # Get total count before pagination
    count_result = await db.execute(
        select(Evaluation.id).where(Evaluation.user_id == user.id)
    )
    total_count = len(count_result.all())

    # Apply pagination and ordering
    query = query.order_by(Evaluation.created_at.desc()).offset(offset).limit(limit)

    result = await db.execute(query)
    evaluations = result.scalars().all()

    # Build job responses with Celery task status
    jobs = []
    for eval in evaluations:
        celery_state = None
        celery_progress = {"current": 0, "total": 0, "message": None}

        # Check Celery task status if available
        if eval.celery_task_id:
            try:
                task_result = AsyncResult(eval.celery_task_id, app=celery_app)
                celery_state = task_result.state
                if task_result.state == "PROGRESS" and task_result.info:
                    celery_progress = task_result.info
            except Exception:
                pass  # Celery may be unavailable

        jobs.append(JobResponse(
            job_id=eval.id,
            evaluation_id=eval.id,
            name=eval.name,
            eval_type=eval.eval_type,
            status=eval.status.value if hasattr(eval.status, 'value') else eval.status,
            progress=eval.progress,
            total=eval.total_questions,
            celery_task_id=eval.celery_task_id,
            celery_state=celery_state,
            celery_progress=celery_progress,
            error_message=eval.error_message,
            created_at=eval.created_at,
            started_at=eval.started_at,
            completed_at=eval.completed_at
        ))

    return JobListResponse(
        jobs=jobs,
        total=total_count,
        limit=limit,
        offset=offset
    )


@router.get("/active", response_model=JobListResponse)
async def list_active_jobs(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    List only active (pending or running) jobs.

    Convenience endpoint for monitoring in-progress evaluations.
    """
    return await list_jobs(
        status=None,
        include_completed=False,
        limit=50,
        offset=0,
        user=user,
        db=db
    )
