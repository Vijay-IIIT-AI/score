"""Providers API routes."""
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.provider import Provider, UserProviderConnection
from app.schemas.provider import (
    ProviderResponse, ProviderListResponse,
    ProviderConnectRequest, ConnectionResponse
)
from app.services.crypto import encrypt_api_key
from app.services.model_sync import sync_provider_models

router = APIRouter(prefix="/providers", tags=["providers"])


@router.get("", response_model=ProviderListResponse)
async def list_providers(db: AsyncSession = Depends(get_db)):
    """List all AI providers."""
    result = await db.execute(select(Provider).order_by(Provider.name))
    providers = result.scalars().all()
    return {"providers": providers, "total": len(providers)}


@router.get("/{provider_id}", response_model=ProviderResponse)
async def get_provider(provider_id: str, db: AsyncSession = Depends(get_db)):
    """Get provider details."""
    result = await db.execute(select(Provider).where(Provider.id == provider_id))
    provider = result.scalar_one_or_none()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    return provider


@router.post("/{provider_id}/connect", response_model=ConnectionResponse)
async def connect_provider(
    provider_id: str,
    data: ProviderConnectRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Connect provider with API key and sync available models."""
    # Check provider exists
    result = await db.execute(select(Provider).where(Provider.id == provider_id))
    provider = result.scalar_one_or_none()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")

    # Check existing connection
    result = await db.execute(
        select(UserProviderConnection)
        .where(UserProviderConnection.user_id == user.id)
        .where(UserProviderConnection.provider_id == provider_id)
    )
    connection = result.scalar_one_or_none()

    encrypted_key = encrypt_api_key(data.api_key)

    if connection:
        connection.api_key_encrypted = encrypted_key
        connection.status = "connected"
    else:
        connection = UserProviderConnection(
            user_id=user.id,
            provider_id=provider_id,
            api_key_encrypted=encrypted_key,
            status="connected"
        )
        db.add(connection)

    await db.flush()

    # Sync models from provider (if supported)
    sync_result = await sync_provider_models(db, provider_id, data.api_key)

    return {
        "status": "connected",
        "provider_id": provider_id,
        "models_synced": sync_result.get("synced", 0)
    }


@router.post("/{provider_id}/sync-models")
async def sync_models(
    provider_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Sync/refresh models from provider."""
    from app.services.crypto import decrypt_api_key

    # Get user's connection for API key
    result = await db.execute(
        select(UserProviderConnection)
        .where(UserProviderConnection.user_id == user.id)
        .where(UserProviderConnection.provider_id == provider_id)
    )
    connection = result.scalar_one_or_none()

    if not connection or not connection.api_key_encrypted:
        raise HTTPException(status_code=400, detail="Provider not connected")

    api_key = decrypt_api_key(connection.api_key_encrypted)
    sync_result = await sync_provider_models(db, provider_id, api_key)

    return {
        "status": "synced",
        "provider_id": provider_id,
        "models_synced": sync_result.get("synced", 0),
        "total_available": sync_result.get("total_available", 0),
        "errors": sync_result.get("errors", [])
    }


@router.delete("/{provider_id}/disconnect")
async def disconnect_provider(
    provider_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Disconnect provider."""
    result = await db.execute(
        select(UserProviderConnection)
        .where(UserProviderConnection.user_id == user.id)
        .where(UserProviderConnection.provider_id == provider_id)
    )
    connection = result.scalar_one_or_none()

    if connection:
        await db.delete(connection)

    return {"status": "disconnected", "provider_id": provider_id}
