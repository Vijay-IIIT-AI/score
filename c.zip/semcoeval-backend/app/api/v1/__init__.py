"""API v1 router aggregation."""
from fastapi import APIRouter

from app.api.v1 import auth, providers, models, datasets, evaluations, reports, jobs, admin

router = APIRouter()

router.include_router(auth.router)
router.include_router(providers.router)
router.include_router(models.router)
router.include_router(datasets.router)
router.include_router(evaluations.router)
router.include_router(reports.router)
router.include_router(jobs.router)
router.include_router(admin.router)
