"""AI Models API routes."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_db
from app.models.ai_model import AIModel
from app.schemas.model import ModelResponse, ModelListResponse

router = APIRouter(prefix="/models", tags=["models"])


@router.get("", response_model=ModelListResponse)
async def list_models(
    provider_id: str | None = Query(None),
    category: str | None = Query(None),
    capability: str | None = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List all AI models with optional filters."""
    query = select(AIModel)

    if provider_id:
        query = query.where(AIModel.provider_id == provider_id)
    if category:
        query = query.where(AIModel.category == category)

    result = await db.execute(query.order_by(AIModel.name))
    models = result.scalars().all()

    # Filter by capability if specified
    if capability:
        models = [m for m in models if capability in (m.capabilities or [])]

    return {"models": models, "total": len(models)}


@router.get("/{model_id}", response_model=ModelResponse)
async def get_model(model_id: str, db: AsyncSession = Depends(get_db)):
    """Get model details."""
    result = await db.execute(select(AIModel).where(AIModel.id == model_id))
    model = result.scalar_one_or_none()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    return model


@router.get("/by-provider/{provider_id}", response_model=ModelListResponse)
async def get_models_by_provider(
    provider_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get models by provider."""
    result = await db.execute(
        select(AIModel)
        .where(AIModel.provider_id == provider_id)
        .order_by(AIModel.name)
    )
    models = result.scalars().all()
    return {"models": models, "total": len(models)}
