"""Auth API - SSO login and user management."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import async_session_maker
from app.dependencies import get_db, get_current_user
from app.models.user import User
from app.schemas.auth import (
    SSOLoginRequest, SSOLoginResponse, UserResult,
    UserResponse, UserUpdate
)
from app.services.auth_service import decode_user_info, create_jwt_token

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/sso_login", response_model=SSOLoginResponse)
async def sso_login(
    data: SSOLoginRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    SSO Login - Exchange encrypted credentials for JWT token.

    Request: { aes_key, user_info }
    Response: { status, result: { token, username, email, ... } }
    """
    # Decode encrypted user info
    user_data = decode_user_info(data.aes_key, data.user_info)

    if not user_data:
        return SSOLoginResponse(status="error", message="Invalid credentials")

    # Extract user fields
    sso_id = str(user_data.get("id") or user_data.get("sub") or user_data.get("user_id", ""))
    email = user_data.get("email", "")
    username = user_data.get("username") or user_data.get("name", "")
    language = user_data.get("language", "en")

    if not sso_id:
        return SSOLoginResponse(status="error", message="Missing user ID")

    # Get or create user
    result = await db.execute(select(User).where(User.sso_id == sso_id))
    user = result.scalar_one_or_none()

    if not user:
        user = User(
            sso_id=sso_id,
            email=email,
            name=username or email.split("@")[0],
            language=language
        )
        db.add(user)
        await db.flush()
    else:
        # Update if changed
        if email and user.email != email:
            user.email = email
        if username and user.name != username:
            user.name = username

    # Generate JWT
    token = create_jwt_token(user.id, user.email, user.name)

    return SSOLoginResponse(
        status="success",
        result=UserResult(
            token=token,
            username=user.name,
            email=user.email,
            api_key=None,  # User connects providers separately
            language=user.language or "en",
            profile_name=user.name
        )
    )


@router.get("/me", response_model=UserResponse)
async def get_me(user: User = Depends(get_current_user)):
    """Get current user details."""
    return UserResponse(
        id=user.id,
        username=user.name,
        email=user.email,
        role=user.role.value if hasattr(user.role, 'value') else user.role,
        organization=user.organization,
        avatar=user.avatar,
        language=user.language or "en",
        is_active=user.is_active
    )


@router.put("/me", response_model=UserResponse)
async def update_me(
    data: UserUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update current user profile."""
    if data.username is not None:
        user.name = data.username
    if data.organization is not None:
        user.organization = data.organization
    if data.avatar is not None:
        user.avatar = data.avatar
    if data.language is not None:
        user.language = data.language

    await db.commit()

    return UserResponse(
        id=user.id,
        username=user.name,
        email=user.email,
        role=user.role.value if hasattr(user.role, 'value') else user.role,
        organization=user.organization,
        avatar=user.avatar,
        language=user.language or "en",
        is_active=user.is_active
    )
