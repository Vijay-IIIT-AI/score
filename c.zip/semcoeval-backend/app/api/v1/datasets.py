"""Datasets API routes."""
import json
import os
import re
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.dataset import Dataset
from app.schemas.dataset import (
    DatasetResponse, DatasetListResponse,
    DatasetPreview, ValidationResult
)
from app.storage import storage
from app.validators import get_validator, VALIDATOR_REGISTRY

router = APIRouter(prefix="/datasets", tags=["datasets"])


def sanitize_filename(filename: str) -> str:
    """Sanitize filename to prevent path traversal attacks."""
    # Remove any path components
    filename = os.path.basename(filename)
    # Remove dangerous characters
    filename = re.sub(r'[^\w\-_\.]', '_', filename)
    # Prevent hidden files
    if filename.startswith('.'):
        filename = '_' + filename[1:]
    # Ensure non-empty
    if not filename:
        filename = "dataset.json"
    return filename


@router.get("", response_model=DatasetListResponse)
async def list_datasets(
    category: str | None = Query(None),
    eval_type: str | None = Query(None),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List datasets."""
    query = select(Dataset)

    if category:
        query = query.where(Dataset.category == category)
    if eval_type:
        query = query.where(Dataset.eval_type == eval_type)

    result = await db.execute(query.order_by(Dataset.created_at.desc()))
    datasets = result.scalars().all()
    return {"datasets": datasets, "total": len(datasets)}


@router.get("/{dataset_id}", response_model=DatasetResponse)
async def get_dataset(
    dataset_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get dataset details."""
    result = await db.execute(select(Dataset).where(Dataset.id == dataset_id))
    dataset = result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # Check ownership or if dataset is public/shared
    if dataset.created_by_id != user.id:
        # For now, allow read access - can be restricted later with is_public field
        pass

    return dataset


@router.post("/upload", response_model=DatasetResponse)
async def upload_dataset(
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Upload new dataset."""
    content = await file.read()

    # Validate JSON
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON file")

    # Extract metadata
    metadata = data.get("metadata", {})
    questions = data.get("questions", [])

    dataset_id = f"ds-{uuid.uuid4().hex[:8]}"

    # Sanitize filename to prevent path traversal
    safe_filename = sanitize_filename(file.filename or "dataset.json")

    # Upload to MinIO
    path = f"datasets/{dataset_id}/{safe_filename}"
    storage.upload_file(path, content, "application/json")

    dataset = Dataset(
        id=dataset_id,
        name=metadata.get("name", safe_filename),
        category=metadata.get("category", "General"),
        eval_type=metadata.get("eval_type", "model"),
        question_count=len(questions),
        file_path=path,
        schema_version=metadata.get("schema_version", "1.0"),
        created_by_id=user.id
    )
    db.add(dataset)
    await db.flush()

    return dataset


@router.post("/validate", response_model=ValidationResult)
async def validate_dataset(file: UploadFile = File(...)):
    """Validate dataset without saving."""
    content = await file.read()

    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return {"valid": False, "errors": ["Invalid JSON format"], "warnings": [], "question_count": 0}

    # Determine eval_type from metadata
    metadata = data.get("metadata", {})
    eval_type = metadata.get("eval_type", "model")

    # Use appropriate validator
    if eval_type not in VALIDATOR_REGISTRY:
        return {
            "valid": False,
            "errors": [f"Unknown eval_type: {eval_type}. Valid types: {list(VALIDATOR_REGISTRY.keys())}"],
            "warnings": [],
            "question_count": 0
        }

    validator = get_validator(eval_type)
    result = validator.validate(data)

    return {
        "valid": result.valid,
        "errors": result.errors,
        "warnings": result.warnings,
        "question_count": result.question_count
    }


@router.get("/{dataset_id}/preview", response_model=DatasetPreview)
async def preview_dataset(
    dataset_id: str,
    limit: int = Query(5, ge=1, le=20),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Preview dataset questions."""
    result = await db.execute(select(Dataset).where(Dataset.id == dataset_id))
    dataset = result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # Check ownership or if dataset is public/shared
    if dataset.created_by_id != user.id:
        # For now, allow read access - can be restricted later
        pass

    # Download from MinIO
    content = storage.download_file(dataset.file_path)
    if not content:
        raise HTTPException(status_code=404, detail="Dataset file not found")

    data = json.loads(content)
    questions = data.get("questions", [])[:limit]

    return {"dataset_id": dataset_id, "questions": questions, "total": dataset.question_count}


@router.delete("/{dataset_id}")
async def delete_dataset(
    dataset_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete dataset."""
    result = await db.execute(select(Dataset).where(Dataset.id == dataset_id))
    dataset = result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # IDOR protection: verify ownership
    if dataset.created_by_id != user.id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this dataset")

    # Delete from MinIO
    storage.delete_file(dataset.file_path)

    await db.delete(dataset)
    return {"status": "deleted", "dataset_id": dataset_id}
