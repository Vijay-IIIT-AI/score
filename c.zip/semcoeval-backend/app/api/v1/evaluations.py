"""Evaluations API routes."""
import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from celery.result import AsyncResult

from app.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.evaluation import Evaluation, EvaluationStatus
from app.schemas.evaluation import (
    EvaluationCreate, EvaluationResponse, EvaluationListResponse,
    EvaluationStatus as StatusResponse, EvaluationResults
)
from app.tasks import celery_app, run_evaluation

router = APIRouter(prefix="/evaluations", tags=["evaluations"])


@router.post("", response_model=EvaluationResponse)
async def create_evaluation(
    data: EvaluationCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create new evaluation."""
    evaluation = Evaluation(
        id=f"eval-{uuid.uuid4().hex[:8]}",
        name=data.name,
        description=data.description,
        eval_type=data.eval_type,
        dataset_id=data.dataset_id,
        model_ids=data.model_ids,
        subgroup=data.subgroup,
        metrics_config=data.metrics_config or {},
        user_id=user.id,
        status=EvaluationStatus.PENDING
    )
    db.add(evaluation)
    await db.flush()
    return evaluation


@router.get("", response_model=EvaluationListResponse)
async def list_evaluations(
    status: str | None = Query(None),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List user's evaluations."""
    query = select(Evaluation).where(Evaluation.user_id == user.id)

    if status:
        query = query.where(Evaluation.status == status)

    result = await db.execute(query.order_by(Evaluation.created_at.desc()))
    evaluations = result.scalars().all()
    return {"evaluations": evaluations, "total": len(evaluations)}


@router.get("/{evaluation_id}", response_model=EvaluationResponse)
async def get_evaluation(
    evaluation_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get evaluation details."""
    result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id == evaluation_id)
        .where(Evaluation.user_id == user.id)
    )
    evaluation = result.scalar_one_or_none()
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")
    return evaluation


@router.post("/{evaluation_id}/start")
async def start_evaluation(
    evaluation_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Start evaluation run."""
    result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id == evaluation_id)
        .where(Evaluation.user_id == user.id)
    )
    evaluation = result.scalar_one_or_none()
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")

    if evaluation.status != EvaluationStatus.PENDING:
        raise HTTPException(status_code=400, detail="Evaluation already started")

    # Update status and commit before starting Celery task
    evaluation.status = EvaluationStatus.RUNNING
    await db.commit()

    # Start Celery task
    task = run_evaluation.delay(evaluation.id, user.id)

    # Update task ID
    evaluation.celery_task_id = task.id
    await db.commit()

    return {"status": "started", "task_id": task.id}


@router.get("/{evaluation_id}/status", response_model=StatusResponse)
async def get_evaluation_status(
    evaluation_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get evaluation progress."""
    result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id == evaluation_id)
        .where(Evaluation.user_id == user.id)
    )
    evaluation = result.scalar_one_or_none()
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")

    progress = {"current": 0, "total": 0}

    # Check Celery task status
    if evaluation.celery_task_id:
        task_result = AsyncResult(evaluation.celery_task_id, app=celery_app)
        if task_result.state == "PROGRESS":
            progress = task_result.info or progress

    return {
        "status": evaluation.status,
        "progress": evaluation.progress,
        "total": evaluation.total_questions,
        "celery_state": progress,
        "error_message": evaluation.error_message
    }


@router.get("/{evaluation_id}/results", response_model=EvaluationResults)
async def get_evaluation_results(
    evaluation_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get evaluation results."""
    from app.models.evaluation import EvaluationResult
    from sqlalchemy.orm import selectinload

    result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id == evaluation_id)
        .where(Evaluation.user_id == user.id)
        .options(selectinload(Evaluation.results))
    )
    evaluation = result.scalar_one_or_none()
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")

    if evaluation.status != EvaluationStatus.COMPLETED:
        raise HTTPException(status_code=400, detail="Evaluation not completed")

    # Build results from EvaluationResult records
    model_results = [
        {
            "model_id": r.model_id,
            "provider": None,  # Could be joined from AIModel if needed
            "rank": r.rank,
            "score": r.score,
            "accuracy": r.accuracy,
            "passed_tests": r.passed_tests,
            "failed_tests": r.failed_tests,
            "total_tests": r.total_tests,
            "metric_scores": r.scores or {}
        }
        for r in sorted(evaluation.results, key=lambda x: x.rank)
    ]

    return {
        "evaluation_id": evaluation_id,
        "status": evaluation.status.value if hasattr(evaluation.status, 'value') else evaluation.status,
        "top_model": evaluation.top_model,
        "top_score": evaluation.top_score,
        "results": model_results
    }
