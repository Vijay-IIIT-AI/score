"""Reports API routes."""
import uuid
import json
import csv
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from io import BytesIO, StringIO

from app.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.report import Report
from app.models.evaluation import Evaluation
from app.schemas.report import (
    ReportCreate, ReportResponse, ReportListResponse,
    ModelComparisonRequest, ModelComparisonResponse
)
from app.storage import storage
from app.tasks import generate_report

router = APIRouter(prefix="/reports", tags=["reports"])


# Model comparison routes MUST come before /{report_id} routes to avoid conflict
@router.post("/comparison", response_model=ModelComparisonResponse)
async def create_model_comparison(
    data: ModelComparisonRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Generate a comparison report across multiple evaluations.

    Compares model performance across multiple evaluations, showing:
    - All model scores side by side
    - Per-metric breakdown for each model
    - Summary statistics
    """
    from app.schemas.report import ModelMetricScore, MetricComparison

    if len(data.evaluation_ids) < 1:
        raise HTTPException(status_code=400, detail="At least one evaluation ID is required")

    # Fetch all evaluations with their results
    result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id.in_(data.evaluation_ids))
        .where(Evaluation.user_id == user.id)
        .options(selectinload(Evaluation.results))
    )
    evaluations = result.scalars().all()

    if len(evaluations) != len(data.evaluation_ids):
        found_ids = {e.id for e in evaluations}
        missing = [eid for eid in data.evaluation_ids if eid not in found_ids]
        raise HTTPException(
            status_code=404,
            detail=f"Evaluations not found: {', '.join(missing)}"
        )

    # Check all evaluations are completed
    for eval in evaluations:
        if eval.status.value != "completed":
            raise HTTPException(
                status_code=400,
                detail=f"Evaluation {eval.id} is not completed (status: {eval.status.value})"
            )

    # Collect all model results across evaluations
    models = []
    all_metrics = set()
    model_metric_data = {}  # model_id -> {metric_name -> score}

    for evaluation in evaluations:
        for r in evaluation.results:
            model_score = ModelMetricScore(
                model_id=r.model_id,
                evaluation_id=evaluation.id,
                evaluation_name=evaluation.name,
                rank=r.rank,
                score=r.score,
                accuracy=r.accuracy,
                passed_tests=r.passed_tests,
                failed_tests=r.failed_tests,
                total_tests=r.total_tests,
                metric_scores=r.scores or {}
            )
            models.append(model_score)

            # Collect metrics
            if r.scores:
                all_metrics.update(r.scores.keys())
                if r.model_id not in model_metric_data:
                    model_metric_data[r.model_id] = {}
                for metric, score in r.scores.items():
                    if metric not in model_metric_data[r.model_id]:
                        model_metric_data[r.model_id][metric] = score
                    else:
                        model_metric_data[r.model_id][metric] = max(
                            model_metric_data[r.model_id][metric], score
                        )

    # Build metric breakdown
    metric_breakdown = []
    for metric in sorted(all_metrics):
        scores = {}
        for model_id, metrics in model_metric_data.items():
            if metric in metrics:
                scores[model_id] = metrics[metric]
        metric_breakdown.append(MetricComparison(
            metric_name=metric,
            scores=scores
        ))

    # Build summary
    all_scores = [m.score for m in models if m.score is not None]
    summary = {
        "total_evaluations": len(evaluations),
        "total_models": len(set(m.model_id for m in models)),
        "total_metrics": len(all_metrics),
        "best_overall_score": max(all_scores) if all_scores else None,
        "average_score": sum(all_scores) / len(all_scores) if all_scores else None,
        "best_model": max(models, key=lambda x: x.score or 0).model_id if models else None
    }

    title = data.title or f"Model Comparison - {len(evaluations)} Evaluations"

    return ModelComparisonResponse(
        title=title,
        evaluation_ids=data.evaluation_ids,
        models=models,
        metric_breakdown=metric_breakdown,
        summary=summary
    )


@router.get("/comparison/download")
async def download_comparison_report(
    evaluation_ids: str = Query(..., description="Comma-separated evaluation IDs"),
    format: Literal["json", "csv"] = Query("json", description="Export format"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Download model comparison report in specified format.

    Supported formats:
    - json: JSON data export
    - csv: CSV spreadsheet
    """
    from app.schemas.report import ModelComparisonRequest

    eval_ids = [eid.strip() for eid in evaluation_ids.split(",") if eid.strip()]
    if not eval_ids:
        raise HTTPException(status_code=400, detail="No evaluation IDs provided")

    # Reuse the comparison logic
    comparison = await create_model_comparison(
        data=ModelComparisonRequest(evaluation_ids=eval_ids),
        user=user,
        db=db
    )

    if format == "json":
        json_content = _generate_comparison_json(comparison)
        return StreamingResponse(
            BytesIO(json_content.encode("utf-8")),
            media_type="application/json",
            headers={"Content-Disposition": "attachment; filename=model_comparison.json"}
        )
    else:  # csv
        csv_content = _generate_comparison_csv(comparison)
        return StreamingResponse(
            BytesIO(csv_content.encode("utf-8")),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=model_comparison.csv"}
        )


@router.post("", response_model=ReportResponse)
async def create_report(
    data: ReportCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Generate report from evaluation."""
    # Check evaluation exists
    result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id == data.evaluation_id)
        .where(Evaluation.user_id == user.id)
    )
    evaluation = result.scalar_one_or_none()
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")

    report = Report(
        id=f"rpt-{uuid.uuid4().hex[:8]}",
        title=data.title or f"Report - {evaluation.name}",
        evaluation_id=evaluation.id,
        user_id=user.id,
        status="pending"
    )
    db.add(report)

    # Commit before starting Celery task to ensure data is visible to worker
    await db.commit()

    # Start async report generation
    generate_report.delay(evaluation.id, report.id)

    return report


@router.get("", response_model=ReportListResponse)
async def list_reports(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List user's reports."""
    result = await db.execute(
        select(Report)
        .where(Report.user_id == user.id)
        .order_by(Report.created_at.desc())
    )
    reports = result.scalars().all()
    return {"reports": reports, "total": len(reports)}


@router.get("/{report_id}", response_model=ReportResponse)
async def get_report(
    report_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get report details."""
    result = await db.execute(
        select(Report)
        .where(Report.id == report_id)
        .where(Report.user_id == user.id)
    )
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.get("/{report_id}/download")
async def download_report(
    report_id: str,
    format: Literal["pdf", "json", "csv", "csv_detailed"] = Query("pdf", description="Export format"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Download report in specified format.

    Supported formats:
    - pdf: PDF document (default)
    - json: JSON data export
    - csv: CSV summary spreadsheet (model-level)
    - csv_detailed: CSV with per-question scores and metrics
    """
    result = await db.execute(
        select(Report)
        .where(Report.id == report_id)
        .where(Report.user_id == user.id)
    )
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    if report.status != "completed":
        raise HTTPException(status_code=400, detail="Report not ready")

    # Get evaluation with results for JSON/CSV export
    eval_result = await db.execute(
        select(Evaluation)
        .where(Evaluation.id == report.evaluation_id)
        .options(selectinload(Evaluation.results))
    )
    evaluation = eval_result.scalar_one_or_none()

    if format == "pdf":
        content = storage.download_file(report.file_path)
        if not content:
            raise HTTPException(status_code=404, detail="Report file not found")

        return StreamingResponse(
            BytesIO(content),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={report_id}.pdf"}
        )

    elif format == "json":
        json_content = _generate_json_export(evaluation, report)
        return StreamingResponse(
            BytesIO(json_content.encode("utf-8")),
            media_type="application/json",
            headers={"Content-Disposition": f"attachment; filename={report_id}.json"}
        )

    elif format == "csv":
        csv_content = _generate_csv_export(evaluation, report)
        return StreamingResponse(
            BytesIO(csv_content.encode("utf-8")),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={report_id}.csv"}
        )

    elif format == "csv_detailed":
        csv_content = _generate_detailed_csv_export(evaluation, report)
        return StreamingResponse(
            BytesIO(csv_content.encode("utf-8")),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={report_id}_detailed.csv"}
        )


def _generate_json_export(evaluation: Evaluation, report: Report) -> str:
    """Generate JSON export of evaluation results with per-question details."""
    model_results = []
    for r in sorted(evaluation.results, key=lambda x: x.rank):
        result_data = {
            "model_id": r.model_id,
            "rank": r.rank,
            "score": r.score,
            "accuracy": r.accuracy,
            "passed_tests": r.passed_tests,
            "failed_tests": r.failed_tests,
            "total_tests": r.total_tests,
            "metric_scores": r.scores or {}
        }
        # Include per-question details if available
        if hasattr(r, 'details') and r.details:
            result_data["question_results"] = r.details
        model_results.append(result_data)

    export_data = {
        "report": {
            "id": report.id,
            "title": report.title,
            "created_at": report.created_at.isoformat() if report.created_at else None
        },
        "evaluation": {
            "id": evaluation.id,
            "name": evaluation.name,
            "description": evaluation.description,
            "eval_type": evaluation.eval_type,
            "dataset_id": evaluation.dataset_id,
            "status": evaluation.status.value if hasattr(evaluation.status, 'value') else evaluation.status,
            "top_model": evaluation.top_model,
            "top_score": evaluation.top_score,
            "total_questions": evaluation.total_questions,
            "created_at": evaluation.created_at.isoformat() if evaluation.created_at else None,
            "completed_at": evaluation.completed_at.isoformat() if evaluation.completed_at else None
        },
        "results": model_results
    }

    return json.dumps(export_data, indent=2)


def _generate_csv_export(evaluation: Evaluation, report: Report) -> str:
    """Generate CSV export of evaluation results."""
    output = StringIO()

    # Collect all unique metric names across all results
    all_metrics = set()
    for r in evaluation.results:
        if r.scores:
            all_metrics.update(r.scores.keys())
    all_metrics = sorted(all_metrics)

    # Define CSV columns
    fieldnames = [
        "rank", "model_id", "score", "accuracy",
        "passed_tests", "failed_tests", "total_tests"
    ] + [f"metric_{m}" for m in all_metrics]

    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()

    for r in sorted(evaluation.results, key=lambda x: x.rank):
        row = {
            "rank": r.rank,
            "model_id": r.model_id,
            "score": r.score,
            "accuracy": r.accuracy,
            "passed_tests": r.passed_tests,
            "failed_tests": r.failed_tests,
            "total_tests": r.total_tests
        }
        # Add metric columns
        for metric in all_metrics:
            row[f"metric_{metric}"] = r.scores.get(metric) if r.scores else None

        writer.writerow(row)

    return output.getvalue()


def _generate_detailed_csv_export(evaluation: Evaluation, report: Report) -> str:
    """Generate detailed CSV export with per-question scores and metrics."""
    output = StringIO()

    # Define CSV columns for detailed per-question output
    fieldnames = [
        "model_id", "question_id", "question_input", "expected_output",
        "actual_output", "passed", "score"
    ]

    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()

    for r in sorted(evaluation.results, key=lambda x: x.rank):
        # Get per-question details if available
        details = r.details if hasattr(r, 'details') and r.details else []

        if details:
            for item in details:
                row = {
                    "model_id": r.model_id,
                    "question_id": item.get("test_id", ""),
                    "question_input": item.get("input", ""),
                    "expected_output": item.get("expected", ""),
                    "actual_output": item.get("output", ""),
                    "passed": "Yes" if item.get("passed") else "No",
                    "score": item.get("score", 0.0)
                }
                writer.writerow(row)
        else:
            # Fallback if no detailed results available - show summary row
            writer.writerow({
                "model_id": r.model_id,
                "question_id": "N/A",
                "question_input": "(No detailed data available)",
                "expected_output": "",
                "actual_output": "",
                "passed": f"{r.passed_tests}/{r.total_tests}",
                "score": r.score
            })

    return output.getvalue()


def _generate_comparison_json(comparison) -> str:
    """Generate JSON export of comparison report."""
    data = {
        "title": comparison.title,
        "evaluation_ids": comparison.evaluation_ids,
        "summary": comparison.summary,
        "models": [
            {
                "model_id": m.model_id,
                "evaluation_id": m.evaluation_id,
                "evaluation_name": m.evaluation_name,
                "rank": m.rank,
                "score": m.score,
                "accuracy": m.accuracy,
                "passed_tests": m.passed_tests,
                "failed_tests": m.failed_tests,
                "total_tests": m.total_tests,
                "metric_scores": m.metric_scores
            }
            for m in comparison.models
        ],
        "metric_breakdown": [
            {
                "metric_name": mb.metric_name,
                "scores": mb.scores
            }
            for mb in comparison.metric_breakdown
        ]
    }
    return json.dumps(data, indent=2)


def _generate_comparison_csv(comparison) -> str:
    """Generate CSV export of comparison report."""
    output = StringIO()

    # Collect all unique metric names
    all_metrics = sorted(set(
        metric
        for m in comparison.models
        for metric in m.metric_scores.keys()
    ))

    # Define CSV columns
    fieldnames = [
        "model_id", "evaluation_id", "evaluation_name", "rank",
        "score", "accuracy", "passed_tests", "failed_tests", "total_tests"
    ] + [f"metric_{m}" for m in all_metrics]

    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()

    for m in comparison.models:
        row = {
            "model_id": m.model_id,
            "evaluation_id": m.evaluation_id,
            "evaluation_name": m.evaluation_name,
            "rank": m.rank,
            "score": m.score,
            "accuracy": m.accuracy,
            "passed_tests": m.passed_tests,
            "failed_tests": m.failed_tests,
            "total_tests": m.total_tests
        }
        # Add metric columns
        for metric in all_metrics:
            row[f"metric_{metric}"] = m.metric_scores.get(metric)

        writer.writerow(row)

    return output.getvalue()
