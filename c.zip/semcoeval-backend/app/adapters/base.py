"""Base adapter for transforming benchmark formats to common schema."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class CommonQuestion:
    """Common question format across all benchmarks."""
    id: str
    eval_type: str  # "model", "agent", "rag"
    input: dict  # prompt, system_prompt, etc.
    expected: dict  # answer, keywords, tool_calls, etc.
    evaluation: dict = field(default_factory=dict)  # scoring_method, etc.
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.eval_type,
            "input": self.input,
            "expected": self.expected,
            "evaluation": self.evaluation,
            "metadata": self.metadata
        }


@dataclass
class CommonDataset:
    """Common dataset format."""
    name: str
    eval_type: str
    category: str
    schema_version: str = "1.0"
    questions: list[CommonQuestion] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "metadata": {
                "name": self.name,
                "eval_type": self.eval_type,
                "category": self.category,
                "schema_version": self.schema_version,
                "question_count": len(self.questions)
            },
            "questions": [q.to_dict() for q in self.questions]
        }


class BaseAdapter(ABC):
    """Abstract base class for dataset adapters."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the adapter name (benchmark name)."""
        pass

    @property
    @abstractmethod
    def eval_type(self) -> str:
        """Return the evaluation type this adapter produces."""
        pass

    @abstractmethod
    def transform(self, raw_data: Any) -> CommonDataset:
        """
        Transform raw benchmark data to common format.

        Args:
            raw_data: Raw data from benchmark (varies by format)

        Returns:
            CommonDataset in standard schema
        """
        pass

    def validate_raw(self, raw_data: Any) -> tuple[bool, list[str]]:
        """
        Validate raw data before transformation.

        Returns:
            (is_valid, list of error messages)
        """
        return True, []


class AdapterRegistry:
    """Registry for dataset adapters."""

    _adapters: dict[str, type[BaseAdapter]] = {}

    @classmethod
    def register(cls, name: str, adapter_class: type[BaseAdapter]):
        """Register an adapter."""
        cls._adapters[name.lower()] = adapter_class

    @classmethod
    def get(cls, name: str) -> Optional[BaseAdapter]:
        """Get adapter by name."""
        adapter_class = cls._adapters.get(name.lower())
        if adapter_class:
            return adapter_class()
        return None

    @classmethod
    def list_adapters(cls) -> list[str]:
        """List registered adapter names."""
        return list(cls._adapters.keys())
