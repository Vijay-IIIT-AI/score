"""MMLU benchmark adapter - Multiple choice knowledge evaluation."""
from app.adapters.base import BaseAdapter, CommonDataset, CommonQuestion, AdapterRegistry


class MMLUAdapter(BaseAdapter):
    """
    Adapter for MMLU (Massive Multitask Language Understanding).

    MMLU format:
    - Multiple choice questions (A, B, C, D)
    - 57 subjects across STEM, humanities, social sciences, etc.
    """

    @property
    def name(self) -> str:
        return "mmlu"

    @property
    def eval_type(self) -> str:
        return "model"

    def transform(self, raw_data: list[dict]) -> CommonDataset:
        """Transform MMLU data to common format."""
        questions = []

        for i, item in enumerate(raw_data):
            # MMLU format: question, A, B, C, D, answer (letter)
            question_text = item.get("question", "")
            choices = {
                "A": item.get("A", item.get("choices", ["", "", "", ""])[0] if len(item.get("choices", [])) > 0 else ""),
                "B": item.get("B", item.get("choices", ["", "", "", ""])[1] if len(item.get("choices", [])) > 1 else ""),
                "C": item.get("C", item.get("choices", ["", "", "", ""])[2] if len(item.get("choices", [])) > 2 else ""),
                "D": item.get("D", item.get("choices", ["", "", "", ""])[3] if len(item.get("choices", [])) > 3 else ""),
            }
            correct = item.get("answer", "")

            # Build prompt with choices
            prompt = f"{question_text}\n\nA) {choices['A']}\nB) {choices['B']}\nC) {choices['C']}\nD) {choices['D']}"

            q = CommonQuestion(
                id=item.get("id", f"mmlu-{i}"),
                eval_type="model",
                input={
                    "prompt": prompt,
                    "system_prompt": "Answer the following multiple choice question. Respond with just the letter (A, B, C, or D)."
                },
                expected={
                    "correct_choice": correct,
                    "answer": choices.get(correct, ""),
                },
                evaluation={
                    "scoring_method": "multiple_choice"
                },
                metadata={
                    "subject": item.get("subject", ""),
                    "source": "mmlu"
                }
            )
            questions.append(q)

        return CommonDataset(
            name="MMLU",
            eval_type="model",
            category="Knowledge",
            questions=questions
        )


# Register adapter
AdapterRegistry.register("mmlu", MMLUAdapter)
