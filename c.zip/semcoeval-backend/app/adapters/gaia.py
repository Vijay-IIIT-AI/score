"""GAIA benchmark adapter - Multi-step reasoning with tools."""
from app.adapters.base import BaseAdapter, CommonDataset, CommonQuestion, AdapterRegistry


class GAIAAdapter(BaseAdapter):
    """
    Adapter for GAIA (General AI Assistant).

    GAIA format:
    - Multi-step reasoning questions
    - May require web browsing, file reading, code execution
    - Levels: 1 (simple), 2 (medium), 3 (hard)
    """

    @property
    def name(self) -> str:
        return "gaia"

    @property
    def eval_type(self) -> str:
        return "agent"

    def transform(self, raw_data: list[dict]) -> CommonDataset:
        """Transform GAIA data to common format."""
        questions = []

        for i, item in enumerate(raw_data):
            question_text = item.get("Question", item.get("question", ""))
            answer = item.get("Final answer", item.get("answer", ""))
            level = item.get("Level", item.get("level", 1))

            # Define available tools based on question requirements
            tools = self._infer_tools(item)

            q = CommonQuestion(
                id=item.get("task_id", f"gaia-{i}"),
                eval_type="agent",
                input={
                    "prompt": question_text,
                    "available_tools": tools,
                    "tool_responses": {}  # Will be filled during evaluation
                },
                expected={
                    "answer": answer,
                    "tool_calls": [],  # GAIA doesn't specify exact tools
                },
                evaluation={
                    "scoring_method": "exact_match"
                },
                metadata={
                    "level": level,
                    "source": "gaia",
                    "annotator_metadata": item.get("Annotator Metadata", {})
                }
            )
            questions.append(q)

        return CommonDataset(
            name="GAIA",
            eval_type="agent",
            category="Multi-step Reasoning",
            questions=questions
        )

    def _infer_tools(self, item: dict) -> list[dict]:
        """Infer available tools from question metadata."""
        tools = []
        metadata = item.get("Annotator Metadata", {})

        # Common GAIA tools
        if metadata.get("number_of_steps", 0) > 1:
            tools.append({
                "name": "web_search",
                "description": "Search the web for information",
                "parameters": {"query": "string"}
            })

        if "file" in str(item).lower():
            tools.append({
                "name": "read_file",
                "description": "Read contents of a file",
                "parameters": {"path": "string"}
            })

        if "code" in str(item).lower() or "calculate" in str(item).lower():
            tools.append({
                "name": "execute_code",
                "description": "Execute Python code",
                "parameters": {"code": "string"}
            })

        return tools


# Register adapter
AdapterRegistry.register("gaia", GAIAAdapter)
