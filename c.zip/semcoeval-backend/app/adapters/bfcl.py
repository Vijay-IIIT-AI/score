"""BFCL benchmark adapter - Berkeley Function Calling Leaderboard."""
from app.adapters.base import BaseAdapter, CommonDataset, CommonQuestion, AdapterRegistry


class BFCLAdapter(BaseAdapter):
    """
    Adapter for BFCL (Berkeley Function Calling Leaderboard).

    BFCL format:
    - Function definitions with JSON schema
    - User prompts requiring function calls
    - Expected function call with arguments
    """

    @property
    def name(self) -> str:
        return "bfcl"

    @property
    def eval_type(self) -> str:
        return "agent"

    def transform(self, raw_data: list[dict]) -> CommonDataset:
        """Transform BFCL data to common format."""
        questions = []

        for i, item in enumerate(raw_data):
            # BFCL format varies by test type
            prompt = item.get("user_query", item.get("question", ""))
            functions = item.get("function", item.get("functions", []))

            # Normalize functions to list
            if isinstance(functions, dict):
                functions = [functions]

            # Convert to available_tools format
            tools = []
            for func in functions:
                tool = {
                    "name": func.get("name", ""),
                    "description": func.get("description", ""),
                    "parameters": func.get("parameters", {})
                }
                tools.append(tool)

            # Expected tool calls
            ground_truth = item.get("ground_truth", item.get("expected", []))
            if isinstance(ground_truth, str):
                # Parse string format like "func_name(arg1=val1)"
                ground_truth = [self._parse_function_call(ground_truth)]
            elif isinstance(ground_truth, dict):
                ground_truth = [ground_truth]

            expected_calls = []
            for gt in ground_truth:
                if isinstance(gt, dict):
                    expected_calls.append({
                        "name": gt.get("name", ""),
                        "arguments": gt.get("arguments", gt.get("parameters", {}))
                    })

            q = CommonQuestion(
                id=item.get("id", f"bfcl-{i}"),
                eval_type="agent",
                input={
                    "prompt": prompt,
                    "available_tools": tools,
                    "tool_responses": {}
                },
                expected={
                    "tool_calls": expected_calls,
                    "max_tool_calls": len(expected_calls)
                },
                evaluation={
                    "scoring_method": "function_call_match"
                },
                metadata={
                    "test_category": item.get("test_category", ""),
                    "source": "bfcl"
                }
            )
            questions.append(q)

        return CommonDataset(
            name="BFCL",
            eval_type="agent",
            category="Function Calling",
            questions=questions
        )

    def _parse_function_call(self, call_str: str) -> dict:
        """Parse function call string like 'func(arg=val)'."""
        try:
            # Simple parsing - find name and args
            if "(" not in call_str:
                return {"name": call_str, "arguments": {}}

            name = call_str.split("(")[0].strip()
            args_str = call_str.split("(", 1)[1].rstrip(")")

            # Parse arguments (simplified)
            arguments = {}
            if args_str:
                for pair in args_str.split(","):
                    if "=" in pair:
                        k, v = pair.split("=", 1)
                        arguments[k.strip()] = v.strip().strip("'\"")

            return {"name": name, "arguments": arguments}
        except Exception:
            return {"name": call_str, "arguments": {}}


# Register adapter
AdapterRegistry.register("bfcl", BFCLAdapter)
