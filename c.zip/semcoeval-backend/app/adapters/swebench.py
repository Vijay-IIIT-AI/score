"""SWE-bench adapter - Software engineering tasks."""
from app.adapters.base import BaseAdapter, CommonDataset, CommonQuestion, AdapterRegistry


class SWEBenchAdapter(BaseAdapter):
    """
    Adapter for SWE-bench software engineering benchmark.

    SWE-bench format:
    - GitHub issue description
    - Repository context
    - Required patch
    """

    @property
    def name(self) -> str:
        return "swebench"

    @property
    def eval_type(self) -> str:
        return "agent"

    def transform(self, raw_data: list[dict]) -> CommonDataset:
        """Transform SWE-bench data to common format."""
        questions = []

        for i, item in enumerate(raw_data):
            instance_id = item.get("instance_id", f"swe-{i}")
            problem_statement = item.get("problem_statement", "")
            repo = item.get("repo", "")
            base_commit = item.get("base_commit", "")
            patch = item.get("patch", "")

            # Build prompt for agent
            prompt = f"""Fix the following issue in the {repo} repository:

{problem_statement}

Analyze the codebase and provide a patch to fix this issue."""

            # Define SWE tools
            tools = [
                {
                    "name": "read_file",
                    "description": "Read a file from the repository",
                    "parameters": {"path": "string"}
                },
                {
                    "name": "search_code",
                    "description": "Search for code patterns in the repository",
                    "parameters": {"pattern": "string", "file_type": "string"}
                },
                {
                    "name": "edit_file",
                    "description": "Edit a file in the repository",
                    "parameters": {"path": "string", "old_content": "string", "new_content": "string"}
                },
                {
                    "name": "run_tests",
                    "description": "Run the test suite",
                    "parameters": {"test_path": "string"}
                }
            ]

            q = CommonQuestion(
                id=instance_id,
                eval_type="agent",
                input={
                    "prompt": prompt,
                    "available_tools": tools,
                    "tool_responses": {}
                },
                expected={
                    "answer": patch,
                    "tool_calls": []  # SWE-bench doesn't specify exact tools
                },
                evaluation={
                    "scoring_method": "patch_apply"
                },
                metadata={
                    "repo": repo,
                    "base_commit": base_commit,
                    "source": "swebench"
                }
            )
            questions.append(q)

        return CommonDataset(
            name="SWE-bench",
            eval_type="agent",
            category="Software Engineering",
            questions=questions
        )


# Register adapter
AdapterRegistry.register("swebench", SWEBenchAdapter)
