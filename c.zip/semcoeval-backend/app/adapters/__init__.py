"""
Dataset Adapters - Transform various benchmark formats to common schema.

Supported Benchmarks:
- GAIA: Multi-step reasoning with tools
- BFCL: Berkeley Function Calling Leaderboard
- SWE-bench: Software Engineering tasks
- ToolBench: API tool usage
- HumanEval: Code generation
- MMLU: Multiple choice knowledge
"""
from app.adapters.base import BaseAdapter, AdapterRegistry, CommonDataset, CommonQuestion
from app.adapters.gaia import GAIAAdapter
from app.adapters.bfcl import BFCLAdapter
from app.adapters.swebench import SWEBenchAdapter
from app.adapters.toolbench import ToolBenchAdapter
from app.adapters.humaneval import HumanEvalAdapter
from app.adapters.mmlu import MMLUAdapter


def get_adapter(name: str) -> BaseAdapter:
    """Get adapter by benchmark name."""
    adapter = AdapterRegistry.get(name)
    if not adapter:
        raise ValueError(f"Unknown adapter: {name}. Available: {AdapterRegistry.list_adapters()}")
    return adapter


__all__ = [
    "BaseAdapter",
    "AdapterRegistry",
    "CommonDataset",
    "CommonQuestion",
    "GAIAAdapter",
    "BFCLAdapter",
    "SWEBenchAdapter",
    "ToolBenchAdapter",
    "HumanEvalAdapter",
    "MMLUAdapter",
    "get_adapter",
]
