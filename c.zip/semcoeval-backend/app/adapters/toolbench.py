"""ToolBench adapter - API tool usage evaluation."""
from app.adapters.base import BaseAdapter, CommonDataset, CommonQuestion, AdapterRegistry


class ToolBenchAdapter(BaseAdapter):
    """
    Adapter for ToolBench API tool usage benchmark.

    ToolBench format:
    - API definitions (OpenAPI style)
    - User instructions
    - Expected API call sequences
    """

    @property
    def name(self) -> str:
        return "toolbench"

    @property
    def eval_type(self) -> str:
        return "agent"

    def transform(self, raw_data: list[dict]) -> CommonDataset:
        """Transform ToolBench data to common format."""
        questions = []

        for i, item in enumerate(raw_data):
            query = item.get("query", item.get("instruction", ""))
            apis = item.get("api_list", item.get("tools", []))
            answer_path = item.get("answer_path", item.get("solution", []))

            # Convert APIs to tools format
            tools = []
            for api in apis:
                tool = {
                    "name": api.get("name", api.get("api_name", "")),
                    "description": api.get("description", api.get("api_description", "")),
                    "parameters": api.get("parameters", api.get("required_parameters", {}))
                }
                tools.append(tool)

            # Convert answer path to expected calls
            expected_calls = []
            if isinstance(answer_path, list):
                for step in answer_path:
                    if isinstance(step, dict):
                        expected_calls.append({
                            "name": step.get("api_name", step.get("name", "")),
                            "arguments": step.get("parameters", step.get("arguments", {}))
                        })
                    elif isinstance(step, str):
                        expected_calls.append({"name": step, "arguments": {}})

            q = CommonQuestion(
                id=item.get("qid", f"toolbench-{i}"),
                eval_type="agent",
                input={
                    "prompt": query,
                    "available_tools": tools,
                    "tool_responses": item.get("api_responses", {})
                },
                expected={
                    "tool_calls": expected_calls,
                    "max_tool_calls": len(expected_calls) + 2  # Allow some flexibility
                },
                evaluation={
                    "scoring_method": "tool_sequence_match"
                },
                metadata={
                    "category": item.get("category", ""),
                    "source": "toolbench"
                }
            )
            questions.append(q)

        return CommonDataset(
            name="ToolBench",
            eval_type="agent",
            category="API Tool Usage",
            questions=questions
        )


# Register adapter
AdapterRegistry.register("toolbench", ToolBenchAdapter)
