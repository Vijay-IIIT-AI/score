"""HumanEval benchmark adapter - Code generation evaluation."""
from app.adapters.base import BaseAdapter, CommonDataset, CommonQuestion, AdapterRegistry


class HumanEvalAdapter(BaseAdapter):
    """
    Adapter for HumanEval code generation benchmark.

    HumanEval format:
    - Function signature and docstring
    - Test cases for validation
    - Canonical solution
    """

    @property
    def name(self) -> str:
        return "humaneval"

    @property
    def eval_type(self) -> str:
        return "model"

    def transform(self, raw_data: list[dict]) -> CommonDataset:
        """Transform HumanEval data to common format."""
        questions = []

        for i, item in enumerate(raw_data):
            task_id = item.get("task_id", f"HumanEval/{i}")
            prompt = item.get("prompt", "")
            canonical = item.get("canonical_solution", "")
            test = item.get("test", "")
            entry_point = item.get("entry_point", "")

            # Build full prompt
            full_prompt = f"""Complete the following Python function:

{prompt}

Write only the function body. Do not include the function signature or any explanation."""

            q = CommonQuestion(
                id=task_id,
                eval_type="model",
                input={
                    "prompt": full_prompt,
                    "system_prompt": "You are an expert Python programmer. Complete the function based on the docstring."
                },
                expected={
                    "answer": canonical,
                    "test_code": test,
                    "entry_point": entry_point
                },
                evaluation={
                    "scoring_method": "code_execution"
                },
                metadata={
                    "language": "python",
                    "source": "humaneval"
                }
            )
            questions.append(q)

        return CommonDataset(
            name="HumanEval",
            eval_type="model",
            category="Coding",
            questions=questions
        )


# Register adapter
AdapterRegistry.register("humaneval", HumanEvalAdapter)
