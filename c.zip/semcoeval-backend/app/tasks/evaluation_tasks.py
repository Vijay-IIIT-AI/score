"""Celery tasks for running evaluations."""
import json
from datetime import datetime
from io import BytesIO

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.config import settings
from app.tasks.celery_app import celery_app
from app.storage import storage
from app.evaluators import get_evaluator, EvalStatus
from app.services.crypto import decrypt_api_key

# Sync engine for Celery tasks
sync_engine = create_engine(
    settings.database_url.replace("+asyncpg", ""),
    pool_pre_ping=True
)
SyncSession = sessionmaker(bind=sync_engine)


@celery_app.task(bind=True, name="run_evaluation")
def run_evaluation(self, evaluation_id: str, user_id: int):
    """Run an evaluation job using SemcoEval."""
    from app.models.evaluation import Evaluation, EvaluationStatus, EvaluationResult
    from app.models.dataset import Dataset
    from app.models.provider import UserProviderConnection
    from app.models.ai_model import AIModel

    db = SyncSession()
    evaluation = None

    try:
        # Get evaluation
        evaluation = db.query(Evaluation).filter(Evaluation.id == evaluation_id).first()
        if not evaluation:
            return {"error": "Evaluation not found"}

        # Update status
        evaluation.status = EvaluationStatus.RUNNING
        evaluation.started_at = datetime.utcnow()
        evaluation.celery_task_id = self.request.id
        db.commit()

        # Get dataset
        dataset = db.query(Dataset).filter(Dataset.id == evaluation.dataset_id).first()
        if not dataset:
            raise ValueError("Dataset not found")

        # Download dataset from MinIO
        dataset_bytes = storage.download_file(dataset.file_path)
        if not dataset_bytes:
            raise ValueError("Dataset file not found in storage")

        dataset_content = json.loads(dataset_bytes.decode("utf-8"))

        # Filter questions by subgroup if specified
        if evaluation.subgroup:
            questions = dataset_content.get("questions", [])
            filtered_questions = [
                q for q in questions
                if q.get("subgroup") == evaluation.subgroup or
                   q.get("metadata", {}).get("subgroup") == evaluation.subgroup
            ]
            dataset_content["questions"] = filtered_questions

        total_questions = len(dataset_content.get("questions", []))
        evaluation.total_questions = total_questions
        db.commit()

        # Get model configs with API keys
        model_configs = []
        for model_id in evaluation.model_ids:
            model = db.query(AIModel).filter(AIModel.id == model_id).first()
            if not model:
                continue

            # Get user's API key for this provider
            connection = db.query(UserProviderConnection).filter(
                UserProviderConnection.user_id == user_id,
                UserProviderConnection.provider_id == model.provider_id
            ).first()

            api_key = None
            if connection and connection.api_key_encrypted:
                api_key = decrypt_api_key(connection.api_key_encrypted)

            model_configs.append({
                "model_id": model.id,
                "provider": model.provider.name.lower() if model.provider else "openrouter",
                "api_key": api_key
            })

        if not model_configs:
            raise ValueError("No valid models found for evaluation")

        # Get evaluator for this eval type
        evaluator = get_evaluator(evaluation.eval_type)

        # Set up progress callback
        def progress_callback(progress):
            self.update_state(
                state="PROGRESS",
                meta={"current": progress.current, "total": progress.total, "message": progress.message}
            )
            # Update evaluation progress
            evaluation.progress = progress.current
            db.commit()

        evaluator.set_progress_callback(progress_callback)

        # Run evaluation
        result = evaluator.evaluate(
            dataset_content=dataset_content,
            model_configs=model_configs,
            metrics_config=evaluation.metrics_config or {},
            evaluation_id=evaluation_id
        )

        # Store results
        if result.status == EvalStatus.COMPLETED:
            evaluation.status = EvaluationStatus.COMPLETED
            evaluation.top_model = result.top_model
            evaluation.top_score = result.top_score

            # Create EvaluationResult ORM records for each model
            for rank, score in enumerate(result.scores, start=1):
                eval_result = EvaluationResult(
                    evaluation_id=evaluation_id,
                    model_id=score.model_id,
                    rank=rank,
                    score=score.overall_score,
                    accuracy=score.overall_score,  # Use overall_score as accuracy
                    passed_tests=score.passed_tests,
                    failed_tests=score.failed_tests,
                    total_tests=score.total_tests,
                    scores=score.metric_scores,
                    details=score.details,  # Per-question results
                    status="completed"
                )
                db.add(eval_result)
        else:
            evaluation.status = EvaluationStatus.FAILED
            evaluation.error_message = result.error_message

        evaluation.completed_at = datetime.utcnow()
        evaluation.progress = total_questions
        db.commit()

        return {"status": "completed", "evaluation_id": evaluation_id}

    except Exception as e:
        if evaluation:
            evaluation.status = EvaluationStatus.FAILED
            evaluation.error_message = str(e)
            evaluation.completed_at = datetime.utcnow()
            db.commit()
        return {"error": str(e)}
    finally:
        db.close()


@celery_app.task(name="generate_report")
def generate_report(evaluation_id: str, report_id: str):
    """Generate PDF report from evaluation results."""
    from app.models.report import Report
    from app.models.evaluation import Evaluation
    from app.models.provider import UserProviderConnection

    db = SyncSession()
    try:
        report = db.query(Report).filter(Report.id == report_id).first()
        if not report:
            return {"error": "Report not found"}

        evaluation = db.query(Evaluation).filter(Evaluation.id == evaluation_id).first()
        if not evaluation:
            report.status = "failed"
            db.commit()
            return {"error": "Evaluation not found"}

        # Get user's OpenRouter API key for LLM analysis
        user_api_key = None
        connection = db.query(UserProviderConnection).filter(
            UserProviderConnection.user_id == evaluation.user_id,
            UserProviderConnection.provider_id == "openrouter"
        ).first()

        if connection and connection.api_key_encrypted:
            user_api_key = decrypt_api_key(connection.api_key_encrypted)

        # Generate PDF using ReportLab with LLM analysis
        pdf_content = _generate_pdf_report(evaluation, report, user_api_key=user_api_key)

        # Upload to MinIO
        path = f"reports/{report_id}/report.pdf"
        storage.upload_file(path, pdf_content, "application/pdf")

        report.file_path = path
        report.status = "completed"
        db.commit()

        return {"status": "completed", "report_id": report_id}

    except Exception as e:
        if report:
            report.status = "failed"
            db.commit()
        return {"error": str(e)}
    finally:
        db.close()


def _generate_pdf_report(evaluation, report, user_api_key: str = None) -> bytes:
    """Generate a comprehensive, professional PDF report from evaluation results with AI analysis."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch, cm
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, HRFlowable, ListFlowable, ListItem, KeepTogether
    )
    from reportlab.graphics.shapes import Drawing, Rect, String
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from reportlab.graphics.charts.piecharts import Pie

    # Initialize LLM service for AI-powered analysis
    llm_service = None
    llm_enabled = getattr(settings, 'report_llm_enabled', True)

    if llm_enabled:
        try:
            from app.services.report_llm_service import ReportLLMService, LLMConfig

            # Use user's API key if available, otherwise fall back to system config
            api_key = user_api_key or getattr(settings, 'report_llm_api_key', None)

            if api_key:
                llm_config = LLMConfig(
                    provider=getattr(settings, 'report_llm_provider', 'openrouter'),
                    model_id=getattr(settings, 'report_llm_model', 'google/gemini-flash-1.5'),
                    api_key=api_key,
                    base_url=getattr(settings, 'report_llm_base_url', 'https://openrouter.ai/api/v1'),
                    max_tokens=getattr(settings, 'report_llm_max_tokens', 1000),
                    temperature=getattr(settings, 'report_llm_temperature', 0.3)
                )
                llm_service = ReportLLMService(llm_config)
        except Exception:
            llm_service = None

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=0.75*inch,
        bottomMargin=0.75*inch,
        leftMargin=0.75*inch,
        rightMargin=0.75*inch
    )

    # Custom styles
    styles = getSampleStyleSheet()

    # Define custom colors
    PRIMARY_COLOR = colors.HexColor("#1a73e8")
    SECONDARY_COLOR = colors.HexColor("#34a853")
    ACCENT_COLOR = colors.HexColor("#ea4335")
    DARK_COLOR = colors.HexColor("#202124")
    LIGHT_BG = colors.HexColor("#f8f9fa")
    SUCCESS_COLOR = colors.HexColor("#34a853")
    WARNING_COLOR = colors.HexColor("#fbbc04")
    ERROR_COLOR = colors.HexColor("#ea4335")

    # Custom paragraph styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=28,
        spaceAfter=6,
        spaceBefore=0,
        textColor=DARK_COLOR,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )

    subtitle_style = ParagraphStyle(
        'Subtitle',
        parent=styles['Normal'],
        fontSize=12,
        spaceAfter=20,
        textColor=colors.grey,
        alignment=TA_CENTER
    )

    section_header = ParagraphStyle(
        'SectionHeader',
        parent=styles['Heading2'],
        fontSize=16,
        spaceBefore=20,
        spaceAfter=12,
        textColor=PRIMARY_COLOR,
        fontName='Helvetica-Bold',
        borderPadding=5
    )

    subsection_header = ParagraphStyle(
        'SubsectionHeader',
        parent=styles['Heading3'],
        fontSize=13,
        spaceBefore=15,
        spaceAfter=8,
        textColor=DARK_COLOR,
        fontName='Helvetica-Bold'
    )

    body_style = ParagraphStyle(
        'BodyText',
        parent=styles['Normal'],
        fontSize=10,
        spaceAfter=8,
        textColor=DARK_COLOR,
        alignment=TA_JUSTIFY,
        leading=14
    )

    metric_label = ParagraphStyle(
        'MetricLabel',
        parent=styles['Normal'],
        fontSize=9,
        textColor=colors.grey
    )

    metric_value = ParagraphStyle(
        'MetricValue',
        parent=styles['Normal'],
        fontSize=14,
        fontName='Helvetica-Bold',
        textColor=DARK_COLOR
    )

    story = []

    # ========== COVER / HEADER SECTION ==========
    story.append(Spacer(1, 0.5*inch))

    # Logo placeholder and title
    story.append(Paragraph("SEMCOEVAL", ParagraphStyle(
        'Logo', fontSize=14, textColor=PRIMARY_COLOR, fontName='Helvetica-Bold', alignment=TA_CENTER
    )))
    story.append(Spacer(1, 0.3*inch))
    story.append(Paragraph(report.title, title_style))

    # Evaluation type badge
    eval_type_display = {
        "model": "Model Evaluation",
        "agent": "Agent Evaluation",
        "rag": "RAG Evaluation"
    }.get(evaluation.eval_type, evaluation.eval_type.upper())

    story.append(Paragraph(eval_type_display, subtitle_style))
    story.append(HRFlowable(width="100%", thickness=2, color=PRIMARY_COLOR, spaceBefore=10, spaceAfter=20))

    # ========== EXECUTIVE SUMMARY ==========
    story.append(Paragraph("Executive Summary", section_header))

    eval_results = list(evaluation.results) if evaluation.results else []
    top_score = evaluation.top_score or 0
    total_passed = sum(r.passed_tests for r in eval_results)
    total_failed = sum(r.failed_tests for r in eval_results)
    total_tests = sum(r.total_tests for r in eval_results)
    pass_rate = (total_passed / total_tests * 100) if total_tests > 0 else 0

    # Summary text - use LLM if available, otherwise use template
    if llm_service:
        # Prepare model results for LLM analysis
        model_results_data = []
        for r in eval_results:
            model_results_data.append({
                "model_id": r.model_id,
                "score": r.score,
                "passed_tests": r.passed_tests,
                "failed_tests": r.failed_tests
            })

        summary_text = llm_service.generate_executive_summary(
            eval_type=evaluation.eval_type,
            total_questions=evaluation.total_questions,
            top_score=top_score,
            pass_rate=pass_rate,
            model_results=model_results_data
        )
        # Add AI badge
        story.append(Paragraph(
            '<font color="#1a73e8" size="8">✨ AI-Generated Analysis</font>',
            ParagraphStyle('AIBadge', fontSize=8, alignment=TA_LEFT, spaceAfter=5)
        ))
    else:
        # Fallback to template-based summary
        if evaluation.eval_type == "model":
            summary_text = f"""
            This report presents the results of a <b>Model Evaluation</b> conducted using the SemcoEval framework.
            The evaluation assessed the model's ability to provide accurate and relevant responses to a set of
            {evaluation.total_questions} test questions. The evaluation measures response accuracy by comparing
            model outputs against expected answers using keyword matching and semantic analysis.
            """
        elif evaluation.eval_type == "agent":
            summary_text = f"""
            This report presents the results of an <b>Agent Evaluation</b> conducted using the SemcoEval framework.
            The evaluation assessed the model's ability to correctly identify and use the appropriate tools
            for {evaluation.total_questions} different scenarios. Agent evaluations measure tool selection accuracy
            and the model's understanding of when to use specific tools based on user requests.
            """
        elif evaluation.eval_type == "rag":
            summary_text = f"""
            This report presents the results of a <b>RAG (Retrieval-Augmented Generation) Evaluation</b>
            conducted using the SemcoEval framework. The evaluation assessed the model's ability to generate
            accurate, faithful responses based on provided context documents across {evaluation.total_questions}
            test cases. RAG evaluations measure faithfulness to source material and hallucination detection.
            """
        else:
            summary_text = f"""
            This report presents the evaluation results for {evaluation.total_questions} test cases
            using the SemcoEval framework.
            """

    story.append(Paragraph(summary_text.strip(), body_style))
    story.append(Spacer(1, 15))

    # Key metrics cards (as a table)
    def format_score(score):
        if score >= 0.9:
            return f'<font color="#{SUCCESS_COLOR.hexval()[2:]}">{score:.1%}</font>'
        elif score >= 0.7:
            return f'<font color="#{WARNING_COLOR.hexval()[2:]}">{score:.1%}</font>'
        else:
            return f'<font color="#{ERROR_COLOR.hexval()[2:]}">{score:.1%}</font>'

    metrics_data = [
        [
            Paragraph("<b>Overall Score</b>", metric_label),
            Paragraph("<b>Pass Rate</b>", metric_label),
            Paragraph("<b>Total Tests</b>", metric_label),
            Paragraph("<b>Models Tested</b>", metric_label)
        ],
        [
            Paragraph(f"<b>{top_score:.1%}</b>", metric_value),
            Paragraph(f"<b>{pass_rate:.1f}%</b>", metric_value),
            Paragraph(f"<b>{total_tests}</b>", metric_value),
            Paragraph(f"<b>{len(eval_results)}</b>", metric_value)
        ]
    ]

    metrics_table = Table(metrics_data, colWidths=[1.5*inch]*4)
    metrics_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), LIGHT_BG),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor("#dadce0")),
        ('LINEABOVE', (0, 1), (-1, 1), 1, colors.HexColor("#dadce0")),
    ]))
    story.append(metrics_table)
    story.append(Spacer(1, 20))

    # ========== EVALUATION DETAILS ==========
    story.append(Paragraph("Evaluation Details", section_header))

    details_data = [
        ["Property", "Value"],
        ["Evaluation ID", evaluation.id],
        ["Evaluation Type", eval_type_display],
        ["Dataset ID", evaluation.dataset_id],
        ["Total Questions", str(evaluation.total_questions)],
        ["Status", evaluation.status.value.upper() if hasattr(evaluation.status, 'value') else str(evaluation.status).upper()],
        ["Created At", evaluation.created_at.strftime("%Y-%m-%d %H:%M UTC") if evaluation.created_at else "N/A"],
        ["Completed At", evaluation.completed_at.strftime("%Y-%m-%d %H:%M UTC") if evaluation.completed_at else "N/A"],
    ]

    if evaluation.subgroup:
        details_data.append(["Subgroup Filter", evaluation.subgroup])

    details_table = Table(details_data, colWidths=[2*inch, 4*inch])
    details_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BACKGROUND', (0, 1), (0, -1), LIGHT_BG),
        ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#dadce0")),
    ]))
    story.append(details_table)

    # ========== METHODOLOGY SECTION ==========
    story.append(Paragraph("Evaluation Methodology", section_header))

    # Use LLM for methodology if available
    if llm_service:
        methodology_text = llm_service.generate_methodology_explanation(evaluation.eval_type)
        story.append(Paragraph(
            '<font color="#1a73e8" size="8">✨ AI-Generated Explanation</font>',
            ParagraphStyle('AIBadge', fontSize=8, alignment=TA_LEFT, spaceAfter=5)
        ))
    else:
        # Fallback to template-based methodology
        if evaluation.eval_type == "model":
            methodology_text = """
            <b>Model Evaluation Process:</b><br/><br/>
            <b>1. Input Processing:</b> Each test question is sent to the model with an optional system prompt
            to establish context and expected behavior.<br/><br/>
            <b>2. Response Generation:</b> The model generates a response based on the input prompt.<br/><br/>
            <b>3. Scoring:</b> Responses are evaluated using multiple methods:
            <br/>• <b>Exact Match:</b> Checks if the expected answer appears in the response
            <br/>• <b>Keyword Matching:</b> Verifies presence of required keywords
            <br/>• <b>Semantic Similarity:</b> Measures conceptual alignment with expected output<br/><br/>
            <b>4. Aggregation:</b> Individual scores are averaged to produce the final accuracy score.
            """
        elif evaluation.eval_type == "agent":
            methodology_text = """
            <b>Agent Evaluation Process:</b><br/><br/>
            <b>1. Scenario Presentation:</b> The model receives a user request along with a list of
            available tools and their descriptions.<br/><br/>
            <b>2. Tool Selection:</b> The model must identify which tool(s) should be used to fulfill
            the user's request.<br/><br/>
            <b>3. Scoring:</b> Tool selection is evaluated by:
            <br/>• <b>Tool Accuracy:</b> Whether the correct tools were identified
            <br/>• <b>Parameter Understanding:</b> If required parameters are recognized
            <br/>• <b>Sequence Correctness:</b> For multi-tool scenarios, proper ordering<br/><br/>
            <b>4. Aggregation:</b> Tool accuracy scores are averaged across all test cases.
            """
        elif evaluation.eval_type == "rag":
            methodology_text = """
            <b>RAG Evaluation Process:</b><br/><br/>
            <b>1. Context Retrieval:</b> Relevant context documents are provided to the model
            along with the user's question.<br/><br/>
            <b>2. Response Generation:</b> The model generates an answer based on the provided context.<br/><br/>
            <b>3. Scoring:</b> Responses are evaluated on multiple dimensions:
            <br/>• <b>Accuracy:</b> How well the answer matches the expected response
            <br/>• <b>Faithfulness:</b> Whether claims are supported by the provided context
            <br/>• <b>Hallucination Rate:</b> Percentage of claims not grounded in context<br/><br/>
            <b>4. Aggregation:</b> Metrics are combined to produce overall quality scores.
            """
        else:
            methodology_text = "Standard evaluation methodology was applied to assess model performance."

    story.append(Paragraph(methodology_text, body_style))

    # ========== MODEL PERFORMANCE RESULTS ==========
    story.append(PageBreak())
    story.append(Paragraph("Model Performance Results", section_header))

    if eval_results:
        # Leaderboard table
        story.append(Paragraph("Performance Leaderboard", subsection_header))

        leaderboard_data = [["Rank", "Model", "Score", "Accuracy", "Passed", "Failed", "Total"]]
        for r in sorted(eval_results, key=lambda x: x.rank):
            model_name = r.model_id
            if len(model_name) > 35:
                model_name = model_name[:32] + "..."

            score_color = SUCCESS_COLOR if (r.score or 0) >= 0.9 else (WARNING_COLOR if (r.score or 0) >= 0.7 else ERROR_COLOR)

            leaderboard_data.append([
                str(r.rank),
                model_name,
                f"{r.score:.1%}" if r.score else "N/A",
                f"{r.accuracy:.1%}" if r.accuracy else "N/A",
                str(r.passed_tests),
                str(r.failed_tests),
                str(r.total_tests)
            ])

        leaderboard_table = Table(leaderboard_data, colWidths=[0.5*inch, 2.5*inch, 0.8*inch, 0.8*inch, 0.6*inch, 0.6*inch, 0.6*inch])
        leaderboard_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, 1), colors.HexColor("#e8f5e9")),  # Highlight top model
            ('ROWBACKGROUNDS', (0, 2), (-1, -1), [colors.white, LIGHT_BG]),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#dadce0")),
        ]))
        story.append(leaderboard_table)
        story.append(Spacer(1, 20))

        # ========== DETAILED METRICS ==========
        story.append(Paragraph("Detailed Metrics Analysis", subsection_header))

        for r in sorted(eval_results, key=lambda x: x.rank):
            model_header = f"#{r.rank} - {r.model_id}"
            story.append(Paragraph(f"<b>{model_header}</b>", ParagraphStyle(
                'ModelHeader', fontSize=11, textColor=DARK_COLOR, fontName='Helvetica-Bold',
                spaceBefore=15, spaceAfter=8, backColor=LIGHT_BG, borderPadding=8
            )))

            if r.scores:
                # Create metrics explanation based on eval type
                metrics_rows = [["Metric", "Score", "Description"]]

                metric_descriptions = {
                    "accuracy": "Measures how accurately the model's response matches the expected answer",
                    "faithfulness": "Measures how well the response is grounded in the provided context",
                    "hallucination_rate": "Percentage of claims in the response not supported by context (lower is better)",
                    "tool_accuracy": "Accuracy of tool selection for the given task",
                    "relevancy": "How relevant the response is to the question asked",
                    "coherence": "Logical flow and consistency of the response"
                }

                for metric, score in r.scores.items():
                    description = metric_descriptions.get(metric, "Performance metric for this evaluation")
                    score_display = f"{score:.1%}" if metric != "hallucination_rate" else f"{score:.1%}"
                    metrics_rows.append([
                        metric.replace("_", " ").title(),
                        score_display,
                        description
                    ])

                metrics_detail_table = Table(metrics_rows, colWidths=[1.2*inch, 0.8*inch, 4*inch])
                metrics_detail_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#e3f2fd")),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('ALIGN', (0, 0), (1, -1), 'CENTER'),
                    ('ALIGN', (2, 0), (2, -1), 'LEFT'),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                    ('TOPPADDING', (0, 0), (-1, -1), 6),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#dadce0")),
                ]))
                story.append(metrics_detail_table)
            story.append(Spacer(1, 10))

        # ========== PER-QUESTION RESULTS ==========
        story.append(PageBreak())
        story.append(Paragraph("Per-Question Results", section_header))

        question_intro = """
        The following section provides detailed results for each test question, including the model's
        response, expected output, and individual scores. This allows for granular analysis of model
        performance across different types of questions.
        """
        story.append(Paragraph(question_intro, body_style))
        story.append(Spacer(1, 15))

        for r in sorted(eval_results, key=lambda x: x.rank):
            story.append(Paragraph(f"<b>Model: {r.model_id}</b>", subsection_header))

            details = r.details if hasattr(r, 'details') and r.details else []

            if details:
                for i, item in enumerate(details, 1):
                    # Question block
                    passed = item.get("passed", False)
                    status_color = SUCCESS_COLOR if passed else ERROR_COLOR
                    status_text = "PASSED" if passed else "FAILED"
                    score = item.get("score", 0)

                    question_block = []

                    # Question header with status
                    q_header = f"""
                    <b>Question {i}:</b> {item.get("test_id", f"Q{i}")}
                    <font color="#{status_color.hexval()[2:]}"> [{status_text}]</font>
                    <font color="#666666"> Score: {score:.1%}</font>
                    """
                    question_block.append(Paragraph(q_header, ParagraphStyle(
                        'QuestionHeader', fontSize=10, spaceBefore=10, spaceAfter=5,
                        backColor=colors.HexColor("#fafafa"), borderPadding=5
                    )))

                    # Input
                    input_text = item.get("input", "N/A")
                    if len(input_text) > 300:
                        input_text = input_text[:297] + "..."
                    question_block.append(Paragraph(f"<b>Input:</b> {input_text}", ParagraphStyle(
                        'QuestionField', fontSize=9, leftIndent=10, spaceAfter=3
                    )))

                    # Expected output
                    expected = item.get("expected", "N/A")
                    if expected:
                        if len(str(expected)) > 200:
                            expected = str(expected)[:197] + "..."
                        question_block.append(Paragraph(f"<b>Expected:</b> {expected}", ParagraphStyle(
                            'QuestionField', fontSize=9, leftIndent=10, spaceAfter=3, textColor=colors.HexColor("#1a73e8")
                        )))

                    # Actual output
                    output = item.get("output", "N/A")
                    if len(str(output)) > 300:
                        output = str(output)[:297] + "..."
                    question_block.append(Paragraph(f"<b>Model Response:</b> {output}", ParagraphStyle(
                        'QuestionField', fontSize=9, leftIndent=10, spaceAfter=8,
                        textColor=SUCCESS_COLOR if passed else ERROR_COLOR
                    )))

                    # Add tools matched for agent evaluations
                    if "tools_matched" in item:
                        tools = ", ".join(item.get("tools_matched", []))
                        question_block.append(Paragraph(f"<b>Tools Identified:</b> {tools}", ParagraphStyle(
                            'QuestionField', fontSize=9, leftIndent=10, spaceAfter=8
                        )))

                    story.append(KeepTogether(question_block))

            else:
                story.append(Paragraph("<i>No detailed question results available for this model.</i>", body_style))

            story.append(Spacer(1, 15))

    else:
        story.append(Paragraph("No evaluation results available.", body_style))

    # ========== RECOMMENDATIONS ==========
    story.append(PageBreak())
    story.append(Paragraph("Analysis & Recommendations", section_header))

    if eval_results:
        best_result = sorted(eval_results, key=lambda x: x.rank)[0]
        best_score = best_result.score or 0

        # Use LLM for intelligent recommendations if available
        if llm_service:
            story.append(Paragraph(
                '<font color="#1a73e8" size="8">✨ AI-Generated Analysis & Recommendations</font>',
                ParagraphStyle('AIBadge', fontSize=8, alignment=TA_LEFT, spaceAfter=10)
            ))

            # Prepare data for LLM analysis
            model_results_data = []
            all_question_results = []
            for r in eval_results:
                result_dict = {
                    "model_id": r.model_id,
                    "score": r.score,
                    "passed_tests": r.passed_tests,
                    "failed_tests": r.failed_tests,
                    "details": r.details if hasattr(r, 'details') else []
                }
                model_results_data.append(result_dict)
                if hasattr(r, 'details') and r.details:
                    all_question_results.extend(r.details)

            # Generate AI analysis for each model
            story.append(Paragraph("<b>Per-Model Analysis:</b>", subsection_header))
            for r in sorted(eval_results, key=lambda x: x.rank)[:3]:  # Top 3 models
                question_results = r.details if hasattr(r, 'details') and r.details else []
                if question_results:
                    analysis = llm_service.analyze_question_results(
                        eval_type=evaluation.eval_type,
                        question_results=question_results,
                        model_id=r.model_id
                    )
                    story.append(Paragraph(f"<b>{r.model_id[:50]}:</b>", ParagraphStyle(
                        'ModelName', fontSize=10, fontName='Helvetica-Bold', spaceBefore=10
                    )))
                    story.append(Paragraph(analysis, body_style))

            story.append(Spacer(1, 15))

            # Generate overall recommendations
            story.append(Paragraph("<b>Strategic Recommendations:</b>", subsection_header))
            recommendations = llm_service.generate_recommendations(
                eval_type=evaluation.eval_type,
                top_score=top_score,
                model_results=model_results_data,
                question_results=all_question_results
            )
            story.append(Paragraph(recommendations, body_style))

        else:
            # Fallback to template-based recommendations
            if best_score >= 0.95:
                performance_assessment = """
                <b>Excellent Performance:</b> The evaluated model demonstrated outstanding performance,
                achieving near-perfect scores across all test cases. The model is well-suited for
                production deployment in this use case.
                """
            elif best_score >= 0.85:
                performance_assessment = """
                <b>Good Performance:</b> The evaluated model showed strong performance with room for
                minor improvements. Consider reviewing failed cases for specific edge cases that may
                need additional training or prompt engineering.
                """
            elif best_score >= 0.70:
                performance_assessment = """
                <b>Moderate Performance:</b> The model achieved acceptable results but has significant
                room for improvement. Review the failed test cases to identify patterns and consider
                additional fine-tuning or prompt optimization.
                """
            else:
                performance_assessment = """
                <b>Needs Improvement:</b> The model's performance is below expected thresholds.
                A thorough review of the evaluation results is recommended to identify systematic
                issues. Consider using a different model or significant prompt engineering improvements.
                """

            story.append(Paragraph(performance_assessment, body_style))
            story.append(Spacer(1, 15))

            # Specific recommendations based on eval type
            if evaluation.eval_type == "rag":
                recommendations = """
                <b>RAG-Specific Recommendations:</b><br/>
                • Review questions with low faithfulness scores for potential context retrieval issues<br/>
                • Analyze hallucination patterns to improve grounding in source material<br/>
                • Consider expanding context windows or improving retrieval relevance<br/>
                • Test with different chunking strategies if hallucination rate is high
                """
            elif evaluation.eval_type == "agent":
                recommendations = """
                <b>Agent-Specific Recommendations:</b><br/>
                • Review tool descriptions for clarity if tool selection accuracy is low<br/>
                • Consider adding examples in system prompts for complex tool scenarios<br/>
                • Test multi-tool workflows separately to identify sequencing issues<br/>
                • Verify parameter extraction accuracy for tools with complex inputs
                """
            else:
                recommendations = """
                <b>Model Evaluation Recommendations:</b><br/>
                • Review failed cases for common patterns in misunderstanding<br/>
                • Consider prompt engineering to improve response formatting<br/>
                • Test with different temperature settings for more consistent outputs<br/>
                • Evaluate with additional test cases to ensure robustness
                """

            story.append(Paragraph(recommendations, body_style))

    # ========== FOOTER ==========
    story.append(Spacer(1, 30))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#dadce0")))
    story.append(Spacer(1, 10))

    footer_style = ParagraphStyle('Footer', fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph(
        f"Generated by SemcoEval Platform | {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
        footer_style
    ))
    story.append(Paragraph(
        "This report is automatically generated and should be reviewed by a qualified professional.",
        footer_style
    ))

    doc.build(story)
    return buffer.getvalue()
