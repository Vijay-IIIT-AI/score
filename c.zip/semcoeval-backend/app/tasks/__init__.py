"""Celery tasks module."""
from app.tasks.celery_app import celery_app
from app.tasks.evaluation_tasks import run_evaluation, generate_report

__all__ = ["celery_app", "run_evaluation", "generate_report"]
