"""Evaluation schemas."""
from datetime import datetime
from typing import Any
from pydantic import BaseModel


class EvaluationCreate(BaseModel):
    name: str
    description: str | None = None
    eval_type: str
    dataset_id: str
    model_ids: list[str]
    subgroup: str | None = None  # Optional dataset subgroup to filter questions
    metrics_config: dict[str, Any] | None = None


class EvaluationResponse(BaseModel):
    id: str
    name: str
    description: str | None = None
    eval_type: str
    dataset_id: str
    model_ids: list[str]
    subgroup: str | None = None
    status: str
    progress: int
    total_questions: int
    top_model: str | None = None
    top_score: float | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None

    model_config = {"from_attributes": True}


class EvaluationListResponse(BaseModel):
    evaluations: list[EvaluationResponse]
    total: int


class EvaluationStatus(BaseModel):
    status: str
    progress: int
    total: int
    celery_state: dict[str, Any] = {}
    error_message: str | None = None


class ModelResult(BaseModel):
    model_id: str
    provider: str | None = None
    rank: int
    score: float | None = None
    accuracy: float | None = None
    passed_tests: int = 0
    failed_tests: int = 0
    total_tests: int = 0
    metric_scores: dict[str, float] = {}

    model_config = {"from_attributes": True}


class EvaluationResults(BaseModel):
    evaluation_id: str
    status: str
    top_model: str | None = None
    top_score: float | None = None
    results: list[ModelResult]
