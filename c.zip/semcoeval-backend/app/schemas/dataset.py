"""Dataset schemas."""
from datetime import datetime
from pydantic import BaseModel
from typing import Any


class DatasetResponse(BaseModel):
    id: str
    name: str
    category: str
    eval_type: str
    question_count: int
    schema_version: str | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class DatasetListResponse(BaseModel):
    datasets: list[DatasetResponse]
    total: int


class ValidationResult(BaseModel):
    valid: bool
    errors: list[str] = []
    warnings: list[str] = []
    question_count: int = 0


class DatasetPreview(BaseModel):
    dataset_id: str
    questions: list[dict[str, Any]]
    total: int
