"""AI Model schemas."""
from pydantic import BaseModel


class ModelResponse(BaseModel):
    id: str
    name: str
    provider_id: str
    category: str | None = None
    capabilities: list[str] = []
    context_window: int | None = None
    input_price: float | None = None
    output_price: float | None = None
    accuracy_score: float | None = None
    agent_score: float | None = None
    is_active: bool = True

    model_config = {"from_attributes": True}


class ModelListResponse(BaseModel):
    models: list[ModelResponse]
    total: int
