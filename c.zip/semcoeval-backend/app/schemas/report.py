"""Report schemas."""
from datetime import datetime
from typing import Any
from pydantic import BaseModel


class ReportCreate(BaseModel):
    evaluation_id: str
    title: str | None = None


class ReportResponse(BaseModel):
    id: str
    title: str
    evaluation_id: str
    status: str
    file_path: str | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class ReportListResponse(BaseModel):
    reports: list[ReportResponse]
    total: int


class ModelComparisonRequest(BaseModel):
    """Request for model comparison report."""
    evaluation_ids: list[str]
    title: str | None = None


class ModelMetricScore(BaseModel):
    """Metric scores for a single model."""
    model_id: str
    evaluation_id: str
    evaluation_name: str
    rank: int
    score: float | None = None
    accuracy: float | None = None
    passed_tests: int = 0
    failed_tests: int = 0
    total_tests: int = 0
    metric_scores: dict[str, float] = {}


class MetricComparison(BaseModel):
    """Comparison data for a single metric across all models."""
    metric_name: str
    scores: dict[str, float]  # model_id -> score


class ModelComparisonResponse(BaseModel):
    """Response for model comparison report."""
    title: str
    evaluation_ids: list[str]
    models: list[ModelMetricScore]
    metric_breakdown: list[MetricComparison]
    summary: dict[str, Any]
