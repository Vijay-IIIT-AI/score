"""Job schemas for evaluation job monitoring."""
from datetime import datetime
from typing import Any
from pydantic import BaseModel


class JobResponse(BaseModel):
    """Response model for a single evaluation job."""
    job_id: str
    evaluation_id: str
    name: str
    eval_type: str
    status: str
    progress: int
    total: int
    celery_task_id: str | None = None
    celery_state: str | None = None
    celery_progress: dict[str, Any] = {}
    error_message: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None

    model_config = {"from_attributes": True}


class JobListResponse(BaseModel):
    """Response model for list of jobs."""
    jobs: list[JobResponse]
    total: int
    limit: int
    offset: int
