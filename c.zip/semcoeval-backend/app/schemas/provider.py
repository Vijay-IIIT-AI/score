"""Provider schemas."""
from pydantic import BaseModel, Field


class ProviderResponse(BaseModel):
    id: str
    name: str
    description: str | None = None
    logo_url: str | None = Field(default=None, validation_alias="logo")
    base_url: str | None = None
    model_count: int = 0

    model_config = {"from_attributes": True, "populate_by_name": True}


class ProviderListResponse(BaseModel):
    providers: list[ProviderResponse]
    total: int


class ProviderConnectRequest(BaseModel):
    api_key: str


class ConnectionResponse(BaseModel):
    status: str
    provider_id: str
    models_synced: int | None = None
