"""Auth schemas."""
from typing import Optional
from pydantic import BaseModel, Field


class SSOLoginRequest(BaseModel):
    """SSO login request."""
    aes_key: str
    user_info: str


class UserResult(BaseModel):
    """User result in login response."""
    token: str
    username: str
    email: str
    api_key: Optional[str] = None
    language: str = "en"
    profile_name: str


class SSOLoginResponse(BaseModel):
    """SSO login response."""
    status: str  # "success" or "error"
    message: Optional[str] = None
    result: Optional[UserResult] = None


class UserResponse(BaseModel):
    """User details response."""
    id: int
    username: str = Field(validation_alias="name")
    email: str
    role: str
    organization: Optional[str] = None
    avatar: Optional[str] = None
    language: str = "en"
    is_active: bool

    model_config = {"from_attributes": True, "populate_by_name": True}


class UserUpdate(BaseModel):
    """User update request."""
    username: Optional[str] = None
    organization: Optional[str] = None
    avatar: Optional[str] = None
    language: Optional[str] = None
