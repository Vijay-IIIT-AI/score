"""Base validator for dataset validation."""
from abc import ABC, abstractmethod
from typing import Any
from dataclasses import dataclass, field


@dataclass
class ValidationResult:
    """Result of dataset validation."""
    valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    question_count: int = 0

    def add_error(self, msg: str) -> None:
        self.errors.append(msg)
        self.valid = False

    def add_warning(self, msg: str) -> None:
        self.warnings.append(msg)

    def merge(self, other: "ValidationResult") -> None:
        self.errors.extend(other.errors)
        self.warnings.extend(other.warnings)
        if not other.valid:
            self.valid = False


class BaseValidator(ABC):
    """Abstract base class for dataset validators."""

    @property
    @abstractmethod
    def eval_type(self) -> str:
        """Return the evaluation type this validator handles."""
        pass

    @abstractmethod
    def validate_question(self, question: dict, index: int) -> ValidationResult:
        """Validate a single question."""
        pass

    def validate(self, data: dict) -> ValidationResult:
        """Validate a complete dataset."""
        result = ValidationResult()

        # Validate metadata
        metadata = data.get("metadata")
        if not metadata:
            result.add_error("Missing 'metadata' field")
        else:
            self._validate_metadata(metadata, result)

        # Validate questions
        questions = data.get("questions", [])
        if not questions:
            result.add_warning("Dataset has no questions")
        else:
            result.question_count = len(questions)
            for i, question in enumerate(questions):
                q_result = self.validate_question(question, i)
                result.merge(q_result)

        return result

    def _validate_metadata(self, metadata: dict, result: ValidationResult) -> None:
        """Validate dataset metadata."""
        if "name" not in metadata:
            result.add_warning("Missing 'name' in metadata")

        if "schema_version" not in metadata:
            result.add_warning("Missing 'schema_version' in metadata")

        eval_type = metadata.get("eval_type")
        if eval_type and eval_type != self.eval_type:
            result.add_error(
                f"Dataset eval_type '{eval_type}' does not match validator type '{self.eval_type}'"
            )

    def _require_field(
        self, obj: dict, field: str, result: ValidationResult, prefix: str = ""
    ) -> bool:
        """Check if required field exists, add error if not."""
        if field not in obj or obj[field] is None:
            result.add_error(f"{prefix}Missing required field '{field}'")
            return False
        return True

    def _require_type(
        self, obj: dict, field: str, expected_type: type, result: ValidationResult, prefix: str = ""
    ) -> bool:
        """Check if field has correct type."""
        if field not in obj:
            return True  # Field existence checked separately
        if not isinstance(obj[field], expected_type):
            result.add_error(
                f"{prefix}Field '{field}' must be {expected_type.__name__}, "
                f"got {type(obj[field]).__name__}"
            )
            return False
        return True
