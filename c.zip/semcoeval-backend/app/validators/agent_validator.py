"""Validator for agent evaluation datasets."""
from app.validators.base_validator import BaseValidator, ValidationResult


class AgentValidator(BaseValidator):
    """Validate agent evaluation datasets."""

    @property
    def eval_type(self) -> str:
        return "agent"

    def validate_question(self, question: dict, index: int) -> ValidationResult:
        result = ValidationResult()
        prefix = f"Question[{index}]: "

        # Check required fields
        self._require_field(question, "id", result, prefix)
        self._require_field(question, "input", result, prefix)
        self._require_field(question, "expected", result, prefix)

        # Validate input structure
        input_data = question.get("input", {})
        if isinstance(input_data, dict):
            if "prompt" not in input_data:
                result.add_error(f"{prefix}input must have 'prompt' field")

            # Validate available_tools
            tools = input_data.get("available_tools", [])
            if not isinstance(tools, list):
                result.add_error(f"{prefix}available_tools must be a list")
            else:
                for i, tool in enumerate(tools):
                    self._validate_tool_definition(tool, result, f"{prefix}available_tools[{i}]: ")

            # Validate tool_responses if present
            tool_responses = input_data.get("tool_responses", {})
            if tool_responses and not isinstance(tool_responses, dict):
                result.add_error(f"{prefix}tool_responses must be an object")

        else:
            result.add_error(f"{prefix}input must be an object")

        # Validate expected structure
        expected = question.get("expected", {})
        if isinstance(expected, dict):
            tool_calls = expected.get("tool_calls", [])

            if not tool_calls:
                result.add_warning(f"{prefix}expected.tool_calls is empty or missing")
            elif isinstance(tool_calls, list):
                for i, call in enumerate(tool_calls):
                    self._validate_expected_tool_call(
                        call, result, f"{prefix}expected.tool_calls[{i}]: "
                    )
            else:
                result.add_error(f"{prefix}expected.tool_calls must be a list")

            # Validate max_tool_calls if present
            max_calls = expected.get("max_tool_calls")
            if max_calls is not None and not isinstance(max_calls, int):
                result.add_error(f"{prefix}max_tool_calls must be an integer")

        else:
            result.add_error(f"{prefix}expected must be an object")

        return result

    def _validate_tool_definition(
        self, tool: dict, result: ValidationResult, prefix: str
    ) -> None:
        """Validate a tool definition in available_tools."""
        if not isinstance(tool, dict):
            result.add_error(f"{prefix}tool must be an object")
            return

        if "name" not in tool:
            result.add_error(f"{prefix}tool must have 'name' field")

        params = tool.get("parameters")
        if params is not None and not isinstance(params, dict):
            result.add_error(f"{prefix}parameters must be an object")

    def _validate_expected_tool_call(
        self, call: dict, result: ValidationResult, prefix: str
    ) -> None:
        """Validate an expected tool call."""
        if not isinstance(call, dict):
            result.add_error(f"{prefix}tool_call must be an object")
            return

        if "name" not in call:
            result.add_error(f"{prefix}tool_call must have 'name' field")

        required_params = call.get("required_params")
        if required_params is not None:
            if not isinstance(required_params, list):
                result.add_error(f"{prefix}required_params must be a list")
            elif not all(isinstance(p, str) for p in required_params):
                result.add_error(f"{prefix}required_params must be a list of strings")
