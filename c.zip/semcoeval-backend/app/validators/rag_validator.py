"""Validator for RAG evaluation datasets."""
from app.validators.base_validator import BaseValidator, ValidationResult


class RAGValidator(BaseValidator):
    """Validate RAG evaluation datasets."""

    @property
    def eval_type(self) -> str:
        return "rag"

    def validate_question(self, question: dict, index: int) -> ValidationResult:
        result = ValidationResult()
        prefix = f"Question[{index}]: "

        # Check required fields
        self._require_field(question, "id", result, prefix)
        self._require_field(question, "input", result, prefix)
        self._require_field(question, "expected", result, prefix)

        # Validate input structure
        input_data = question.get("input", {})
        if isinstance(input_data, dict):
            if "question" not in input_data:
                result.add_error(f"{prefix}input must have 'question' field")

            # Validate retrieved_contexts
            contexts = input_data.get("retrieved_contexts", [])
            if not isinstance(contexts, list):
                result.add_error(f"{prefix}retrieved_contexts must be a list")
            elif not contexts:
                result.add_warning(f"{prefix}retrieved_contexts is empty")
            else:
                for i, ctx in enumerate(contexts):
                    self._validate_context(ctx, result, f"{prefix}retrieved_contexts[{i}]: ")

        else:
            result.add_error(f"{prefix}input must be an object")

        # Validate expected structure
        expected = question.get("expected", {})
        if isinstance(expected, dict):
            if "answer" not in expected:
                result.add_warning(f"{prefix}expected.answer is missing")

            # Validate supporting_context_ids
            supporting = expected.get("supporting_context_ids", [])
            if supporting and not isinstance(supporting, list):
                result.add_error(f"{prefix}supporting_context_ids must be a list")

            # Validate forbidden_claims
            forbidden = expected.get("forbidden_claims", [])
            if forbidden:
                if not isinstance(forbidden, list):
                    result.add_error(f"{prefix}forbidden_claims must be a list")
                elif not all(isinstance(c, str) for c in forbidden):
                    result.add_error(f"{prefix}forbidden_claims must be a list of strings")

        elif not isinstance(expected, str):
            result.add_error(f"{prefix}expected must be an object or string")

        return result

    def _validate_context(
        self, ctx: dict, result: ValidationResult, prefix: str
    ) -> None:
        """Validate a context object."""
        if not isinstance(ctx, dict):
            result.add_error(f"{prefix}context must be an object")
            return

        if "id" not in ctx:
            result.add_warning(f"{prefix}context missing 'id' field")

        if "content" not in ctx:
            result.add_error(f"{prefix}context must have 'content' field")
        elif not isinstance(ctx["content"], str):
            result.add_error(f"{prefix}content must be a string")
        elif not ctx["content"].strip():
            result.add_warning(f"{prefix}content is empty")
