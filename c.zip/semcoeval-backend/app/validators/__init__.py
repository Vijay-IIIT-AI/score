"""Dataset validators for different evaluation types."""
from app.validators.base_validator import BaseValidator, ValidationResult
from app.validators.model_validator import ModelValidator
from app.validators.agent_validator import AgentValidator
from app.validators.rag_validator import RAGValidator

# Registry of validators by eval_type
VALIDATOR_REGISTRY = {
    "model": ModelValidator,
    "agent": AgentValidator,
    "rag": RAGValidator,
}


def get_validator(eval_type: str) -> BaseValidator:
    """Get validator for evaluation type."""
    validator_class = VALIDATOR_REGISTRY.get(eval_type)
    if not validator_class:
        raise ValueError(f"Unknown eval_type: {eval_type}")
    return validator_class()


__all__ = [
    "BaseValidator",
    "ValidationResult",
    "ModelValidator",
    "AgentValidator",
    "RAGValidator",
    "get_validator",
    "VALIDATOR_REGISTRY",
]
