"""Validator for model evaluation datasets."""
from app.validators.base_validator import BaseValidator, ValidationResult


VALID_SCORING_METHODS = {
    "exact_match",
    "contains_keywords",
    "semantic_similarity",
    "llm_judge",
    "multiple_choice",
}


class ModelValidator(BaseValidator):
    """Validate model evaluation datasets."""

    @property
    def eval_type(self) -> str:
        return "model"

    def validate_question(self, question: dict, index: int) -> ValidationResult:
        result = ValidationResult()
        prefix = f"Question[{index}]: "

        # Check required fields
        self._require_field(question, "id", result, prefix)
        self._require_field(question, "input", result, prefix)
        self._require_field(question, "expected", result, prefix)

        # Validate input structure
        input_data = question.get("input", {})
        if isinstance(input_data, dict):
            if "prompt" not in input_data and "question" not in input_data:
                result.add_error(f"{prefix}input must have 'prompt' or 'question' field")
        else:
            result.add_error(f"{prefix}input must be an object")

        # Validate expected structure
        expected = question.get("expected", {})
        if isinstance(expected, dict):
            has_answer = "answer" in expected
            has_keywords = "keywords_required" in expected
            has_choices = "correct_choice" in expected

            if not (has_answer or has_keywords or has_choices):
                result.add_error(
                    f"{prefix}expected must have 'answer', 'keywords_required', or 'correct_choice'"
                )

            # Validate keywords if present
            if has_keywords:
                keywords = expected["keywords_required"]
                if not isinstance(keywords, list):
                    result.add_error(f"{prefix}keywords_required must be a list")
                elif not keywords:
                    result.add_warning(f"{prefix}keywords_required is empty")

        elif not isinstance(expected, str):
            result.add_error(f"{prefix}expected must be an object or string")

        # Validate evaluation config if present
        evaluation = question.get("evaluation", {})
        if evaluation:
            scoring = evaluation.get("scoring_method")
            if scoring and scoring not in VALID_SCORING_METHODS:
                result.add_warning(
                    f"{prefix}Unknown scoring_method '{scoring}'. "
                    f"Valid options: {', '.join(VALID_SCORING_METHODS)}"
                )

        return result
