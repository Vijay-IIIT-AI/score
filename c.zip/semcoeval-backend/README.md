# SemcoEval Backend

FastAPI backend for the SemcoEval AI Model Evaluation Platform. Supports Model, Agent, and RAG evaluation types with hybrid LLM-powered report generation.

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Project Structure](#project-structure)
3. [Database Schema](#database-schema)
4. [API Endpoints](#api-endpoints)
5. [Dataset JSON Formats](#dataset-json-formats)
6. [Configuration](#configuration)
7. [Custom Providers & vLLM Support](#custom-providers--vllm-support)
8. [Deployment](#deployment)
9. [AI Agent Coding Guidelines](#ai-agent-coding-guidelines)

---

## Quick Start

### Docker (Recommended)

```bash
# Start all services
docker-compose up -d

# Run database migrations
docker-compose exec api alembic upgrade head

# View logs
docker-compose logs -f api
```

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Start PostgreSQL, Redis, MinIO via Docker
docker-compose up -d db redis minio

# Run migrations
alembic upgrade head

# Start API server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Start Celery worker (separate terminal)
celery -A app.tasks.celery_app worker --loglevel=info
```

### Service URLs

| Service | URL |
|---------|-----|
| API | http://localhost:8000 |
| Swagger Docs | http://localhost:8000/docs |
| MinIO Console | http://localhost:9001 |

---

## Project Structure

```
semcoeval-backend/
├── alembic/                          # Database migrations
│   ├── versions/                     # Migration files
│   └── env.py                        # Alembic configuration
│
├── app/
│   ├── main.py                       # FastAPI application entry point
│   ├── config.py                     # Settings & environment variables
│   ├── database.py                   # SQLAlchemy async setup
│   ├── dependencies.py               # FastAPI dependencies (auth, db)
│   │
│   ├── api/
│   │   └── v1/
│   │       ├── __init__.py           # Router aggregation
│   │       ├── auth.py               # SSO login, user profile
│   │       ├── providers.py          # Provider listing, API key connection
│   │       ├── models.py             # AI model listing, filtering
│   │       ├── datasets.py           # Dataset upload, validation, preview
│   │       ├── evaluations.py        # Evaluation CRUD, start/stop
│   │       ├── reports.py            # Report generation, PDF download
│   │       ├── jobs.py               # Background job status
│   │       └── admin.py              # Admin LLM configuration
│   │
│   ├── models/                       # SQLAlchemy ORM models
│   │   ├── user.py                   # User model with roles
│   │   ├── provider.py               # Provider model
│   │   ├── ai_model.py               # AIModel model
│   │   ├── dataset.py                # Dataset model
│   │   ├── evaluation.py             # Evaluation, EvaluationResult models
│   │   └── report.py                 # Report model
│   │
│   ├── schemas/                      # Pydantic request/response schemas
│   │   ├── auth.py                   # Auth schemas
│   │   ├── provider.py               # Provider schemas
│   │   ├── model.py                  # Model schemas
│   │   ├── dataset.py                # Dataset schemas
│   │   ├── evaluation.py             # Evaluation schemas
│   │   ├── report.py                 # Report schemas
│   │   └── job.py                    # Job status schemas
│   │
│   ├── services/                     # Business logic layer
│   │   ├── auth_service.py           # JWT, SSO decoding
│   │   ├── crypto.py                 # API key encryption/decryption
│   │   ├── model_sync.py             # Provider model synchronization
│   │   └── report_llm_service.py     # LLM-powered report analysis
│   │
│   ├── validators/                   # Dataset validation
│   │   ├── base_validator.py         # Abstract validator interface
│   │   ├── model_validator.py        # Model evaluation validator
│   │   ├── agent_validator.py        # Agent evaluation validator
│   │   └── rag_validator.py          # RAG evaluation validator
│   │
│   ├── evaluators/                   # Evaluation engines
│   │   ├── base_evaluator.py         # Abstract evaluator interface
│   │   ├── model_evaluator.py        # Text matching, keyword scoring
│   │   ├── agent_evaluator.py        # Tool call validation
│   │   └── rag_evaluator.py          # Context faithfulness scoring
│   │
│   ├── adapters/                     # External dataset format adapters
│   │   ├── base.py                   # Base adapter interface
│   │   ├── mmlu.py                   # MMLU format adapter
│   │   ├── humaneval.py              # HumanEval adapter
│   │   ├── gaia.py                   # GAIA benchmark adapter
│   │   ├── bfcl.py                   # BFCL adapter
│   │   ├── swebench.py               # SWE-Bench adapter
│   │   └── toolbench.py              # ToolBench adapter
│   │
│   ├── tasks/                        # Celery background tasks
│   │   ├── celery_app.py             # Celery configuration
│   │   └── evaluation_tasks.py       # Evaluation & report generation tasks
│   │
│   └── storage/                      # File storage
│       └── minio_client.py           # MinIO S3 client
│
├── datasets/                         # Dataset file storage
│   ├── official/                     # Pre-loaded official datasets
│   └── uploads/                      # User uploaded datasets
│
├── tests/                            # Test suite
│   ├── conftest.py                   # Pytest fixtures
│   └── test_e2e.py                   # End-to-end tests
│
├── docker-compose.yml                # Docker services configuration
├── Dockerfile                        # API container definition
├── requirements.txt                  # Python dependencies
└── .env.example                      # Environment template
```

---

## Database Schema

### Entity Relationship

```
users (1) ----< (N) user_provider_connections >---- (1) providers
                                                          |
                                                          v
users (1) ----< (N) evaluations                    ai_models (N)
                        |                                |
                        v                                |
              evaluation_results (N) >-------------------+
                        |
                        v
                   reports (N)
```

### Tables

#### users
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| sso_id | VARCHAR(255) | External SSO identifier |
| email | VARCHAR(255) | User email |
| name | VARCHAR(255) | Display name |
| role | ENUM | 'user', 'admin' |
| organization | VARCHAR(255) | Organization name |
| avatar | VARCHAR(500) | Avatar URL |
| language | VARCHAR(10) | Preferred language |
| is_active | BOOLEAN | Account status |
| created_at | TIMESTAMP | Creation time |

#### providers
| Column | Type | Description |
|--------|------|-------------|
| id | VARCHAR(50) | Primary key (e.g., 'openai', 'anthropic') |
| name | VARCHAR(100) | Display name |
| description | TEXT | Provider description |
| logo | VARCHAR(255) | Logo URL |
| base_url | VARCHAR(255) | API base URL |
| is_active | BOOLEAN | Provider availability |
| supports_streaming | BOOLEAN | Streaming support |
| supports_tool_calling | BOOLEAN | Tool calling support |

#### user_provider_connections
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| user_id | INTEGER | FK to users |
| provider_id | VARCHAR(50) | FK to providers |
| api_key_encrypted | TEXT | Encrypted API key (Fernet) |
| status | VARCHAR(20) | 'connected', 'disconnected', 'error' |
| last_validated | TIMESTAMP | Last successful validation |

#### ai_models
| Column | Type | Description |
|--------|------|-------------|
| id | VARCHAR(100) | Primary key (e.g., 'gpt-4o') |
| name | VARCHAR(200) | Display name |
| provider_id | VARCHAR(50) | FK to providers |
| capabilities | JSON | Array of capabilities |
| context_window | INTEGER | Max context tokens |
| input_price | DECIMAL | Price per 1M input tokens |
| output_price | DECIMAL | Price per 1M output tokens |
| category | VARCHAR(50) | 'chat', 'code', 'vision', etc. |
| is_active | BOOLEAN | Model availability |

#### datasets
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| name | VARCHAR(255) | Dataset name |
| description | TEXT | Dataset description |
| eval_type | VARCHAR(20) | 'model', 'agent', 'rag' |
| category | VARCHAR(100) | 'General', 'Coding', 'Finance', etc. |
| question_count | INTEGER | Number of questions |
| file_path | VARCHAR(500) | Storage path |
| schema_version | VARCHAR(10) | JSON schema version |
| is_official | BOOLEAN | Official vs user-uploaded |
| user_id | INTEGER | FK to users (if uploaded) |
| created_at | TIMESTAMP | Creation time |

#### evaluations
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| name | VARCHAR(255) | Evaluation name |
| description | TEXT | Evaluation description |
| eval_type | VARCHAR(20) | 'model', 'agent', 'rag' |
| dataset_id | INTEGER | FK to datasets |
| user_id | INTEGER | FK to users |
| status | VARCHAR(20) | 'pending', 'running', 'completed', 'failed' |
| progress | INTEGER | 0-100 percentage |
| celery_task_id | VARCHAR(100) | Background task ID |
| started_at | TIMESTAMP | Run start time |
| completed_at | TIMESTAMP | Run completion time |
| created_at | TIMESTAMP | Creation time |

#### evaluation_results
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| evaluation_id | INTEGER | FK to evaluations |
| model_id | VARCHAR(100) | FK to ai_models |
| rank | INTEGER | Ranking position |
| overall_score | DECIMAL | 0-100 score |
| metrics | JSON | Detailed metrics object |
| details | JSON | Per-question results array |
| execution_time_seconds | DECIMAL | Total run time |
| total_tokens | INTEGER | Total tokens used |
| total_cost | DECIMAL | Total API cost |

#### reports
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| evaluation_id | INTEGER | FK to evaluations |
| title | VARCHAR(255) | Report title |
| summary | TEXT | Executive summary |
| pdf_path | VARCHAR(500) | PDF storage path |
| status | VARCHAR(20) | 'pending', 'generating', 'ready', 'failed' |
| created_at | TIMESTAMP | Creation time |

---

## API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/sso_login` | Exchange SSO credentials for JWT |
| GET | `/api/v1/auth/me` | Get current user profile |
| PUT | `/api/v1/auth/me` | Update user profile |

### Providers

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/providers` | List all providers |
| GET | `/api/v1/providers/{id}` | Get provider details |
| POST | `/api/v1/providers/{id}/connect` | Connect with API key |
| DELETE | `/api/v1/providers/{id}/disconnect` | Disconnect provider |
| GET | `/api/v1/providers/connections` | List user connections |

### Models

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/models` | List all models |
| GET | `/api/v1/models?capability=tool_calling` | Filter by capability |
| GET | `/api/v1/models?provider_id=openai` | Filter by provider |
| GET | `/api/v1/models/{id}` | Get model details |

### Datasets

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/datasets` | List datasets |
| GET | `/api/v1/datasets/{id}` | Get dataset details |
| GET | `/api/v1/datasets/{id}/preview` | Preview questions |
| POST | `/api/v1/datasets/upload` | Upload new dataset |
| POST | `/api/v1/datasets/validate` | Validate without saving |
| DELETE | `/api/v1/datasets/{id}` | Delete dataset |

### Evaluations

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/evaluations` | List user evaluations |
| GET | `/api/v1/evaluations/{id}` | Get evaluation details |
| POST | `/api/v1/evaluations` | Create evaluation |
| POST | `/api/v1/evaluations/{id}/start` | Start evaluation run |
| POST | `/api/v1/evaluations/{id}/stop` | Stop running evaluation |
| GET | `/api/v1/evaluations/{id}/status` | Get progress status |
| GET | `/api/v1/evaluations/{id}/results` | Get results |
| DELETE | `/api/v1/evaluations/{id}` | Delete evaluation |

### Reports

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/reports` | List user reports |
| GET | `/api/v1/reports/{id}` | Get report details |
| POST | `/api/v1/reports` | Generate report from evaluation |
| GET | `/api/v1/reports/{id}/download` | Download PDF |
| DELETE | `/api/v1/reports/{id}` | Delete report |

### Admin (Admin role required)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/admin/report-llm-config` | Get LLM config |
| PUT | `/api/v1/admin/report-llm-config` | Update LLM config |
| POST | `/api/v1/admin/report-llm-config/test` | Test LLM connection |
| GET | `/api/v1/admin/available-models` | List available LLM models |

### Jobs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/jobs/{task_id}` | Get background job status |

---

## Dataset JSON Formats

### Universal Envelope Structure

All datasets must follow this structure:

```json
{
  "metadata": {
    "schema_version": "1.0",
    "name": "Dataset Name",
    "description": "Dataset description",
    "eval_type": "model | agent | rag",
    "category": "General | Coding | Finance | Medical",
    "question_count": 100
  },
  "questions": [...]
}
```

### Model Evaluation Question

```json
{
  "id": "q-001",
  "type": "model",
  "input": {
    "prompt": "What is the capital of France?",
    "system_prompt": "You are a helpful assistant."
  },
  "expected": {
    "answer": "Paris",
    "keywords_required": ["Paris"],
    "keywords_forbidden": ["London", "Berlin"]
  },
  "evaluation": {
    "scoring_method": "exact_match | contains_keywords | semantic_similarity",
    "case_sensitive": false,
    "partial_credit": true
  }
}
```

### Agent Evaluation Question

```json
{
  "id": "agent-001",
  "type": "agent",
  "input": {
    "prompt": "Get the current weather in San Francisco",
    "available_tools": [
      {
        "name": "get_weather",
        "description": "Get weather for a location",
        "parameters": {
          "type": "object",
          "properties": {
            "location": { "type": "string" }
          },
          "required": ["location"]
        }
      }
    ],
    "tool_responses": {
      "get_weather": { "temperature": 65, "condition": "sunny" }
    }
  },
  "expected": {
    "tool_calls": [
      {
        "name": "get_weather",
        "required_params": ["location"],
        "expected_values": { "location": "San Francisco" }
      }
    ],
    "max_tool_calls": 2,
    "final_answer_keywords": ["65", "sunny"]
  }
}
```

### RAG Evaluation Question

```json
{
  "id": "rag-001",
  "type": "rag",
  "input": {
    "question": "What is the company's return policy?",
    "retrieved_contexts": [
      {
        "id": "doc-1",
        "content": "Our return policy allows returns within 30 days of purchase with original receipt.",
        "source": "policies.pdf",
        "relevance_score": 0.95
      },
      {
        "id": "doc-2",
        "content": "Refunds are processed within 5-7 business days.",
        "source": "faq.pdf",
        "relevance_score": 0.82
      }
    ]
  },
  "expected": {
    "answer": "Returns are accepted within 30 days with receipt",
    "supporting_context_ids": ["doc-1"],
    "keywords_required": ["30 days", "receipt"],
    "forbidden_claims": ["60 days", "no receipt needed"]
  },
  "evaluation": {
    "check_faithfulness": true,
    "check_relevance": true,
    "check_completeness": true
  }
}
```

---

## Configuration

### Environment Variables

Create `.env` file from `.env.example`:

```bash
# Database
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/semcoeval

# Redis (Celery broker)
REDIS_URL=redis://localhost:6379/0

# MinIO Storage
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=semcoeval

# JWT Authentication
JWT_SECRET_KEY=your-secret-key-minimum-32-characters
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# SSO Configuration
SSO_ENCRYPTION_KEY=your-aes-encryption-key

# API Key Encryption
ENCRYPTION_KEY=your-fernet-encryption-key

# Report LLM Configuration (Admin configurable via API)
REPORT_LLM_ENABLED=true
REPORT_LLM_PROVIDER=openrouter
REPORT_LLM_MODEL=google/gemini-flash-1.5
REPORT_LLM_BASE_URL=https://openrouter.ai/api/v1
REPORT_LLM_MAX_TOKENS=1000
REPORT_LLM_TEMPERATURE=0.3
```

---

## Custom Providers & vLLM Support

### Custom Provider Support

Yes, users can add custom providers with individual models:

1. Admin creates a custom provider entry in the `providers` table
2. Set `base_url` to the custom API endpoint
3. Users connect with their API key
4. Models are synced from the provider's API or manually added

### vLLM Integration

Yes, users can connect vLLM self-hosted models:

1. Create a custom provider with:
   - `id`: 'vllm-custom' (or similar)
   - `base_url`: Your vLLM server URL (e.g., 'http://localhost:8000/v1')
   - `supports_streaming`: true
   - `supports_tool_calling`: depends on model

2. Add models to `ai_models` table:
   ```sql
   INSERT INTO ai_models (id, name, provider_id, capabilities)
   VALUES ('llama-3-70b', 'Llama 3 70B', 'vllm-custom', '["chat"]');
   ```

3. User connects with vLLM API key (if authentication enabled)

**Note**: vLLM uses OpenAI-compatible API format, so no adapter changes needed.

---

## Deployment

### Production Docker Compose

```yaml
version: '3.8'
services:
  api:
    build: .
    environment:
      - DATABASE_URL=postgresql+asyncpg://user:pass@db:5432/semcoeval
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - db
      - redis
      - minio

  worker:
    build: .
    command: celery -A app.tasks.celery_app worker --loglevel=info
    depends_on:
      - api
      - redis

  db:
    image: postgres:15
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

  minio:
    image: minio/minio
    command: server /data --console-address ":9001"
```

### Production Checklist

- [ ] Set strong `JWT_SECRET_KEY` (32+ characters)
- [ ] Set strong `ENCRYPTION_KEY` for API key encryption
- [ ] Configure proper database credentials
- [ ] Set up SSL/TLS termination
- [ ] Configure backup for PostgreSQL and MinIO
- [ ] Set up monitoring (health endpoint: `/health`)
- [ ] Configure log aggregation

---

## AI Agent Coding Guidelines

**IMPORTANT**: These rules must be followed by any AI agent or developer modifying this codebase.

### Critical Rules

1. **Never Create Shortcuts**
   - Write complete, explicit code
   - No abbreviated variable names
   - No magic numbers without constants
   - No implicit behavior

2. **No Function Length Shortcuts**
   - Functions can be long if necessary
   - Do not artificially split functions just for length
   - Prefer readability over arbitrary line limits
   - Keep related logic together

3. **Explicit Over Implicit**
   - Always use explicit type hints
   - Always use explicit return types
   - No `Any` types unless absolutely necessary
   - Document complex logic with comments

4. **Database Operations**
   - Always use async SQLAlchemy patterns
   - Always use transactions for multi-step operations
   - Always handle `None` results from queries
   - Use `select()` not string queries

5. **Error Handling**
   - Always catch specific exceptions
   - Always log errors with context
   - Return proper HTTP status codes
   - Never expose internal errors to users

6. **Security Requirements**
   - Never log sensitive data (API keys, tokens)
   - Always encrypt API keys before storage
   - Always validate user input
   - Always check user permissions

7. **API Design**
   - Use Pydantic models for all request/response
   - Use proper HTTP methods (GET, POST, PUT, DELETE)
   - Use proper status codes (200, 201, 400, 401, 404, 500)
   - Document all endpoints with docstrings

8. **Background Tasks**
   - Use Celery for long-running operations
   - Always update status during progress
   - Always handle task failures gracefully
   - Store task IDs for status tracking

9. **Testing Requirements**
   - Write tests for new endpoints
   - Use pytest fixtures for setup
   - Mock external API calls
   - Test error cases

10. **Code Organization**
    - Models in `app/models/`
    - Schemas in `app/schemas/`
    - Business logic in `app/services/`
    - API routes in `app/api/v1/`
    - Background tasks in `app/tasks/`

### Prohibited Patterns

```python
# BAD: Implicit any type
def process(data):
    return data["value"]

# GOOD: Explicit types
def process(data: dict[str, Any]) -> str:
    return data["value"]

# BAD: Silent exception swallowing
try:
    result = api_call()
except:
    pass

# GOOD: Explicit exception handling
try:
    result = api_call()
except HTTPException as e:
    logger.error(f"API call failed: {e}")
    raise

# BAD: Magic strings
if user.role == "admin":
    pass

# GOOD: Use enums
if user.role == UserRole.ADMIN:
    pass

# BAD: SQL injection risk
query = f"SELECT * FROM users WHERE id = {user_id}"

# GOOD: Parameterized queries
stmt = select(User).where(User.id == user_id)

# BAD: Logging sensitive data
logger.info(f"User connected with key: {api_key}")

# GOOD: Mask sensitive data
logger.info(f"User connected with key: {api_key[:8]}...")

# BAD: Hardcoded configuration
API_KEY = "sk-12345"

# GOOD: Environment configuration
API_KEY = settings.api_key
```

### File Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Models | `{entity}.py` | `user.py`, `evaluation.py` |
| Schemas | `{entity}.py` | `auth.py`, `report.py` |
| API Routes | `{resource}.py` | `evaluations.py`, `datasets.py` |
| Services | `{domain}_service.py` | `auth_service.py` |
| Validators | `{type}_validator.py` | `model_validator.py` |
| Evaluators | `{type}_evaluator.py` | `agent_evaluator.py` |
| Tasks | `{domain}_tasks.py` | `evaluation_tasks.py` |

### Import Order

```python
# 1. Standard library
import os
from datetime import datetime
from typing import Optional, List

# 2. Third-party packages
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

# 3. Local application imports
from app.config import settings
from app.database import get_db
from app.models.user import User
from app.schemas.auth import LoginRequest
```

---

## Support

For issues and feature requests, contact the development team.
