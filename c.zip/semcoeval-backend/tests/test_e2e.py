"""End-to-end tests for SemcoEval backend API."""
import pytest
import httpx
import json
import asyncio
from pathlib import Path

# Test configuration
BASE_URL = "http://localhost:8000/api/v1"
TEST_TIMEOUT = 30.0


@pytest.fixture
def client():
    """Create async HTTP client."""
    return httpx.AsyncClient(base_url=BASE_URL, timeout=TEST_TIMEOUT)


@pytest.fixture
def sample_dataset():
    """Sample dataset for testing."""
    return {
        "metadata": {
            "name": "Test Dataset",
            "eval_type": "model",
            "category": "General",
            "schema_version": "1.0"
        },
        "questions": [
            {
                "id": "q-001",
                "type": "model",
                "input": {
                    "prompt": "What is the capital of France?",
                    "system_prompt": "You are a helpful assistant."
                },
                "expected": {
                    "answer": "Paris",
                    "keywords_required": ["Paris"]
                },
                "evaluation": {
                    "scoring_method": "contains_keywords"
                }
            },
            {
                "id": "q-002",
                "type": "model",
                "input": {
                    "prompt": "What is 2 + 2?",
                    "system_prompt": "You are a math tutor."
                },
                "expected": {
                    "answer": "4"
                },
                "evaluation": {
                    "scoring_method": "exact_match"
                }
            }
        ]
    }


class TestHealthCheck:
    """Test basic API health."""

    @pytest.mark.asyncio
    async def test_api_root(self, client):
        """Test API is reachable."""
        response = await client.get("/")
        # May return 404 at root, but should connect
        assert response.status_code in [200, 404, 307]


class TestAuthAPI:
    """Test authentication endpoints."""

    @pytest.mark.asyncio
    async def test_sso_login_invalid(self, client):
        """Test SSO login with invalid credentials returns error."""
        response = await client.post("/auth/sso_login", json={
            "aes_key": "invalid_key",
            "user_info": "invalid_info"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "error"

    @pytest.mark.asyncio
    async def test_get_me_unauthorized(self, client):
        """Test /me without token returns 401."""
        response = await client.get("/auth/me")
        assert response.status_code == 401


class TestProvidersAPI:
    """Test providers endpoints."""

    @pytest.mark.asyncio
    async def test_list_providers(self, client):
        """Test listing providers."""
        response = await client.get("/providers")
        assert response.status_code == 200
        data = response.json()
        assert "providers" in data
        assert "total" in data


class TestModelsAPI:
    """Test models endpoints."""

    @pytest.mark.asyncio
    async def test_list_models(self, client):
        """Test listing models."""
        response = await client.get("/models")
        assert response.status_code == 200
        data = response.json()
        assert "models" in data
        assert "total" in data


class TestDatasetsAPI:
    """Test datasets endpoints."""

    @pytest.mark.asyncio
    async def test_validate_dataset_valid(self, client, sample_dataset):
        """Test validating a valid dataset."""
        # Create a file-like object
        files = {
            "file": ("test_dataset.json", json.dumps(sample_dataset), "application/json")
        }
        response = await client.post("/datasets/validate", files=files)
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is True
        assert data["question_count"] == 2
        assert len(data["errors"]) == 0

    @pytest.mark.asyncio
    async def test_validate_dataset_invalid_json(self, client):
        """Test validating invalid JSON."""
        files = {
            "file": ("invalid.json", "not valid json {{{", "application/json")
        }
        response = await client.post("/datasets/validate", files=files)
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is False
        assert "Invalid JSON" in data["errors"][0]

    @pytest.mark.asyncio
    async def test_validate_dataset_missing_fields(self, client):
        """Test validating dataset with missing required fields."""
        invalid_dataset = {"questions": [{"id": "q1"}]}  # Missing input, expected
        files = {
            "file": ("test.json", json.dumps(invalid_dataset), "application/json")
        }
        response = await client.post("/datasets/validate", files=files)
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is False
        assert len(data["errors"]) > 0


class TestValidators:
    """Test dataset validators directly."""

    def test_model_validator(self, sample_dataset):
        """Test model validator."""
        from app.validators import get_validator
        validator = get_validator("model")
        result = validator.validate(sample_dataset)
        assert result.valid is True
        assert result.question_count == 2

    def test_agent_validator(self):
        """Test agent validator."""
        from app.validators import get_validator
        validator = get_validator("agent")

        agent_dataset = {
            "metadata": {"eval_type": "agent"},
            "questions": [{
                "id": "a-001",
                "input": {
                    "prompt": "Get weather in NYC",
                    "available_tools": [{"name": "get_weather", "parameters": {"location": "string"}}]
                },
                "expected": {
                    "tool_calls": [{"name": "get_weather", "required_params": ["location"]}]
                }
            }]
        }
        result = validator.validate(agent_dataset)
        assert result.valid is True

    def test_rag_validator(self):
        """Test RAG validator."""
        from app.validators import get_validator
        validator = get_validator("rag")

        rag_dataset = {
            "metadata": {"eval_type": "rag"},
            "questions": [{
                "id": "r-001",
                "input": {
                    "question": "What is the return policy?",
                    "retrieved_contexts": [{"id": "ctx-1", "content": "Returns within 30 days."}]
                },
                "expected": {"answer": "30 days"}
            }]
        }
        result = validator.validate(rag_dataset)
        assert result.valid is True


class TestAdapters:
    """Test benchmark adapters."""

    def test_mmlu_adapter(self):
        """Test MMLU adapter transformation."""
        from app.adapters import get_adapter
        adapter = get_adapter("mmlu")

        raw_data = [{
            "question": "What is the speed of light?",
            "A": "3x10^8 m/s",
            "B": "3x10^6 m/s",
            "C": "3x10^4 m/s",
            "D": "3x10^2 m/s",
            "answer": "A",
            "subject": "physics"
        }]

        result = adapter.transform(raw_data)
        assert result.name == "MMLU"
        assert result.eval_type == "model"
        assert len(result.questions) == 1
        assert result.questions[0].expected["correct_choice"] == "A"

    def test_gaia_adapter(self):
        """Test GAIA adapter transformation."""
        from app.adapters import get_adapter
        adapter = get_adapter("gaia")

        raw_data = [{
            "Question": "Find the population of Tokyo",
            "Final answer": "13.96 million",
            "Level": 2
        }]

        result = adapter.transform(raw_data)
        assert result.name == "GAIA"
        assert result.eval_type == "agent"
        assert len(result.questions) == 1


class TestEvaluators:
    """Test evaluation engines."""

    def test_model_evaluator_init(self):
        """Test model evaluator can be initialized."""
        from app.evaluators import get_evaluator
        evaluator = get_evaluator("model")
        assert evaluator.eval_type == "model"

    def test_agent_evaluator_init(self):
        """Test agent evaluator can be initialized."""
        from app.evaluators import get_evaluator
        evaluator = get_evaluator("agent")
        assert evaluator.eval_type == "agent"

    def test_rag_evaluator_init(self):
        """Test RAG evaluator can be initialized."""
        from app.evaluators import get_evaluator
        evaluator = get_evaluator("rag")
        assert evaluator.eval_type == "rag"


class TestCrypto:
    """Test encryption utilities."""

    def test_api_key_encryption_roundtrip(self):
        """Test API key encryption and decryption."""
        from app.services.crypto import encrypt_api_key, decrypt_api_key

        original_key = "sk-test-1234567890abcdef"
        encrypted = encrypt_api_key(original_key)

        # Encrypted should be different from original
        assert encrypted != original_key

        # Decryption should recover original
        decrypted = decrypt_api_key(encrypted)
        assert decrypted == original_key

    def test_empty_key_handling(self):
        """Test empty key handling."""
        from app.services.crypto import encrypt_api_key, decrypt_api_key

        assert encrypt_api_key("") == ""
        assert decrypt_api_key("") == ""


class TestStorageClient:
    """Test MinIO storage client."""

    @pytest.mark.asyncio
    async def test_storage_operations(self):
        """Test storage upload/download cycle."""
        from app.storage import storage

        test_data = b"test content for storage"
        test_path = "test/test_file.txt"

        try:
            # Upload
            result_path = storage.upload_file(test_path, test_data, "text/plain")
            assert result_path == test_path

            # Download
            downloaded = storage.download_file(test_path)
            assert downloaded == test_data

            # Delete
            deleted = storage.delete_file(test_path)
            assert deleted is True

            # Verify deleted
            not_found = storage.download_file(test_path)
            assert not_found is None

        except Exception as e:
            # MinIO might not be running during unit tests
            pytest.skip(f"MinIO not available: {e}")


# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
