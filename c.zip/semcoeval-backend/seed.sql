-- SemcoEval Database Seed Script
-- Run with: docker exec -i semcoeval-backend-db-1 psql -U postgres -d semcoeval < seed.sql

-- Create tables if they don't exist
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    sso_id VARCHAR(255) UNIQUE,
    email VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    organization VARCHAR(255),
    avatar VARCHAR(500),
    language VARCHAR(10) DEFAULT 'en',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS providers (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    logo VARCHAR(500),
    base_url VARCHAR(500),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ai_models (
    id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    provider_id VARCHAR(50) REFERENCES providers(id),
    category VARCHAR(50),
    capabilities TEXT[],
    context_window INTEGER,
    input_price FLOAT,
    output_price FLOAT,
    accuracy_score FLOAT,
    agent_score FLOAT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_provider_connections (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    provider_id VARCHAR(50) REFERENCES providers(id),
    api_key_encrypted TEXT,
    status VARCHAR(50) DEFAULT 'connected',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, provider_id)
);

CREATE TABLE IF NOT EXISTS datasets (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    eval_type VARCHAR(50),
    question_count INTEGER DEFAULT 0,
    schema_version VARCHAR(20),
    file_path VARCHAR(500),
    user_id INTEGER REFERENCES users(id),
    is_public BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS evaluations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    eval_type VARCHAR(50),
    dataset_id INTEGER REFERENCES datasets(id),
    user_id INTEGER REFERENCES users(id),
    model_ids TEXT[],
    status VARCHAR(50) DEFAULT 'pending',
    progress INTEGER DEFAULT 0,
    total_questions INTEGER DEFAULT 0,
    top_model VARCHAR(255),
    top_score FLOAT,
    avg_response_time FLOAT,
    cost_spent FLOAT,
    celery_task_id VARCHAR(255),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS evaluation_results (
    id SERIAL PRIMARY KEY,
    evaluation_id INTEGER REFERENCES evaluations(id),
    model_id VARCHAR(255),
    rank INTEGER,
    score FLOAT,
    accuracy FLOAT,
    response_time FLOAT,
    cost FLOAT,
    passed_tests INTEGER DEFAULT 0,
    failed_tests INTEGER DEFAULT 0,
    total_tests INTEGER DEFAULT 0,
    scores JSONB,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reports (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    evaluation_id INTEGER REFERENCES evaluations(id),
    user_id INTEGER REFERENCES users(id),
    summary TEXT,
    file_path VARCHAR(500),
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Clear existing data
DELETE FROM evaluation_results;
DELETE FROM evaluations;
DELETE FROM datasets;
DELETE FROM reports;
DELETE FROM user_provider_connections;
DELETE FROM ai_models;
DELETE FROM providers;
DELETE FROM users;

-- Seed dev user
INSERT INTO users (id, sso_id, email, name, role, is_active) VALUES
(1, 'dev-user-001', 'dev@example.com', 'Dev User', 'admin', true);

-- Seed providers
INSERT INTO providers (id, name, description, logo, base_url, is_active) VALUES
('openrouter', 'OpenRouter', 'Unified routing engine providing access to 200+ models', 'https://openrouter.ai/favicon.ico', 'https://openrouter.ai/api/v1', true),
('openai', 'OpenAI', 'GPT-4o, o1-reasoning models', 'https://openai.com/favicon.ico', 'https://api.openai.com/v1', true),
('anthropic', 'Anthropic', 'Claude 3.5 Sonnet and Opus', 'https://anthropic.com/favicon.ico', 'https://api.anthropic.com', true),
('google', 'Google Gemini', 'Gemini models with massive context', 'https://gemini.google.com/favicon.ico', 'https://generativelanguage.googleapis.com', true),
('together', 'Together AI', 'Open-source model hosting', 'https://together.ai/favicon.ico', 'https://api.together.xyz/v1', true),
('groq', 'Groq', 'Ultra-fast LPU inference', 'https://groq.com/favicon.ico', 'https://api.groq.com/openai/v1', true);

-- Seed low-cost models (via OpenRouter)
INSERT INTO ai_models (id, name, provider_id, category, capabilities, context_window, input_price, output_price, is_active) VALUES
('meta-llama/llama-3.2-3b-instruct', 'Llama 3.2 3B Instruct', 'openrouter', 'model', ARRAY['chat', 'instruct'], 131072, 0.06, 0.06, true),
('mistralai/mistral-7b-instruct', 'Mistral 7B Instruct', 'openrouter', 'model', ARRAY['chat', 'instruct'], 32768, 0.06, 0.06, true),
('google/gemma-2-9b-it', 'Gemma 2 9B IT', 'openrouter', 'model', ARRAY['chat', 'instruct'], 8192, 0.08, 0.08, true),
('qwen/qwen-2.5-7b-instruct', 'Qwen 2.5 7B Instruct', 'openrouter', 'model', ARRAY['chat', 'instruct', 'coding'], 131072, 0.07, 0.07, true),
('microsoft/phi-3-mini-128k-instruct', 'Phi-3 Mini 128K', 'openrouter', 'model', ARRAY['chat', 'instruct'], 131072, 0.10, 0.10, true),
('meta-llama/llama-3.1-8b-instruct', 'Llama 3.1 8B Instruct', 'openrouter', 'model', ARRAY['chat', 'instruct'], 131072, 0.055, 0.055, true);

-- Connect OpenRouter for dev user (API key needs to be encrypted - using placeholder)
INSERT INTO user_provider_connections (user_id, provider_id, api_key_encrypted, status) VALUES
(1, 'openrouter', 'PLACEHOLDER_NEEDS_ENCRYPTION', 'connected');

-- Reset sequence
SELECT setval('users_id_seq', (SELECT MAX(id) FROM users));

-- Verify
SELECT 'Providers: ' || COUNT(*) FROM providers;
SELECT 'Models: ' || COUNT(*) FROM ai_models;
SELECT 'Users: ' || COUNT(*) FROM users;

\echo 'Database seeded successfully!'
