"""
Portkey Provider - AI Gateway with model listing capability.
"""

import os
from typing import List, Optional, Any, Dict
from .base import BaseProvider, ModelInfo, ModelCategory


# Portkey supported providers and sample models
PORTKEY_MODELS: Dict[str, ModelInfo] = {
    "openai/gpt-4o": ModelInfo(
        id="openai/gpt-4o",
        name="GPT-4o (via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=16384,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="OpenAI GPT-4o via Portkey gateway"
    ),
    "anthropic/claude-3-5-sonnet-20241022": ModelInfo(
        id="anthropic/claude-3-5-sonnet-20241022",
        name="Claude 3.5 Sonnet (via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Anthropic Claude via Portkey gateway"
    ),
    "azure-openai/gpt-4o": ModelInfo(
        id="azure-openai/gpt-4o",
        name="GPT-4o (Azure via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=16384,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Azure OpenAI via Portkey gateway"
    ),
    "google/gemini-1.5-pro": ModelInfo(
        id="google/gemini-1.5-pro",
        name="Gemini 1.5 Pro (via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=2000000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Google Gemini via Portkey gateway"
    ),
    "mistral/mistral-large-latest": ModelInfo(
        id="mistral/mistral-large-latest",
        name="Mistral Large (via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Mistral AI via Portkey gateway"
    ),
    "cohere/command-r-plus": ModelInfo(
        id="cohere/command-r-plus",
        name="Command R+ (via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=4096,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Cohere via Portkey gateway"
    ),
    "together-ai/meta-llama/Llama-3.1-405B-Instruct-Turbo": ModelInfo(
        id="together-ai/meta-llama/Llama-3.1-405B-Instruct-Turbo",
        name="Llama 3.1 405B (Together via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Together AI via Portkey gateway"
    ),
    "groq/llama-3.2-90b-vision-preview": ModelInfo(
        id="groq/llama-3.2-90b-vision-preview",
        name="Llama 3.2 90B Vision (Groq via Portkey)",
        provider="portkey",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Groq via Portkey gateway"
    ),
}


class PortkeyProvider(BaseProvider):
    """
    Portkey AI Gateway provider.

    Portkey provides a unified gateway with features like:
    - Load balancing across providers
    - Fallbacks and retries
    - Caching and rate limiting
    - Observability and analytics

    Usage:
        provider = PortkeyProvider(
            api_key="pk-xxx",
            virtual_key="openai-xxx"  # Provider-specific virtual key
        )
        if provider.connect():
            models = provider.list_models()
    """

    PORTKEY_BASE_URL = "https://api.portkey.ai/v1"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        virtual_key: Optional[str] = None,
        config_id: Optional[str] = None,
    ):
        super().__init__(
            api_key=api_key or os.getenv("PORTKEY_API_KEY"),
            base_url=base_url or self.PORTKEY_BASE_URL,
        )
        self.virtual_key = virtual_key or os.getenv("PORTKEY_VIRTUAL_KEY")
        self.config_id = config_id or os.getenv("PORTKEY_CONFIG_ID")

    @property
    def name(self) -> str:
        return "portkey"

    @property
    def display_name(self) -> str:
        return "Portkey AI Gateway"

    def connect(self) -> bool:
        """Test connection to Portkey gateway."""
        if not self.api_key:
            return False

        try:
            import httpx
            headers = {
                "x-portkey-api-key": self.api_key,
            }
            if self.virtual_key:
                headers["x-portkey-virtual-key"] = self.virtual_key
            if self.config_id:
                headers["x-portkey-config"] = self.config_id

            response = httpx.get(
                f"{self.base_url}/models",
                headers=headers,
                timeout=10.0
            )
            # Only 200 is success; 401 means authentication failed
            return response.status_code == 200
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available Portkey models."""
        models = list(PORTKEY_MODELS.values())

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return PORTKEY_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible model instance via Portkey."""
        try:
            from deepeval.models import GPTModel

            # Build custom headers for Portkey
            custom_headers = {
                "x-portkey-api-key": self.api_key,
            }
            if self.virtual_key:
                custom_headers["x-portkey-virtual-key"] = self.virtual_key
            if self.config_id:
                custom_headers["x-portkey-config"] = self.config_id

            return GPTModel(
                model=model_id,
                api_key=self.api_key,
                base_url=self.base_url,
                default_headers=custom_headers,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
