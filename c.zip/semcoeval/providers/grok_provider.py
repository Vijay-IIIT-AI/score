"""
Grok Provider - xAI Grok models with model listing capability.
"""

import os
from typing import List, Optional, Any, Dict
from .base import BaseProvider, ModelInfo, ModelCategory


GROK_MODELS: Dict[str, ModelInfo] = {
    "grok-3": ModelInfo(
        id="grok-3",
        name="Grok 3",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=131072,
        max_output_tokens=16384,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="xAI Grok 3 - Latest flagship model"
    ),
    "grok-3-fast": ModelInfo(
        id="grok-3-fast",
        name="Grok 3 Fast",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=131072,
        max_output_tokens=16384,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="xAI Grok 3 Fast - Optimized for speed"
    ),
    "grok-3-mini": ModelInfo(
        id="grok-3-mini",
        name="Grok 3 Mini",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=131072,
        max_output_tokens=16384,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="xAI Grok 3 Mini - Efficient reasoning model"
    ),
    "grok-3-mini-fast": ModelInfo(
        id="grok-3-mini-fast",
        name="Grok 3 Mini Fast",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=131072,
        max_output_tokens=16384,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="xAI Grok 3 Mini Fast - Fastest reasoning"
    ),
    "grok-2-1212": ModelInfo(
        id="grok-2-1212",
        name="Grok 2",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=131072,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="xAI Grok 2"
    ),
    "grok-2-vision-1212": ModelInfo(
        id="grok-2-vision-1212",
        name="Grok 2 Vision",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=32768,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="xAI Grok 2 with vision capabilities"
    ),
    "grok-vision-beta": ModelInfo(
        id="grok-vision-beta",
        name="Grok Vision Beta",
        provider="grok",
        category=ModelCategory.CHAT,
        context_window=8192,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=False,
        supports_json_mode=True,
        description="xAI Grok Vision Beta"
    ),
}


class GrokProvider(BaseProvider):
    """
    xAI Grok provider with model listing capability.

    Usage:
        provider = GrokProvider(api_key="xai-xxx")
        if provider.connect():
            models = provider.list_models()
    """

    XAI_BASE_URL = "https://api.x.ai/v1"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        super().__init__(
            api_key=api_key or os.getenv("XAI_API_KEY"),
            base_url=base_url or self.XAI_BASE_URL,
        )

    @property
    def name(self) -> str:
        return "grok"

    @property
    def display_name(self) -> str:
        return "xAI Grok"

    def connect(self) -> bool:
        """Test connection to xAI API."""
        if not self.api_key:
            return False

        try:
            import httpx
            response = httpx.get(
                f"{self.base_url}/models",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10.0
            )
            return response.status_code == 200
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available Grok models."""
        models = list(GROK_MODELS.values())

        # Try to fetch from API
        if self.api_key:
            try:
                import httpx
                response = httpx.get(
                    f"{self.base_url}/models",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=10.0
                )
                if response.status_code == 200:
                    data = response.json()
                    api_model_ids = {m.get("id") for m in data.get("data", [])}

                    # Add any new models from API
                    for model_data in data.get("data", []):
                        model_id = model_data.get("id")
                        if model_id and model_id not in GROK_MODELS:
                            models.append(ModelInfo(
                                id=model_id,
                                name=model_data.get("name", model_id),
                                provider="grok",
                                category=ModelCategory.CHAT,
                                context_window=model_data.get("context_length", 131072),
                                max_output_tokens=8192,
                                description=f"xAI model: {model_id}"
                            ))
            except Exception:
                pass

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return GROK_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible GrokModel instance."""
        try:
            from deepeval.models import GrokModel
            return GrokModel(
                model=model_id,
                api_key=self.api_key,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
