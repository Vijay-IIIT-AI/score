"""
Moonshot Provider - Moonshot AI (Kimi) with model listing capability.
"""

import os
from typing import List, Optional, Any, Dict
from .base import BaseProvider, ModelInfo, ModelCategory


MOONSHOT_MODELS: Dict[str, ModelInfo] = {
    "moonshot-v1-8k": ModelInfo(
        id="moonshot-v1-8k",
        name="Moonshot V1 8K",
        provider="moonshot",
        category=ModelCategory.CHAT,
        context_window=8192,
        max_output_tokens=4096,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Moonshot V1 with 8K context"
    ),
    "moonshot-v1-32k": ModelInfo(
        id="moonshot-v1-32k",
        name="Moonshot V1 32K",
        provider="moonshot",
        category=ModelCategory.CHAT,
        context_window=32768,
        max_output_tokens=4096,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Moonshot V1 with 32K context"
    ),
    "moonshot-v1-128k": ModelInfo(
        id="moonshot-v1-128k",
        name="Moonshot V1 128K",
        provider="moonshot",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=4096,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Moonshot V1 with 128K context"
    ),
    "kimi-latest": ModelInfo(
        id="kimi-latest",
        name="Kimi Latest",
        provider="moonshot",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Kimi latest model with vision"
    ),
    "kimi-vision": ModelInfo(
        id="kimi-vision",
        name="Kimi Vision",
        provider="moonshot",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Kimi model optimized for vision tasks"
    ),
}


class MoonshotProvider(BaseProvider):
    """
    Moonshot AI (Kimi) provider with model listing capability.

    Moonshot AI is a Chinese AI company known for their Kimi assistant.
    Their API is OpenAI-compatible.

    Usage:
        provider = MoonshotProvider(api_key="sk-xxx")
        if provider.connect():
            models = provider.list_models()
    """

    MOONSHOT_BASE_URL = "https://api.moonshot.cn/v1"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        super().__init__(
            api_key=api_key or os.getenv("MOONSHOT_API_KEY"),
            base_url=base_url or self.MOONSHOT_BASE_URL,
        )

    @property
    def name(self) -> str:
        return "moonshot"

    @property
    def display_name(self) -> str:
        return "Moonshot AI (Kimi)"

    def connect(self) -> bool:
        """Test connection to Moonshot API."""
        if not self.api_key:
            return False

        try:
            import httpx
            response = httpx.get(
                f"{self.base_url}/models",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10.0
            )
            return response.status_code == 200
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available Moonshot models."""
        models = list(MOONSHOT_MODELS.values())

        # Try to fetch from API
        if self.api_key:
            try:
                import httpx
                response = httpx.get(
                    f"{self.base_url}/models",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=10.0
                )
                if response.status_code == 200:
                    data = response.json()

                    # Add any new models from API
                    for model_data in data.get("data", []):
                        model_id = model_data.get("id")
                        if model_id and model_id not in MOONSHOT_MODELS:
                            models.append(ModelInfo(
                                id=model_id,
                                name=model_id,
                                provider="moonshot",
                                category=ModelCategory.CHAT,
                                context_window=8192,
                                max_output_tokens=4096,
                                description=f"Moonshot model: {model_id}"
                            ))
            except Exception:
                pass

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return MOONSHOT_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible model instance (OpenAI-compatible)."""
        try:
            from deepeval.models import GPTModel
            return GPTModel(
                model=model_id,
                api_key=self.api_key,
                base_url=self.base_url,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
