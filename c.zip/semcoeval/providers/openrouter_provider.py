"""
OpenRouter Provider - Access multiple model providers through one API.
"""

import os
from typing import List, Optional, Any, Dict
from .base import BaseProvider, ModelInfo, ModelCategory


class OpenRouterProvider(BaseProvider):
    """
    OpenRouter provider - Access 100+ models through one API.

    OpenRouter provides access to models from OpenAI, Anthropic, Google,
    Meta, Mistral, and many others through a unified API.

    Usage:
        provider = OpenRouterProvider(api_key="sk-or-...")
        if provider.connect():
            models = provider.list_models()
            for model in models:
                print(f"{model.id}: ${model.input_price_per_1m}/1M input tokens")
    """

    DEFAULT_BASE_URL = "https://openrouter.ai/api/v1"

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(
            api_key=api_key or os.getenv("OPENROUTER_API_KEY"),
            base_url=base_url or self.DEFAULT_BASE_URL
        )
        self._models_cache: Optional[List[ModelInfo]] = None

    @property
    def name(self) -> str:
        return "openrouter"

    @property
    def display_name(self) -> str:
        return "OpenRouter"

    def connect(self) -> bool:
        """Test connection to OpenRouter API."""
        if not self.api_key:
            return False

        try:
            import requests
            headers = {"Authorization": f"Bearer {self.api_key}"}
            response = requests.get(
                f"{self.base_url}/models",
                headers=headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available OpenRouter models.

        Gets live data from OpenRouter API.
        """
        if self._models_cache is not None:
            models = self._models_cache
        else:
            models = self._fetch_models()
            self._models_cache = models

        if category:
            models = [m for m in models if m.category == category]

        return models

    def _fetch_models(self) -> List[ModelInfo]:
        """Fetch models from OpenRouter API."""
        models = []

        try:
            import requests
            headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
            response = requests.get(
                f"{self.base_url}/models",
                headers=headers,
                timeout=30
            )

            if response.status_code == 200:
                data = response.json()
                for model_data in data.get("data", []):
                    model_id = model_data.get("id", "")

                    # Determine category
                    category = ModelCategory.CHAT
                    if "vision" in model_id.lower() or model_data.get("architecture", {}).get("modality") == "multimodal":
                        category = ModelCategory.VISION
                    elif "o1" in model_id.lower() or "o3" in model_id.lower() or "r1" in model_id.lower():
                        category = ModelCategory.REASONING

                    # Parse pricing (OpenRouter uses per-token pricing)
                    pricing = model_data.get("pricing", {})
                    input_price = float(pricing.get("prompt", 0)) * 1000000  # Convert to per-1M
                    output_price = float(pricing.get("completion", 0)) * 1000000

                    # Determine capabilities
                    architecture = model_data.get("architecture", {})
                    supports_vision = architecture.get("modality") == "multimodal"
                    supports_fc = "function" in str(model_data.get("supported_generation_methods", [])).lower()

                    models.append(ModelInfo(
                        id=model_id,
                        name=model_data.get("name", model_id),
                        provider="openrouter",
                        category=category,
                        context_window=model_data.get("context_length", 4096),
                        max_output_tokens=model_data.get("top_provider", {}).get("max_completion_tokens", 4096),
                        input_price_per_1m=input_price,
                        output_price_per_1m=output_price,
                        supports_vision=supports_vision,
                        supports_function_calling=supports_fc,
                        supports_json_mode=True,  # Most models support JSON
                        description=model_data.get("description", "")[:200]
                    ))
        except Exception:
            pass

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        models = self.list_models()
        for model in models:
            if model.id == model_id:
                return model
        return None

    def get_models_by_provider(self, provider_name: str) -> List[ModelInfo]:
        """Get all models from a specific provider through OpenRouter."""
        models = self.list_models()
        return [m for m in models if provider_name.lower() in m.id.lower()]

    def get_free_models(self) -> List[ModelInfo]:
        """Get all free models available on OpenRouter."""
        models = self.list_models()
        return [m for m in models if m.input_price_per_1m == 0 and m.output_price_per_1m == 0]

    def search_models(self, query: str) -> List[ModelInfo]:
        """Search models by name or ID."""
        query = query.lower()
        models = self.list_models()
        return [m for m in models if query in m.id.lower() or query in m.name.lower()]

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible model instance for OpenRouter.

        Uses GPTModel with OpenRouter's OpenAI-compatible base URL.

        Args:
            model_id: The OpenRouter model ID
            **kwargs: Additional parameters

        Returns:
            DeepEval GPTModel instance configured for OpenRouter
        """
        try:
            from deepeval.models import GPTModel
            return GPTModel(
                model=model_id,
                api_key=self.api_key,
                base_url=self.base_url,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
