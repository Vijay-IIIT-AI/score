"""
Amazon Bedrock Provider - AWS Bedrock with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


BEDROCK_MODELS = {
    # Anthropic on Bedrock
    "anthropic.claude-3-5-sonnet-20241022-v2:0": ModelInfo(
        id="anthropic.claude-3-5-sonnet-20241022-v2:0",
        name="Claude 3.5 Sonnet v2",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Claude 3.5 Sonnet on Bedrock"
    ),
    "anthropic.claude-3-opus-20240229-v1:0": ModelInfo(
        id="anthropic.claude-3-opus-20240229-v1:0",
        name="Claude 3 Opus",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=4096,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Claude 3 Opus on Bedrock"
    ),
    "anthropic.claude-3-haiku-20240307-v1:0": ModelInfo(
        id="anthropic.claude-3-haiku-20240307-v1:0",
        name="Claude 3 Haiku",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=4096,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Claude 3 Haiku on Bedrock"
    ),
    # Amazon Titan
    "amazon.titan-text-premier-v1:0": ModelInfo(
        id="amazon.titan-text-premier-v1:0",
        name="Titan Text Premier",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=32000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Amazon Titan Text Premier"
    ),
    "amazon.titan-embed-text-v2:0": ModelInfo(
        id="amazon.titan-embed-text-v2:0",
        name="Titan Embeddings V2",
        provider="bedrock",
        category=ModelCategory.EMBEDDING,
        context_window=8192,
        max_output_tokens=0,
        description="Amazon Titan Embeddings"
    ),
    # Meta Llama
    "meta.llama3-2-90b-instruct-v1:0": ModelInfo(
        id="meta.llama3-2-90b-instruct-v1:0",
        name="Llama 3.2 90B",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Meta Llama 3.2 90B on Bedrock"
    ),
    "meta.llama3-1-405b-instruct-v1:0": ModelInfo(
        id="meta.llama3-1-405b-instruct-v1:0",
        name="Llama 3.1 405B",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Meta Llama 3.1 405B on Bedrock"
    ),
    # Mistral
    "mistral.mistral-large-2407-v1:0": ModelInfo(
        id="mistral.mistral-large-2407-v1:0",
        name="Mistral Large",
        provider="bedrock",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Mistral Large on Bedrock"
    ),
}


class BedrockProvider(BaseProvider):
    """
    Amazon Bedrock provider with model listing capability.

    Usage:
        provider = BedrockProvider(region_name="us-east-1")
        if provider.connect():
            models = provider.list_models()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        region_name: Optional[str] = None,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
    ):
        super().__init__(api_key=api_key, base_url=base_url)
        self.region_name = region_name or os.getenv("AWS_REGION", "us-east-1")
        self.aws_access_key_id = aws_access_key_id or os.getenv("AWS_ACCESS_KEY_ID")
        self.aws_secret_access_key = aws_secret_access_key or os.getenv("AWS_SECRET_ACCESS_KEY")

    @property
    def name(self) -> str:
        return "bedrock"

    @property
    def display_name(self) -> str:
        return "Amazon Bedrock"

    def connect(self) -> bool:
        """Test connection to Bedrock."""
        try:
            import boto3
            client = boto3.client(
                "bedrock",
                region_name=self.region_name,
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key,
            )
            # Test by listing foundation models
            client.list_foundation_models()
            self._client = client
            return True
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available Bedrock models."""
        models = list(BEDROCK_MODELS.values())

        # Try to get live models if connected
        if self._client:
            try:
                response = self._client.list_foundation_models()
                api_model_ids = {m["modelId"] for m in response.get("modelSummaries", [])}

                # Add any new models from API
                for model_summary in response.get("modelSummaries", []):
                    model_id = model_summary["modelId"]
                    if model_id not in BEDROCK_MODELS:
                        models.append(ModelInfo(
                            id=model_id,
                            name=model_summary.get("modelName", model_id),
                            provider="bedrock",
                            category=ModelCategory.CHAT,
                            context_window=model_summary.get("inputTokenLimit", 4096),
                            max_output_tokens=model_summary.get("outputTokenLimit", 4096),
                            description="Discovered from API"
                        ))
            except Exception:
                pass

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return BEDROCK_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible AmazonBedrockModel instance."""
        try:
            from deepeval.models import AmazonBedrockModel
            return AmazonBedrockModel(
                model=model_id,
                region=self.region_name,  # DeepEval v3.7.6+ uses 'region' not 'region_name'
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
