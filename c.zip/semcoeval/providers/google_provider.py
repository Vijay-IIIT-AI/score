"""
Google Provider - Wraps Google AI (Gemini) API with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


# Known Google models with their capabilities (as of 2026)
GOOGLE_MODELS = {
    # Gemini 2.5 family (2026)
    "gemini-2.5-pro": ModelInfo(
        id="gemini-2.5-pro",
        name="Gemini 2.5 Pro",
        provider="google",
        category=ModelCategory.CHAT,
        context_window=1000000,
        max_output_tokens=65536,
        input_price_per_1m=1.25,
        output_price_per_1m=10.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Most capable Gemini with 1M context"
    ),
    "gemini-2.5-flash": ModelInfo(
        id="gemini-2.5-flash",
        name="Gemini 2.5 Flash",
        provider="google",
        category=ModelCategory.CHAT,
        context_window=1000000,
        max_output_tokens=65536,
        input_price_per_1m=0.075,
        output_price_per_1m=0.30,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Fast and efficient with 1M context"
    ),
    # Gemini 2.0 family
    "gemini-2.0-flash": ModelInfo(
        id="gemini-2.0-flash",
        name="Gemini 2.0 Flash",
        provider="google",
        category=ModelCategory.CHAT,
        context_window=1000000,
        max_output_tokens=8192,
        input_price_per_1m=0.075,
        output_price_per_1m=0.30,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Previous gen fast model"
    ),
    "gemini-2.0-flash-thinking": ModelInfo(
        id="gemini-2.0-flash-thinking",
        name="Gemini 2.0 Flash Thinking",
        provider="google",
        category=ModelCategory.REASONING,
        context_window=1000000,
        max_output_tokens=65536,
        input_price_per_1m=0.075,
        output_price_per_1m=0.30,
        supports_vision=True,
        supports_function_calling=False,
        supports_json_mode=False,
        description="Reasoning-focused flash model"
    ),
    # Gemini 1.5 family
    "gemini-1.5-pro": ModelInfo(
        id="gemini-1.5-pro",
        name="Gemini 1.5 Pro",
        provider="google",
        category=ModelCategory.CHAT,
        context_window=2000000,
        max_output_tokens=8192,
        input_price_per_1m=1.25,
        output_price_per_1m=5.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="2M context legacy pro model"
    ),
    "gemini-1.5-flash": ModelInfo(
        id="gemini-1.5-flash",
        name="Gemini 1.5 Flash",
        provider="google",
        category=ModelCategory.CHAT,
        context_window=1000000,
        max_output_tokens=8192,
        input_price_per_1m=0.075,
        output_price_per_1m=0.30,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Legacy fast model"
    ),
    # Embeddings
    "text-embedding-004": ModelInfo(
        id="text-embedding-004",
        name="Text Embedding 004",
        provider="google",
        category=ModelCategory.EMBEDDING,
        context_window=2048,
        max_output_tokens=0,
        input_price_per_1m=0.00,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=False,
        description="Free embedding model"
    ),
}


class GoogleProvider(BaseProvider):
    """
    Google (Gemini) provider with model listing capability.

    Usage:
        provider = GoogleProvider(api_key="...")
        if provider.connect():
            models = provider.list_models()
            for model in models:
                print(f"{model.id}: {model.description}")
    """

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(
            api_key=api_key or os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY"),
            base_url=base_url
        )

    @property
    def name(self) -> str:
        return "google"

    @property
    def display_name(self) -> str:
        return "Google AI (Gemini)"

    def connect(self) -> bool:
        """Test connection to Google AI API."""
        if not self.api_key:
            return False

        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            # Test by listing models
            list(genai.list_models())
            self._client = genai
            return True
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available Google models.

        Attempts to get live data from API, falls back to static list.
        """
        models = list(GOOGLE_MODELS.values())

        # Try to get live models from API if connected
        if self._client:
            try:
                api_models = list(self._client.list_models())
                api_model_names = {m.name.split("/")[-1] for m in api_models}

                # Add any new models from API
                for api_model in api_models:
                    model_id = api_model.name.split("/")[-1]
                    if model_id not in GOOGLE_MODELS and "gemini" in model_id.lower():
                        models.append(ModelInfo(
                            id=model_id,
                            name=api_model.display_name,
                            provider="google",
                            category=ModelCategory.CHAT,
                            context_window=api_model.input_token_limit or 128000,
                            max_output_tokens=api_model.output_token_limit or 8192,
                            supports_vision="vision" in model_id.lower(),
                            supports_function_calling=True,
                            description=api_model.description or "Discovered from API"
                        ))
            except Exception:
                pass

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return GOOGLE_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible GeminiModel instance.

        Args:
            model_id: The Google model ID
            **kwargs: Additional parameters

        Returns:
            DeepEval GeminiModel instance
        """
        try:
            from deepeval.models import GeminiModel
            return GeminiModel(
                model=model_id,
                api_key=self.api_key,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
