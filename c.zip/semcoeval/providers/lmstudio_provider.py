"""
LM Studio Provider - Local LM Studio server with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


class LMStudioProvider(BaseProvider):
    """
    LM Studio provider for local model inference.

    LM Studio provides a local OpenAI-compatible API server.

    Usage:
        provider = LMStudioProvider(base_url="http://localhost:1234")
        if provider.connect():
            models = provider.list_models()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        super().__init__(
            api_key=api_key or os.getenv("LMSTUDIO_API_KEY", "lm-studio"),
            base_url=base_url or os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234"),
        )
        self._models_cache: List[ModelInfo] = []

    @property
    def name(self) -> str:
        return "lmstudio"

    @property
    def display_name(self) -> str:
        return "LM Studio"

    def connect(self) -> bool:
        """Test connection to LM Studio server."""
        if not self.base_url:
            return False

        try:
            import httpx
            response = httpx.get(
                f"{self.base_url.rstrip('/')}/v1/models",
                timeout=10.0
            )
            if response.status_code == 200:
                self._parse_models(response.json())
                return True
            return False
        except Exception:
            return False

    def _parse_models(self, data: dict):
        """Parse models from LM Studio /v1/models response."""
        self._models_cache = []
        for model_data in data.get("data", []):
            model_id = model_data.get("id", "")
            self._models_cache.append(ModelInfo(
                id=model_id,
                name=self._format_model_name(model_id),
                provider="lmstudio",
                category=ModelCategory.CHAT,
                context_window=4096,  # LM Studio doesn't expose this
                max_output_tokens=4096,
                supports_vision=False,
                supports_function_calling=False,
                supports_json_mode=True,
                description=f"LM Studio local model: {model_id}"
            ))

    def _format_model_name(self, model_id: str) -> str:
        """Format model ID into display name."""
        # LM Studio model IDs are typically file paths
        name = model_id.split("/")[-1] if "/" in model_id else model_id
        name = name.replace("-", " ").replace("_", " ")
        return name.title()

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available LM Studio models."""
        if not self._models_cache:
            self.connect()

        models = self._models_cache

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        for model in self.list_models():
            if model.id == model_id:
                return model
        return None

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible model instance (OpenAI-compatible)."""
        try:
            from deepeval.models import GPTModel
            return GPTModel(
                model=model_id,
                api_key=self.api_key,
                base_url=f"{self.base_url}/v1",
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
