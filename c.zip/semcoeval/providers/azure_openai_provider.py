"""
Azure OpenAI Provider - Wraps Azure OpenAI API with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


class AzureOpenAIProvider(BaseProvider):
    """
    Azure OpenAI provider with model listing capability.

    Usage:
        provider = AzureOpenAIProvider(
            api_key="...",
            base_url="https://your-resource.openai.azure.com/",
            api_version="2024-02-15-preview"
        )
        if provider.connect():
            models = provider.list_models()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        api_version: Optional[str] = None,
        deployment_name: Optional[str] = None,
    ):
        super().__init__(
            api_key=api_key or os.getenv("AZURE_OPENAI_API_KEY"),
            base_url=base_url or os.getenv("AZURE_OPENAI_ENDPOINT"),
        )
        self.api_version = api_version or os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
        self.deployment_name = deployment_name or os.getenv("AZURE_OPENAI_DEPLOYMENT")
        self._deployments_cache = None

    @property
    def name(self) -> str:
        return "azure_openai"

    @property
    def display_name(self) -> str:
        return "Azure OpenAI"

    def connect(self) -> bool:
        """Test connection to Azure OpenAI."""
        if not self.api_key or not self.base_url:
            return False

        try:
            from openai import AzureOpenAI
            client = AzureOpenAI(
                api_key=self.api_key,
                azure_endpoint=self.base_url,
                api_version=self.api_version,
            )
            # Test with deployments list
            self._client = client
            return True
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available Azure OpenAI deployments.

        Note: Azure OpenAI uses deployments, not direct model access.
        """
        models = []

        # Try to list deployments via Azure Management API
        # For now, return common deployment patterns
        common_deployments = [
            ModelInfo(
                id="gpt-4o",
                name="GPT-4o",
                provider="azure_openai",
                category=ModelCategory.CHAT,
                context_window=128000,
                max_output_tokens=16384,
                supports_vision=True,
                supports_function_calling=True,
                supports_json_mode=True,
                description="GPT-4o deployment"
            ),
            ModelInfo(
                id="gpt-4o-mini",
                name="GPT-4o Mini",
                provider="azure_openai",
                category=ModelCategory.CHAT,
                context_window=128000,
                max_output_tokens=16384,
                supports_vision=True,
                supports_function_calling=True,
                supports_json_mode=True,
                description="GPT-4o Mini deployment"
            ),
            ModelInfo(
                id="gpt-4",
                name="GPT-4",
                provider="azure_openai",
                category=ModelCategory.CHAT,
                context_window=128000,
                max_output_tokens=8192,
                supports_vision=False,
                supports_function_calling=True,
                supports_json_mode=True,
                description="GPT-4 deployment"
            ),
            ModelInfo(
                id="text-embedding-ada-002",
                name="Text Embedding Ada 002",
                provider="azure_openai",
                category=ModelCategory.EMBEDDING,
                context_window=8191,
                max_output_tokens=0,
                description="Embedding model"
            ),
        ]

        if self.deployment_name:
            # If specific deployment provided, return just that
            for model in common_deployments:
                if model.id == self.deployment_name:
                    return [model]

        if category:
            common_deployments = [m for m in common_deployments if m.category == category]

        return common_deployments

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific deployment."""
        for model in self.list_models():
            if model.id == model_id:
                return model
        return None

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible AzureOpenAIModel instance."""
        try:
            from deepeval.models import AzureOpenAIModel
            return AzureOpenAIModel(
                model=model_id,
                deployment_name=kwargs.get("deployment_name", model_id),
                azure_endpoint=self.base_url,
                api_key=self.api_key,
                api_version=self.api_version,
                **{k: v for k, v in kwargs.items() if k != "deployment_name"}
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
