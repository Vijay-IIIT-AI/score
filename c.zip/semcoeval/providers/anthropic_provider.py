"""
Anthropic Provider - Wraps Anthropic API with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


# Known Anthropic models with their capabilities (as of 2026)
ANTHROPIC_MODELS = {
    # Claude 4 family (2026)
    "claude-opus-4-20250514": ModelInfo(
        id="claude-opus-4-20250514",
        name="Claude Opus 4",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=32000,
        input_price_per_1m=15.00,
        output_price_per_1m=75.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Most capable Claude model"
    ),
    "claude-sonnet-4-20250514": ModelInfo(
        id="claude-sonnet-4-20250514",
        name="Claude Sonnet 4",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=64000,
        input_price_per_1m=3.00,
        output_price_per_1m=15.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Balanced performance and cost"
    ),
    # Claude 3.5 family
    "claude-3-5-sonnet-20241022": ModelInfo(
        id="claude-3-5-sonnet-20241022",
        name="Claude 3.5 Sonnet",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        input_price_per_1m=3.00,
        output_price_per_1m=15.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Previous generation balanced model"
    ),
    "claude-3-5-haiku-20241022": ModelInfo(
        id="claude-3-5-haiku-20241022",
        name="Claude 3.5 Haiku",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        input_price_per_1m=0.80,
        output_price_per_1m=4.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Fast and efficient model"
    ),
    # Claude 3 family
    "claude-3-opus-20240229": ModelInfo(
        id="claude-3-opus-20240229",
        name="Claude 3 Opus",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=4096,
        input_price_per_1m=15.00,
        output_price_per_1m=75.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Legacy flagship model"
    ),
    "claude-3-sonnet-20240229": ModelInfo(
        id="claude-3-sonnet-20240229",
        name="Claude 3 Sonnet",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=4096,
        input_price_per_1m=3.00,
        output_price_per_1m=15.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Legacy balanced model"
    ),
    "claude-3-haiku-20240307": ModelInfo(
        id="claude-3-haiku-20240307",
        name="Claude 3 Haiku",
        provider="anthropic",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=4096,
        input_price_per_1m=0.25,
        output_price_per_1m=1.25,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Legacy fast model"
    ),
}

# Alias mappings
MODEL_ALIASES = {
    "claude-opus-4": "claude-opus-4-20250514",
    "claude-sonnet-4": "claude-sonnet-4-20250514",
    "claude-3-5-sonnet": "claude-3-5-sonnet-20241022",
    "claude-3-5-haiku": "claude-3-5-haiku-20241022",
    "claude-3-opus": "claude-3-opus-20240229",
    "claude-3-sonnet": "claude-3-sonnet-20240229",
    "claude-3-haiku": "claude-3-haiku-20240307",
}


class AnthropicProvider(BaseProvider):
    """
    Anthropic provider with model listing capability.

    Usage:
        provider = AnthropicProvider(api_key="sk-ant-...")
        if provider.connect():
            models = provider.list_models()
            for model in models:
                print(f"{model.id}: {model.description}")
    """

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(
            api_key=api_key or os.getenv("ANTHROPIC_API_KEY"),
            base_url=base_url or os.getenv("ANTHROPIC_BASE_URL")
        )

    @property
    def name(self) -> str:
        return "anthropic"

    @property
    def display_name(self) -> str:
        return "Anthropic"

    def connect(self) -> bool:
        """Test connection to Anthropic API."""
        if not self.api_key:
            return False

        try:
            import anthropic
            client = anthropic.Anthropic(
                api_key=self.api_key,
                base_url=self.base_url
            )
            # Test with a minimal message
            client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}]
            )
            self._client = client
            return True
        except Exception:
            return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available Anthropic models.

        Note: Anthropic doesn't have a models list API, so we use static data.
        """
        models = list(ANTHROPIC_MODELS.values())

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        # Resolve alias if needed
        resolved_id = MODEL_ALIASES.get(model_id, model_id)
        return ANTHROPIC_MODELS.get(resolved_id)

    def resolve_model_id(self, model_id: str) -> str:
        """Resolve a model alias to the full model ID."""
        return MODEL_ALIASES.get(model_id, model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible AnthropicModel instance.

        Args:
            model_id: The Anthropic model ID (or alias)
            **kwargs: Additional parameters

        Returns:
            DeepEval AnthropicModel instance
        """
        try:
            from deepeval.models import AnthropicModel
            resolved_id = self.resolve_model_id(model_id)
            return AnthropicModel(
                model=resolved_id,
                api_key=self.api_key,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
