"""
Vertex AI Provider - Google Cloud Vertex AI with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


VERTEX_MODELS = {
    "gemini-1.5-pro": ModelInfo(
        id="gemini-1.5-pro",
        name="Gemini 1.5 Pro",
        provider="vertex_ai",
        category=ModelCategory.CHAT,
        context_window=2000000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Gemini 1.5 Pro on Vertex AI"
    ),
    "gemini-1.5-flash": ModelInfo(
        id="gemini-1.5-flash",
        name="Gemini 1.5 Flash",
        provider="vertex_ai",
        category=ModelCategory.CHAT,
        context_window=1000000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Gemini 1.5 Flash on Vertex AI"
    ),
    "gemini-2.0-flash": ModelInfo(
        id="gemini-2.0-flash",
        name="Gemini 2.0 Flash",
        provider="vertex_ai",
        category=ModelCategory.CHAT,
        context_window=1000000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Gemini 2.0 Flash on Vertex AI"
    ),
    "claude-3-5-sonnet": ModelInfo(
        id="claude-3-5-sonnet@20241022",
        name="Claude 3.5 Sonnet (Vertex)",
        provider="vertex_ai",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Claude 3.5 Sonnet via Vertex AI"
    ),
    "claude-3-opus": ModelInfo(
        id="claude-3-opus@20240229",
        name="Claude 3 Opus (Vertex)",
        provider="vertex_ai",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=4096,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Claude 3 Opus via Vertex AI"
    ),
}


class VertexAIProvider(BaseProvider):
    """
    Google Cloud Vertex AI provider.

    Supports both Google models (Gemini) and partner models (Claude).

    Usage:
        provider = VertexAIProvider(
            project_id="your-project",
            location="us-central1"
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        project_id: Optional[str] = None,
        location: Optional[str] = None,
    ):
        super().__init__(api_key=api_key, base_url=base_url)
        self.project_id = project_id or os.getenv("GOOGLE_CLOUD_PROJECT")
        self.location = location or os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")

    @property
    def name(self) -> str:
        return "vertex_ai"

    @property
    def display_name(self) -> str:
        return "Google Vertex AI"

    def connect(self) -> bool:
        """Test connection to Vertex AI."""
        if not self.project_id:
            return False

        try:
            import vertexai
            vertexai.init(project=self.project_id, location=self.location)
            return True
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available Vertex AI models."""
        models = list(VERTEX_MODELS.values())

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return VERTEX_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible model instance."""
        try:
            # Vertex AI models use Google's SDK
            from deepeval.models import GeminiModel
            return GeminiModel(
                model=model_id,
                project=self.project_id,
                location=self.location,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
