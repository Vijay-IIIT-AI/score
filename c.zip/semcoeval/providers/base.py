"""
Base Provider class - Extends DeepEval's model support with model listing capability.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from enum import Enum


class ModelCategory(Enum):
    """Categories of AI models."""
    CHAT = "chat"
    COMPLETION = "completion"
    EMBEDDING = "embedding"
    IMAGE_GENERATION = "image_generation"
    AUDIO = "audio"
    VISION = "vision"
    REASONING = "reasoning"


@dataclass
class ModelInfo:
    """Information about an available model."""
    id: str
    name: str
    provider: str
    category: ModelCategory
    context_window: int
    max_output_tokens: int
    input_price_per_1m: Optional[float] = None  # USD per 1M tokens
    output_price_per_1m: Optional[float] = None
    supports_vision: bool = False
    supports_function_calling: bool = False
    supports_json_mode: bool = False
    supports_streaming: bool = True
    description: str = ""
    deprecated: bool = False


class BaseProvider(ABC):
    """
    Base class for all AI providers.

    Extends DeepEval's provider support with:
    - Model listing from API
    - Model capability detection
    - Unified interface across providers
    """

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url
        self._client = None

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider name (e.g., 'openai', 'anthropic')."""
        pass

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable provider name."""
        pass

    @abstractmethod
    def connect(self) -> bool:
        """
        Test connection to the provider.

        Returns:
            True if connection successful, False otherwise.
        """
        pass

    @abstractmethod
    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List all available models from this provider.

        Args:
            category: Optional filter by model category

        Returns:
            List of ModelInfo objects
        """
        pass

    @abstractmethod
    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """
        Get info about a specific model.

        Args:
            model_id: The model identifier

        Returns:
            ModelInfo if found, None otherwise
        """
        pass

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible model instance.

        Args:
            model_id: The model identifier
            **kwargs: Additional parameters for the model

        Returns:
            DeepEval model instance
        """
        raise NotImplementedError("Subclasses must implement get_deepeval_model")

    def get_chat_models(self) -> List[ModelInfo]:
        """Get all chat-capable models."""
        return self.list_models(ModelCategory.CHAT)

    def get_vision_models(self) -> List[ModelInfo]:
        """Get all vision-capable models."""
        return [m for m in self.list_models() if m.supports_vision]

    def get_function_calling_models(self) -> List[ModelInfo]:
        """Get all function-calling capable models."""
        return [m for m in self.list_models() if m.supports_function_calling]


@dataclass
class ProviderConnection:
    """Represents a connection to a provider."""
    provider: BaseProvider
    api_key: str
    is_connected: bool = False
    error_message: Optional[str] = None
    available_models: List[ModelInfo] = None

    def __post_init__(self):
        if self.available_models is None:
            self.available_models = []
