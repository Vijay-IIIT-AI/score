"""
Ollama Provider - Wraps Ollama local server with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


# Common Ollama models with their capabilities
OLLAMA_MODELS = {
    "llama3.2": ModelInfo(
        id="llama3.2",
        name="Llama 3.2",
        provider="ollama",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Meta's Llama 3.2"
    ),
    "llama3.2-vision": ModelInfo(
        id="llama3.2-vision",
        name="Llama 3.2 Vision",
        provider="ollama",
        category=ModelCategory.VISION,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=True,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Meta's Llama 3.2 with vision"
    ),
    "qwen2.5": ModelInfo(
        id="qwen2.5",
        name="Qwen 2.5",
        provider="ollama",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Alibaba's Qwen 2.5"
    ),
    "qwen2.5-coder": ModelInfo(
        id="qwen2.5-coder",
        name="Qwen 2.5 Coder",
        provider="ollama",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Qwen 2.5 optimized for code"
    ),
    "mistral": ModelInfo(
        id="mistral",
        name="Mistral",
        provider="ollama",
        category=ModelCategory.CHAT,
        context_window=32000,
        max_output_tokens=8192,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Mistral AI model"
    ),
    "codellama": ModelInfo(
        id="codellama",
        name="Code Llama",
        provider="ollama",
        category=ModelCategory.CHAT,
        context_window=16000,
        max_output_tokens=4096,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Meta's Code Llama"
    ),
    "deepseek-r1": ModelInfo(
        id="deepseek-r1",
        name="DeepSeek R1",
        provider="ollama",
        category=ModelCategory.REASONING,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=False,
        description="DeepSeek reasoning model (local)"
    ),
    "phi3": ModelInfo(
        id="phi3",
        name="Phi-3",
        provider="ollama",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=4096,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Microsoft Phi-3"
    ),
}


class OllamaProvider(BaseProvider):
    """
    Ollama provider for local models with model listing capability.

    Usage:
        provider = OllamaProvider()  # Uses localhost:11434 by default
        if provider.connect():
            models = provider.list_models()
            for model in models:
                print(f"{model.id}: {model.description}")
    """

    DEFAULT_BASE_URL = "http://localhost:11434"

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(
            api_key=api_key,  # Ollama doesn't require API key
            base_url=base_url or os.getenv("OLLAMA_HOST") or self.DEFAULT_BASE_URL
        )

    @property
    def name(self) -> str:
        return "ollama"

    @property
    def display_name(self) -> str:
        return "Ollama (Local)"

    def connect(self) -> bool:
        """Test connection to Ollama server."""
        try:
            import requests
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except Exception:
            return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available Ollama models.

        Gets live data from local Ollama server.
        """
        models = []

        try:
            import requests
            response = requests.get(f"{self.base_url}/api/tags", timeout=10)
            if response.status_code == 200:
                data = response.json()
                for model_data in data.get("models", []):
                    model_name = model_data["name"].split(":")[0]  # Remove tag

                    # Check if we have predefined info
                    if model_name in OLLAMA_MODELS:
                        model_info = OLLAMA_MODELS[model_name]
                        # Update with actual model name (with tag)
                        model_info = ModelInfo(
                            id=model_data["name"],
                            name=model_info.name,
                            provider="ollama",
                            category=model_info.category,
                            context_window=model_info.context_window,
                            max_output_tokens=model_info.max_output_tokens,
                            input_price_per_1m=0,
                            output_price_per_1m=0,
                            supports_vision=model_info.supports_vision,
                            supports_function_calling=model_info.supports_function_calling,
                            supports_json_mode=model_info.supports_json_mode,
                            description=model_info.description
                        )
                    else:
                        # Create basic info for unknown models
                        model_info = ModelInfo(
                            id=model_data["name"],
                            name=model_data["name"],
                            provider="ollama",
                            category=ModelCategory.CHAT,
                            context_window=8192,  # Conservative default
                            max_output_tokens=4096,
                            input_price_per_1m=0,
                            output_price_per_1m=0,
                            supports_vision="vision" in model_name.lower(),
                            supports_function_calling=False,
                            supports_json_mode=True,
                            description="Local Ollama model"
                        )

                    models.append(model_info)
        except Exception:
            # Fall back to common models if server unreachable
            models = list(OLLAMA_MODELS.values())

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        base_name = model_id.split(":")[0]
        return OLLAMA_MODELS.get(base_name)

    def pull_model(self, model_name: str) -> bool:
        """
        Pull a model from Ollama registry.

        Args:
            model_name: Model name to pull

        Returns:
            True if successful
        """
        try:
            import requests
            response = requests.post(
                f"{self.base_url}/api/pull",
                json={"name": model_name},
                timeout=600  # 10 minutes for large models
            )
            return response.status_code == 200
        except Exception:
            return False

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible OllamaModel instance.

        Args:
            model_id: The Ollama model name
            **kwargs: Additional parameters

        Returns:
            DeepEval OllamaModel instance
        """
        try:
            from deepeval.models import OllamaModel
            return OllamaModel(
                model=model_id,
                base_url=self.base_url,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
