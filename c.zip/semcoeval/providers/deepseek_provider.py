"""
DeepSeek Provider - Wraps DeepSeek API with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


# Known DeepSeek models with their capabilities (as of 2026)
DEEPSEEK_MODELS = {
    # DeepSeek V3
    "deepseek-chat": ModelInfo(
        id="deepseek-chat",
        name="DeepSeek V3",
        provider="deepseek",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0.14,
        output_price_per_1m=0.28,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Latest DeepSeek chat model"
    ),
    # DeepSeek R1 (Reasoning)
    "deepseek-reasoner": ModelInfo(
        id="deepseek-reasoner",
        name="DeepSeek R1",
        provider="deepseek",
        category=ModelCategory.REASONING,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0.55,
        output_price_per_1m=2.19,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=False,
        description="Reasoning-focused model"
    ),
    # DeepSeek Coder
    "deepseek-coder": ModelInfo(
        id="deepseek-coder",
        name="DeepSeek Coder V2",
        provider="deepseek",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        input_price_per_1m=0.14,
        output_price_per_1m=0.28,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Code-specialized model"
    ),
}


class DeepSeekProvider(BaseProvider):
    """
    DeepSeek provider with model listing capability.

    Usage:
        provider = DeepSeekProvider(api_key="sk-...")
        if provider.connect():
            models = provider.list_models()
            for model in models:
                print(f"{model.id}: {model.description}")
    """

    DEFAULT_BASE_URL = "https://api.deepseek.com"

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(
            api_key=api_key or os.getenv("DEEPSEEK_API_KEY"),
            base_url=base_url or os.getenv("DEEPSEEK_BASE_URL") or self.DEFAULT_BASE_URL
        )

    @property
    def name(self) -> str:
        return "deepseek"

    @property
    def display_name(self) -> str:
        return "DeepSeek"

    def connect(self) -> bool:
        """Test connection to DeepSeek API."""
        if not self.api_key:
            return False

        try:
            from openai import OpenAI
            client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            # Test with models list
            client.models.list()
            self._client = client
            return True
        except Exception:
                        return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available DeepSeek models.
        """
        models = list(DEEPSEEK_MODELS.values())

        # Try to get live models from API
        if self._client:
            try:
                api_models = self._client.models.list()
                api_model_ids = {m.id for m in api_models.data}

                # Add any new models from API
                for api_model in api_models.data:
                    if api_model.id not in DEEPSEEK_MODELS:
                        models.append(ModelInfo(
                            id=api_model.id,
                            name=api_model.id,
                            provider="deepseek",
                            category=ModelCategory.CHAT,
                            context_window=128000,
                            max_output_tokens=8192,
                            supports_function_calling=True,
                            description="Discovered from API"
                        ))
            except Exception:
                pass

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return DEEPSEEK_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible DeepSeekModel instance.

        Args:
            model_id: The DeepSeek model ID
            **kwargs: Additional parameters

        Returns:
            DeepEval DeepSeekModel instance
        """
        try:
            from deepeval.models import DeepSeekModel
            return DeepSeekModel(
                model=model_id,
                api_key=self.api_key,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
