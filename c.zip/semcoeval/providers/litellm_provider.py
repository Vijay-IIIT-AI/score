"""
LiteLLM Provider - Universal LLM gateway with model listing capability.
"""

import os
from typing import List, Optional, Any, Dict
from .base import BaseProvider, ModelInfo, ModelCategory


# LiteLLM supported models with their providers
LITELLM_MODELS: Dict[str, ModelInfo] = {
    # OpenAI via LiteLLM
    "openai/gpt-4o": ModelInfo(
        id="openai/gpt-4o",
        name="GPT-4o (via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=16384,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="OpenAI GPT-4o via LiteLLM"
    ),
    # Anthropic via LiteLLM
    "anthropic/claude-3-5-sonnet-20241022": ModelInfo(
        id="anthropic/claude-3-5-sonnet-20241022",
        name="Claude 3.5 Sonnet (via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Anthropic Claude via LiteLLM"
    ),
    # Bedrock via LiteLLM
    "bedrock/anthropic.claude-3-5-sonnet-20241022-v2:0": ModelInfo(
        id="bedrock/anthropic.claude-3-5-sonnet-20241022-v2:0",
        name="Claude 3.5 Sonnet (Bedrock via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=200000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Bedrock Claude via LiteLLM"
    ),
    # Vertex AI via LiteLLM
    "vertex_ai/gemini-1.5-pro": ModelInfo(
        id="vertex_ai/gemini-1.5-pro",
        name="Gemini 1.5 Pro (Vertex via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=2000000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Vertex AI Gemini via LiteLLM"
    ),
    # Azure via LiteLLM
    "azure/gpt-4o": ModelInfo(
        id="azure/gpt-4o",
        name="GPT-4o (Azure via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=16384,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Azure OpenAI via LiteLLM"
    ),
    # Ollama via LiteLLM
    "ollama/llama3.2": ModelInfo(
        id="ollama/llama3.2",
        name="Llama 3.2 (Ollama via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Ollama Llama via LiteLLM"
    ),
    # Together AI via LiteLLM
    "together_ai/meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo": ModelInfo(
        id="together_ai/meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo",
        name="Llama 3.1 405B (Together via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Together AI Llama via LiteLLM"
    ),
    # Groq via LiteLLM
    "groq/llama-3.2-90b-vision-preview": ModelInfo(
        id="groq/llama-3.2-90b-vision-preview",
        name="Llama 3.2 90B Vision (Groq via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=True,
        supports_function_calling=False,
        supports_json_mode=True,
        description="Groq Llama via LiteLLM"
    ),
    # Mistral via LiteLLM
    "mistral/mistral-large-latest": ModelInfo(
        id="mistral/mistral-large-latest",
        name="Mistral Large (via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=8192,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Mistral AI via LiteLLM"
    ),
    # Cohere via LiteLLM
    "cohere/command-r-plus": ModelInfo(
        id="cohere/command-r-plus",
        name="Command R+ (via LiteLLM)",
        provider="litellm",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=4096,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Cohere Command via LiteLLM"
    ),
}


class LiteLLMProvider(BaseProvider):
    """
    LiteLLM universal gateway provider.

    LiteLLM provides a unified interface to 100+ LLM providers.
    Supports OpenAI-compatible format with provider prefixes.

    Usage:
        provider = LiteLLMProvider()
        models = provider.list_models()
        # Use model IDs like "openai/gpt-4o", "anthropic/claude-3-5-sonnet"
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        super().__init__(
            api_key=api_key,
            base_url=base_url or os.getenv("LITELLM_BASE_URL"),
        )

    @property
    def name(self) -> str:
        return "litellm"

    @property
    def display_name(self) -> str:
        return "LiteLLM"

    def connect(self) -> bool:
        """Test LiteLLM availability."""
        try:
            import litellm
            return True
        except ImportError:
            return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """List available LiteLLM models."""
        models = list(LITELLM_MODELS.values())

        # Try to get dynamic model list from LiteLLM
        try:
            import litellm
            # LiteLLM maintains a model list
            for model_name in litellm.model_list:
                if model_name not in LITELLM_MODELS:
                    models.append(ModelInfo(
                        id=model_name,
                        name=model_name,
                        provider="litellm",
                        category=ModelCategory.CHAT,
                        context_window=4096,
                        max_output_tokens=4096,
                        description=f"LiteLLM model: {model_name}"
                    ))
        except Exception:
            pass

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return LITELLM_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """Get a DeepEval-compatible LiteLLMModel instance."""
        try:
            from deepeval.models import LiteLLMModel
            return LiteLLMModel(
                model=model_id,
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")

    def _get_provider_api_key(self, provider: str) -> Optional[str]:
        """Get API key for underlying provider."""
        key_mapping = {
            "openai": "OPENAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "azure": "AZURE_API_KEY",
            "bedrock": "AWS_ACCESS_KEY_ID",
            "vertex_ai": "GOOGLE_APPLICATION_CREDENTIALS",
            "together_ai": "TOGETHER_API_KEY",
            "groq": "GROQ_API_KEY",
            "mistral": "MISTRAL_API_KEY",
            "cohere": "COHERE_API_KEY",
        }
        env_var = key_mapping.get(provider, "")
        return os.getenv(env_var) if env_var else self.api_key
