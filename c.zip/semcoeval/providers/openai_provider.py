"""
OpenAI Provider - Wraps OpenAI API with model listing capability.
"""

import os
from typing import List, Optional, Any
from .base import BaseProvider, ModelInfo, ModelCategory


# Known OpenAI models with their capabilities (as of 2026)
OPENAI_MODELS = {
    # GPT-4o family
    "gpt-4o": ModelInfo(
        id="gpt-4o",
        name="GPT-4o",
        provider="openai",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=16384,
        input_price_per_1m=2.50,
        output_price_per_1m=10.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Most capable GPT-4o model with vision"
    ),
    "gpt-4o-mini": ModelInfo(
        id="gpt-4o-mini",
        name="GPT-4o Mini",
        provider="openai",
        category=ModelCategory.CHAT,
        context_window=128000,
        max_output_tokens=16384,
        input_price_per_1m=0.15,
        output_price_per_1m=0.60,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Affordable GPT-4o variant"
    ),
    # o-series (reasoning)
    "o1": ModelInfo(
        id="o1",
        name="o1",
        provider="openai",
        category=ModelCategory.REASONING,
        context_window=200000,
        max_output_tokens=100000,
        input_price_per_1m=15.00,
        output_price_per_1m=60.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=False,
        description="Advanced reasoning model"
    ),
    "o1-mini": ModelInfo(
        id="o1-mini",
        name="o1 Mini",
        provider="openai",
        category=ModelCategory.REASONING,
        context_window=128000,
        max_output_tokens=65536,
        input_price_per_1m=3.00,
        output_price_per_1m=12.00,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=False,
        description="Faster reasoning model"
    ),
    "o3": ModelInfo(
        id="o3",
        name="o3",
        provider="openai",
        category=ModelCategory.REASONING,
        context_window=200000,
        max_output_tokens=100000,
        input_price_per_1m=20.00,
        output_price_per_1m=80.00,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Most advanced reasoning model"
    ),
    "o3-mini": ModelInfo(
        id="o3-mini",
        name="o3 Mini",
        provider="openai",
        category=ModelCategory.REASONING,
        context_window=200000,
        max_output_tokens=100000,
        input_price_per_1m=1.10,
        output_price_per_1m=4.40,
        supports_vision=False,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Efficient reasoning model"
    ),
    # o4-mini (latest 2026)
    "o4-mini": ModelInfo(
        id="o4-mini",
        name="o4 Mini",
        provider="openai",
        category=ModelCategory.REASONING,
        context_window=200000,
        max_output_tokens=100000,
        input_price_per_1m=1.10,
        output_price_per_1m=4.40,
        supports_vision=True,
        supports_function_calling=True,
        supports_json_mode=True,
        description="Latest efficient reasoning model (2026)"
    ),
    # Embeddings
    "text-embedding-3-large": ModelInfo(
        id="text-embedding-3-large",
        name="Text Embedding 3 Large",
        provider="openai",
        category=ModelCategory.EMBEDDING,
        context_window=8191,
        max_output_tokens=0,
        input_price_per_1m=0.13,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=False,
        description="High-dimension embedding model"
    ),
    "text-embedding-3-small": ModelInfo(
        id="text-embedding-3-small",
        name="Text Embedding 3 Small",
        provider="openai",
        category=ModelCategory.EMBEDDING,
        context_window=8191,
        max_output_tokens=0,
        input_price_per_1m=0.02,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=False,
        description="Efficient embedding model"
    ),
    # Image generation
    "dall-e-3": ModelInfo(
        id="dall-e-3",
        name="DALL-E 3",
        provider="openai",
        category=ModelCategory.IMAGE_GENERATION,
        context_window=4000,
        max_output_tokens=0,
        input_price_per_1m=0,
        output_price_per_1m=0,
        supports_vision=False,
        supports_function_calling=False,
        supports_json_mode=False,
        description="Advanced image generation"
    ),
}


class OpenAIProvider(BaseProvider):
    """
    OpenAI provider with model listing capability.

    Usage:
        provider = OpenAIProvider(api_key="sk-...")
        if provider.connect():
            models = provider.list_models()
            for model in models:
                print(f"{model.id}: {model.description}")
    """

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(
            api_key=api_key or os.getenv("OPENAI_API_KEY"),
            base_url=base_url or os.getenv("OPENAI_BASE_URL")
        )
        self._models_cache: Optional[List[ModelInfo]] = None

    @property
    def name(self) -> str:
        return "openai"

    @property
    def display_name(self) -> str:
        return "OpenAI"

    def connect(self) -> bool:
        """Test connection to OpenAI API."""
        if not self.api_key:
            return False

        try:
            from openai import OpenAI
            client = OpenAI(api_key=self.api_key, base_url=self.base_url)
            # Test with a simple models list call
            client.models.list()
            self._client = client
            return True
        except Exception:
            return False

    def list_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List available OpenAI models.

        Combines static model info with live API data.
        """
        models = list(OPENAI_MODELS.values())

        # Try to get live models from API if connected
        if self._client:
            try:
                api_models = self._client.models.list()
                api_model_ids = {m.id for m in api_models.data}

                # Mark deprecated if not in API response
                for model in models:
                    if model.id not in api_model_ids:
                        model.deprecated = True

                # Add any new models from API (basic info only)
                for api_model in api_models.data:
                    if api_model.id not in OPENAI_MODELS:
                        # Only add chat/completion models
                        if any(prefix in api_model.id for prefix in ["gpt", "o1", "o3", "o4"]):
                            models.append(ModelInfo(
                                id=api_model.id,
                                name=api_model.id,
                                provider="openai",
                                category=ModelCategory.CHAT,
                                context_window=128000,  # Default assumption
                                max_output_tokens=16384,
                                supports_function_calling=True,
                                description="Discovered from API"
                            ))
            except Exception:
                pass  # Fall back to static list

        if category:
            models = [m for m in models if m.category == category]

        return models

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return OPENAI_MODELS.get(model_id)

    def get_deepeval_model(self, model_id: str, **kwargs) -> Any:
        """
        Get a DeepEval-compatible GPTModel instance.

        Args:
            model_id: The OpenAI model ID
            **kwargs: Additional parameters (temperature, etc.)

        Returns:
            DeepEval GPTModel instance
        """
        try:
            from deepeval.models import GPTModel
            return GPTModel(
                model=model_id,
                api_key=self.api_key,
                **({"base_url": self.base_url} if self.base_url else {}),
                **kwargs
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
