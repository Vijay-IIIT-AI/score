"""
Provider Registry - Central registry for managing all AI providers.
"""

from typing import Dict, List, Optional, Type, Tuple
from .base import BaseProvider, ModelInfo, ModelCategory, ProviderConnection


class ProviderRegistry:
    """
    Central registry for managing AI providers and their connections.

    Usage:
        registry = ProviderRegistry()

        # Register providers
        registry.register_provider("openai", OpenAIProvider)
        registry.register_provider("anthropic", AnthropicProvider)

        # Connect to a provider
        connection = registry.connect("openai", api_key="sk-...")
        if connection.is_connected:
            models = connection.available_models

        # List all connected models
        all_models = registry.list_all_models()
    """

    def __init__(self):
        self._provider_classes: Dict[str, Type[BaseProvider]] = {}
        self._connections: Dict[str, ProviderConnection] = {}
        self._register_defaults()

    def _register_defaults(self):
        """Register default provider classes."""
        # Cloud providers
        from .openai_provider import OpenAIProvider
        from .anthropic_provider import AnthropicProvider
        from .google_provider import GoogleProvider
        from .deepseek_provider import DeepSeekProvider
        from .grok_provider import GrokProvider
        from .moonshot_provider import MoonshotProvider

        # Enterprise/Cloud platforms
        from .azure_openai_provider import AzureOpenAIProvider
        from .vertex_ai_provider import VertexAIProvider
        from .bedrock_provider import BedrockProvider

        # Local/Self-hosted
        from .ollama_provider import OllamaProvider
        from .vllm_provider import VLLMProvider
        from .lmstudio_provider import LMStudioProvider

        # Gateways/Routers
        from .openrouter_provider import OpenRouterProvider
        from .litellm_provider import LiteLLMProvider
        from .portkey_provider import PortkeyProvider

        # Register cloud providers
        self.register_provider("openai", OpenAIProvider)
        self.register_provider("anthropic", AnthropicProvider)
        self.register_provider("google", GoogleProvider)
        self.register_provider("deepseek", DeepSeekProvider)
        self.register_provider("grok", GrokProvider)
        self.register_provider("moonshot", MoonshotProvider)

        # Register enterprise platforms
        self.register_provider("azure_openai", AzureOpenAIProvider)
        self.register_provider("vertex_ai", VertexAIProvider)
        self.register_provider("bedrock", BedrockProvider)

        # Register local providers
        self.register_provider("ollama", OllamaProvider)
        self.register_provider("vllm", VLLMProvider)
        self.register_provider("lmstudio", LMStudioProvider)

        # Register gateways
        self.register_provider("openrouter", OpenRouterProvider)
        self.register_provider("litellm", LiteLLMProvider)
        self.register_provider("portkey", PortkeyProvider)

    def register_provider(self, name: str, provider_class: Type[BaseProvider]):
        """Register a provider class."""
        self._provider_classes[name] = provider_class

    def connect(
        self,
        provider_name: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None
    ) -> ProviderConnection:
        """
        Connect to a provider.

        Args:
            provider_name: Name of the provider to connect to
            api_key: API key for the provider
            base_url: Optional custom base URL

        Returns:
            ProviderConnection with connection status and available models
        """
        if provider_name not in self._provider_classes:
            return ProviderConnection(
                provider=None,
                api_key=api_key or "",
                is_connected=False,
                error_message=f"Unknown provider: {provider_name}"
            )

        provider_class = self._provider_classes[provider_name]
        provider = provider_class(api_key=api_key, base_url=base_url)

        try:
            is_connected = provider.connect()
            models = provider.list_models() if is_connected else []

            connection = ProviderConnection(
                provider=provider,
                api_key=api_key or "",
                is_connected=is_connected,
                available_models=models,
                error_message=None if is_connected else "Connection failed"
            )

            if is_connected:
                self._connections[provider_name] = connection

            return connection

        except Exception as e:
            return ProviderConnection(
                provider=provider,
                api_key=api_key or "",
                is_connected=False,
                error_message=str(e)
            )

    def disconnect(self, provider_name: str):
        """Disconnect from a provider."""
        if provider_name in self._connections:
            del self._connections[provider_name]

    def get_connection(self, provider_name: str) -> Optional[ProviderConnection]:
        """Get an existing connection."""
        return self._connections.get(provider_name)

    def list_providers(self) -> List[str]:
        """List all registered provider names."""
        return list(self._provider_classes.keys())

    def list_connected_providers(self) -> List[str]:
        """List all connected provider names."""
        return list(self._connections.keys())

    def list_all_models(self, category: Optional[ModelCategory] = None) -> List[ModelInfo]:
        """
        List all models from all connected providers.

        Args:
            category: Optional filter by category

        Returns:
            List of ModelInfo from all connected providers
        """
        models = []
        for connection in self._connections.values():
            if connection.is_connected and connection.provider:
                provider_models = connection.provider.list_models(category)
                models.extend(provider_models)
        return models

    def get_model(self, provider_name: str, model_id: str) -> Optional[ModelInfo]:
        """Get info about a specific model from a provider."""
        connection = self._connections.get(provider_name)
        if connection and connection.provider:
            return connection.provider.get_model(model_id)
        return None

    def get_deepeval_model(self, provider_name: str, model_id: str, **kwargs):
        """Get a DeepEval-compatible model instance."""
        connection = self._connections.get(provider_name)
        if connection and connection.provider:
            return connection.provider.get_deepeval_model(model_id, **kwargs)
        raise ValueError(f"Provider '{provider_name}' not connected")

    def find_model(self, model_id: str) -> Optional[Tuple[str, ModelInfo]]:
        """
        Find a model across all connected providers.

        Returns:
            Tuple of (provider_name, ModelInfo) if found, None otherwise
        """
        for provider_name, connection in self._connections.items():
            if connection.provider:
                model = connection.provider.get_model(model_id)
                if model:
                    return (provider_name, model)
        return None

    def get_models_with_capability(
        self,
        capability: str,
        providers: Optional[List[str]] = None
    ) -> List[ModelInfo]:
        """
        Get models with a specific capability.

        Args:
            capability: Capability to filter by (e.g., 'vision', 'function_calling')
            providers: Optional list of provider names to search

        Returns:
            List of ModelInfo with the requested capability
        """
        models = []
        provider_names = providers or self.list_connected_providers()

        for provider_name in provider_names:
            connection = self._connections.get(provider_name)
            if connection and connection.provider:
                for model in connection.provider.list_models():
                    if capability == "vision" and model.supports_vision:
                        models.append(model)
                    elif capability == "function_calling" and model.supports_function_calling:
                        models.append(model)
                    elif capability == "json_mode" and model.supports_json_mode:
                        models.append(model)

        return models

    def connection_status(self) -> Dict[str, bool]:
        """Get connection status for all registered providers."""
        return {
            name: name in self._connections and self._connections[name].is_connected
            for name in self._provider_classes.keys()
        }
