"""
Task Enums - All task/subgroup definitions for benchmarks.

This module provides task enums for all supported benchmarks:
- DeepEval benchmark tasks (MMLU, BigBenchHard, BBQ, etc.)
- Custom benchmark tasks (GPQA, GAIA, SWE-bench, etc.)

Note: Local definitions mirror DeepEval's task enums for compatibility.
Benchmarks without subgroups use placeholder ALL="all" for API consistency.
"""

from enum import Enum
from typing import Dict, Type


# =============================================================================
# DeepEval Task Enums
# =============================================================================

class MMLUTask(Enum):
    """MMLU subjects (57 total)."""
    HIGH_SCHOOL_EUROPEAN_HISTORY = "high_school_european_history"
    BUSINESS_ETHICS = "business_ethics"
    CLINICAL_KNOWLEDGE = "clinical_knowledge"
    MEDICAL_GENETICS = "medical_genetics"
    HIGH_SCHOOL_US_HISTORY = "high_school_us_history"
    HIGH_SCHOOL_PHYSICS = "high_school_physics"
    HIGH_SCHOOL_WORLD_HISTORY = "high_school_world_history"
    VIROLOGY = "virology"
    HIGH_SCHOOL_MICROECONOMICS = "high_school_microeconomics"
    ECONOMETRICS = "econometrics"
    COLLEGE_COMPUTER_SCIENCE = "college_computer_science"
    HIGH_SCHOOL_BIOLOGY = "high_school_biology"
    ABSTRACT_ALGEBRA = "abstract_algebra"
    PROFESSIONAL_ACCOUNTING = "professional_accounting"
    PHILOSOPHY = "philosophy"
    PROFESSIONAL_MEDICINE = "professional_medicine"
    NUTRITION = "nutrition"
    GLOBAL_FACTS = "global_facts"
    MACHINE_LEARNING = "machine_learning"
    SECURITY_STUDIES = "security_studies"
    PUBLIC_RELATIONS = "public_relations"
    PROFESSIONAL_PSYCHOLOGY = "professional_psychology"
    PREHISTORY = "prehistory"
    ANATOMY = "anatomy"
    HUMAN_SEXUALITY = "human_sexuality"
    COLLEGE_MEDICINE = "college_medicine"
    HIGH_SCHOOL_GOVERNMENT_AND_POLITICS = "high_school_government_and_politics"
    COLLEGE_CHEMISTRY = "college_chemistry"
    LOGICAL_FALLACIES = "logical_fallacies"
    HIGH_SCHOOL_GEOGRAPHY = "high_school_geography"
    ELEMENTARY_MATHEMATICS = "elementary_mathematics"
    HUMAN_AGING = "human_aging"
    COLLEGE_MATHEMATICS = "college_mathematics"
    HIGH_SCHOOL_PSYCHOLOGY = "high_school_psychology"
    FORMAL_LOGIC = "formal_logic"
    HIGH_SCHOOL_STATISTICS = "high_school_statistics"
    INTERNATIONAL_LAW = "international_law"
    HIGH_SCHOOL_MATHEMATICS = "high_school_mathematics"
    HIGH_SCHOOL_COMPUTER_SCIENCE = "high_school_computer_science"
    CONCEPTUAL_PHYSICS = "conceptual_physics"
    MISCELLANEOUS = "miscellaneous"
    HIGH_SCHOOL_CHEMISTRY = "high_school_chemistry"
    MARKETING = "marketing"
    PROFESSIONAL_LAW = "professional_law"
    MANAGEMENT = "management"
    COLLEGE_PHYSICS = "college_physics"
    JURISPRUDENCE = "jurisprudence"
    WORLD_RELIGIONS = "world_religions"
    SOCIOLOGY = "sociology"
    US_FOREIGN_POLICY = "us_foreign_policy"
    HIGH_SCHOOL_MACROECONOMICS = "high_school_macroeconomics"
    COMPUTER_SECURITY = "computer_security"
    MORAL_SCENARIOS = "moral_scenarios"
    MORAL_DISPUTES = "moral_disputes"
    ELECTRICAL_ENGINEERING = "electrical_engineering"
    ASTRONOMY = "astronomy"
    COLLEGE_BIOLOGY = "college_biology"


class BigBenchHardTask(Enum):
    """BigBench Hard tasks (27 total)."""
    BOOLEAN_EXPRESSIONS = "boolean_expressions"
    CAUSAL_JUDGEMENT = "causal_judgement"
    DATE_UNDERSTANDING = "date_understanding"
    DISAMBIGUATION_QA = "disambiguation_qa"
    DYCK_LANGUAGES = "dyck_languages"
    FORMAL_FALLACIES = "formal_fallacies"
    GEOMETRIC_SHAPES = "geometric_shapes"
    HYPERBATON = "hyperbaton"
    LOGICAL_DEDUCTION_FIVE_OBJECTS = "logical_deduction_five_objects"
    LOGICAL_DEDUCTION_SEVEN_OBJECTS = "logical_deduction_seven_objects"
    LOGICAL_DEDUCTION_THREE_OBJECTS = "logical_deduction_three_objects"
    MOVIE_RECOMMENDATION = "movie_recommendation"
    MULTISTEP_ARITHMETIC_TWO = "multistep_arithmetic_two"
    NAVIGATE = "navigate"
    OBJECT_COUNTING = "object_counting"
    PENGUINS_IN_A_TABLE = "penguins_in_a_table"
    REASONING_ABOUT_COLORED_OBJECTS = "reasoning_about_colored_objects"
    RUIN_NAMES = "ruin_names"
    SALIENT_TRANSLATION_ERROR_DETECTION = "salient_translation_error_detection"
    SNARKS = "snarks"
    SPORTS_UNDERSTANDING = "sports_understanding"
    TEMPORAL_SEQUENCES = "temporal_sequences"
    TRACKING_SHUFFLED_OBJECTS_FIVE_OBJECTS = "tracking_shuffled_objects_five_objects"
    TRACKING_SHUFFLED_OBJECTS_SEVEN_OBJECTS = "tracking_shuffled_objects_seven_objects"
    TRACKING_SHUFFLED_OBJECTS_THREE_OBJECTS = "tracking_shuffled_objects_three_objects"
    WEB_OF_LIES = "web_of_lies"
    WORD_SORTING = "word_sorting"


class ARCMode(Enum):
    """ARC difficulty levels."""
    CHALLENGE = "ARC-Challenge"
    EASY = "ARC-Easy"


class TruthfulQAMode(Enum):
    """TruthfulQA modes."""
    MC1 = "mc1"  # Single correct answer
    MC2 = "mc2"  # Multiple correct answers


class HellaSwagTask(Enum):
    """HellaSwag doesn't have subgroups, but we define for consistency."""
    ALL = "all"


class DROPTask(Enum):
    """DROP doesn't have subgroups."""
    ALL = "all"


class GSM8KTask(Enum):
    """GSM8K doesn't have subgroups."""
    ALL = "all"


class BoolQTask(Enum):
    """BoolQ doesn't have subgroups."""
    ALL = "all"


class SQuADTask(Enum):
    """SQuAD doesn't have subgroups."""
    ALL = "all"


class WinograndeTask(Enum):
    """Winogrande doesn't have subgroups."""
    ALL = "all"


class LAMBADATask(Enum):
    """LAMBADA doesn't have subgroups."""
    ALL = "all"


class MathQATask(Enum):
    """MathQA categories."""
    GENERAL = "general"
    GAIN = "gain"
    GEOMETRY = "geometry"
    OTHER = "other"
    PHYSICS = "physics"
    PROBABILITY = "probability"


class LogiQATask(Enum):
    """LogiQA doesn't have subgroups."""
    ALL = "all"


class BBQTask(Enum):
    """BBQ bias categories."""
    AGE = "Age"
    DISABILITY_STATUS = "Disability_status"
    GENDER_IDENTITY = "Gender_identity"
    NATIONALITY = "Nationality"
    PHYSICAL_APPEARANCE = "Physical_appearance"
    RACE_ETHNICITY = "Race_ethnicity"
    RELIGION = "Religion"
    SES = "SES"
    SEXUAL_ORIENTATION = "Sexual_orientation"


class IFEvalTask(Enum):
    """IFEval doesn't have subgroups."""
    ALL = "all"


# =============================================================================
# Custom Benchmark Task Enums
# =============================================================================

class GPQATask(Enum):
    """GPQA subsets."""
    DIAMOND = "diamond"  # 198 questions, hardest
    MAIN = "main"  # Extended set
    EXTENDED = "extended"  # Full set


class GAIATask(Enum):
    """GAIA difficulty levels."""
    LEVEL_1 = "level1"  # Simple, few steps
    LEVEL_2 = "level2"  # Medium complexity
    LEVEL_3 = "level3"  # Complex, many steps


class SWEBenchTask(Enum):
    """SWE-bench subsets."""
    LITE = "lite"  # 300 instances
    VERIFIED = "verified"  # Human-verified subset
    FULL = "full"  # Complete dataset


class BFCLTask(Enum):
    """BFCL (Berkeley Function Calling) categories."""
    SIMPLE = "simple"
    MULTIPLE = "multiple"
    PARALLEL = "parallel"
    PARALLEL_MULTIPLE = "parallel_multiple"
    JAVA = "java"
    JAVASCRIPT = "javascript"
    REST = "rest"
    SQL = "sql"
    LIVE_SIMPLE = "live_simple"
    LIVE_MULTIPLE = "live_multiple"
    LIVE_PARALLEL = "live_parallel"
    LIVE_PARALLEL_MULTIPLE = "live_parallel_multiple"
    LIVE_RELEVANCE = "live_relevance"
    LIVE_IRRELEVANCE = "live_irrelevance"


class MMMUTask(Enum):
    """MMMU subjects."""
    ART = "Art"
    ART_THEORY = "Art_Theory"
    DESIGN = "Design"
    MUSIC = "Music"
    ACCOUNTING = "Accounting"
    ECONOMICS = "Economics"
    FINANCE = "Finance"
    MANAGE = "Manage"
    MARKETING = "Marketing"
    BIOLOGY = "Biology"
    CHEMISTRY = "Chemistry"
    GEOGRAPHY = "Geography"
    MATH = "Math"
    PHYSICS = "Physics"
    BASIC_MEDICAL_SCIENCE = "Basic_Medical_Science"
    CLINICAL_MEDICINE = "Clinical_Medicine"
    DIAGNOSTICS_AND_LABORATORY_MEDICINE = "Diagnostics_and_Laboratory_Medicine"
    PHARMACY = "Pharmacy"
    PUBLIC_HEALTH = "Public_Health"
    COMPUTER_SCIENCE = "Computer_Science"
    ELECTRONICS = "Electronics"
    ENERGY_AND_POWER = "Energy_and_Power"
    MATERIALS = "Materials"
    MECHANICAL_ENGINEERING = "Mechanical_Engineering"
    HISTORY = "History"
    LITERATURE = "Literature"
    SOCIOLOGY = "Sociology"
    PSYCHOLOGY = "Psychology"


class LiveCodeBenchTask(Enum):
    """LiveCodeBench categories."""
    CODE_GENERATION = "code_generation"
    SELF_REPAIR = "self_repair"
    CODE_EXECUTION = "code_execution"
    TEST_OUTPUT = "test_output"


class HLETask(Enum):
    """Humanity's Last Exam subjects."""
    MATH = "math"
    PHYSICS = "physics"
    CHEMISTRY = "chemistry"
    BIOLOGY = "biology"
    COMPUTER_SCIENCE = "computer_science"
    ECONOMICS = "economics"
    PHILOSOPHY = "philosophy"
    LAW = "law"
    MEDICINE = "medicine"
    ENGINEERING = "engineering"


# =============================================================================
# Task Registry
# =============================================================================

TASK_REGISTRY: Dict[str, Type[Enum]] = {
    # DeepEval benchmarks
    "MMLU": MMLUTask,
    "BigBenchHard": BigBenchHardTask,
    "ARC": ARCMode,
    "TruthfulQA": TruthfulQAMode,
    "HellaSwag": HellaSwagTask,
    "DROP": DROPTask,
    "GSM8K": GSM8KTask,
    "BoolQ": BoolQTask,
    "SQuAD": SQuADTask,
    "Winogrande": WinograndeTask,
    "LAMBADA": LAMBADATask,
    "MathQA": MathQATask,
    "LogiQA": LogiQATask,
    "BBQ": BBQTask,
    "IFEval": IFEvalTask,
    # Custom benchmarks
    "GPQA": GPQATask,
    "GAIA": GAIATask,
    "SWE-bench": SWEBenchTask,
    "BFCL": BFCLTask,
    "MMMU": MMMUTask,
    "LiveCodeBench": LiveCodeBenchTask,
    "HLE": HLETask,
}


def get_task_enum(benchmark_name: str) -> Type[Enum]:
    """Get the task enum for a benchmark."""
    return TASK_REGISTRY.get(benchmark_name)


def list_tasks(benchmark_name: str) -> list:
    """List all tasks for a benchmark."""
    enum_class = get_task_enum(benchmark_name)
    if enum_class:
        return [task.value for task in enum_class]
    return []
