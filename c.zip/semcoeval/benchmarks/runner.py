"""
Benchmark Runner - Run multiple benchmarks and generate comparative reports.
"""

from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass, field
from pathlib import Path
import json
from datetime import datetime

from .base import BaseBenchmark, BenchmarkConfig, BenchmarkResult
from .deepeval_benchmarks import DEEPEVAL_BENCHMARKS, get_benchmark
from .custom_benchmarks import CUSTOM_BENCHMARKS, get_custom_benchmark
from ..capabilities.validator import CapabilityValidator, ValidationLevel


def _get_any_benchmark(name: str, config: BenchmarkConfig = None) -> BaseBenchmark:
    """Get any benchmark by name (internal helper)."""
    if name in DEEPEVAL_BENCHMARKS:
        return get_benchmark(name, config)
    elif name in CUSTOM_BENCHMARKS:
        return get_custom_benchmark(name, config)
    else:
        all_benchmarks = {**DEEPEVAL_BENCHMARKS, **CUSTOM_BENCHMARKS}
        raise ValueError(f"Unknown benchmark: {name}. Available: {list(all_benchmarks.keys())}")


def _list_all_benchmarks() -> list:
    """List all available benchmark names (internal helper)."""
    all_benchmarks = {**DEEPEVAL_BENCHMARKS, **CUSTOM_BENCHMARKS}
    return list(all_benchmarks.keys())


@dataclass
class BenchmarkSuite:
    """A collection of benchmarks to run together."""
    name: str
    benchmarks: List[str]
    description: str = ""
    config: Optional[BenchmarkConfig] = None


# Predefined benchmark suites
BENCHMARK_SUITES = {
    "reasoning": BenchmarkSuite(
        name="Reasoning Suite",
        benchmarks=["MMLU", "BigBenchHard", "GSM8K", "ARC", "LogiQA"],
        description="Tests reasoning and knowledge capabilities"
    ),
    "coding": BenchmarkSuite(
        name="Coding Suite",
        benchmarks=["HumanEval", "LiveCodeBench"],
        description="Tests code generation capabilities"
    ),
    "agent": BenchmarkSuite(
        name="Agent Suite",
        benchmarks=["BFCL", "GAIA"],
        description="Tests agent and tool use capabilities"
    ),
    "safety": BenchmarkSuite(
        name="Safety Suite",
        benchmarks=["TruthfulQA", "BBQ"],
        description="Tests safety and bias"
    ),
    "multimodal": BenchmarkSuite(
        name="Multimodal Suite",
        benchmarks=["MMMU"],
        description="Tests vision and multimodal capabilities"
    ),
    "comprehensive": BenchmarkSuite(
        name="Comprehensive Suite",
        benchmarks=["MMLU", "HumanEval", "GSM8K", "TruthfulQA", "HellaSwag"],
        description="Standard comprehensive evaluation"
    ),
    "frontier": BenchmarkSuite(
        name="Frontier Suite",
        benchmarks=["GPQA", "GAIA", "SWE-bench", "MMMU"],
        description="Hardest benchmarks for frontier models"
    ),
}


@dataclass
class BenchmarkRunResult:
    """Result from running a benchmark suite."""
    suite_name: str
    model_id: str
    provider: str
    timestamp: str
    results: Dict[str, BenchmarkResult]
    overall_score: float
    capability_warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "suite_name": self.suite_name,
            "model_id": self.model_id,
            "provider": self.provider,
            "timestamp": self.timestamp,
            "overall_score": self.overall_score,
            "benchmark_scores": {
                name: result.overall_accuracy
                for name, result in self.results.items()
            },
            "capability_warnings": self.capability_warnings,
            "metadata": self.metadata,
        }

    def save(self, path: Union[str, Path]):
        """Save results to JSON file."""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)


class BenchmarkRunner:
    """
    Run benchmarks on models with capability validation.

    Usage:
        runner = BenchmarkRunner()

        # Run single benchmark
        result = runner.run_benchmark(
            benchmark="MMLU",
            model=my_model,
            provider="openai",
            model_id="gpt-4o",
            config=BenchmarkConfig(tasks=["high_school_physics"], n_samples_per_task=50)
        )

        # Run benchmark suite
        results = runner.run_suite(
            suite="reasoning",
            model=my_model,
            provider="openai",
            model_id="gpt-4o"
        )

        # Compare models
        comparison = runner.compare_models(
            benchmark="MMLU",
            models=[
                {"model": model1, "provider": "openai", "model_id": "gpt-4o"},
                {"model": model2, "provider": "anthropic", "model_id": "claude-3-opus"},
            ]
        )
    """

    def __init__(self, capability_validator: Optional[CapabilityValidator] = None):
        self.validator = capability_validator or CapabilityValidator()

    def run_benchmark(
        self,
        benchmark: Union[str, BaseBenchmark],
        model: Any,
        provider: str,
        model_id: str,
        config: Optional[BenchmarkConfig] = None,
        validation_level: ValidationLevel = ValidationLevel.WARN,
        **kwargs
    ) -> BenchmarkResult:
        """
        Run a single benchmark.

        Args:
            benchmark: Benchmark name or instance
            model: Model to evaluate
            provider: Provider name
            model_id: Model ID
            config: Benchmark configuration
            validation_level: How strictly to validate capabilities
            **kwargs: Additional arguments passed to evaluate()

        Returns:
            BenchmarkResult
        """
        # Get benchmark instance
        if isinstance(benchmark, str):
            benchmark_instance = _get_any_benchmark(benchmark, config)
        else:
            benchmark_instance = benchmark

        # Validate capabilities
        validation = self.validator.validate(
            provider, model_id, benchmark_instance.name, validation_level
        )
        if not validation.is_valid and validation_level == ValidationLevel.STRICT:
            raise ValueError(
                f"Model {provider}:{model_id} incompatible with {benchmark_instance.name}: "
                f"{validation.errors}"
            )

        # Run benchmark
        result = benchmark_instance.evaluate(model, **kwargs)

        # Add validation warnings to result
        if validation.warnings:
            result.metadata["capability_warnings"] = validation.warnings

        return result

    def run_suite(
        self,
        suite: Union[str, BenchmarkSuite],
        model: Any,
        provider: str,
        model_id: str,
        config: Optional[BenchmarkConfig] = None,
        validation_level: ValidationLevel = ValidationLevel.WARN,
        **kwargs
    ) -> BenchmarkRunResult:
        """
        Run a benchmark suite.

        Args:
            suite: Suite name or BenchmarkSuite instance
            model: Model to evaluate
            provider: Provider name
            model_id: Model ID
            config: Default configuration for all benchmarks
            validation_level: Capability validation level
            **kwargs: Additional arguments

        Returns:
            BenchmarkRunResult with all benchmark results
        """
        # Get suite
        if isinstance(suite, str):
            if suite not in BENCHMARK_SUITES:
                raise ValueError(f"Unknown suite: {suite}. Available: {list(BENCHMARK_SUITES.keys())}")
            suite_instance = BENCHMARK_SUITES[suite]
        else:
            suite_instance = suite

        # Run each benchmark
        results = {}
        capability_warnings = []

        for benchmark_name in suite_instance.benchmarks:
            try:
                result = self.run_benchmark(
                    benchmark=benchmark_name,
                    model=model,
                    provider=provider,
                    model_id=model_id,
                    config=config or suite_instance.config,
                    validation_level=validation_level,
                    **kwargs
                )
                results[benchmark_name] = result

                # Collect warnings
                if result.metadata.get("capability_warnings"):
                    capability_warnings.extend(result.metadata["capability_warnings"])

            except Exception as e:
                print(f"Warning: Failed to run {benchmark_name}: {e}")
                # Create error result
                results[benchmark_name] = BenchmarkResult(
                    benchmark_name=benchmark_name,
                    overall_accuracy=0,
                    task_scores={},
                    total_samples=0,
                    correct_samples=0,
                    predictions=[],
                    metadata={"error": str(e)}
                )

        # Calculate overall score
        scores = [r.overall_accuracy for r in results.values() if r.total_samples > 0]
        overall_score = sum(scores) / len(scores) if scores else 0

        return BenchmarkRunResult(
            suite_name=suite_instance.name,
            model_id=model_id,
            provider=provider,
            timestamp=datetime.now().isoformat(),
            results=results,
            overall_score=overall_score,
            capability_warnings=list(set(capability_warnings)),
        )

    def compare_models(
        self,
        benchmark: str,
        models: List[Dict[str, Any]],
        config: Optional[BenchmarkConfig] = None,
        **kwargs
    ) -> Dict[str, BenchmarkResult]:
        """
        Compare multiple models on a benchmark.

        Args:
            benchmark: Benchmark name
            models: List of {"model": model, "provider": str, "model_id": str}
            config: Benchmark configuration
            **kwargs: Additional arguments

        Returns:
            Dict mapping "provider:model_id" to BenchmarkResult
        """
        results = {}

        for model_info in models:
            model = model_info["model"]
            provider = model_info["provider"]
            model_id = model_info["model_id"]
            key = f"{provider}:{model_id}"

            try:
                result = self.run_benchmark(
                    benchmark=benchmark,
                    model=model,
                    provider=provider,
                    model_id=model_id,
                    config=config,
                    **kwargs
                )
                results[key] = result
            except Exception as e:
                print(f"Warning: Failed to evaluate {key}: {e}")

        return results

    def generate_leaderboard(
        self,
        results: Dict[str, BenchmarkResult],
        sort_by: str = "overall_accuracy"
    ) -> List[Dict[str, Any]]:
        """
        Generate a leaderboard from comparison results.

        Args:
            results: Dict of model_key -> BenchmarkResult
            sort_by: Field to sort by

        Returns:
            Sorted list of leaderboard entries
        """
        leaderboard = []

        for model_key, result in results.items():
            provider, model_id = model_key.split(":", 1)
            entry = {
                "rank": 0,
                "model": model_key,
                "provider": provider,
                "model_id": model_id,
                "benchmark": result.benchmark_name,
                "overall_accuracy": result.overall_accuracy,
                "total_samples": result.total_samples,
                "correct_samples": result.correct_samples,
            }
            leaderboard.append(entry)

        # Sort
        leaderboard.sort(key=lambda x: x.get(sort_by, 0), reverse=True)

        # Add ranks
        for i, entry in enumerate(leaderboard):
            entry["rank"] = i + 1

        return leaderboard

    @staticmethod
    def list_suites() -> List[str]:
        """List available benchmark suites."""
        return list(BENCHMARK_SUITES.keys())

    @staticmethod
    def get_suite_info(suite_name: str) -> Dict[str, Any]:
        """Get information about a benchmark suite."""
        if suite_name not in BENCHMARK_SUITES:
            raise ValueError(f"Unknown suite: {suite_name}")
        suite = BENCHMARK_SUITES[suite_name]
        return {
            "name": suite.name,
            "description": suite.description,
            "benchmarks": suite.benchmarks,
        }
