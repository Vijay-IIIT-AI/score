"""
DeepEval Benchmark Wrappers - Unified interface for all DeepEval benchmarks.

Wraps 17 DeepEval benchmarks with:
- Consistent interface
- Subgroup/task filtering
- Offline dataset support
- Capability requirements
"""

from typing import Optional, Set, Type, Any, List, Dict
from enum import Enum

from .base import BaseBenchmark, DeepEvalBenchmarkWrapper, BenchmarkConfig, BenchmarkResult
from .tasks import (
    MMLUTask, BigBenchHardTask, ARCMode, TruthfulQAMode,
    HellaSwagTask, DROPTask, GSM8KTask, BoolQTask, SQuADTask,
    WinograndeTask, LAMBADATask, MathQATask, LogiQATask, BBQTask, IFEvalTask
)
from ..capabilities.registry import Capability


# =============================================================================
# MMLU - Massive Multitask Language Understanding
# =============================================================================

class MMLUBenchmark(DeepEvalBenchmarkWrapper):
    """
    MMLU Benchmark - 57 subjects across STEM, humanities, social sciences, etc.

    Usage:
        benchmark = MMLUBenchmark(config=BenchmarkConfig(
            tasks=["high_school_physics", "college_mathematics"],
            n_shots=5,
            n_samples_per_task=50
        ))
        result = benchmark.evaluate(model)
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import MMLU
        super().__init__(
            deepeval_benchmark_class=MMLU,
            task_enum=MMLUTask,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "MMLU"

    @property
    def description(self) -> str:
        return "Massive Multitask Language Understanding - 57 subjects, 14,042 questions"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "cais/mmlu"


# =============================================================================
# BigBench Hard - Challenging reasoning tasks
# =============================================================================

class BigBenchHardBenchmark(DeepEvalBenchmarkWrapper):
    """
    BigBench Hard - 27 challenging reasoning tasks.

    Tasks include logical deduction, causal reasoning, date understanding, etc.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import BigBenchHard
        super().__init__(
            deepeval_benchmark_class=BigBenchHard,
            task_enum=BigBenchHardTask,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "BigBenchHard"

    @property
    def description(self) -> str:
        return "BigBench Hard - 27 challenging reasoning tasks"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "maveriq/bigbenchhard"


# =============================================================================
# ARC - AI2 Reasoning Challenge
# =============================================================================

class ARCBenchmark(DeepEvalBenchmarkWrapper):
    """
    ARC Benchmark - Science questions at Easy and Challenge levels.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import ARC
        super().__init__(
            deepeval_benchmark_class=ARC,
            task_enum=ARCMode,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "ARC"

    @property
    def description(self) -> str:
        return "AI2 Reasoning Challenge - Science questions (Easy & Challenge)"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "allenai/ai2_arc"


# =============================================================================
# TruthfulQA - Truthfulness evaluation
# =============================================================================

class TruthfulQABenchmark(DeepEvalBenchmarkWrapper):
    """
    TruthfulQA - Tests for truthful responses vs common misconceptions.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import TruthfulQA
        super().__init__(
            deepeval_benchmark_class=TruthfulQA,
            task_enum=TruthfulQAMode,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "TruthfulQA"

    @property
    def description(self) -> str:
        return "TruthfulQA - 817 questions testing truthfulness"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "truthful_qa"


# =============================================================================
# HellaSwag - Commonsense reasoning
# =============================================================================

class HellaSwagBenchmark(DeepEvalBenchmarkWrapper):
    """
    HellaSwag - Commonsense reasoning about situations.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import HellaSwag
        super().__init__(
            deepeval_benchmark_class=HellaSwag,
            task_enum=None,  # No subgroups
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "HellaSwag"

    @property
    def description(self) -> str:
        return "HellaSwag - Commonsense reasoning completion"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "Rowan/hellaswag"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# DROP - Discrete Reasoning Over Paragraphs
# =============================================================================

class DROPBenchmark(DeepEvalBenchmarkWrapper):
    """
    DROP - Reading comprehension requiring discrete reasoning.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import DROP
        super().__init__(
            deepeval_benchmark_class=DROP,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "DROP"

    @property
    def description(self) -> str:
        return "DROP - Discrete reasoning over paragraphs"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "ucinlp/drop"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# HumanEval - Code generation
# =============================================================================

class HumanEvalBenchmark(DeepEvalBenchmarkWrapper):
    """
    HumanEval - Code generation benchmark (164 problems).
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import HumanEval
        # Map n_samples_per_task to 'n' for pass@k calculations
        if config and config.n_samples_per_task:
            kwargs['n'] = config.n_samples_per_task
        super().__init__(
            deepeval_benchmark_class=HumanEval,
            task_enum=None,  # Tasks are individual problems
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "HumanEval"

    @property
    def description(self) -> str:
        return "HumanEval - 164 code generation problems"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.CODE_EXECUTION}

    @property
    def huggingface_dataset(self) -> str:
        return "openai_humaneval"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# GSM8K - Grade school math
# =============================================================================

class GSM8KBenchmark(DeepEvalBenchmarkWrapper):
    """
    GSM8K - Grade school math word problems.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import GSM8K
        super().__init__(
            deepeval_benchmark_class=GSM8K,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "GSM8K"

    @property
    def description(self) -> str:
        return "GSM8K - 8,500 grade school math problems"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "gsm8k"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# BoolQ - Boolean questions
# =============================================================================

class BoolQBenchmark(DeepEvalBenchmarkWrapper):
    """
    BoolQ - Yes/no reading comprehension questions.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import BoolQ
        super().__init__(
            deepeval_benchmark_class=BoolQ,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "BoolQ"

    @property
    def description(self) -> str:
        return "BoolQ - Boolean yes/no questions"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "google/boolq"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# SQuAD - Reading comprehension
# =============================================================================

class SQuADBenchmark(DeepEvalBenchmarkWrapper):
    """
    SQuAD - Stanford Question Answering Dataset.

    Requires an evaluation_model parameter for scoring responses.
    """

    def __init__(
        self,
        config: Optional[BenchmarkConfig] = None,
        evaluation_model: Optional[Any] = None,
        **kwargs
    ):
        from deepeval.benchmarks import SQuAD
        # SQuAD requires an evaluation_model for judging
        if evaluation_model is not None:
            kwargs['evaluation_model'] = evaluation_model
        super().__init__(
            deepeval_benchmark_class=SQuAD,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "SQuAD"

    @property
    def description(self) -> str:
        return "SQuAD - Reading comprehension"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "rajpurkar/squad"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# Winogrande - Commonsense reasoning
# =============================================================================

class WinograndeBenchmark(DeepEvalBenchmarkWrapper):
    """
    Winogrande - Commonsense reasoning (pronoun resolution).
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import Winogrande
        super().__init__(
            deepeval_benchmark_class=Winogrande,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "Winogrande"

    @property
    def description(self) -> str:
        return "Winogrande - Commonsense reasoning"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "winogrande"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# LAMBADA - Word prediction
# =============================================================================

class LAMBADABenchmark(DeepEvalBenchmarkWrapper):
    """
    LAMBADA - Long-range word prediction.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import LAMBADA
        super().__init__(
            deepeval_benchmark_class=LAMBADA,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "LAMBADA"

    @property
    def description(self) -> str:
        return "LAMBADA - Long-range word prediction"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "lambada"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# MathQA - Math word problems
# =============================================================================

class MathQABenchmark(DeepEvalBenchmarkWrapper):
    """
    MathQA - Math word problems with rationales.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import MathQA
        super().__init__(
            deepeval_benchmark_class=MathQA,
            task_enum=MathQATask,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "MathQA"

    @property
    def description(self) -> str:
        return "MathQA - Math word problems"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "math_qa"


# =============================================================================
# LogiQA - Logical reasoning
# =============================================================================

class LogiQABenchmark(DeepEvalBenchmarkWrapper):
    """
    LogiQA - Logical reasoning questions.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import LogiQA
        super().__init__(
            deepeval_benchmark_class=LogiQA,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "LogiQA"

    @property
    def description(self) -> str:
        return "LogiQA - Logical reasoning"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "lucasmccabe/logiqa"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# BBQ - Bias Benchmark for QA
# =============================================================================

class BBQBenchmark(DeepEvalBenchmarkWrapper):
    """
    BBQ - Bias Benchmark for QA across 9 social categories.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import BBQ
        super().__init__(
            deepeval_benchmark_class=BBQ,
            task_enum=BBQTask,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "BBQ"

    @property
    def description(self) -> str:
        return "BBQ - Bias evaluation across 9 social categories"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "lighteval/bbq_helm"


# =============================================================================
# IFEval - Instruction Following
# =============================================================================

class IFEvalBenchmark(DeepEvalBenchmarkWrapper):
    """
    IFEval - Instruction following evaluation.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import IFEval
        super().__init__(
            deepeval_benchmark_class=IFEval,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "IFEval"

    @property
    def description(self) -> str:
        return "IFEval - Instruction following evaluation"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "google/IFEval"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# EquityMedQA - Medical QA with equity focus
# =============================================================================

class EquityMedQABenchmark(DeepEvalBenchmarkWrapper):
    """
    EquityMedQA - Medical question answering with health equity focus.

    Tests model performance on medical questions across diverse patient
    demographics to identify potential biases in healthcare recommendations.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None, **kwargs):
        from deepeval.benchmarks import EquityMedQA
        super().__init__(
            deepeval_benchmark_class=EquityMedQA,
            task_enum=None,
            config=config,
            **kwargs
        )

    @property
    def name(self) -> str:
        return "EquityMedQA"

    @property
    def description(self) -> str:
        return "EquityMedQA - Medical QA with health equity focus"

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION}

    @property
    def huggingface_dataset(self) -> str:
        return "google/equity_med_qa"

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return None


# =============================================================================
# Registry of all DeepEval benchmarks
# =============================================================================

DEEPEVAL_BENCHMARKS = {
    "MMLU": MMLUBenchmark,
    "BigBenchHard": BigBenchHardBenchmark,
    "ARC": ARCBenchmark,
    "TruthfulQA": TruthfulQABenchmark,
    "HellaSwag": HellaSwagBenchmark,
    "DROP": DROPBenchmark,
    "HumanEval": HumanEvalBenchmark,
    "GSM8K": GSM8KBenchmark,
    "BoolQ": BoolQBenchmark,
    "SQuAD": SQuADBenchmark,
    "Winogrande": WinograndeBenchmark,
    "LAMBADA": LAMBADABenchmark,
    "MathQA": MathQABenchmark,
    "LogiQA": LogiQABenchmark,
    "BBQ": BBQBenchmark,
    "IFEval": IFEvalBenchmark,
    "EquityMedQA": EquityMedQABenchmark,
}


def get_benchmark(name: str, config: Optional[BenchmarkConfig] = None) -> BaseBenchmark:
    """
    Get a benchmark by name.

    Args:
        name: Benchmark name (e.g., 'MMLU', 'HumanEval')
        config: Optional benchmark configuration

    Returns:
        Benchmark instance
    """
    if name not in DEEPEVAL_BENCHMARKS:
        raise ValueError(f"Unknown benchmark: {name}. Available: {list(DEEPEVAL_BENCHMARKS.keys())}")

    return DEEPEVAL_BENCHMARKS[name](config=config)


def list_benchmarks() -> List[str]:
    """List all available benchmark names."""
    return list(DEEPEVAL_BENCHMARKS.keys())


def get_benchmark_info() -> List[Dict[str, Any]]:
    """Get info about all available benchmarks."""
    info = []
    for name, cls in DEEPEVAL_BENCHMARKS.items():
        instance = cls()
        info.append({
            "name": name,
            "description": instance.description,
            "tasks": instance.available_tasks,
            "task_count": len(instance.available_tasks),
            "required_capabilities": [c.value for c in instance.required_capabilities],
            "huggingface_dataset": instance.huggingface_dataset,
        })
    return info
