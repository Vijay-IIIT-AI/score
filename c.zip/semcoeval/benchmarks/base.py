"""
Base Benchmark - Abstract base class for all SemcoEval benchmarks.

Provides:
- Unified interface for DeepEval benchmarks and custom benchmarks
- Offline dataset loading support
- Subgroup filtering
- Capability requirements
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Set, Union, Type
from enum import Enum
from pathlib import Path

from ..capabilities.registry import Capability


@dataclass
class BenchmarkResult:
    """Result from a benchmark evaluation."""
    benchmark_name: str
    overall_accuracy: float
    task_scores: Dict[str, float]  # task_name -> score
    total_samples: int
    correct_samples: int
    predictions: List[Dict[str, Any]]
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def pass_rate(self) -> float:
        return self.correct_samples / self.total_samples if self.total_samples > 0 else 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "benchmark": self.benchmark_name,
            "overall_accuracy": self.overall_accuracy,
            "pass_rate": self.pass_rate,
            "total_samples": self.total_samples,
            "correct_samples": self.correct_samples,
            "task_scores": self.task_scores,
            "metadata": self.metadata,
        }


@dataclass
class BenchmarkConfig:
    """Configuration for running a benchmark."""
    # Task/subgroup selection
    tasks: Optional[List[str]] = None  # None = all tasks

    # Sampling
    n_samples_per_task: Optional[int] = None  # None = all samples
    random_seed: Optional[int] = None

    # Few-shot settings
    n_shots: int = 0

    # Execution
    batch_size: Optional[int] = None
    verbose: bool = False

    # Offline mode
    offline_dataset_path: Optional[str] = None


class BaseBenchmark(ABC):
    """
    Abstract base class for all benchmarks.

    Subclasses must implement:
    - name: Benchmark name
    - task_enum: Enum class defining available tasks/subgroups
    - required_capabilities: Set of capabilities needed
    - load_dataset(): Load the benchmark dataset
    - evaluate(): Run evaluation on a model
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        self.config = config or BenchmarkConfig()
        self._dataset = None
        self._tasks = None

    @property
    @abstractmethod
    def name(self) -> str:
        """Benchmark name (e.g., 'MMLU', 'HumanEval')."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Brief description of the benchmark."""
        pass

    @property
    @abstractmethod
    def task_enum(self) -> Optional[Type[Enum]]:
        """Enum class defining available tasks/subgroups, or None if no subgroups."""
        pass

    @property
    @abstractmethod
    def required_capabilities(self) -> Set[Capability]:
        """Capabilities required to run this benchmark."""
        pass

    @property
    def huggingface_dataset(self) -> Optional[str]:
        """HuggingFace dataset identifier, or None if not available."""
        return None

    @property
    def available_tasks(self) -> List[str]:
        """List of available task/subgroup names."""
        if self.task_enum is None:
            return []
        return [task.value for task in self.task_enum]

    @property
    def selected_tasks(self) -> List[Any]:
        """Get the tasks to run based on config."""
        if self._tasks is not None:
            return self._tasks

        if self.task_enum is None:
            return []

        if self.config.tasks is None:
            # All tasks
            self._tasks = list(self.task_enum)
        else:
            # Filter to selected tasks
            self._tasks = [
                task for task in self.task_enum
                if task.value in self.config.tasks or task.name in self.config.tasks
            ]

        return self._tasks

    def get_task_by_name(self, name: str) -> Optional[Any]:
        """Get a task enum by its name or value."""
        if self.task_enum is None:
            return None
        for task in self.task_enum:
            if task.value == name or task.name == name:
                return task
        return None

    @abstractmethod
    def load_dataset(self, task: Optional[Any] = None) -> List[Dict[str, Any]]:
        """
        Load the benchmark dataset.

        Args:
            task: Optional specific task to load

        Returns:
            List of samples, each with 'input', 'expected_output', etc.
        """
        pass

    def load_offline_dataset(self, path: Union[str, Path]) -> List[Dict[str, Any]]:
        """
        Load dataset from local file for offline evaluation.

        Args:
            path: Path to local dataset file (JSON/JSONL)

        Returns:
            List of samples
        """
        import json
        path = Path(path)

        if path.suffix == '.jsonl':
            samples = []
            with open(path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        samples.append(json.loads(line))
            return samples
        else:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
            return data.get('questions', data.get('data', data.get('samples', [])))

    @abstractmethod
    def evaluate(self, model: Any, **kwargs) -> BenchmarkResult:
        """
        Run the benchmark evaluation.

        Args:
            model: The model to evaluate (DeepEval model or callable)
            **kwargs: Additional evaluation parameters

        Returns:
            BenchmarkResult with scores and details
        """
        pass

    def get_deepeval_benchmark(self) -> Any:
        """
        Get the underlying DeepEval benchmark instance if available.

        Returns:
            DeepEval benchmark instance or None
        """
        return None

    def __repr__(self) -> str:
        tasks_str = f", tasks={len(self.available_tasks)}" if self.available_tasks else ""
        return f"{self.__class__.__name__}(name='{self.name}'{tasks_str})"


class DeepEvalBenchmarkWrapper(BaseBenchmark):
    """
    Wrapper for DeepEval's built-in benchmarks.

    Provides:
    - Unified interface
    - Subgroup/task filtering
    - Offline dataset support
    - Capability requirements
    """

    def __init__(
        self,
        deepeval_benchmark_class: Type,
        task_enum: Optional[Type[Enum]],
        config: Optional[BenchmarkConfig] = None,
        **benchmark_kwargs
    ):
        super().__init__(config)
        self._deepeval_class = deepeval_benchmark_class
        self._task_enum = task_enum
        self._benchmark_kwargs = benchmark_kwargs
        self._deepeval_instance = None

    @property
    def task_enum(self) -> Optional[Type[Enum]]:
        return self._task_enum

    def _get_deepeval_instance(self):
        """Get or create the DeepEval benchmark instance."""
        if self._deepeval_instance is None:
            # Build kwargs for DeepEval benchmark
            kwargs = self._benchmark_kwargs.copy()

            # Add tasks if specified
            if self.config.tasks and self._task_enum:
                tasks = [
                    task for task in self._task_enum
                    if task.value in self.config.tasks or task.name in self.config.tasks
                ]
                kwargs['tasks'] = tasks

            # Add n_shots if supported
            if self.config.n_shots > 0:
                kwargs['n_shots'] = self.config.n_shots

            # Add n_problems_per_task if supported
            if self.config.n_samples_per_task:
                kwargs['n_problems_per_task'] = self.config.n_samples_per_task

            # Add verbose mode
            kwargs['verbose_mode'] = self.config.verbose

            self._deepeval_instance = self._deepeval_class(**kwargs)

        return self._deepeval_instance

    def get_deepeval_benchmark(self) -> Any:
        return self._get_deepeval_instance()

    def load_dataset(self, task: Optional[Any] = None) -> List[Dict[str, Any]]:
        """Load dataset from DeepEval or offline."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        benchmark = self._get_deepeval_instance()
        goldens = self._load_goldens(benchmark, task)

        if not goldens:
            raise RuntimeError(f"No data loaded for benchmark {self.name}")

        samples = self._convert_goldens(goldens)
        if not samples:
            raise RuntimeError(f"No valid samples for benchmark {self.name}")

        return samples

    def _load_goldens(self, benchmark, task: Optional[Any]) -> List:
        """Load golden data from benchmark.

        Note: DeepEval's load_benchmark_dataset() takes no arguments.
        Tasks are filtered at benchmark construction time via the 'tasks' parameter.
        """
        try:
            # DeepEval benchmarks load all configured tasks at once
            result = benchmark.load_benchmark_dataset()
            if result:
                return result if isinstance(result, list) else [result]
            return []
        except Exception as e:
            raise RuntimeError(f"Failed to load benchmark {self.name}: {e}")

    def _convert_goldens(self, goldens: List) -> List[Dict[str, Any]]:
        """Convert Golden objects to dicts."""
        samples = []
        for g in goldens:
            if g is None:
                continue
            sample = {
                'input': getattr(g, 'input', ''),
                'expected_output': getattr(g, 'expected_output', None),
            }
            if hasattr(g, 'context') and g.context:
                sample['context'] = g.context
            if hasattr(g, 'additional_metadata') and g.additional_metadata:
                sample['metadata'] = g.additional_metadata
            samples.append(sample)
        return samples

    def evaluate(self, model: Any, **kwargs) -> BenchmarkResult:
        """Run evaluation using DeepEval's evaluate method."""
        benchmark = self._get_deepeval_instance()

        # Merge kwargs
        eval_kwargs = {**kwargs}
        if self.config.batch_size:
            eval_kwargs['batch_size'] = self.config.batch_size

        # Run DeepEval evaluation
        result = benchmark.evaluate(model, **eval_kwargs)

        # Convert to our result format
        task_scores = {}
        if hasattr(benchmark, 'task_scores') and benchmark.task_scores is not None:
            for _, row in benchmark.task_scores.iterrows():
                task_scores[row['Task']] = row['Score']

        predictions = []
        if hasattr(benchmark, 'predictions') and benchmark.predictions is not None:
            predictions = benchmark.predictions.to_dict('records')

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=result.overall_accuracy,
            task_scores=task_scores,
            total_samples=len(predictions) if predictions else 0,
            correct_samples=sum(1 for p in predictions if p.get('Correct', p.get('Score', 0))),
            predictions=predictions,
            metadata={
                'n_shots': self.config.n_shots,
                'tasks': [t.value for t in self.selected_tasks] if self.selected_tasks else [],
            }
        )
