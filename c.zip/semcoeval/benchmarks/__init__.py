"""
Benchmarks Module - Unified interface for all evaluation benchmarks.

Includes:
- 17 DeepEval benchmarks (MMLU, HumanEval, GSM8K, etc.)
- 7 Custom benchmarks (GPQA, GAIA, BFCL, MMMU, SWE-bench, LiveCodeBench, HLE)
- Subgroup/task filtering
- Offline dataset support
"""

from .base import (
    BaseBenchmark,
    DeepEvalBenchmarkWrapper,
    BenchmarkConfig,
    BenchmarkResult,
)

from .tasks import (
    # DeepEval task enums
    MMLUTask,
    BigBenchHardTask,
    ARCMode,
    TruthfulQAMode,
    BBQTask,
    MathQATask,
    # Custom benchmark task enums
    GPQATask,
    GAIATask,
    SWEBenchTask,
    BFCLTask,
    MMMUTask,
    LiveCodeBenchTask,
    HLETask,
    # Registry
    TASK_REGISTRY,
    get_task_enum,
    list_tasks,
)

from .deepeval_benchmarks import (
    # Individual benchmarks
    MMLUBenchmark,
    BigBenchHardBenchmark,
    ARCBenchmark,
    TruthfulQABenchmark,
    HellaSwagBenchmark,
    DROPBenchmark,
    HumanEvalBenchmark,
    GSM8KBenchmark,
    BoolQBenchmark,
    SQuADBenchmark,
    WinograndeBenchmark,
    LAMBADABenchmark,
    MathQABenchmark,
    LogiQABenchmark,
    BBQBenchmark,
    IFEvalBenchmark,
    EquityMedQABenchmark,
    # Registry
    DEEPEVAL_BENCHMARKS,
    get_benchmark,
    list_benchmarks,
    get_benchmark_info,
)

from .custom_benchmarks import (
    GPQABenchmark,
    GAIABenchmark,
    BFCLBenchmark,
    MMMUBenchmark,
    SWEBenchBenchmark,
    LiveCodeBenchBenchmark,
    HLEBenchmark,
    CUSTOM_BENCHMARKS,
    get_custom_benchmark,
)

from .runner import (
    BenchmarkRunner,
    BenchmarkSuite,
    BenchmarkRunResult,
    BENCHMARK_SUITES,
)

# Combined registry
ALL_BENCHMARKS = {**DEEPEVAL_BENCHMARKS, **CUSTOM_BENCHMARKS}


def get_any_benchmark(name: str, config: BenchmarkConfig = None) -> BaseBenchmark:
    """
    Get any benchmark by name (DeepEval or custom).

    Args:
        name: Benchmark name
        config: Optional configuration

    Returns:
        Benchmark instance
    """
    if name in DEEPEVAL_BENCHMARKS:
        return get_benchmark(name, config)
    elif name in CUSTOM_BENCHMARKS:
        return get_custom_benchmark(name, config)
    else:
        raise ValueError(f"Unknown benchmark: {name}. Available: {list(ALL_BENCHMARKS.keys())}")


def list_all_benchmarks() -> list:
    """List all available benchmark names."""
    return list(ALL_BENCHMARKS.keys())


__all__ = [
    # Base classes
    "BaseBenchmark",
    "DeepEvalBenchmarkWrapper",
    "BenchmarkConfig",
    "BenchmarkResult",
    # Task enums
    "MMLUTask",
    "BigBenchHardTask",
    "ARCMode",
    "TruthfulQAMode",
    "BBQTask",
    "MathQATask",
    "GPQATask",
    "GAIATask",
    "SWEBenchTask",
    "BFCLTask",
    "MMMUTask",
    "LiveCodeBenchTask",
    "HLETask",
    # DeepEval benchmarks
    "MMLUBenchmark",
    "BigBenchHardBenchmark",
    "ARCBenchmark",
    "TruthfulQABenchmark",
    "HellaSwagBenchmark",
    "DROPBenchmark",
    "HumanEvalBenchmark",
    "GSM8KBenchmark",
    "BoolQBenchmark",
    "SQuADBenchmark",
    "WinograndeBenchmark",
    "LAMBADABenchmark",
    "MathQABenchmark",
    "LogiQABenchmark",
    "BBQBenchmark",
    "IFEvalBenchmark",
    "EquityMedQABenchmark",
    # Custom benchmarks
    "GPQABenchmark",
    "GAIABenchmark",
    "BFCLBenchmark",
    "MMMUBenchmark",
    "SWEBenchBenchmark",
    "LiveCodeBenchBenchmark",
    "HLEBenchmark",
    # Registries
    "DEEPEVAL_BENCHMARKS",
    "CUSTOM_BENCHMARKS",
    "ALL_BENCHMARKS",
    "TASK_REGISTRY",
    # Functions
    "get_benchmark",
    "get_custom_benchmark",
    "get_any_benchmark",
    "list_benchmarks",
    "list_all_benchmarks",
    "get_benchmark_info",
    "get_task_enum",
    "list_tasks",
    # Runner
    "BenchmarkRunner",
    "BenchmarkSuite",
    "BenchmarkRunResult",
    "BENCHMARK_SUITES",
]
