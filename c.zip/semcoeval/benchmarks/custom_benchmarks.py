"""
Custom Benchmarks - Implementations for benchmarks not in DeepEval.

These benchmarks require custom implementation:
- GPQA: Graduate-level science questions
- GAIA: General AI Assistants (agent benchmark)
- SWE-bench: Software engineering tasks
- BFCL: Berkeley Function Calling Leaderboard
- MMMU: Multimodal understanding
- LiveCodeBench: Live code generation
- HLE: Humanity's Last Exam
"""

from typing import Optional, Set, Type, Any, List, Dict, Callable
from enum import Enum
from pathlib import Path
import json

from .base import BaseBenchmark, BenchmarkConfig, BenchmarkResult
from .tasks import (
    GPQATask, GAIATask, SWEBenchTask, BFCLTask,
    MMMUTask, LiveCodeBenchTask, HLETask
)
from ..capabilities.registry import Capability


class CustomBenchmark(BaseBenchmark):
    """Base class for custom benchmarks with common functionality."""

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)
        self._dataset_cache = {}

    def _load_from_huggingface(self, dataset_name: str, split: str = "test") -> List[Dict]:
        """Load dataset from HuggingFace."""
        try:
            from datasets import load_dataset
            dataset = load_dataset(dataset_name, split=split)
            return [dict(item) for item in dataset]
        except Exception as e:
            raise RuntimeError(f"Failed to load dataset {dataset_name}: {e}")

    def _score_exact_match(self, prediction: str, expected: str) -> bool:
        """Simple exact match scoring."""
        return prediction.strip().lower() == expected.strip().lower()

    def _score_contains(self, prediction: str, expected: str) -> bool:
        """Check if prediction contains expected answer."""
        return expected.strip().lower() in prediction.strip().lower()

    def _score_multiple_choice(self, prediction: str, expected: str, options: List[str] = None) -> bool:
        """Score multiple-choice answer with proper letter extraction."""
        import re
        pred = prediction.strip()
        exp = expected.strip()

        # Support A-G for MMMU and similar benchmarks
        if len(exp) == 1 and exp.upper() in "ABCDEFG":
            letter = exp.upper()
            patterns = [
                rf'^{letter}[\.\)\:\s]',
                rf'\b[Aa]nswer[\s\:\-]*{letter}\b',
                rf'\b[Tt]he answer is[\s\:\-]*{letter}\b',
                rf'\b[Oo]ption[\s\:\-]*{letter}\b',
                rf'\({letter}\)', rf'\[{letter}\]',
            ]
            if any(re.search(p, pred, re.IGNORECASE) for p in patterns):
                return True
            # Exact single-letter match
            if pred.upper() == letter:
                return True
            # Match option content (only if unambiguous)
            if options:
                idx = ord(letter) - ord('A')
                if 0 <= idx < len(options):
                    opt = options[idx].strip().lower()
                    # Require longer content to avoid false positives
                    if len(opt) > 5 and opt in pred.lower():
                        return True
            return False

        return exp.lower() in pred.lower()


# =============================================================================
# GPQA - Graduate-Level Google-Proof Q&A
# =============================================================================

class GPQABenchmark(CustomBenchmark):
    """
    GPQA Benchmark - Graduate-level science questions.

    Subsets:
    - Diamond: 198 hardest questions (expert-validated)
    - Main: Standard set
    - Extended: Full dataset

    Usage:
        benchmark = GPQABenchmark(config=BenchmarkConfig(
            tasks=["diamond"],
            n_samples_per_task=50
        ))
        result = benchmark.evaluate(model)
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "GPQA"

    @property
    def description(self) -> str:
        return "GPQA - Graduate-level science questions (Biology, Physics, Chemistry)"

    @property
    def task_enum(self) -> Type[Enum]:
        return GPQATask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "Idavidrein/gpqa"

    def load_dataset(self, task: Optional[GPQATask] = None) -> List[Dict[str, Any]]:
        """Load GPQA dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        # Load from HuggingFace
        subset = task.value if task else "diamond"
        try:
            from datasets import load_dataset
            dataset = load_dataset("Idavidrein/gpqa", f"gpqa_{subset}")
            samples = []
            for item in dataset["train"]:
                samples.append({
                    "input": item["Question"],
                    "expected_output": item["Correct Answer"],
                    "choices": [
                        item["Correct Answer"],
                        item["Incorrect Answer 1"],
                        item["Incorrect Answer 2"],
                        item["Incorrect Answer 3"],
                    ],
                    "subject": item.get("High-level domain", ""),
                    "subdomain": item.get("Subdomain", ""),
                })
            return samples
        except Exception as e:
            raise RuntimeError(f"Failed to load GPQA: {e}")

    def evaluate(self, model: Any, **kwargs) -> BenchmarkResult:
        """Run GPQA evaluation."""
        tasks = self.selected_tasks or [GPQATask.DIAMOND]
        all_predictions = []
        task_scores = {}
        total_correct = 0
        total_samples = 0

        for task in tasks:
            samples = self.load_dataset(task)
            if self.config.n_samples_per_task:
                samples = samples[:self.config.n_samples_per_task]

            task_correct = 0
            for sample in samples:
                # Format prompt with choices
                prompt = self._format_prompt(sample)

                # Get model prediction
                if callable(model):
                    prediction = model(prompt)
                else:
                    prediction = model.generate(prompt)

                # Score
                is_correct = self._score_gpqa(prediction, sample)
                if is_correct:
                    task_correct += 1
                    total_correct += 1

                all_predictions.append({
                    "task": task.value,
                    "input": sample["input"][:200],
                    "prediction": prediction[:200] if prediction else "",
                    "expected": sample["expected_output"],
                    "correct": is_correct,
                })

            total_samples += len(samples)
            task_scores[task.value] = task_correct / len(samples) if samples else 0

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / total_samples if total_samples else 0,
            task_scores=task_scores,
            total_samples=total_samples,
            correct_samples=total_correct,
            predictions=all_predictions,
        )

    def _format_prompt(self, sample: Dict) -> str:
        """Format a GPQA question with choices."""
        prompt = f"Question: {sample['input']}\n\n"
        if sample.get("choices"):
            prompt += "Choices:\n"
            for i, choice in enumerate(sample["choices"]):
                prompt += f"{chr(65+i)}. {choice}\n"
        prompt += "\nAnswer with the letter of the correct choice."
        return prompt

    def _score_gpqa(self, prediction: str, sample: Dict) -> bool:
        """Score a GPQA prediction."""
        expected = sample["expected_output"].strip()
        pred = prediction.strip()

        # Check for letter answer (A, B, C, D)
        if len(pred) >= 1 and pred[0].upper() in "ABCD":
            choices = sample.get("choices", [])
            if choices:
                idx = ord(pred[0].upper()) - ord("A")
                if idx < len(choices):
                    return choices[idx].strip().lower() == expected.lower()

        # Direct answer match
        return expected.lower() in pred.lower()


# =============================================================================
# GAIA - General AI Assistants
# =============================================================================

class GAIABenchmark(CustomBenchmark):
    """
    GAIA Benchmark - General AI Assistants.

    Tests real-world assistant tasks requiring:
    - Web browsing
    - File handling
    - Multi-step reasoning
    - Tool use

    Levels:
    - Level 1: Simple, few steps
    - Level 2: Medium complexity
    - Level 3: Complex, many steps
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "GAIA"

    @property
    def description(self) -> str:
        return "GAIA - General AI Assistant benchmark (web browsing, tool use)"

    @property
    def task_enum(self) -> Type[Enum]:
        return GAIATask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.FUNCTION_CALLING, Capability.TOOL_USE, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "gaia-benchmark/GAIA"

    def load_dataset(self, task: Optional[GAIATask] = None) -> List[Dict[str, Any]]:
        """Load GAIA dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        try:
            from datasets import load_dataset
            dataset = load_dataset("gaia-benchmark/GAIA", "2023_all")
            samples = []
            for item in dataset["validation"]:
                level = item.get("Level", 1)
                if task and task.value != f"level{level}":
                    continue

                samples.append({
                    "input": item["Question"],
                    "expected_output": item.get("Final answer", ""),
                    "level": level,
                    "annotator_metadata": item.get("Annotator Metadata", {}),
                    "file_name": item.get("file_name", ""),
                })
            return samples
        except Exception as e:
            raise RuntimeError(f"Failed to load GAIA: {e}")

    def evaluate(self, model: Any, tool_executor: Optional[Callable] = None, **kwargs) -> BenchmarkResult:
        """
        Run GAIA evaluation.

        Args:
            model: The model to evaluate
            tool_executor: Optional function to execute tool calls
        """
        tasks = self.selected_tasks or list(GAIATask)
        all_predictions = []
        task_scores = {}
        total_correct = 0
        total_samples = 0

        for task in tasks:
            samples = self.load_dataset(task)
            if self.config.n_samples_per_task:
                samples = samples[:self.config.n_samples_per_task]

            task_correct = 0
            for sample in samples:
                prompt = f"Task: {sample['input']}\n\nProvide your final answer."

                # Get model prediction
                if callable(model):
                    prediction = model(prompt)
                else:
                    prediction = model.generate(prompt)

                # Score (exact match for GAIA)
                is_correct = self._score_exact_match(prediction, sample["expected_output"])
                if is_correct:
                    task_correct += 1
                    total_correct += 1

                all_predictions.append({
                    "task": task.value,
                    "level": sample.get("level", 1),
                    "input": sample["input"][:200],
                    "prediction": prediction[:200] if prediction else "",
                    "expected": sample["expected_output"],
                    "correct": is_correct,
                })

            total_samples += len(samples)
            task_scores[task.value] = task_correct / len(samples) if samples else 0

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / total_samples if total_samples else 0,
            task_scores=task_scores,
            total_samples=total_samples,
            correct_samples=total_correct,
            predictions=all_predictions,
        )


# =============================================================================
# BFCL - Berkeley Function Calling Leaderboard
# =============================================================================

class BFCLBenchmark(CustomBenchmark):
    """
    BFCL - Berkeley Function Calling Leaderboard.

    Tests function/tool calling capabilities:
    - Simple: Single function call
    - Multiple: Multiple sequential calls
    - Parallel: Parallel function calls
    - REST/SQL/Java/JavaScript: Domain-specific
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "BFCL"

    @property
    def description(self) -> str:
        return "BFCL - Berkeley Function Calling Leaderboard"

    @property
    def task_enum(self) -> Type[Enum]:
        return BFCLTask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.FUNCTION_CALLING, Capability.TOOL_USE}

    @property
    def huggingface_dataset(self) -> str:
        return "gorilla-llm/Berkeley-Function-Calling-Leaderboard"

    def load_dataset(self, task: Optional[BFCLTask] = None) -> List[Dict[str, Any]]:
        """Load BFCL dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        try:
            from datasets import load_dataset
            # BFCL has multiple subsets
            subset = task.value if task else "simple"
            dataset = load_dataset(
                "gorilla-llm/Berkeley-Function-Calling-Leaderboard",
                f"BFCL_v3_{subset}"
            )
            samples = []
            for item in dataset["train"]:
                samples.append({
                    "input": item.get("question", item.get("user_query", "")),
                    "expected_output": item.get("ground_truth", []),
                    "functions": item.get("function", item.get("functions", [])),
                    "category": subset,
                })
            return samples
        except Exception as e:
            # Fallback: return empty with warning
            print(f"Warning: Failed to load BFCL dataset: {e}")
            return []

    def evaluate(self, model: Any, **kwargs) -> BenchmarkResult:
        """Run BFCL evaluation."""
        tasks = self.selected_tasks or [BFCLTask.SIMPLE]
        all_predictions = []
        task_scores = {}
        total_correct = 0
        total_samples = 0

        for task in tasks:
            samples = self.load_dataset(task)
            if self.config.n_samples_per_task:
                samples = samples[:self.config.n_samples_per_task]

            task_correct = 0
            for sample in samples:
                # Format prompt with available functions
                prompt = self._format_bfcl_prompt(sample)

                # Get model prediction (expecting function call format)
                if callable(model):
                    prediction = model(prompt)
                else:
                    prediction = model.generate(prompt)

                # Score function call
                is_correct = self._score_function_call(prediction, sample)
                if is_correct:
                    task_correct += 1
                    total_correct += 1

                all_predictions.append({
                    "task": task.value,
                    "input": sample["input"][:200],
                    "prediction": str(prediction)[:200] if prediction else "",
                    "expected": str(sample["expected_output"])[:200],
                    "correct": is_correct,
                })

            total_samples += len(samples)
            task_scores[task.value] = task_correct / len(samples) if samples else 0

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / total_samples if total_samples else 0,
            task_scores=task_scores,
            total_samples=total_samples,
            correct_samples=total_correct,
            predictions=all_predictions,
        )

    def _format_bfcl_prompt(self, sample: Dict) -> str:
        """Format a BFCL prompt with function definitions."""
        prompt = f"User Query: {sample['input']}\n\n"
        prompt += "Available Functions:\n"
        for func in sample.get("functions", []):
            if isinstance(func, dict):
                prompt += f"- {func.get('name', 'unknown')}: {func.get('description', '')}\n"
            else:
                prompt += f"- {func}\n"
        prompt += "\nCall the appropriate function(s) to answer the query."
        return prompt

    def _score_function_call(self, prediction: str, sample: Dict) -> bool:
        """Score a function call prediction."""
        expected = sample.get("expected_output", [])
        if not expected:
            return False

        # Simple check: does prediction contain expected function name?
        if isinstance(expected, list) and len(expected) > 0:
            first_expected = expected[0]
            if isinstance(first_expected, dict):
                func_name = first_expected.get("name", "")
                return func_name.lower() in prediction.lower()
            else:
                return str(first_expected).lower() in prediction.lower()

        return str(expected).lower() in prediction.lower()


# =============================================================================
# MMMU - Massive Multi-discipline Multimodal Understanding
# =============================================================================

class MMMUBenchmark(CustomBenchmark):
    """
    MMMU - Multimodal understanding across 30 subjects.

    Requires vision capabilities to process images.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "MMMU"

    @property
    def description(self) -> str:
        return "MMMU - Multimodal understanding (30 subjects, requires vision)"

    @property
    def task_enum(self) -> Type[Enum]:
        return MMMUTask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.VISION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "MMMU/MMMU"

    def load_dataset(self, task: Optional[MMMUTask] = None) -> List[Dict[str, Any]]:
        """Load MMMU dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        try:
            from datasets import load_dataset
            subset = task.value if task else "Art"
            dataset = load_dataset("MMMU/MMMU", subset)
            samples = []
            for item in dataset["validation"]:
                samples.append({
                    "input": item["question"],
                    "expected_output": item["answer"],
                    "image": item.get("image", None),
                    "options": item.get("options", []),
                    "subject": subset,
                })
            return samples
        except Exception as e:
            raise RuntimeError(f"Failed to load MMMU: {e}")

    def evaluate(self, model: Any, **kwargs) -> BenchmarkResult:
        """Run MMMU evaluation (requires multimodal model)."""
        tasks = self.selected_tasks or [MMMUTask.ART]
        all_predictions = []
        task_scores = {}
        total_correct = 0
        total_samples = 0

        for task in tasks:
            samples = self.load_dataset(task)
            if self.config.n_samples_per_task:
                samples = samples[:self.config.n_samples_per_task]

            task_correct = 0
            for sample in samples:
                # Note: Full implementation needs multimodal input handling
                prompt = f"Question: {sample['input']}\n"
                if sample.get("options"):
                    prompt += "Options:\n"
                    for i, opt in enumerate(sample["options"]):
                        prompt += f"{chr(65+i)}. {opt}\n"

                # Get model prediction
                if callable(model):
                    prediction = model(prompt)
                else:
                    prediction = model.generate(prompt)

                # Use proper multiple-choice scoring to avoid single-letter collision
                is_correct = self._score_multiple_choice(
                    prediction,
                    sample["expected_output"],
                    options=sample.get("options")
                )
                if is_correct:
                    task_correct += 1
                    total_correct += 1

                all_predictions.append({
                    "task": task.value,
                    "input": sample["input"][:200],
                    "prediction": prediction[:200] if prediction else "",
                    "expected": sample["expected_output"],
                    "correct": is_correct,
                })

            total_samples += len(samples)
            task_scores[task.value] = task_correct / len(samples) if samples else 0

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / total_samples if total_samples else 0,
            task_scores=task_scores,
            total_samples=total_samples,
            correct_samples=total_correct,
            predictions=all_predictions,
        )


# =============================================================================
# SWE-bench - Software Engineering
# =============================================================================

class SWEBenchBenchmark(CustomBenchmark):
    """
    SWE-bench - Software engineering tasks.

    Requires code execution capabilities.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "SWE-bench"

    @property
    def description(self) -> str:
        return "SWE-bench - Real-world GitHub issues (requires code execution)"

    @property
    def task_enum(self) -> Type[Enum]:
        return SWEBenchTask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.CODE_EXECUTION, Capability.LONG_CONTEXT}

    @property
    def huggingface_dataset(self) -> str:
        return "princeton-nlp/SWE-bench"

    def load_dataset(self, task: Optional[SWEBenchTask] = None) -> List[Dict[str, Any]]:
        """Load SWE-bench dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        try:
            from datasets import load_dataset
            subset = task.value if task else "lite"
            dataset_name = f"princeton-nlp/SWE-bench_{subset.capitalize()}"
            dataset = load_dataset(dataset_name)
            samples = []
            for item in dataset["test"]:
                samples.append({
                    "input": item["problem_statement"],
                    "expected_output": item.get("patch", ""),
                    "repo": item.get("repo", ""),
                    "instance_id": item.get("instance_id", ""),
                    "base_commit": item.get("base_commit", ""),
                })
            return samples
        except Exception as e:
            raise RuntimeError(f"Failed to load SWE-bench: {e}")

    def evaluate(self, model: Any, code_executor: Optional[Callable] = None, **kwargs) -> BenchmarkResult:
        """
        Run SWE-bench evaluation.

        Note: Full evaluation requires code execution environment.
        This implementation provides a simplified text-based evaluation.
        """
        tasks = self.selected_tasks or [SWEBenchTask.LITE]
        all_predictions = []
        task_scores = {}
        total_correct = 0
        total_samples = 0

        for task in tasks:
            samples = self.load_dataset(task)
            if self.config.n_samples_per_task:
                samples = samples[:self.config.n_samples_per_task]

            task_correct = 0
            for sample in samples:
                prompt = f"GitHub Issue:\n{sample['input']}\n\nProvide a code patch to fix this issue."

                if callable(model):
                    prediction = model(prompt)
                else:
                    prediction = model.generate(prompt)

                # Score using code executor if available, otherwise use heuristic
                is_correct = False
                score_reason = "requires_code_execution"

                if code_executor is not None:
                    try:
                        # Use provided code executor to validate patch
                        exec_result = code_executor(
                            prediction,
                            sample.get("instance_id"),
                            sample.get("base_commit"),
                            sample.get("repo")
                        )
                        is_correct = exec_result.get("passed", False)
                        score_reason = "code_execution"
                    except Exception as e:
                        score_reason = f"execution_error: {str(e)[:100]}"
                else:
                    # Heuristic: Check if prediction contains diff-like content
                    # This is NOT a substitute for real execution, just for completeness
                    if prediction:
                        has_diff_markers = any(
                            marker in prediction
                            for marker in ['diff --git', '@@', '+++ ', '--- ', '```diff']
                        )
                        score_reason = "heuristic_generated" if has_diff_markers else "no_patch_detected"
                    else:
                        score_reason = "no_prediction"

                if is_correct:
                    task_correct += 1
                    total_correct += 1

                all_predictions.append({
                    "task": task.value,
                    "instance_id": sample.get("instance_id", ""),
                    "input": sample["input"][:200],
                    "prediction": prediction[:500] if prediction else "",
                    "correct": is_correct,
                    "score_reason": score_reason,
                })

            total_samples += len(samples)
            task_scores[task.value] = task_correct / len(samples) if samples else 0

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / total_samples if total_samples else 0,
            task_scores=task_scores,
            total_samples=total_samples,
            correct_samples=total_correct,
            predictions=all_predictions,
            metadata={"note": "Full evaluation requires code execution environment"}
        )


# =============================================================================
# LiveCodeBench
# =============================================================================

class LiveCodeBenchBenchmark(CustomBenchmark):
    """
    LiveCodeBench - Continuously updated code generation benchmark.
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "LiveCodeBench"

    @property
    def description(self) -> str:
        return "LiveCodeBench - Live code generation benchmark"

    @property
    def task_enum(self) -> Type[Enum]:
        return LiveCodeBenchTask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.CODE_EXECUTION}

    @property
    def huggingface_dataset(self) -> str:
        return "livecodebench/code_generation_lite"

    def load_dataset(self, task: Optional[LiveCodeBenchTask] = None) -> List[Dict[str, Any]]:
        """Load LiveCodeBench dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        try:
            from datasets import load_dataset
            dataset = load_dataset("livecodebench/code_generation_lite")
            samples = []
            for item in dataset["test"]:
                samples.append({
                    "input": item["question_content"],
                    "expected_output": item.get("code_solution", ""),
                    "difficulty": item.get("difficulty", ""),
                    "question_id": item.get("question_id", ""),
                    "test_cases": item.get("test_cases", item.get("public_test_cases", [])),
                })
            return samples
        except Exception as e:
            raise RuntimeError(f"Failed to load LiveCodeBench: {e}")

    def evaluate(self, model: Any, code_executor: Optional[Callable] = None, **kwargs) -> BenchmarkResult:
        """
        Run LiveCodeBench evaluation.

        Args:
            model: The model to evaluate
            code_executor: Optional function(code, test_cases) -> {"passed": bool, "output": str}
        """
        samples = self.load_dataset()
        if self.config.n_samples_per_task:
            samples = samples[:self.config.n_samples_per_task]

        all_predictions = []
        total_correct = 0

        for sample in samples:
            prompt = f"Problem:\n{sample['input']}\n\nWrite a solution in Python."

            if callable(model):
                prediction = model(prompt)
            else:
                prediction = model.generate(prompt)

            # Score using code executor if available
            is_correct = False
            score_reason = "requires_code_execution"

            if not prediction:
                score_reason = "no_prediction"
            elif code_executor is not None:
                try:
                    # Extract code from prediction (handle markdown code blocks)
                    code = self._extract_code(prediction)
                    exec_result = code_executor(
                        code,
                        sample.get("test_cases", [])
                    )
                    is_correct = exec_result.get("passed", False)
                    score_reason = "code_execution"
                except Exception as e:
                    score_reason = f"execution_error: {str(e)[:100]}"
            else:
                # Heuristic: Check if prediction contains Python code
                has_code = any(
                    keyword in prediction
                    for keyword in ['def ', 'class ', 'return ', 'import ', '```python']
                )
                score_reason = "heuristic_generated" if has_code else "no_code_detected"

            if is_correct:
                total_correct += 1

            all_predictions.append({
                "question_id": sample.get("question_id", ""),
                "input": sample["input"][:200],
                "prediction": prediction[:500] if prediction else "",
                "correct": is_correct,
                "score_reason": score_reason,
            })

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / len(samples) if samples else 0,
            task_scores={},
            total_samples=len(samples),
            correct_samples=total_correct,
            predictions=all_predictions,
            metadata={"note": "Full evaluation requires code execution environment"} if code_executor is None else {}
        )

    def _extract_code(self, text: str) -> str:
        """Extract Python code from model response."""
        import re

        # Try to extract from markdown code block
        code_block = re.search(r'```(?:python)?\s*(.*?)```', text, re.DOTALL)
        if code_block:
            return code_block.group(1).strip()

        # If no code block, assume entire response is code
        return text.strip()


# =============================================================================
# HLE - Humanity's Last Exam
# =============================================================================

class HLEBenchmark(CustomBenchmark):
    """
    HLE - Humanity's Last Exam benchmark.

    Expert-level questions across multiple domains designed to be
    extremely challenging for AI models. Questions are curated by
    domain experts to test the limits of AI capabilities.

    Subjects:
    - Math, Physics, Chemistry, Biology
    - Computer Science, Economics, Philosophy
    - Law, Medicine, Engineering
    """

    def __init__(self, config: Optional[BenchmarkConfig] = None):
        super().__init__(config)

    @property
    def name(self) -> str:
        return "HLE"

    @property
    def description(self) -> str:
        return "Humanity's Last Exam - Expert-level questions across multiple domains"

    @property
    def task_enum(self) -> Type[Enum]:
        return HLETask

    @property
    def required_capabilities(self) -> Set[Capability]:
        return {Capability.TEXT_GENERATION, Capability.REASONING}

    @property
    def huggingface_dataset(self) -> str:
        return "cais/hle"

    def load_dataset(self, task: Optional[HLETask] = None) -> List[Dict[str, Any]]:
        """Load HLE dataset."""
        if self.config.offline_dataset_path:
            return self.load_offline_dataset(self.config.offline_dataset_path)

        try:
            from datasets import load_dataset
            dataset = load_dataset("cais/hle")
            samples = []
            for item in dataset["test"]:
                subject = item.get("subject", "").lower()
                if task and task.value != subject:
                    continue

                samples.append({
                    "input": item["question"],
                    "expected_output": item.get("answer", ""),
                    "subject": item.get("subject", ""),
                    "difficulty": item.get("difficulty", "expert"),
                    "explanation": item.get("explanation", ""),
                })
            return samples
        except Exception as e:
            raise RuntimeError(f"Failed to load HLE: {e}")

    def evaluate(self, model: Any, **kwargs) -> BenchmarkResult:
        """Run HLE evaluation."""
        tasks = self.selected_tasks or list(HLETask)
        all_predictions = []
        task_scores = {}
        total_correct = 0
        total_samples = 0

        for task in tasks:
            samples = self.load_dataset(task)
            if self.config.n_samples_per_task:
                samples = samples[:self.config.n_samples_per_task]

            task_correct = 0
            for sample in samples:
                prompt = f"Question ({sample.get('subject', 'Expert')}):\n{sample['input']}\n\nProvide your answer."

                if callable(model):
                    prediction = model(prompt)
                else:
                    prediction = model.generate(prompt)

                # Score - HLE uses exact match or contains
                is_correct = self._score_hle(prediction, sample)
                if is_correct:
                    task_correct += 1
                    total_correct += 1

                all_predictions.append({
                    "task": task.value,
                    "subject": sample.get("subject", ""),
                    "input": sample["input"][:200],
                    "prediction": prediction[:200] if prediction else "",
                    "expected": sample["expected_output"],
                    "correct": is_correct,
                })

            total_samples += len(samples)
            task_scores[task.value] = task_correct / len(samples) if samples else 0

        return BenchmarkResult(
            benchmark_name=self.name,
            overall_accuracy=total_correct / total_samples if total_samples else 0,
            task_scores=task_scores,
            total_samples=total_samples,
            correct_samples=total_correct,
            predictions=all_predictions,
        )

    def _score_hle(self, prediction: str, sample: Dict) -> bool:
        """Score an HLE prediction."""
        expected = sample.get("expected_output", "").strip().lower()
        pred = prediction.strip().lower() if prediction else ""

        # Exact match
        if pred == expected:
            return True

        # Contains expected answer
        if expected and expected in pred:
            return True

        return False


# =============================================================================
# Registry
# =============================================================================

CUSTOM_BENCHMARKS = {
    "GPQA": GPQABenchmark,
    "GAIA": GAIABenchmark,
    "BFCL": BFCLBenchmark,
    "MMMU": MMMUBenchmark,
    "SWE-bench": SWEBenchBenchmark,
    "LiveCodeBench": LiveCodeBenchBenchmark,
    "HLE": HLEBenchmark,
}


def get_custom_benchmark(name: str, config: Optional[BenchmarkConfig] = None) -> BaseBenchmark:
    """Get a custom benchmark by name."""
    if name not in CUSTOM_BENCHMARKS:
        raise ValueError(f"Unknown custom benchmark: {name}")
    return CUSTOM_BENCHMARKS[name](config=config)
