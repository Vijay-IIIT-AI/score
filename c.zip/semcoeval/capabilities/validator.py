"""
Capability Validator - Validates model compatibility before running evaluations.

This is the key component that addresses the gap in DeepEval where there's no
automatic validation of model capabilities against metric/benchmark requirements.
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple, Set
from enum import Enum

from .registry import CapabilityRegistry, Capability, ModelCapability, MetricRequirement


class ValidationLevel(Enum):
    """How strictly to enforce capability validation."""
    STRICT = "strict"      # Fail if any required capability is missing
    WARN = "warn"          # Warn but continue if capability is missing
    SKIP = "skip"          # Skip validation entirely


@dataclass
class ValidationResult:
    """Result of a capability validation check."""
    is_valid: bool
    metric_name: str
    model_id: str
    provider: str
    missing_capabilities: Set[Capability]
    missing_optional: Set[Capability]
    context_window_ok: bool
    required_context: int
    actual_context: int
    warnings: List[str]
    errors: List[str]

    def summary(self) -> str:
        """Get a human-readable summary."""
        if self.is_valid:
            msg = f"[OK] {self.provider}:{self.model_id} is compatible with {self.metric_name}"
            if self.warnings:
                msg += f"\n  Warnings: {', '.join(self.warnings)}"
            return msg
        else:
            msg = f"[FAIL] {self.provider}:{self.model_id} is NOT compatible with {self.metric_name}"
            if self.errors:
                msg += f"\n  Errors: {', '.join(self.errors)}"
            return msg


class CapabilityValidator:
    """
    Validates that a model has the required capabilities to run a metric/benchmark.

    Usage:
        validator = CapabilityValidator()
        result = validator.validate("openai", "gpt-4o", "ToolCorrectnessMetric")
        if not result.is_valid:
            print(f"Cannot run: {result.errors}")
    """

    def __init__(self, registry: Optional[CapabilityRegistry] = None):
        self.registry = registry or CapabilityRegistry()

    def validate(
        self,
        provider: str,
        model_id: str,
        metric_name: str,
        level: ValidationLevel = ValidationLevel.STRICT
    ) -> ValidationResult:
        """
        Validate if a model can run a specific metric/benchmark.

        Args:
            provider: The model provider (openai, anthropic, etc.)
            model_id: The model identifier
            metric_name: The metric or benchmark name
            level: How strictly to validate

        Returns:
            ValidationResult with details about compatibility
        """
        warnings = []
        errors = []

        # Get metric requirements
        metric_req = self.registry.get_metric_requirements(metric_name)
        if not metric_req:
            warnings.append(f"Unknown metric '{metric_name}' - no requirements defined")
            return ValidationResult(
                is_valid=True,  # Unknown metrics pass by default
                metric_name=metric_name,
                model_id=model_id,
                provider=provider,
                missing_capabilities=set(),
                missing_optional=set(),
                context_window_ok=True,
                required_context=0,
                actual_context=0,
                warnings=warnings,
                errors=errors
            )

        # Get model capabilities
        model_cap = self.registry.get_model_capabilities(provider, model_id)
        if not model_cap:
            if level == ValidationLevel.STRICT:
                errors.append(f"Unknown model '{provider}:{model_id}' - capabilities not registered")
                return ValidationResult(
                    is_valid=False,
                    metric_name=metric_name,
                    model_id=model_id,
                    provider=provider,
                    missing_capabilities=metric_req.required_capabilities,
                    missing_optional=metric_req.optional_capabilities,
                    context_window_ok=False,
                    required_context=metric_req.min_context_window,
                    actual_context=0,
                    warnings=warnings,
                    errors=errors
                )
            else:
                warnings.append(f"Unknown model '{provider}:{model_id}' - skipping validation")
                return ValidationResult(
                    is_valid=True,
                    metric_name=metric_name,
                    model_id=model_id,
                    provider=provider,
                    missing_capabilities=set(),
                    missing_optional=set(),
                    context_window_ok=True,
                    required_context=0,
                    actual_context=0,
                    warnings=warnings,
                    errors=errors
                )

        # Check required capabilities
        missing_required = metric_req.required_capabilities - model_cap.capabilities
        if missing_required:
            cap_names = [c.value for c in missing_required]
            errors.append(f"Missing required capabilities: {', '.join(cap_names)}")

        # Check optional capabilities
        missing_optional = metric_req.optional_capabilities - model_cap.capabilities
        if missing_optional:
            cap_names = [c.value for c in missing_optional]
            warnings.append(f"Missing optional capabilities (may affect quality): {', '.join(cap_names)}")

        # Check context window
        context_ok = model_cap.context_window >= metric_req.min_context_window
        if not context_ok:
            errors.append(
                f"Context window too small: {model_cap.context_window} < {metric_req.min_context_window} required"
            )

        # Determine validity
        is_valid = len(missing_required) == 0 and context_ok
        if level == ValidationLevel.WARN:
            is_valid = True  # Warnings don't fail

        return ValidationResult(
            is_valid=is_valid,
            metric_name=metric_name,
            model_id=model_id,
            provider=provider,
            missing_capabilities=missing_required,
            missing_optional=missing_optional,
            context_window_ok=context_ok,
            required_context=metric_req.min_context_window,
            actual_context=model_cap.context_window,
            warnings=warnings,
            errors=errors
        )

    def validate_batch(
        self,
        provider: str,
        model_id: str,
        metric_names: List[str],
        level: ValidationLevel = ValidationLevel.STRICT
    ) -> List[ValidationResult]:
        """Validate multiple metrics for a model."""
        return [
            self.validate(provider, model_id, metric, level)
            for metric in metric_names
        ]

    def find_compatible_metrics(
        self,
        provider: str,
        model_id: str
    ) -> List[str]:
        """Find all metrics this model can run."""
        compatible = self.registry.get_compatible_metrics(provider, model_id)
        return [m.metric_name for m in compatible]

    def find_compatible_models(
        self,
        metric_name: str
    ) -> List[Tuple[str, str]]:
        """Find all models that can run this metric."""
        compatible = self.registry.get_compatible_models(metric_name)
        return [(m.provider, m.model_id) for m in compatible]

    def generate_compatibility_matrix(
        self,
        providers: Optional[List[str]] = None,
        metrics: Optional[List[str]] = None
    ) -> dict:
        """
        Generate a compatibility matrix showing which models can run which metrics.

        Returns:
            Dict with structure: {model_key: {metric_name: is_compatible}}
        """
        if metrics is None:
            metrics = self.registry.list_metrics()

        if providers is None:
            model_keys = self.registry.list_models()
        else:
            model_keys = [k for k in self.registry.list_models() if k.split(":")[0] in providers]

        matrix = {}
        for model_key in model_keys:
            provider, model_id = model_key.split(":", 1)
            matrix[model_key] = {}
            for metric in metrics:
                result = self.validate(provider, model_id, metric, ValidationLevel.STRICT)
                matrix[model_key][metric] = result.is_valid

        return matrix
