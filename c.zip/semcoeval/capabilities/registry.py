"""
Capability Registry - Maps model capabilities to metric/benchmark requirements.

This addresses the gap in DeepEval where there's no automatic validation
of whether a model supports the capabilities required by a metric or benchmark.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set
from enum import Enum


class Capability(Enum):
    """All possible model capabilities."""
    TEXT_GENERATION = "text_generation"
    CHAT = "chat"
    FUNCTION_CALLING = "function_calling"
    TOOL_USE = "tool_use"
    VISION = "vision"
    IMAGE_GENERATION = "image_generation"
    AUDIO = "audio"
    JSON_MODE = "json_mode"
    STRUCTURED_OUTPUT = "structured_output"
    LOG_PROBS = "log_probs"
    STREAMING = "streaming"
    EMBEDDINGS = "embeddings"
    CODE_EXECUTION = "code_execution"
    LONG_CONTEXT = "long_context"  # >32K tokens
    VERY_LONG_CONTEXT = "very_long_context"  # >128K tokens
    REASONING = "reasoning"  # o1-style reasoning
    MULTIMODAL_OUTPUT = "multimodal_output"


@dataclass
class ModelCapability:
    """Defines a model's capabilities."""
    model_id: str
    provider: str
    capabilities: Set[Capability]
    context_window: int = 4096
    max_output_tokens: int = 4096
    supports_system_prompt: bool = True
    supports_temperature: bool = True

    def has_capability(self, cap: Capability) -> bool:
        return cap in self.capabilities

    def has_all_capabilities(self, caps: Set[Capability]) -> bool:
        return caps.issubset(self.capabilities)


@dataclass
class MetricRequirement:
    """Defines what capabilities a metric/benchmark requires."""
    metric_name: str
    required_capabilities: Set[Capability]
    optional_capabilities: Set[Capability] = field(default_factory=set)
    min_context_window: int = 0
    description: str = ""


class CapabilityRegistry:
    """
    Central registry mapping metrics/benchmarks to their capability requirements.
    Also stores known model capabilities for validation.
    """

    def __init__(self):
        self._metric_requirements: Dict[str, MetricRequirement] = {}
        self._model_capabilities: Dict[str, ModelCapability] = {}
        self._load_default_requirements()
        self._load_known_models()

    def _load_default_requirements(self):
        """Load default metric/benchmark requirements."""

        # DeepEval Metrics - Core
        self.register_metric(MetricRequirement(
            metric_name="GEval",
            required_capabilities={Capability.TEXT_GENERATION},
            description="General evaluation metric"
        ))

        self.register_metric(MetricRequirement(
            metric_name="AnswerRelevancyMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Checks if answer is relevant to input"
        ))

        self.register_metric(MetricRequirement(
            metric_name="FaithfulnessMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Checks if output is faithful to context"
        ))

        # Tool/Agent Metrics
        self.register_metric(MetricRequirement(
            metric_name="ToolCorrectnessMetric",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE},
            description="Validates correct tool calls"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ToolUseMetric",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE},
            description="Evaluates tool usage patterns"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ArgumentCorrectnessMetric",
            required_capabilities={Capability.FUNCTION_CALLING},
            description="Validates function arguments"
        ))

        # Structured Output Metrics
        self.register_metric(MetricRequirement(
            metric_name="JsonCorrectnessMetric",
            required_capabilities={Capability.JSON_MODE},
            optional_capabilities={Capability.STRUCTURED_OUTPUT},
            description="Validates JSON output format"
        ))

        # Multimodal Metrics
        self.register_metric(MetricRequirement(
            metric_name="TextToImageMetric",
            required_capabilities={Capability.IMAGE_GENERATION},
            description="Evaluates text-to-image generation"
        ))

        # MCP Metrics
        self.register_metric(MetricRequirement(
            metric_name="MCPUseMetric",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE},
            description="Evaluates MCP primitive usage"
        ))

        self.register_metric(MetricRequirement(
            metric_name="MCPTaskCompletionMetric",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE},
            description="Evaluates task completion with MCP"
        ))

        self.register_metric(MetricRequirement(
            metric_name="MultiTurnMCPUseMetric",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE},
            description="Evaluates multi-turn MCP usage"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ImageCoherenceMetric",
            required_capabilities={Capability.VISION},
            description="Evaluates image understanding"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ImageHelpfulnessMetric",
            required_capabilities={Capability.VISION},
            description="Evaluates helpfulness with image input"
        ))

        # Benchmarks - Text
        self.register_metric(MetricRequirement(
            metric_name="MMLU",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Massive Multitask Language Understanding"
        ))

        self.register_metric(MetricRequirement(
            metric_name="MMLU_Pro",
            required_capabilities={Capability.TEXT_GENERATION, Capability.REASONING},
            description="MMLU Professional - harder reasoning"
        ))

        self.register_metric(MetricRequirement(
            metric_name="GPQA",
            required_capabilities={Capability.TEXT_GENERATION, Capability.REASONING},
            description="Graduate-level science questions"
        ))

        self.register_metric(MetricRequirement(
            metric_name="HumanEval",
            required_capabilities={Capability.TEXT_GENERATION, Capability.CODE_EXECUTION},
            description="Code generation benchmark"
        ))

        self.register_metric(MetricRequirement(
            metric_name="TruthfulQA",
            required_capabilities={Capability.TEXT_GENERATION},
            optional_capabilities={Capability.LOG_PROBS},
            description="Tests for truthful responses"
        ))

        # Benchmarks - Agent
        self.register_metric(MetricRequirement(
            metric_name="BFCL",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE},
            description="Berkeley Function Calling Leaderboard"
        ))

        self.register_metric(MetricRequirement(
            metric_name="GAIA",
            required_capabilities={Capability.FUNCTION_CALLING, Capability.TOOL_USE, Capability.REASONING},
            description="General AI Assistants benchmark"
        ))

        self.register_metric(MetricRequirement(
            metric_name="SWE_Bench",
            required_capabilities={Capability.CODE_EXECUTION, Capability.FUNCTION_CALLING},
            min_context_window=32000,
            description="Software Engineering benchmark"
        ))

        # Benchmarks - Vision
        self.register_metric(MetricRequirement(
            metric_name="MMMU",
            required_capabilities={Capability.VISION, Capability.REASONING},
            description="Massive Multi-discipline Multimodal Understanding"
        ))

        # Long Context Benchmarks
        self.register_metric(MetricRequirement(
            metric_name="RULER",
            required_capabilities={Capability.LONG_CONTEXT},
            min_context_window=128000,
            description="Long context understanding"
        ))

        self.register_metric(MetricRequirement(
            metric_name="InfiniteBench",
            required_capabilities={Capability.VERY_LONG_CONTEXT},
            min_context_window=200000,
            description="Very long context benchmark"
        ))

        # Additional core metrics
        self.register_metric(MetricRequirement(
            metric_name="ContextualRelevancyMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Checks if context is relevant to input"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ContextualPrecisionMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Precision of context retrieval"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ContextualRecallMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Recall of context retrieval"
        ))

        self.register_metric(MetricRequirement(
            metric_name="HallucinationMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Detects hallucinated content"
        ))

        self.register_metric(MetricRequirement(
            metric_name="SummarizationMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Evaluates summarization quality"
        ))

        self.register_metric(MetricRequirement(
            metric_name="BiasMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Detects bias in outputs"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ToxicityMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Detects toxic content"
        ))

        self.register_metric(MetricRequirement(
            metric_name="KnowledgeRetentionMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Tests knowledge retention across conversation"
        ))

        # Conversational metrics
        self.register_metric(MetricRequirement(
            metric_name="ConversationalGEval",
            required_capabilities={Capability.TEXT_GENERATION, Capability.CHAT},
            description="GEval for conversations"
        ))

        self.register_metric(MetricRequirement(
            metric_name="ConversationCompletenessMetric",
            required_capabilities={Capability.TEXT_GENERATION, Capability.CHAT},
            description="Evaluates conversation completeness"
        ))

        # DAG metrics
        self.register_metric(MetricRequirement(
            metric_name="DAGMetric",
            required_capabilities={Capability.TEXT_GENERATION, Capability.REASONING},
            description="Deep Acyclic Graph evaluation"
        ))

        # Turn-based metrics
        self.register_metric(MetricRequirement(
            metric_name="TurnContextualPrecisionMetric",
            required_capabilities={Capability.TEXT_GENERATION, Capability.CHAT},
            description="Turn-level contextual precision"
        ))

        self.register_metric(MetricRequirement(
            metric_name="TurnContextualRecallMetric",
            required_capabilities={Capability.TEXT_GENERATION, Capability.CHAT},
            description="Turn-level contextual recall"
        ))

        self.register_metric(MetricRequirement(
            metric_name="TurnFaithfulnessMetric",
            required_capabilities={Capability.TEXT_GENERATION, Capability.CHAT},
            description="Turn-level faithfulness"
        ))

        # Non-LLM metrics
        self.register_metric(MetricRequirement(
            metric_name="ExactMatchMetric",
            required_capabilities=set(),  # No LLM required
            description="Exact string match evaluation"
        ))

        self.register_metric(MetricRequirement(
            metric_name="PatternMatchMetric",
            required_capabilities=set(),  # No LLM required
            description="Pattern/regex match evaluation"
        ))

        # Format metrics
        self.register_metric(MetricRequirement(
            metric_name="PromptAlignmentMetric",
            required_capabilities={Capability.TEXT_GENERATION},
            description="Checks alignment with prompt instructions"
        ))

        # HLE Benchmark
        self.register_metric(MetricRequirement(
            metric_name="HLE",
            required_capabilities={Capability.TEXT_GENERATION, Capability.REASONING},
            description="Humanity's Last Exam - Expert-level questions"
        ))

    def _load_known_models(self):
        """Load known model capabilities."""

        # OpenAI Models
        self.register_model(ModelCapability(
            model_id="gpt-4o",
            provider="openai",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.JSON_MODE,
                Capability.STRUCTURED_OUTPUT, Capability.STREAMING, Capability.LONG_CONTEXT
            },
            context_window=128000,
            max_output_tokens=16384
        ))

        self.register_model(ModelCapability(
            model_id="gpt-4o-mini",
            provider="openai",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.JSON_MODE,
                Capability.STRUCTURED_OUTPUT, Capability.STREAMING, Capability.LONG_CONTEXT
            },
            context_window=128000,
            max_output_tokens=16384
        ))

        self.register_model(ModelCapability(
            model_id="o1",
            provider="openai",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.REASONING,
                Capability.VISION, Capability.FUNCTION_CALLING, Capability.TOOL_USE,
                Capability.LONG_CONTEXT
            },
            context_window=200000,
            max_output_tokens=100000,
            supports_temperature=False
        ))

        self.register_model(ModelCapability(
            model_id="o3",
            provider="openai",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.REASONING,
                Capability.VISION, Capability.FUNCTION_CALLING, Capability.TOOL_USE,
                Capability.VERY_LONG_CONTEXT
            },
            context_window=200000,
            max_output_tokens=100000,
            supports_temperature=False
        ))

        # Anthropic Models
        self.register_model(ModelCapability(
            model_id="claude-opus-4",
            provider="anthropic",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.JSON_MODE,
                Capability.LONG_CONTEXT, Capability.CODE_EXECUTION
            },
            context_window=200000,
            max_output_tokens=32000
        ))

        self.register_model(ModelCapability(
            model_id="claude-sonnet-4",
            provider="anthropic",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.JSON_MODE,
                Capability.LONG_CONTEXT, Capability.CODE_EXECUTION
            },
            context_window=200000,
            max_output_tokens=64000
        ))

        self.register_model(ModelCapability(
            model_id="claude-3-5-sonnet",
            provider="anthropic",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.JSON_MODE,
                Capability.LONG_CONTEXT
            },
            context_window=200000,
            max_output_tokens=8192
        ))

        self.register_model(ModelCapability(
            model_id="claude-3-5-haiku",
            provider="anthropic",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.JSON_MODE
            },
            context_window=200000,
            max_output_tokens=8192
        ))

        # Google Models
        self.register_model(ModelCapability(
            model_id="gemini-2.5-pro",
            provider="google",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.AUDIO,
                Capability.JSON_MODE, Capability.VERY_LONG_CONTEXT, Capability.REASONING
            },
            context_window=1000000,
            max_output_tokens=65536
        ))

        self.register_model(ModelCapability(
            model_id="gemini-2.5-flash",
            provider="google",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.TOOL_USE, Capability.VISION, Capability.AUDIO,
                Capability.JSON_MODE, Capability.VERY_LONG_CONTEXT
            },
            context_window=1000000,
            max_output_tokens=65536
        ))

        # DeepSeek Models
        self.register_model(ModelCapability(
            model_id="deepseek-v3",
            provider="deepseek",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.FUNCTION_CALLING,
                Capability.JSON_MODE, Capability.LONG_CONTEXT, Capability.CODE_EXECUTION
            },
            context_window=128000,
            max_output_tokens=8192
        ))

        self.register_model(ModelCapability(
            model_id="deepseek-r1",
            provider="deepseek",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.REASONING,
                Capability.LONG_CONTEXT, Capability.CODE_EXECUTION
            },
            context_window=128000,
            max_output_tokens=8192
        ))

        # Meta Models
        self.register_model(ModelCapability(
            model_id="llama-4-maverick",
            provider="meta",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.VISION,
                Capability.FUNCTION_CALLING, Capability.LONG_CONTEXT
            },
            context_window=1000000,
            max_output_tokens=16384
        ))

        # xAI Models
        self.register_model(ModelCapability(
            model_id="grok-3",
            provider="xai",
            capabilities={
                Capability.TEXT_GENERATION, Capability.CHAT, Capability.VISION,
                Capability.FUNCTION_CALLING, Capability.LONG_CONTEXT, Capability.REASONING
            },
            context_window=131072,
            max_output_tokens=16384
        ))

    def register_metric(self, requirement: MetricRequirement):
        """Register a metric's capability requirements."""
        self._metric_requirements[requirement.metric_name] = requirement

    def register_model(self, capability: ModelCapability):
        """Register a model's capabilities."""
        key = f"{capability.provider}:{capability.model_id}"
        self._model_capabilities[key] = capability

    def get_metric_requirements(self, metric_name: str) -> Optional[MetricRequirement]:
        """Get requirements for a metric/benchmark."""
        return self._metric_requirements.get(metric_name)

    def get_model_capabilities(self, provider: str, model_id: str) -> Optional[ModelCapability]:
        """Get capabilities for a model."""
        key = f"{provider}:{model_id}"
        return self._model_capabilities.get(key)

    def list_metrics(self) -> List[str]:
        """List all registered metrics/benchmarks."""
        return list(self._metric_requirements.keys())

    def list_models(self) -> List[str]:
        """List all registered models."""
        return list(self._model_capabilities.keys())

    def get_compatible_models(self, metric_name: str) -> List[ModelCapability]:
        """Get all models compatible with a metric."""
        req = self.get_metric_requirements(metric_name)
        if not req:
            return []

        compatible = []
        for model in self._model_capabilities.values():
            if model.has_all_capabilities(req.required_capabilities):
                if model.context_window >= req.min_context_window:
                    compatible.append(model)
        return compatible

    def get_compatible_metrics(self, provider: str, model_id: str) -> List[MetricRequirement]:
        """Get all metrics compatible with a model."""
        model = self.get_model_capabilities(provider, model_id)
        if not model:
            return []

        compatible = []
        for req in self._metric_requirements.values():
            if model.has_all_capabilities(req.required_capabilities):
                if model.context_window >= req.min_context_window:
                    compatible.append(req)
        return compatible
