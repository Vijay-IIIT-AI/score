"""
Custom evaluators for SemcoEval.
"""

# This module is reserved for custom evaluation logic
# that extends beyond DeepEval's built-in capabilities.

__all__ = []
