"""
RAGAS Metrics - RAG Assessment metrics integration.

Wraps RAGAS library metrics for RAG evaluation.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from enum import Enum


class RAGASMetricType(Enum):
    """Available RAGAS metrics."""
    # Generation metrics
    FAITHFULNESS = "faithfulness"
    ANSWER_RELEVANCY = "answer_relevancy"
    ANSWER_CORRECTNESS = "answer_correctness"
    ANSWER_SIMILARITY = "answer_similarity"

    # Retrieval metrics
    CONTEXT_PRECISION = "context_precision"
    CONTEXT_RECALL = "context_recall"
    CONTEXT_RELEVANCY = "context_relevancy"
    CONTEXT_ENTITY_RECALL = "context_entity_recall"

    # Combined metrics
    HARMFULNESS = "harmfulness"
    COHERENCE = "coherence"
    CONCISENESS = "conciseness"

    # Critique metrics
    MALICIOUSNESS = "maliciousness"
    CRITIQUE = "critique"


@dataclass
class RAGASTestCase:
    """Test case for RAGAS evaluation."""
    question: str
    answer: str
    contexts: List[str]
    ground_truth: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RAGASResult:
    """Result from RAGAS evaluation."""
    metric: str
    score: float
    test_case: RAGASTestCase
    details: Dict[str, Any] = field(default_factory=dict)


class RAGASEvaluator:
    """
    RAGAS metrics evaluator for RAG systems.

    Wraps the RAGAS library for easy evaluation.

    Usage:
        evaluator = RAGASEvaluator()

        # Create test cases
        test_cases = [
            RAGASTestCase(
                question="What is the capital of France?",
                answer="Paris is the capital of France.",
                contexts=["Paris is the capital and largest city of France."],
                ground_truth="Paris"
            )
        ]

        # Evaluate
        results = evaluator.evaluate(
            test_cases,
            metrics=["faithfulness", "answer_relevancy"]
        )
    """

    def __init__(
        self,
        llm: Optional[Any] = None,
        embeddings: Optional[Any] = None
    ):
        self._llm = llm
        self._embeddings = embeddings
        self._ragas_available = self._check_ragas()

    def _check_ragas(self) -> bool:
        """Check if RAGAS is available."""
        try:
            import ragas
            return True
        except ImportError:
            return False

    def _init_defaults(self):
        """Initialize default LLM and embeddings if not provided."""
        if self._llm is None:
            try:
                from langchain_openai import ChatOpenAI
                self._llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
            except ImportError:
                pass

        if self._embeddings is None:
            try:
                from langchain_openai import OpenAIEmbeddings
                self._embeddings = OpenAIEmbeddings()
            except ImportError:
                pass

    def _get_metric(self, metric_name: str) -> Any:
        """Get a RAGAS metric by name."""
        try:
            from ragas.metrics import (
                faithfulness,
                answer_relevancy,
                answer_correctness,
                answer_similarity,
                context_precision,
                context_recall,
                context_relevancy,
                context_entity_recall,
            )

            metric_map = {
                "faithfulness": faithfulness,
                "answer_relevancy": answer_relevancy,
                "answer_correctness": answer_correctness,
                "answer_similarity": answer_similarity,
                "context_precision": context_precision,
                "context_recall": context_recall,
                "context_relevancy": context_relevancy,
                "context_entity_recall": context_entity_recall,
            }

            return metric_map.get(metric_name)
        except ImportError:
            return None

    def evaluate(
        self,
        test_cases: List[RAGASTestCase],
        metrics: Optional[List[str]] = None
    ) -> List[RAGASResult]:
        """
        Evaluate test cases with RAGAS metrics.

        Args:
            test_cases: List of RAGASTestCase
            metrics: List of metric names to use

        Returns:
            List of RAGASResult
        """
        if not self._ragas_available:
            return self._evaluate_fallback(test_cases, metrics)

        self._init_defaults()

        try:
            from ragas import evaluate
            from datasets import Dataset

            # Convert to RAGAS dataset format
            data = {
                "question": [tc.question for tc in test_cases],
                "answer": [tc.answer for tc in test_cases],
                "contexts": [tc.contexts for tc in test_cases],
                "ground_truth": [tc.ground_truth or "" for tc in test_cases]
            }
            dataset = Dataset.from_dict(data)

            # Get metrics
            metrics_to_use = metrics or ["faithfulness", "answer_relevancy"]
            ragas_metrics = []
            for m in metrics_to_use:
                metric = self._get_metric(m)
                if metric:
                    ragas_metrics.append(metric)

            if not ragas_metrics:
                return self._evaluate_fallback(test_cases, metrics)

            # Run evaluation
            result = evaluate(
                dataset,
                metrics=ragas_metrics,
                llm=self._llm,
                embeddings=self._embeddings
            )

            # Convert results
            results = []
            for i, tc in enumerate(test_cases):
                for metric_name in metrics_to_use:
                    if metric_name in result:
                        score = result[metric_name][i] if hasattr(result[metric_name], '__getitem__') else result[metric_name]
                        results.append(RAGASResult(
                            metric=metric_name,
                            score=float(score) if score is not None else 0.0,
                            test_case=tc
                        ))

            return results

        except Exception as e:
            # Fallback to simple evaluation
            return self._evaluate_fallback(test_cases, metrics, error=str(e))

    def _evaluate_fallback(
        self,
        test_cases: List[RAGASTestCase],
        metrics: Optional[List[str]] = None,
        error: Optional[str] = None
    ) -> List[RAGASResult]:
        """Fallback evaluation without RAGAS."""
        results = []
        metrics_to_use = metrics or ["faithfulness", "answer_relevancy"]

        for tc in test_cases:
            for metric_name in metrics_to_use:
                # Simple heuristic scores
                score = self._compute_simple_score(tc, metric_name)
                results.append(RAGASResult(
                    metric=metric_name,
                    score=score,
                    test_case=tc,
                    details={"fallback": True, "error": error}
                ))

        return results

    def _compute_simple_score(self, tc: RAGASTestCase, metric: str) -> float:
        """Compute simple heuristic score."""
        if metric == "faithfulness":
            # Check if answer content appears in contexts
            answer_words = set(tc.answer.lower().split())
            context_words = set(" ".join(tc.contexts).lower().split())
            overlap = len(answer_words & context_words)
            return min(overlap / max(len(answer_words), 1), 1.0)

        elif metric == "answer_relevancy":
            # Check if question keywords appear in answer
            question_words = set(tc.question.lower().split())
            answer_words = set(tc.answer.lower().split())
            overlap = len(question_words & answer_words)
            return min(overlap / max(len(question_words), 1), 1.0)

        elif metric == "context_precision":
            # Check if ground truth is in contexts
            if not tc.ground_truth:
                # Cannot compute without ground truth - return 0 not 0.5
                return 0.0
            gt_lower = tc.ground_truth.lower()
            for ctx in tc.contexts:
                if gt_lower in ctx.lower():
                    return 1.0
            return 0.0

        elif metric == "context_recall":
            # Similar to precision for simple case
            return self._compute_simple_score(tc, "context_precision")

        # Unknown metric - return 0 to indicate failure, not fake 0.5
        return 0.0

    def evaluate_single(
        self,
        question: str,
        answer: str,
        contexts: List[str],
        ground_truth: Optional[str] = None,
        metrics: Optional[List[str]] = None
    ) -> Dict[str, float]:
        """
        Evaluate a single RAG response.

        Returns dict of metric_name -> score.
        """
        tc = RAGASTestCase(
            question=question,
            answer=answer,
            contexts=contexts,
            ground_truth=ground_truth
        )

        results = self.evaluate([tc], metrics)

        return {r.metric: r.score for r in results}


def create_ragas_test_case(
    question: str,
    answer: str,
    contexts: Union[str, List[str]],
    ground_truth: Optional[str] = None
) -> RAGASTestCase:
    """Helper to create a RAGAS test case."""
    if isinstance(contexts, str):
        contexts = [contexts]

    return RAGASTestCase(
        question=question,
        answer=answer,
        contexts=contexts,
        ground_truth=ground_truth
    )
