"""
Citation Metrics - Evaluate citation quality and accuracy in RAG responses.

Measures how well a model cites sources and whether citations are accurate.
"""

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Citation:
    """A citation reference in a response."""
    marker: str  # e.g., "[1]", "(Source A)"
    position: int  # Position in response text
    claimed_source: Optional[str] = None
    actual_source_id: Optional[str] = None
    is_valid: bool = False
    supporting_text: Optional[str] = None


@dataclass
class CitationTestCase:
    """Test case for citation evaluation."""
    question: str
    response: str
    sources: List[Dict[str, str]]  # List of {"id": "1", "content": "..."}
    expected_citations: Optional[List[str]] = None  # Expected source IDs
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CitationResult:
    """Result from citation evaluation."""
    precision: float  # Valid citations / Total citations
    recall: float  # Cited sources / Sources that should be cited
    f1: float
    citation_coverage: float  # % of claims with citations
    attribution_score: float  # How well citations support claims
    total_citations: int
    valid_citations: int
    invalid_citations: int
    uncited_claims: int
    citations: List[Citation]
    details: Dict[str, Any] = field(default_factory=dict)


class CitationMetric:
    """
    Evaluate citation quality in RAG responses.

    Measures:
    - Citation precision: Are citations pointing to relevant sources?
    - Citation recall: Are all relevant sources cited?
    - Attribution: Do citations support the claims they're attached to?
    - Coverage: Are factual claims properly cited?

    Usage:
        metric = CitationMetric()

        result = metric.evaluate(CitationTestCase(
            question="What are the benefits of exercise?",
            response="Exercise improves cardiovascular health [1] and mental wellbeing [2].",
            sources=[
                {"id": "1", "content": "Regular exercise strengthens the heart..."},
                {"id": "2", "content": "Physical activity reduces depression..."}
            ]
        ))

        print(f"Citation F1: {result.f1}")
    """

    # Common citation patterns
    CITATION_PATTERNS = [
        r'\[(\d+)\]',  # [1], [2], etc.
        r'\[([a-zA-Z])\]',  # [a], [b], etc.
        r'\((\d+)\)',  # (1), (2), etc.
        r'\(Source (\d+)\)',  # (Source 1), etc.
        r'\(Doc (\d+)\)',  # (Doc 1), etc.
        r'<ref>(\d+)</ref>',  # <ref>1</ref>, etc.
        r'\[source:(\d+)\]',  # [source:1], etc.
    ]

    def __init__(
        self,
        llm_judge: Optional[str] = None,
        use_semantic_matching: bool = True
    ):
        self.llm_judge = llm_judge
        self.use_semantic_matching = use_semantic_matching
        self._client = None

    def extract_citations(self, text: str) -> List[Citation]:
        """Extract all citations from text."""
        citations = []

        for pattern in self.CITATION_PATTERNS:
            for match in re.finditer(pattern, text):
                citations.append(Citation(
                    marker=match.group(0),
                    position=match.start(),
                    actual_source_id=match.group(1)
                ))

        # Sort by position
        citations.sort(key=lambda c: c.position)
        return citations

    def extract_claims(self, text: str) -> List[Tuple[str, int, int]]:
        """Extract factual claims from text."""
        # Split into sentences
        sentences = re.split(r'[.!?]+', text)
        claims = []

        position = 0
        for sentence in sentences:
            sentence = sentence.strip()
            if sentence and len(sentence) > 10:  # Skip very short fragments
                # Check if sentence contains factual indicators
                if self._is_factual_claim(sentence):
                    start = text.find(sentence, position)
                    claims.append((sentence, start, start + len(sentence)))
                    position = start + len(sentence)

        return claims

    def _is_factual_claim(self, sentence: str) -> bool:
        """Check if a sentence appears to be a factual claim."""
        # Skip questions
        if sentence.endswith('?'):
            return False

        # Skip pure opinions with hedging
        opinion_markers = ['i think', 'i believe', 'in my opinion', 'perhaps', 'maybe']
        sentence_lower = sentence.lower()
        if any(marker in sentence_lower for marker in opinion_markers):
            return False

        # Look for factual indicators
        factual_indicators = [
            'is', 'are', 'was', 'were', 'has', 'have', 'had',
            'show', 'demonstrate', 'indicate', 'reveal', 'found',
            'according to', 'research', 'study', 'data', 'evidence'
        ]

        return any(indicator in sentence_lower for indicator in factual_indicators)

    def validate_citation(
        self,
        citation: Citation,
        claim: str,
        sources: List[Dict[str, str]]
    ) -> bool:
        """Validate that a citation supports its claim."""
        # Find the source
        source = None
        for s in sources:
            if str(s.get("id")) == str(citation.actual_source_id):
                source = s
                break

        if not source:
            return False

        source_content = source.get("content", "")

        if self.use_semantic_matching and self.llm_judge:
            return self._validate_with_llm(claim, source_content)
        else:
            return self._validate_with_overlap(claim, source_content)

    def _validate_with_overlap(self, claim: str, source: str) -> bool:
        """Word overlap validation fallback. Use LLM validation for accuracy."""
        import warnings
        warnings.warn("Using word-overlap validation fallback", UserWarning)

        stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'}
        claim_words = set(claim.lower().split()) - stopwords
        source_words = set(source.lower().split()) - stopwords

        if not claim_words:
            return False

        overlap = len(claim_words & source_words) / len(claim_words)
        return overlap > 0.5

    def _validate_with_llm(self, claim: str, source: str) -> bool:
        """Use LLM to validate citation."""
        if self._client is None:
            try:
                from openai import OpenAI
                self._client = OpenAI()
            except ImportError:
                return self._validate_with_overlap(claim, source)

        prompt = f"""Does the source text support the claim? Answer only YES or NO.

Claim: {claim}

Source: {source[:1000]}

Answer:"""

        try:
            response = self._client.chat.completions.create(
                model=self.llm_judge or "gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=10
            )
            answer = response.choices[0].message.content.strip().upper()
            return "YES" in answer
        except Exception:
            return self._validate_with_overlap(claim, source)

    def evaluate(self, test_case: CitationTestCase) -> CitationResult:
        """Evaluate citation quality for a test case."""
        # Extract citations and claims
        citations = self.extract_citations(test_case.response)
        claims = self.extract_claims(test_case.response)

        # Track metrics
        valid_citations = 0
        invalid_citations = 0
        cited_sources = set()

        # Validate each citation
        for citation in citations:
            # Find the claim this citation is attached to
            attached_claim = None
            for claim_text, start, end in claims:
                if start <= citation.position <= end + 5:  # Citation within 5 chars of claim end
                    attached_claim = claim_text
                    break

            if attached_claim:
                is_valid = self.validate_citation(citation, attached_claim, test_case.sources)
                citation.is_valid = is_valid
                citation.supporting_text = attached_claim

                if is_valid:
                    valid_citations += 1
                    cited_sources.add(citation.actual_source_id)
                else:
                    invalid_citations += 1
            else:
                invalid_citations += 1

        # Calculate metrics
        total_citations = len(citations)
        precision = valid_citations / total_citations if total_citations > 0 else 0.0

        # Calculate recall
        expected_sources = set(test_case.expected_citations or [])
        if expected_sources:
            recall = len(cited_sources & expected_sources) / len(expected_sources)
        else:
            recall = len(cited_sources) / len(test_case.sources) if test_case.sources else 0.0

        # F1 score
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        # Citation coverage: claims with citations
        claims_with_citations = 0
        uncited_claims = 0
        for claim_text, start, end in claims:
            has_citation = any(start <= c.position <= end + 5 for c in citations)
            if has_citation:
                claims_with_citations += 1
            else:
                uncited_claims += 1

        coverage = claims_with_citations / len(claims) if claims else 1.0

        # Attribution score (average of valid citations)
        attribution = valid_citations / total_citations if total_citations > 0 else 0.0

        return CitationResult(
            precision=round(precision, 4),
            recall=round(recall, 4),
            f1=round(f1, 4),
            citation_coverage=round(coverage, 4),
            attribution_score=round(attribution, 4),
            total_citations=total_citations,
            valid_citations=valid_citations,
            invalid_citations=invalid_citations,
            uncited_claims=uncited_claims,
            citations=citations,
            details={
                "claims_count": len(claims),
                "sources_count": len(test_case.sources),
                "cited_sources": list(cited_sources)
            }
        )

    def evaluate_batch(
        self,
        test_cases: List[CitationTestCase]
    ) -> List[CitationResult]:
        """Evaluate multiple test cases."""
        return [self.evaluate(tc) for tc in test_cases]

    def aggregate_results(self, results: List[CitationResult]) -> Dict[str, float]:
        """Aggregate results across multiple test cases."""
        if not results:
            return {}

        return {
            "avg_precision": sum(r.precision for r in results) / len(results),
            "avg_recall": sum(r.recall for r in results) / len(results),
            "avg_f1": sum(r.f1 for r in results) / len(results),
            "avg_coverage": sum(r.citation_coverage for r in results) / len(results),
            "avg_attribution": sum(r.attribution_score for r in results) / len(results),
            "total_citations": sum(r.total_citations for r in results),
            "total_valid": sum(r.valid_citations for r in results),
            "total_invalid": sum(r.invalid_citations for r in results)
        }
