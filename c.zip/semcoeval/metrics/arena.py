"""
Arena Metrics - Model comparison and ranking metrics for A/B testing.

Implements pairwise comparison metrics similar to LMSYS Chatbot Arena.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
import random


class ComparisonResult(Enum):
    """Result of a pairwise comparison."""
    MODEL_A_WINS = "model_a"
    MODEL_B_WINS = "model_b"
    TIE = "tie"
    BOTH_BAD = "both_bad"


@dataclass
class ArenaMatch:
    """A single arena match between two models."""
    prompt: str
    model_a_id: str
    model_b_id: str
    response_a: str
    response_b: str
    result: Optional[ComparisonResult] = None
    judge_model: Optional[str] = None
    judge_reasoning: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EloRating:
    """ELO rating for a model."""
    model_id: str
    rating: float = 1000.0
    matches: int = 0
    wins: int = 0
    losses: int = 0
    ties: int = 0

    @property
    def win_rate(self) -> float:
        if self.matches == 0:
            return 0.0
        return self.wins / self.matches


class ArenaMetric:
    """
    Arena-style pairwise comparison metric.

    Uses an LLM judge to compare responses from two models
    and compute ELO ratings.

    Usage:
        arena = ArenaMetric(judge_model="gpt-4o")

        # Add matches
        arena.add_match(ArenaMatch(
            prompt="Explain quantum computing",
            model_a_id="gpt-4o",
            model_b_id="claude-3-5-sonnet",
            response_a="Quantum computing uses...",
            response_b="Quantum computers leverage..."
        ))

        # Run judging
        arena.judge_all()

        # Get rankings
        rankings = arena.get_rankings()
    """

    DEFAULT_JUDGE_PROMPT = """You are an impartial judge comparing two AI assistant responses.

Prompt: {prompt}

Response A:
{response_a}

Response B:
{response_b}

Compare these responses based on:
1. Helpfulness and accuracy
2. Clarity and organization
3. Completeness
4. Safety and appropriateness

Output your judgment in this exact format:
WINNER: [A/B/TIE/BOTH_BAD]
REASONING: [Brief explanation]"""

    def __init__(
        self,
        judge_model: str = "gpt-4o",
        k_factor: float = 32.0,
        judge_prompt: Optional[str] = None
    ):
        self.judge_model = judge_model
        self.k_factor = k_factor
        self.judge_prompt = judge_prompt or self.DEFAULT_JUDGE_PROMPT
        self._matches: List[ArenaMatch] = []
        self._ratings: Dict[str, EloRating] = {}
        self._client = None

    def _get_or_create_rating(self, model_id: str) -> EloRating:
        """Get or create ELO rating for a model."""
        if model_id not in self._ratings:
            self._ratings[model_id] = EloRating(model_id=model_id)
        return self._ratings[model_id]

    def add_match(self, match: ArenaMatch) -> None:
        """Add a match to the arena."""
        self._matches.append(match)
        # Initialize ratings if needed
        self._get_or_create_rating(match.model_a_id)
        self._get_or_create_rating(match.model_b_id)

    def add_matches_batch(
        self,
        prompts: List[str],
        model_a_id: str,
        model_b_id: str,
        responses_a: List[str],
        responses_b: List[str]
    ) -> None:
        """Add multiple matches at once."""
        for prompt, resp_a, resp_b in zip(prompts, responses_a, responses_b):
            self.add_match(ArenaMatch(
                prompt=prompt,
                model_a_id=model_a_id,
                model_b_id=model_b_id,
                response_a=resp_a,
                response_b=resp_b
            ))

    def judge_match(self, match: ArenaMatch) -> ComparisonResult:
        """Judge a single match using the LLM judge."""
        if self._client is None:
            self._init_client()

        # Randomly swap to reduce position bias
        swap = random.random() > 0.5
        if swap:
            prompt = self.judge_prompt.format(
                prompt=match.prompt,
                response_a=match.response_b,
                response_b=match.response_a
            )
        else:
            prompt = self.judge_prompt.format(
                prompt=match.prompt,
                response_a=match.response_a,
                response_b=match.response_b
            )

        try:
            response = self._client.chat.completions.create(
                model=self.judge_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0
            )
            judgment = response.choices[0].message.content

            # Parse result
            result = self._parse_judgment(judgment, swap)
            match.result = result
            match.judge_model = self.judge_model
            match.judge_reasoning = judgment

            return result
        except Exception as e:
            match.result = None
            match.judge_reasoning = f"Error: {e}"
            return None

    def _init_client(self):
        """Initialize OpenAI client for judging."""
        try:
            from openai import OpenAI
            self._client = OpenAI()
        except ImportError:
            raise ImportError("OpenAI not installed. Run: pip install openai")

    def _parse_judgment(self, judgment: str, swapped: bool) -> ComparisonResult:
        """Parse the judge's response."""
        judgment_upper = judgment.upper()

        if "WINNER: A" in judgment_upper or "WINNER:A" in judgment_upper:
            result = ComparisonResult.MODEL_A_WINS
        elif "WINNER: B" in judgment_upper or "WINNER:B" in judgment_upper:
            result = ComparisonResult.MODEL_B_WINS
        elif "WINNER: TIE" in judgment_upper or "WINNER:TIE" in judgment_upper:
            result = ComparisonResult.TIE
        elif "WINNER: BOTH_BAD" in judgment_upper or "BOTH_BAD" in judgment_upper:
            result = ComparisonResult.BOTH_BAD
        else:
            result = ComparisonResult.TIE

        # Swap back if we swapped
        if swapped:
            if result == ComparisonResult.MODEL_A_WINS:
                result = ComparisonResult.MODEL_B_WINS
            elif result == ComparisonResult.MODEL_B_WINS:
                result = ComparisonResult.MODEL_A_WINS

        return result

    def judge_all(self) -> None:
        """Judge all pending matches."""
        for match in self._matches:
            if match.result is None:
                self.judge_match(match)

    def update_ratings(self) -> None:
        """Update ELO ratings based on match results using deterministic replay."""
        # Reset all ratings to base and replay all matches for deterministic results
        for rating in self._ratings.values():
            rating.rating = 1000.0
            rating.matches = 0
            rating.wins = 0
            rating.losses = 0
            rating.ties = 0

        # Process all judged matches in order
        for match in self._matches:
            if match.result is None:
                continue

            rating_a = self._get_or_create_rating(match.model_a_id)
            rating_b = self._get_or_create_rating(match.model_b_id)

            # Calculate expected scores
            expected_a = 1 / (1 + 10 ** ((rating_b.rating - rating_a.rating) / 400))
            expected_b = 1 - expected_a

            # Determine actual scores
            if match.result == ComparisonResult.MODEL_A_WINS:
                score_a, score_b = 1.0, 0.0
                rating_a.wins += 1
                rating_b.losses += 1
            elif match.result == ComparisonResult.MODEL_B_WINS:
                score_a, score_b = 0.0, 1.0
                rating_a.losses += 1
                rating_b.wins += 1
            else:  # TIE or BOTH_BAD
                score_a, score_b = 0.5, 0.5
                rating_a.ties += 1
                rating_b.ties += 1

            # Update ratings
            rating_a.rating += self.k_factor * (score_a - expected_a)
            rating_b.rating += self.k_factor * (score_b - expected_b)
            rating_a.matches += 1
            rating_b.matches += 1

    def get_rankings(self) -> List[EloRating]:
        """Get models ranked by ELO rating."""
        self.update_ratings()
        return sorted(
            self._ratings.values(),
            key=lambda r: r.rating,
            reverse=True
        )

    def get_leaderboard(self) -> List[Dict[str, Any]]:
        """Get leaderboard as list of dicts."""
        rankings = self.get_rankings()
        return [
            {
                "rank": i + 1,
                "model": r.model_id,
                "elo": round(r.rating, 1),
                "matches": r.matches,
                "wins": r.wins,
                "losses": r.losses,
                "ties": r.ties,
                "win_rate": round(r.win_rate * 100, 1)
            }
            for i, r in enumerate(rankings)
        ]

    def get_head_to_head(self, model_a: str, model_b: str) -> Dict[str, Any]:
        """Get head-to-head statistics between two models."""
        a_wins = 0
        b_wins = 0
        ties = 0

        for match in self._matches:
            if match.result is None:
                continue

            if match.model_a_id == model_a and match.model_b_id == model_b:
                if match.result == ComparisonResult.MODEL_A_WINS:
                    a_wins += 1
                elif match.result == ComparisonResult.MODEL_B_WINS:
                    b_wins += 1
                else:
                    ties += 1
            elif match.model_a_id == model_b and match.model_b_id == model_a:
                if match.result == ComparisonResult.MODEL_A_WINS:
                    b_wins += 1
                elif match.result == ComparisonResult.MODEL_B_WINS:
                    a_wins += 1
                else:
                    ties += 1

        total = a_wins + b_wins + ties
        return {
            "model_a": model_a,
            "model_b": model_b,
            "total_matches": total,
            f"{model_a}_wins": a_wins,
            f"{model_b}_wins": b_wins,
            "ties": ties,
            f"{model_a}_win_rate": round(a_wins / total * 100, 1) if total > 0 else 0
        }
