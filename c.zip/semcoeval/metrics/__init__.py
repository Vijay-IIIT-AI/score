"""
Metric wrappers for DeepEval metrics and custom evaluation metrics.
"""

# DeepEval metrics by category
METRICS = {
    # Core metrics
    "core": [
        "GEval",
        "AnswerRelevancyMetric",
        "FaithfulnessMetric",
        "HallucinationMetric",
        "SummarizationMetric",
        "ConversationalGEval",  # Conversational general eval
        "ArenaGEval",  # Arena comparison metric
    ],
    # DAG metrics (Deep Acyclic Graph for complex evaluation flows)
    "dag": [
        "DAGMetric",
        "DeepAcyclicGraph",
        "ConversationalDAGMetric",
    ],
    # Non-LLM metrics (deterministic, no model needed)
    "non_llm": [
        "ExactMatchMetric",
        "PatternMatchMetric",
    ],
    # RAG metrics
    "rag": [
        "ContextualRecallMetric",
        "ContextualRelevancyMetric",
        "ContextualPrecisionMetric",
    ],
    # Agent/Tool metrics
    "agent": [
        "ToolCorrectnessMetric",
        "ToolUseMetric",
        "ArgumentCorrectnessMetric",
        "ToolPermissionMetric",
    ],
    # Safety metrics
    "safety": [
        "BiasMetric",
        "ToxicityMetric",
        "PIILeakageMetric",
        "NonAdviceMetric",
        "MisuseMetric",
        "RoleViolationMetric",
    ],
    # Agentic metrics
    "agentic": [
        "TaskCompletionMetric",
        "StepEfficiencyMetric",
        "PlanAdherenceMetric",
        "PlanQualityMetric",
        "GoalAccuracyMetric",
        "AgentLoopDetectionMetric",
        "TopicAdherenceMetric",  # Topic adherence tracking
        "KnowledgeRetentionMetric",  # Knowledge retention across turns
    ],
    # Conversational metrics
    "conversational": [
        "TurnRelevancyMetric",
        "TurnFaithfulnessMetric",
        "TurnContextualPrecisionMetric",  # Turn-level contextual precision
        "TurnContextualRecallMetric",  # Turn-level contextual recall
        "TurnContextualRelevancyMetric",  # Turn-level contextual relevancy
        "ConversationCompletenessMetric",
        "RoleAdherenceMetric",
    ],
    # Format/Task metrics (JSON validation, prompt alignment)
    "format": [
        "JsonCorrectnessMetric",
        "PromptAlignmentMetric",
    ],
    # Multimodal metrics
    "multimodal": [
        "TextToImageMetric",
        "ImageEditingMetric",
        "ImageCoherenceMetric",
        "ImageHelpfulnessMetric",
        "ImageReferenceMetric",
    ],
}

# Flatten for easy access
ALL_METRICS = [m for category in METRICS.values() for m in category]

# Custom SemcoEval metrics
from .arena import ArenaMetric, ArenaMatch, EloRating, ComparisonResult
from .ragas import RAGASEvaluator, RAGASTestCase, RAGASResult, RAGASMetricType, create_ragas_test_case
from .citation import CitationMetric, CitationTestCase, CitationResult, Citation

__all__ = [
    "METRICS",
    "ALL_METRICS",
    # Arena metrics
    "ArenaMetric",
    "ArenaMatch",
    "EloRating",
    "ComparisonResult",
    # RAGAS metrics
    "RAGASEvaluator",
    "RAGASTestCase",
    "RAGASResult",
    "RAGASMetricType",
    "create_ragas_test_case",
    # Citation metrics
    "CitationMetric",
    "CitationTestCase",
    "CitationResult",
    "Citation",
]
