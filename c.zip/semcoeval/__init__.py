"""
SemcoEval - AI Model Evaluation Framework
Built on top of DeepEval with capability validation and extended provider support.

Modules:
- core: Main evaluator and test cases
- providers: 15 LLM provider integrations
- agents: 11 agent framework integrations
- benchmarks: 24 benchmark wrappers (17 DeepEval + 7 custom)
- capabilities: Model capability validation
- mcp: Model Context Protocol support
- metrics: Custom evaluation metrics
- redteam: Red teaming and safety testing
- synthesizer: Synthetic data generation
- prompts: Prompt optimization tools
- datasets: Dataset loading and management
"""

__version__ = "0.1.0"

# Core
from .core.evaluator import SemcoEvaluator
from .core.test_case import SemcoTestCase

# Capabilities
from .capabilities.validator import CapabilityValidator
from .capabilities.registry import CapabilityRegistry, Capability

# MCP
from .mcp import MCPEvaluator

# Lazy imports for optional heavy modules
_LAZY_MODULES = {
    "providers", "agents", "benchmarks", "metrics",
    "redteam", "synthesizer", "prompts", "datasets"
}

def __getattr__(name):
    """Lazy load heavy modules."""
    if name in _LAZY_MODULES:
        import importlib
        module = importlib.import_module(f".{name}", __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    # Version
    "__version__",
    # Core
    "SemcoEvaluator",
    "SemcoTestCase",
    # Capabilities
    "CapabilityValidator",
    "CapabilityRegistry",
    "Capability",
    # MCP
    "MCPEvaluator",
    # Submodules (lazy loaded)
    "providers",
    "agents",
    "benchmarks",
    "metrics",
    "redteam",
    "synthesizer",
    "prompts",
    "datasets",
]
