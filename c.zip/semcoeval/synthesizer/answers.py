"""
Answer Generator - Generate expected answers for evaluation.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json


@dataclass
class AnswerConfig:
    """Configuration for answer generation."""
    answer_style: str = "concise"  # concise, detailed, comprehensive
    include_reasoning: bool = False
    include_citations: bool = False
    model: str = "gpt-4o-mini"
    temperature: float = 0.3


@dataclass
class GeneratedAnswer:
    """A generated answer."""
    answer: str
    reasoning: Optional[str] = None
    citations: List[str] = field(default_factory=list)
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


class AnswerGenerator:
    """
    Generate expected answers for questions.

    Useful for creating golden test cases when you have
    questions but need expected outputs.

    Usage:
        generator = AnswerGenerator()

        # Generate answer for a question
        answer = generator.generate(
            question="What is photosynthesis?",
            context="Photosynthesis is the process...",
            config=AnswerConfig(answer_style="detailed")
        )

        # Generate with citations
        answer = generator.generate_with_citations(
            question="What are the benefits?",
            contexts=["Source 1...", "Source 2..."]
        )
    """

    ANSWER_PROMPT = """Answer the following question based on the provided context.

Question: {question}

Context:
{context}

Answer style: {style}
{reasoning_instruction}
{citation_instruction}

Provide a {style} answer. Output as JSON:
{{
  "answer": "your answer here",
  "reasoning": "your reasoning (if requested)",
  "citations": ["cited text snippets (if requested)"]
}}"""

    STYLE_DESCRIPTIONS = {
        "concise": "brief and to-the-point (1-2 sentences)",
        "detailed": "thorough with explanations (2-4 sentences)",
        "comprehensive": "complete and exhaustive (multiple paragraphs if needed)"
    }

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model
        self._client = None

    def _init_client(self):
        """Initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
                import os
                self._client = OpenAI(api_key=self._api_key or os.getenv("OPENAI_API_KEY"))
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")

    def generate(
        self,
        question: str,
        context: Optional[str] = None,
        config: Optional[AnswerConfig] = None
    ) -> GeneratedAnswer:
        """
        Generate an answer for a question.

        Args:
            question: Question to answer
            context: Optional context to base answer on
            config: Generation configuration

        Returns:
            GeneratedAnswer
        """
        config = config or AnswerConfig()
        self._init_client()

        style_desc = self.STYLE_DESCRIPTIONS.get(config.answer_style, "concise")
        reasoning_instruction = "Include your reasoning process." if config.include_reasoning else ""
        citation_instruction = "Include relevant citations from the context." if config.include_citations else ""

        prompt = self.ANSWER_PROMPT.format(
            question=question,
            context=context or "No specific context provided. Use your knowledge.",
            style=style_desc,
            reasoning_instruction=reasoning_instruction,
            citation_instruction=citation_instruction
        )

        try:
            response = self._client.chat.completions.create(
                model=config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=config.temperature,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)

            return GeneratedAnswer(
                answer=data.get("answer", ""),
                reasoning=data.get("reasoning") if config.include_reasoning else None,
                citations=data.get("citations", []) if config.include_citations else [],
                confidence=1.0,
                metadata={"style": config.answer_style}
            )

        except Exception as e:
            return GeneratedAnswer(
                answer="",
                confidence=0.0,
                metadata={"error": str(e)}
            )

    def generate_with_citations(
        self,
        question: str,
        contexts: List[str],
        config: Optional[AnswerConfig] = None
    ) -> GeneratedAnswer:
        """
        Generate an answer with proper citations to sources.

        Args:
            question: Question to answer
            contexts: List of context passages (sources)
            config: Generation configuration

        Returns:
            GeneratedAnswer with citations
        """
        config = config or AnswerConfig()
        config.include_citations = True
        self._init_client()

        # Format contexts with source numbers
        formatted_contexts = []
        for i, ctx in enumerate(contexts):
            formatted_contexts.append(f"[Source {i+1}]: {ctx}")

        prompt = f"""Answer the following question using ONLY the provided sources.
Cite each fact with its source number in brackets, e.g., [1], [2].

Question: {question}

Sources:
{chr(10).join(formatted_contexts)}

Output as JSON:
{{
  "answer": "Your answer with inline citations like [1], [2]",
  "citations": ["exact quote from source 1", "exact quote from source 2"]
}}"""

        try:
            response = self._client.chat.completions.create(
                model=config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=config.temperature,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)

            return GeneratedAnswer(
                answer=data.get("answer", ""),
                citations=data.get("citations", []),
                confidence=1.0,
                metadata={"num_sources": len(contexts)}
            )

        except Exception as e:
            return GeneratedAnswer(
                answer="",
                confidence=0.0,
                metadata={"error": str(e)}
            )

    def batch_generate(
        self,
        questions: List[str],
        contexts: Optional[List[str]] = None,
        config: Optional[AnswerConfig] = None
    ) -> List[GeneratedAnswer]:
        """
        Generate answers for multiple questions.

        Args:
            questions: List of questions
            contexts: Optional list of contexts (one per question)
            config: Generation configuration

        Returns:
            List of GeneratedAnswer
        """
        answers = []
        contexts = contexts or [None] * len(questions)

        for question, context in zip(questions, contexts):
            answer = self.generate(question, context, config)
            answers.append(answer)

        return answers

    def evaluate_answer_quality(
        self,
        question: str,
        answer: str,
        reference_answer: str
    ) -> Dict[str, float]:
        """
        Evaluate the quality of an answer against a reference.

        Args:
            question: The question
            answer: Answer to evaluate
            reference_answer: Reference/expected answer

        Returns:
            Dict with quality scores
        """
        self._init_client()

        prompt = f"""Evaluate the quality of an answer compared to a reference answer.

Question: {question}

Answer to evaluate: {answer}

Reference answer: {reference_answer}

Rate on a scale of 0-1 for each criterion:
1. Correctness: Is the answer factually correct?
2. Completeness: Does it cover all key points?
3. Relevance: Is it relevant to the question?
4. Clarity: Is it clear and well-written?

Output as JSON:
{{
  "correctness": 0.0-1.0,
  "completeness": 0.0-1.0,
  "relevance": 0.0-1.0,
  "clarity": 0.0-1.0,
  "overall": 0.0-1.0
}}"""

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            return json.loads(content)

        except Exception as e:
            return {
                "correctness": None, "completeness": None, "relevance": None,
                "clarity": None, "overall": None, "error": str(e), "status": "error"
            }
