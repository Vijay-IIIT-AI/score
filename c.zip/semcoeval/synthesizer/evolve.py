"""
Data Evolver - Evolve and augment test data for better coverage.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from enum import Enum
import json
import random


class EvolveMethod(Enum):
    """Methods for evolving data."""
    REPHRASE = "rephrase"
    COMPLICATE = "complicate"
    SIMPLIFY = "simplify"
    ADD_CONTEXT = "add_context"
    ADD_NOISE = "add_noise"
    CHANGE_DOMAIN = "change_domain"
    ADVERSARIAL = "adversarial"
    MULTI_HOP = "multi_hop"


@dataclass
class EvolveConfig:
    """Configuration for data evolution."""
    methods: List[EvolveMethod] = field(default_factory=lambda: [EvolveMethod.REPHRASE])
    num_variations: int = 3
    preserve_answer: bool = True
    model: str = "gpt-4o-mini"
    temperature: float = 0.8


@dataclass
class EvolvedData:
    """Result of data evolution."""
    original_input: str
    evolved_input: str
    method: EvolveMethod
    original_answer: Optional[str] = None
    evolved_answer: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class DataEvolver:
    """
    Evolve and augment test data for better evaluation coverage.

    Supports multiple evolution methods:
    - Rephrase: Different ways to ask the same thing
    - Complicate: Add complexity to questions
    - Simplify: Make questions simpler
    - Add noise: Add distracting information
    - Domain change: Adapt to different domains
    - Adversarial: Create challenging variations
    - Multi-hop: Create multi-step reasoning questions

    Usage:
        evolver = DataEvolver()

        # Evolve a single question
        variations = evolver.evolve(
            input_text="What is the capital of France?",
            config=EvolveConfig(methods=[EvolveMethod.REPHRASE, EvolveMethod.COMPLICATE])
        )

        # Evolve a dataset
        evolved_data = evolver.evolve_dataset(
            dataset=[{"input": "...", "expected_output": "..."}],
            config=EvolveConfig(num_variations=2)
        )
    """

    METHOD_PROMPTS = {
        EvolveMethod.REPHRASE: """Rephrase this question/input in a different way while keeping the same meaning.
Original: {input}
Generate a rephrased version that asks the same thing differently.""",

        EvolveMethod.COMPLICATE: """Make this question/input more complex while keeping the core intent.
Original: {input}
Add conditions, constraints, or additional requirements.""",

        EvolveMethod.SIMPLIFY: """Simplify this question/input while preserving the core intent.
Original: {input}
Make it more direct and straightforward.""",

        EvolveMethod.ADD_CONTEXT: """Add relevant context or background to this question.
Original: {input}
Include additional details that might help or be relevant.""",

        EvolveMethod.ADD_NOISE: """Add distracting but related information to this question.
Original: {input}
Include tangential details that don't change the core question.""",

        EvolveMethod.CHANGE_DOMAIN: """Adapt this question to a different domain or context.
Original: {input}
Target domain: {domain}
Rewrite for the new domain while keeping the structure.""",

        EvolveMethod.ADVERSARIAL: """Create an adversarial version of this question that might trip up an AI.
Original: {input}
Make it tricky while still having a clear correct answer.""",

        EvolveMethod.MULTI_HOP: """Convert this into a multi-step reasoning question.
Original: {input}
Create a version that requires multiple reasoning steps to answer.""",
    }

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model
        self._client = None

    def _init_client(self):
        """Initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
                import os
                self._client = OpenAI(api_key=self._api_key or os.getenv("OPENAI_API_KEY"))
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")

    def evolve(
        self,
        input_text: str,
        expected_output: Optional[str] = None,
        config: Optional[EvolveConfig] = None
    ) -> List[EvolvedData]:
        """
        Evolve a single input using configured methods.

        Args:
            input_text: Original input/question
            expected_output: Optional expected output/answer
            config: Evolution configuration

        Returns:
            List of EvolvedData with variations
        """
        config = config or EvolveConfig()
        self._init_client()

        evolved = []

        for method in config.methods:
            for _ in range(config.num_variations):
                result = self._apply_method(
                    input_text,
                    expected_output,
                    method,
                    config
                )
                if result:
                    evolved.append(result)

        return evolved

    def _apply_method(
        self,
        input_text: str,
        expected_output: Optional[str],
        method: EvolveMethod,
        config: EvolveConfig,
        domain: str = "general"
    ) -> Optional[EvolvedData]:
        """Apply a single evolution method."""
        prompt_template = self.METHOD_PROMPTS.get(method, "")
        prompt = prompt_template.format(input=input_text, domain=domain)

        if config.preserve_answer and expected_output:
            prompt += f"\n\nIMPORTANT: The answer should still be: {expected_output}"

        prompt += "\n\nOutput only the evolved version, no explanations."

        try:
            response = self._client.chat.completions.create(
                model=config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=config.temperature
            )

            evolved_input = response.choices[0].message.content.strip()

            # Generate evolved answer if needed
            evolved_answer = expected_output
            if not config.preserve_answer and expected_output:
                evolved_answer = self._generate_answer(evolved_input, config.model)

            return EvolvedData(
                original_input=input_text,
                evolved_input=evolved_input,
                method=method,
                original_answer=expected_output,
                evolved_answer=evolved_answer
            )

        except Exception:
            return None

    def _generate_answer(self, question: str, model: str) -> str:
        """Generate an answer for an evolved question."""
        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "user", "content": f"Answer concisely: {question}"}
                ],
                temperature=0.3
            )
            return response.choices[0].message.content.strip()
        except Exception:
            return ""

    def evolve_dataset(
        self,
        dataset: List[Dict[str, str]],
        config: Optional[EvolveConfig] = None
    ) -> List[EvolvedData]:
        """
        Evolve an entire dataset.

        Args:
            dataset: List of dicts with 'input' and optionally 'expected_output'
            config: Evolution configuration

        Returns:
            List of EvolvedData
        """
        all_evolved = []

        for item in dataset:
            input_text = item.get("input", "")
            expected_output = item.get("expected_output")

            evolved = self.evolve(input_text, expected_output, config)
            all_evolved.extend(evolved)

        return all_evolved

    def augment_with_negatives(
        self,
        input_text: str,
        correct_answer: str,
        num_negatives: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Generate negative examples (wrong answers).

        Useful for creating multiple-choice evaluations.

        Args:
            input_text: Question/input
            correct_answer: The correct answer
            num_negatives: Number of wrong answers to generate

        Returns:
            List with correct and incorrect options
        """
        self._init_client()

        prompt = f"""For this question, generate {num_negatives} plausible but INCORRECT answers.

Question: {input_text}
Correct answer: {correct_answer}

Generate wrong answers that:
1. Are related to the topic
2. Sound plausible
3. Are clearly incorrect

Output as JSON array of strings."""

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.8,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)
            negatives = data if isinstance(data, list) else data.get("answers", [])

            options = [
                {"answer": correct_answer, "is_correct": True}
            ]
            for neg in negatives[:num_negatives]:
                options.append({"answer": neg, "is_correct": False})

            random.shuffle(options)
            return options

        except Exception:
            return [{"answer": correct_answer, "is_correct": True}]

    def create_multi_hop(
        self,
        facts: List[str],
        num_questions: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Create multi-hop reasoning questions from facts.

        Args:
            facts: List of related facts
            num_questions: Number of questions to generate

        Returns:
            List of multi-hop questions with answers
        """
        self._init_client()

        prompt = f"""Given these facts, create {num_questions} multi-hop reasoning questions.
Each question should require combining information from multiple facts to answer.

Facts:
{chr(10).join(f"- {fact}" for fact in facts)}

Output as JSON:
[
  {{
    "question": "...",
    "answer": "...",
    "required_facts": [0, 2],  // indices of facts needed
    "reasoning_steps": ["step 1", "step 2"]
  }}
]"""

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)
            return data if isinstance(data, list) else data.get("questions", [])

        except Exception:
            return []
