"""
Synthetic Data Generation Module - Wraps DeepEval's Synthesizer for test generation.

Provides tools for generating:
- Golden test cases (via DeepEval's Synthesizer)
- Multi-turn conversations (via ConversationSimulator)
- RAG contexts and expected answers
"""

from .goldens import (
    # DeepEval wrappers (recommended)
    SynthesizerWrapper,
    SynthesizerConfig,
    ConversationSimulatorWrapper,
    EvolutionType,
    # Legacy interface (backwards compatibility)
    GoldenGenerator,
    Golden,
    GoldenContext,
)

from .contexts import (
    ContextGenerator,
    ContextConfig,
    GeneratedContext,
)

from .questions import (
    QuestionGenerator,
    QuestionConfig,
    QuestionType,
    GeneratedQuestion,
)

from .answers import (
    AnswerGenerator,
    AnswerConfig,
    GeneratedAnswer,
)

from .evolve import (
    DataEvolver,
    EvolveConfig,
    EvolveMethod,
)

__all__ = [
    # DeepEval wrappers (recommended)
    "SynthesizerWrapper",
    "SynthesizerConfig",
    "ConversationSimulatorWrapper",
    "EvolutionType",
    # Legacy interface (backwards compatibility)
    "GoldenGenerator",
    "Golden",
    "GoldenContext",
    # Contexts
    "ContextGenerator",
    "ContextConfig",
    "GeneratedContext",
    # Questions
    "QuestionGenerator",
    "QuestionConfig",
    "QuestionType",
    "GeneratedQuestion",
    # Answers
    "AnswerGenerator",
    "AnswerConfig",
    "GeneratedAnswer",
    # Evolution
    "DataEvolver",
    "EvolveConfig",
    "EvolveMethod",
]
