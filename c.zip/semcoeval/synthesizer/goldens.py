"""
Golden Test Case Generator - Wraps DeepEval's Synthesizer for synthetic test generation.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from enum import Enum


class EvolutionType(Enum):
    """Evolution types for data synthesis (maps to DeepEval's Evolution)."""
    SIMPLE = "simple"
    REASONING = "reasoning"
    MULTI_CONTEXT = "multi_context"
    COMPARATIVE = "comparative"


@dataclass
class SynthesizerConfig:
    """Configuration for the Synthesizer wrapper."""
    model: Optional[Any] = None
    async_mode: bool = True
    max_goldens_per_context: int = 2
    evolutions: Optional[List[EvolutionType]] = None
    num_evolutions: int = 1


class SynthesizerWrapper:
    """
    Wrapper for DeepEval's Synthesizer.

    Provides unified interface for generating synthetic test data:
    - generate_goldens_from_docs(): Generate from documents
    - generate_goldens_from_contexts(): Generate from context strings
    - generate_goldens_from_scratch(): Generate without source material

    Usage:
        from semcoeval.synthesizer import SynthesizerWrapper

        synth = SynthesizerWrapper(model=your_model)

        # Generate from documents
        goldens = synth.generate_goldens_from_docs(
            document_paths=["doc1.txt", "doc2.pdf"],
            max_goldens_per_document=5
        )

        # Generate from contexts
        goldens = synth.generate_goldens_from_contexts(
            contexts=[["context 1", "context 2"]],
            max_goldens_per_context=3
        )

        # Generate from scratch
        goldens = synth.generate_goldens_from_scratch(
            subject="Machine Learning",
            num_goldens=10
        )
    """

    def __init__(self, config: Optional[SynthesizerConfig] = None):
        self.config = config or SynthesizerConfig()
        self._synthesizer = None

    def _get_synthesizer(self):
        """Lazily initialize DeepEval Synthesizer."""
        if self._synthesizer is None:
            try:
                from deepeval.synthesizer import Synthesizer

                kwargs = {}
                if self.config.model is not None:
                    kwargs['model'] = self.config.model
                if self.config.async_mode is not None:
                    kwargs['async_mode'] = self.config.async_mode

                self._synthesizer = Synthesizer(**kwargs)
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._synthesizer

    def _get_evolutions(self) -> Optional[List]:
        """Convert EvolutionType enums to DeepEval Evolution enums."""
        if self.config.evolutions is None:
            return None

        try:
            from deepeval.synthesizer import Evolution

            evolution_map = {
                EvolutionType.SIMPLE: Evolution.SIMPLE,
                EvolutionType.REASONING: Evolution.REASONING,
                EvolutionType.MULTI_CONTEXT: Evolution.MULTI_CONTEXT,
                EvolutionType.COMPARATIVE: Evolution.COMPARATIVE,
            }
            return [evolution_map.get(e, Evolution.SIMPLE) for e in self.config.evolutions]
        except ImportError:
            return None

    def generate_goldens_from_docs(
        self,
        document_paths: List[str],
        max_goldens_per_document: int = 5,
        chunk_size: int = 1024,
        chunk_overlap: int = 0,
    ) -> List[Any]:
        """
        Generate golden test cases from documents.

        Args:
            document_paths: List of paths to documents (txt, pdf, docx, etc.)
            max_goldens_per_document: Max goldens to generate per document
            chunk_size: Size of text chunks for processing
            chunk_overlap: Overlap between chunks

        Returns:
            List of DeepEval Golden objects
        """
        synth = self._get_synthesizer()

        kwargs = {
            'document_paths': document_paths,
            'max_goldens_per_document': max_goldens_per_document,
            'chunk_size': chunk_size,
            'chunk_overlap': chunk_overlap,
        }

        evolutions = self._get_evolutions()
        if evolutions:
            kwargs['evolutions'] = evolutions
            kwargs['num_evolutions'] = self.config.num_evolutions

        return synth.generate_goldens_from_docs(**kwargs)

    def generate_goldens_from_contexts(
        self,
        contexts: List[List[str]],
        max_goldens_per_context: Optional[int] = None,
    ) -> List[Any]:
        """
        Generate golden test cases from context strings.

        Args:
            contexts: List of context lists (each inner list is contexts for one golden)
            max_goldens_per_context: Max goldens per context set

        Returns:
            List of DeepEval Golden objects
        """
        synth = self._get_synthesizer()

        kwargs = {
            'contexts': contexts,
            'max_goldens_per_context': max_goldens_per_context or self.config.max_goldens_per_context,
        }

        evolutions = self._get_evolutions()
        if evolutions:
            kwargs['evolutions'] = evolutions
            kwargs['num_evolutions'] = self.config.num_evolutions

        return synth.generate_goldens_from_contexts(**kwargs)

    def generate_goldens_from_scratch(
        self,
        subject: str,
        num_goldens: int = 10,
        context_length: str = "medium",
    ) -> List[Any]:
        """
        Generate golden test cases from scratch without source material.

        Args:
            subject: Topic/subject to generate questions about
            num_goldens: Number of goldens to generate
            context_length: Length of generated contexts ("short", "medium", "long")

        Returns:
            List of DeepEval Golden objects
        """
        synth = self._get_synthesizer()

        kwargs = {
            'subject': subject,
            'num_goldens': num_goldens,
            'context_length': context_length,
        }

        evolutions = self._get_evolutions()
        if evolutions:
            kwargs['evolutions'] = evolutions
            kwargs['num_evolutions'] = self.config.num_evolutions

        return synth.generate_goldens_from_scratch(**kwargs)

    def save_goldens(self, goldens: List[Any], filepath: str) -> None:
        """Save goldens to a JSON file."""
        synth = self._get_synthesizer()
        synth.save_as(filepath, goldens)

    def to_test_cases(self, goldens: List[Any]) -> List[Any]:
        """Convert goldens to DeepEval LLMTestCase objects."""
        try:
            from deepeval.test_case import LLMTestCase

            return [
                LLMTestCase(
                    input=g.input,
                    expected_output=g.expected_output,
                    context=g.context if hasattr(g, 'context') else None,
                    retrieval_context=g.retrieval_context if hasattr(g, 'retrieval_context') else None,
                )
                for g in goldens
            ]
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")


class ConversationSimulatorWrapper:
    """
    Wrapper for DeepEval's ConversationSimulator.

    Generates multi-turn dialogue test cases for conversational AI evaluation.

    Usage:
        from semcoeval.synthesizer import ConversationSimulatorWrapper

        simulator = ConversationSimulatorWrapper(
            model=your_model,
            user_persona="A curious student"
        )

        conversations = simulator.simulate(
            num_conversations=5,
            turns_per_conversation=4
        )
    """

    def __init__(
        self,
        model: Optional[Any] = None,
        user_persona: Optional[str] = None,
        async_mode: bool = True,
    ):
        self.model = model
        self.user_persona = user_persona
        self.async_mode = async_mode
        self._simulator = None

    def _get_simulator(self):
        """Lazily initialize DeepEval ConversationSimulator."""
        if self._simulator is None:
            try:
                from deepeval.synthesizer import ConversationSimulator

                kwargs = {'async_mode': self.async_mode}
                if self.model is not None:
                    kwargs['model'] = self.model
                if self.user_persona is not None:
                    kwargs['user_persona'] = self.user_persona

                self._simulator = ConversationSimulator(**kwargs)
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._simulator

    def simulate(
        self,
        chatbot_callback,
        num_conversations: int = 5,
        turns_per_conversation: int = 4,
    ) -> List[Any]:
        """
        Simulate conversations with a chatbot.

        Args:
            chatbot_callback: Function that takes user message and returns bot response
            num_conversations: Number of conversations to generate
            turns_per_conversation: Number of turns per conversation

        Returns:
            List of ConversationalTestCase objects
        """
        simulator = self._get_simulator()
        return simulator.simulate(
            chatbot_callback=chatbot_callback,
            num_conversations=num_conversations,
            turns_per_conversation=turns_per_conversation,
        )


# Legacy compatibility - keep old interface working
@dataclass
class GoldenContext:
    """A context chunk for RAG evaluation."""
    content: str
    source: Optional[str] = None
    relevance: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Golden:
    """A golden test case for evaluation."""
    input: str
    expected_output: str
    contexts: List[GoldenContext] = field(default_factory=list)
    additional_metadata: Dict[str, Any] = field(default_factory=dict)
    source_file: Optional[str] = None


class GoldenGenerator:
    """
    Legacy interface - wraps SynthesizerWrapper for backwards compatibility.

    For new code, use SynthesizerWrapper directly.
    """

    def __init__(self, api_key: Optional[str] = None, model: Optional[Any] = None):
        self._synth = SynthesizerWrapper(SynthesizerConfig(model=model))

    def from_documents(
        self,
        documents: List[str],
        max_goldens: int = 10
    ) -> List[Golden]:
        """Generate goldens from documents (legacy interface)."""
        import tempfile
        import os

        # Write documents to temp files
        temp_files = []
        try:
            for i, doc in enumerate(documents):
                temp_path = os.path.join(tempfile.gettempdir(), f"doc_{i}.txt")
                with open(temp_path, 'w', encoding='utf-8') as f:
                    f.write(doc)
                temp_files.append(temp_path)

            # Generate using DeepEval
            deepeval_goldens = self._synth.generate_goldens_from_docs(
                document_paths=temp_files,
                max_goldens_per_document=max(1, max_goldens // len(documents))
            )

            # Convert to legacy format
            return self._convert_to_legacy(deepeval_goldens)

        finally:
            # Cleanup temp files
            for temp_path in temp_files:
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

    def generate(
        self,
        topic: str,
        num_goldens: int = 10
    ) -> List[Golden]:
        """Generate goldens for a topic (legacy interface)."""
        deepeval_goldens = self._synth.generate_goldens_from_scratch(
            subject=topic,
            num_goldens=num_goldens
        )
        return self._convert_to_legacy(deepeval_goldens)

    def _convert_to_legacy(self, deepeval_goldens: List[Any]) -> List[Golden]:
        """Convert DeepEval goldens to legacy format."""
        result = []
        for g in deepeval_goldens:
            contexts = []
            if hasattr(g, 'context') and g.context:
                for ctx in g.context:
                    contexts.append(GoldenContext(content=ctx))
            elif hasattr(g, 'retrieval_context') and g.retrieval_context:
                for ctx in g.retrieval_context:
                    contexts.append(GoldenContext(content=ctx))

            result.append(Golden(
                input=g.input,
                expected_output=g.expected_output if hasattr(g, 'expected_output') else "",
                contexts=contexts,
                additional_metadata=g.additional_metadata if hasattr(g, 'additional_metadata') else {}
            ))
        return result

    def to_deepeval(self, goldens: List[Golden]) -> List[Any]:
        """Convert legacy goldens to DeepEval LLMTestCase format."""
        try:
            from deepeval.test_case import LLMTestCase

            return [
                LLMTestCase(
                    input=g.input,
                    expected_output=g.expected_output,
                    retrieval_context=[c.content for c in g.contexts] if g.contexts else None,
                    additional_metadata=g.additional_metadata
                )
                for g in goldens
            ]
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
