"""
Question Generator - Generate synthetic questions for evaluation.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum
import json


class QuestionType(Enum):
    """Types of questions to generate."""
    FACTUAL = "factual"
    REASONING = "reasoning"
    COMPARISON = "comparison"
    DEFINITION = "definition"
    PROCEDURAL = "procedural"
    CAUSAL = "causal"
    HYPOTHETICAL = "hypothetical"
    SUMMARIZATION = "summarization"


@dataclass
class QuestionConfig:
    """Configuration for question generation."""
    num_questions: int = 10
    question_types: List[QuestionType] = field(default_factory=lambda: [QuestionType.FACTUAL])
    difficulty: str = "medium"
    domain: Optional[str] = None
    model: str = "gpt-4o-mini"
    temperature: float = 0.7


@dataclass
class GeneratedQuestion:
    """A generated question."""
    question: str
    question_type: QuestionType
    difficulty: str
    expected_answer: Optional[str] = None
    contexts: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class QuestionGenerator:
    """
    Generate synthetic questions for evaluation datasets.

    Supports multiple question types and difficulty levels.

    Usage:
        generator = QuestionGenerator()

        # Generate from context
        questions = generator.from_context(
            context="Machine learning is a subset of AI...",
            config=QuestionConfig(num_questions=5)
        )

        # Generate for topic
        questions = generator.for_topic(
            topic="Climate Change",
            config=QuestionConfig(
                question_types=[QuestionType.FACTUAL, QuestionType.REASONING]
            )
        )
    """

    TYPE_PROMPTS = {
        QuestionType.FACTUAL: "Generate factual questions that ask about specific facts, dates, names, or definitions.",
        QuestionType.REASONING: "Generate reasoning questions that require analysis, inference, or logical deduction.",
        QuestionType.COMPARISON: "Generate comparison questions that ask to compare/contrast concepts, entities, or approaches.",
        QuestionType.DEFINITION: "Generate definition questions that ask what something is or means.",
        QuestionType.PROCEDURAL: "Generate procedural questions that ask how to do something step-by-step.",
        QuestionType.CAUSAL: "Generate causal questions that ask why something happens or what causes/effects exist.",
        QuestionType.HYPOTHETICAL: "Generate hypothetical questions that explore what-if scenarios.",
        QuestionType.SUMMARIZATION: "Generate questions that ask for summaries or main points.",
    }

    CONTEXT_PROMPT = """Based on the following context, generate {num} {type_desc}

Context:
{context}

Difficulty: {difficulty}

Output format (JSON array):
[
  {{
    "question": "...",
    "answer": "...",
    "reasoning": "brief explanation of why this is the answer"
  }}
]

Generate questions that can be answered using the context."""

    TOPIC_PROMPT = """Generate {num} {type_desc} about {topic}.

Difficulty: {difficulty}
Domain: {domain}

Output format (JSON array):
[
  {{
    "question": "...",
    "answer": "...",
    "reasoning": "brief explanation"
  }}
]

Generate diverse and interesting questions."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model
        self._client = None

    def _init_client(self):
        """Initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
                import os
                self._client = OpenAI(api_key=self._api_key or os.getenv("OPENAI_API_KEY"))
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")

    def from_context(
        self,
        context: str,
        config: Optional[QuestionConfig] = None
    ) -> List[GeneratedQuestion]:
        """
        Generate questions from a given context.

        Args:
            context: Text to generate questions from
            config: Generation configuration

        Returns:
            List of GeneratedQuestion
        """
        config = config or QuestionConfig()
        self._init_client()

        questions = []
        questions_per_type = max(1, config.num_questions // len(config.question_types))

        for q_type in config.question_types:
            type_desc = self.TYPE_PROMPTS.get(q_type, "questions")

            prompt = self.CONTEXT_PROMPT.format(
                num=questions_per_type,
                type_desc=type_desc,
                context=context[:6000],
                difficulty=config.difficulty
            )

            try:
                response = self._client.chat.completions.create(
                    model=config.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=config.temperature,
                    response_format={"type": "json_object"}
                )

                content = response.choices[0].message.content
                data = json.loads(content)

                items = data if isinstance(data, list) else data.get("questions", [])

                for item in items:
                    questions.append(GeneratedQuestion(
                        question=item.get("question", ""),
                        question_type=q_type,
                        difficulty=config.difficulty,
                        expected_answer=item.get("answer"),
                        contexts=[context],
                        metadata={"reasoning": item.get("reasoning", "")}
                    ))

            except Exception:
                continue

        return questions[:config.num_questions]

    def for_topic(
        self,
        topic: str,
        config: Optional[QuestionConfig] = None
    ) -> List[GeneratedQuestion]:
        """
        Generate questions for a topic.

        Args:
            topic: Topic to generate questions about
            config: Generation configuration

        Returns:
            List of GeneratedQuestion
        """
        config = config or QuestionConfig()
        self._init_client()

        questions = []
        questions_per_type = max(1, config.num_questions // len(config.question_types))

        for q_type in config.question_types:
            type_desc = self.TYPE_PROMPTS.get(q_type, "questions")

            prompt = self.TOPIC_PROMPT.format(
                num=questions_per_type,
                type_desc=type_desc,
                topic=topic,
                difficulty=config.difficulty,
                domain=config.domain or "general"
            )

            try:
                response = self._client.chat.completions.create(
                    model=config.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=config.temperature,
                    response_format={"type": "json_object"}
                )

                content = response.choices[0].message.content
                data = json.loads(content)

                items = data if isinstance(data, list) else data.get("questions", [])

                for item in items:
                    questions.append(GeneratedQuestion(
                        question=item.get("question", ""),
                        question_type=q_type,
                        difficulty=config.difficulty,
                        expected_answer=item.get("answer"),
                        metadata={
                            "topic": topic,
                            "reasoning": item.get("reasoning", "")
                        }
                    ))

            except Exception:
                continue

        return questions[:config.num_questions]

    def diversify(
        self,
        base_question: str,
        num_variations: int = 5
    ) -> List[str]:
        """
        Generate diverse variations of a base question.

        Args:
            base_question: Original question to diversify
            num_variations: Number of variations to generate

        Returns:
            List of question variations
        """
        self._init_client()

        prompt = f"""Generate {num_variations} different ways to ask this same question.
Keep the meaning but vary the phrasing, complexity, and style.

Original question: {base_question}

Output as JSON array of strings."""

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.8,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)

            return data if isinstance(data, list) else data.get("questions", [])

        except Exception:
            return [base_question]
