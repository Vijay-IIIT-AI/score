"""
Context Generator - Generate synthetic contexts for RAG evaluation.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json


@dataclass
class ContextConfig:
    """Configuration for context generation."""
    num_contexts: int = 5
    context_length: int = 200  # words
    include_irrelevant: bool = True
    irrelevant_ratio: float = 0.3
    model: str = "gpt-4o-mini"
    temperature: float = 0.7


@dataclass
class GeneratedContext:
    """A generated context chunk."""
    content: str
    is_relevant: bool = True
    relevance_score: float = 1.0
    source_type: str = "synthetic"
    metadata: Dict[str, Any] = field(default_factory=dict)


class ContextGenerator:
    """
    Generate synthetic contexts for RAG evaluation.

    Creates both relevant and irrelevant contexts to test
    context filtering and retrieval accuracy.

    Usage:
        generator = ContextGenerator()

        # Generate contexts for a question
        contexts = generator.generate(
            question="What is machine learning?",
            answer="Machine learning is...",
            config=ContextConfig(num_contexts=5)
        )
    """

    RELEVANT_CONTEXT_PROMPT = """Generate a passage of approximately {length} words that contains information relevant to answering this question.

Question: {question}
Answer hint: {answer_hint}

The passage should:
1. Contain factual information that supports the answer
2. Be written in a natural, document-like style
3. Include some additional related information

Generate ONLY the passage, no explanations."""

    IRRELEVANT_CONTEXT_PROMPT = """Generate a passage of approximately {length} words about a topic COMPLETELY UNRELATED to this question.

Question: {question}

The passage should:
1. Be about a different topic entirely
2. Sound like a real document excerpt
3. Not contain any information useful for answering the question

Generate ONLY the passage, no explanations."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model
        self._client = None

    def _init_client(self):
        """Initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
                import os
                self._client = OpenAI(api_key=self._api_key or os.getenv("OPENAI_API_KEY"))
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")

    def generate(
        self,
        question: str,
        answer: Optional[str] = None,
        config: Optional[ContextConfig] = None
    ) -> List[GeneratedContext]:
        """
        Generate contexts for a question.

        Args:
            question: The question to generate contexts for
            answer: Optional answer hint for relevant contexts
            config: Generation configuration

        Returns:
            List of GeneratedContext
        """
        config = config or ContextConfig()
        self._init_client()

        contexts = []

        # Calculate relevant vs irrelevant counts
        if config.include_irrelevant:
            num_irrelevant = int(config.num_contexts * config.irrelevant_ratio)
            num_relevant = config.num_contexts - num_irrelevant
        else:
            num_relevant = config.num_contexts
            num_irrelevant = 0

        # Generate relevant contexts
        for i in range(num_relevant):
            prompt = self.RELEVANT_CONTEXT_PROMPT.format(
                length=config.context_length,
                question=question,
                answer_hint=answer or "the correct answer"
            )

            try:
                response = self._client.chat.completions.create(
                    model=config.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=config.temperature
                )
                content = response.choices[0].message.content.strip()

                # Vary relevance scores
                relevance = 1.0 - (i * 0.1)  # First context most relevant

                contexts.append(GeneratedContext(
                    content=content,
                    is_relevant=True,
                    relevance_score=max(relevance, 0.5),
                    source_type="synthetic_relevant",
                    metadata={"index": i}
                ))
            except Exception:
                continue

        # Generate irrelevant contexts
        for i in range(num_irrelevant):
            prompt = self.IRRELEVANT_CONTEXT_PROMPT.format(
                length=config.context_length,
                question=question
            )

            try:
                response = self._client.chat.completions.create(
                    model=config.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=config.temperature
                )
                content = response.choices[0].message.content.strip()

                contexts.append(GeneratedContext(
                    content=content,
                    is_relevant=False,
                    relevance_score=0.0,
                    source_type="synthetic_irrelevant",
                    metadata={"index": i}
                ))
            except Exception:
                continue

        return contexts

    def from_document(
        self,
        document: str,
        chunk_size: int = 200,
        chunk_overlap: int = 50
    ) -> List[GeneratedContext]:
        """
        Create contexts by chunking a document.

        Args:
            document: Document text to chunk
            chunk_size: Target chunk size in words
            chunk_overlap: Overlap between chunks in words

        Returns:
            List of GeneratedContext from document chunks
        """
        # Validate parameters to prevent infinite loop
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        if chunk_overlap < 0:
            raise ValueError("chunk_overlap must be non-negative")
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be less than chunk_size to ensure progress")

        words = document.split()
        contexts = []

        # Calculate step size (guaranteed positive due to validation above)
        step = chunk_size - chunk_overlap

        start = 0
        while start < len(words):
            end = min(start + chunk_size, len(words))
            chunk_words = words[start:end]
            chunk_text = " ".join(chunk_words)

            contexts.append(GeneratedContext(
                content=chunk_text,
                is_relevant=True,  # Assume all document chunks are potentially relevant
                relevance_score=1.0,
                source_type="document_chunk",
                metadata={
                    "start_word": start,
                    "end_word": end
                }
            ))

            start += step

        return contexts

    def mix_contexts(
        self,
        relevant: List[GeneratedContext],
        irrelevant: List[GeneratedContext],
        shuffle: bool = True
    ) -> List[GeneratedContext]:
        """Mix relevant and irrelevant contexts."""
        mixed = relevant + irrelevant

        if shuffle:
            import random
            random.shuffle(mixed)

        return mixed
