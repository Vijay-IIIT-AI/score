"""
Few-Shot Generator - Generate and manage few-shot examples for prompts.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json


@dataclass
class FewShotExample:
    """A few-shot example for prompting."""
    input: str
    output: str
    explanation: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FewShotConfig:
    """Configuration for few-shot generation."""
    num_examples: int = 3
    include_explanations: bool = False
    diverse: bool = True  # Select diverse examples
    format_style: str = "standard"  # standard, qa, dialogue
    model: str = "gpt-4o-mini"
    temperature: float = 0.7


class FewShotGenerator:
    """
    Generate and manage few-shot examples for prompting.

    Usage:
        generator = FewShotGenerator()

        # Generate examples for a task
        examples = generator.generate(
            task_description="Classify sentiment as positive or negative",
            config=FewShotConfig(num_examples=5)
        )

        # Format examples for prompting
        formatted = generator.format_examples(
            examples,
            format_style="qa"
        )

        # Select best examples for a new input
        selected = generator.select_examples(
            pool=all_examples,
            new_input="I love this product!",
            num_examples=3
        )
    """

    GENERATION_PROMPT = """Generate {num} example input-output pairs for this task:

Task: {task}

{explanation_instruction}

Output as JSON array:
[
  {{
    "input": "example input",
    "output": "expected output",
    "explanation": "why this is the correct output (if requested)"
  }}
]

Generate diverse examples that cover different cases."""

    FORMAT_TEMPLATES = {
        "standard": "Input: {input}\nOutput: {output}",
        "qa": "Q: {input}\nA: {output}",
        "dialogue": "User: {input}\nAssistant: {output}",
        "markdown": "**Input:** {input}\n**Output:** {output}",
    }

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model
        self._client = None

    def _init_client(self):
        """Initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
                import os
                self._client = OpenAI(api_key=self._api_key or os.getenv("OPENAI_API_KEY"))
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")

    def generate(
        self,
        task_description: str,
        config: Optional[FewShotConfig] = None
    ) -> List[FewShotExample]:
        """
        Generate few-shot examples for a task.

        Args:
            task_description: Description of the task
            config: Generation configuration

        Returns:
            List of FewShotExample
        """
        config = config or FewShotConfig()
        self._init_client()

        explanation_instruction = (
            "Include a brief explanation for each example."
            if config.include_explanations
            else "Do not include explanations."
        )

        prompt = self.GENERATION_PROMPT.format(
            num=config.num_examples,
            task=task_description,
            explanation_instruction=explanation_instruction
        )

        try:
            response = self._client.chat.completions.create(
                model=config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=config.temperature,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)
            items = data if isinstance(data, list) else data.get("examples", [])

            examples = []
            for item in items[:config.num_examples]:
                examples.append(FewShotExample(
                    input=item.get("input", ""),
                    output=item.get("output", ""),
                    explanation=item.get("explanation") if config.include_explanations else None
                ))

            return examples

        except Exception as e:
            raise RuntimeError(f"Failed to generate examples: {e}")

    def format_examples(
        self,
        examples: List[FewShotExample],
        format_style: str = "standard",
        include_explanations: bool = False
    ) -> str:
        """
        Format examples for inclusion in a prompt.

        Args:
            examples: List of examples to format
            format_style: Formatting style (standard, qa, dialogue, markdown)
            include_explanations: Whether to include explanations

        Returns:
            Formatted string of examples
        """
        template = self.FORMAT_TEMPLATES.get(format_style, self.FORMAT_TEMPLATES["standard"])

        formatted_parts = []
        for i, ex in enumerate(examples, 1):
            formatted = template.format(input=ex.input, output=ex.output)
            if include_explanations and ex.explanation:
                formatted += f"\nExplanation: {ex.explanation}"
            formatted_parts.append(f"Example {i}:\n{formatted}")

        return "\n\n".join(formatted_parts)

    def select_examples(
        self,
        pool: List[FewShotExample],
        new_input: str,
        num_examples: int = 3,
        method: str = "similarity"  # similarity, diverse, random
    ) -> List[FewShotExample]:
        """
        Select the most relevant examples for a new input.

        Args:
            pool: Pool of available examples
            new_input: New input to select examples for
            num_examples: Number of examples to select
            method: Selection method

        Returns:
            Selected examples
        """
        if len(pool) <= num_examples:
            return pool

        if method == "random":
            import random
            return random.sample(pool, num_examples)

        elif method == "similarity":
            # Simple keyword-based similarity
            new_words = set(new_input.lower().split())
            scored = []
            for ex in pool:
                ex_words = set(ex.input.lower().split())
                similarity = len(new_words & ex_words) / max(len(new_words), 1)
                scored.append((ex, similarity))

            scored.sort(key=lambda x: x[1], reverse=True)
            return [ex for ex, _ in scored[:num_examples]]

        elif method == "diverse":
            # Select diverse examples
            selected = [pool[0]]
            remaining = pool[1:]

            while len(selected) < num_examples and remaining:
                # Find most different from already selected
                best_idx = 0
                best_diversity = -1

                for i, ex in enumerate(remaining):
                    ex_words = set(ex.input.lower().split())
                    min_overlap = float('inf')

                    for sel in selected:
                        sel_words = set(sel.input.lower().split())
                        overlap = len(ex_words & sel_words)
                        min_overlap = min(min_overlap, overlap)

                    if min_overlap < best_diversity or best_diversity < 0:
                        best_diversity = min_overlap
                        best_idx = i

                selected.append(remaining.pop(best_idx))

            return selected

        return pool[:num_examples]

    def from_dataset(
        self,
        dataset: List[Dict[str, str]],
        input_key: str = "input",
        output_key: str = "output"
    ) -> List[FewShotExample]:
        """
        Create few-shot examples from a dataset.

        Args:
            dataset: List of dicts with input/output pairs
            input_key: Key for input field
            output_key: Key for output field

        Returns:
            List of FewShotExample
        """
        return [
            FewShotExample(
                input=item.get(input_key, ""),
                output=item.get(output_key, ""),
                metadata=item
            )
            for item in dataset
        ]

    def create_prompt_with_examples(
        self,
        task_instruction: str,
        examples: List[FewShotExample],
        new_input: str,
        format_style: str = "standard"
    ) -> str:
        """
        Create a complete few-shot prompt.

        Args:
            task_instruction: Instruction for the task
            examples: Few-shot examples
            new_input: New input to process
            format_style: Formatting style

        Returns:
            Complete prompt with examples
        """
        formatted_examples = self.format_examples(examples, format_style)
        template = self.FORMAT_TEMPLATES.get(format_style, self.FORMAT_TEMPLATES["standard"])

        prompt = f"""{task_instruction}

Here are some examples:

{formatted_examples}

Now process this input:
{template.format(input=new_input, output="")}"""

        return prompt
