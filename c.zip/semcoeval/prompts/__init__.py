"""
Prompt Optimization Module - Wraps DeepEval's DSPy-adapted optimization algorithms.

Provides:
- PromptOptimizerWrapper: Access to GEPA, MIPROv2, COPRO algorithms
- PromptWrapper: Structured prompt definition for optimization
"""

from .templates import (
    PromptTemplate,
    PromptLibrary,
    PromptCategory,
)

from .optimizer import (
    # DeepEval wrappers (recommended)
    PromptOptimizerWrapper,
    PromptWrapper,
    OptimizationAlgorithm,
    PromptConfig,
    # Legacy interface (backwards compatibility)
    PromptOptimizer,
    OptimizationConfig,
    OptimizationResult,
)

from .few_shot import (
    FewShotGenerator,
    FewShotConfig,
    FewShotExample,
)

from .chain_of_thought import (
    ChainOfThoughtPrompt,
    CoTConfig,
    ReasoningStep,
)

__all__ = [
    # Templates
    "PromptTemplate",
    "PromptLibrary",
    "PromptCategory",
    # DeepEval wrappers (recommended)
    "PromptOptimizerWrapper",
    "PromptWrapper",
    "OptimizationAlgorithm",
    "PromptConfig",
    # Legacy interface (backwards compatibility)
    "PromptOptimizer",
    "OptimizationConfig",
    "OptimizationResult",
    # Few-shot
    "FewShotGenerator",
    "FewShotConfig",
    "FewShotExample",
    # Chain of thought
    "ChainOfThoughtPrompt",
    "CoTConfig",
    "ReasoningStep",
]
