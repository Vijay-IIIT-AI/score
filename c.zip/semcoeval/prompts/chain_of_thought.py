"""
Chain of Thought Prompting - Structured reasoning prompts.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json


@dataclass
class ReasoningStep:
    """A step in chain-of-thought reasoning."""
    step_number: int
    description: str
    reasoning: str
    intermediate_result: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CoTConfig:
    """Configuration for chain-of-thought prompting."""
    num_steps: int = 5
    include_verification: bool = True
    format_style: str = "numbered"  # numbered, bullet, narrative
    model: str = "gpt-4o-mini"
    temperature: float = 0.3


class ChainOfThoughtPrompt:
    """
    Generate and manage chain-of-thought prompts.

    Supports various CoT strategies:
    - Zero-shot CoT: "Let's think step by step"
    - Few-shot CoT: With reasoning examples
    - Self-consistency: Multiple reasoning paths
    - Tree of Thoughts: Branching reasoning

    Usage:
        cot = ChainOfThoughtPrompt()

        # Zero-shot CoT
        prompt = cot.zero_shot("What is 15% of 240?")

        # Generate reasoning steps
        steps = cot.generate_reasoning(
            question="If John has 3 apples...",
            config=CoTConfig(num_steps=4)
        )

        # Format as prompt
        formatted = cot.format_cot_prompt(
            question="...",
            examples=[...],
            format_style="numbered"
        )
    """

    ZERO_SHOT_TEMPLATE = """{question}

Let's think through this step by step:

1."""

    FEW_SHOT_TEMPLATE = """Here are some examples of step-by-step reasoning:

{examples}

Now, let's solve this problem:

{question}

Let's think through this step by step:"""

    REASONING_PROMPT = """For this question, generate {num_steps} logical reasoning steps.

Question: {question}

For each step:
1. State what you're figuring out
2. Show your reasoning
3. Note any intermediate result

Output as JSON:
[
  {{
    "step": 1,
    "description": "what this step does",
    "reasoning": "the actual reasoning",
    "result": "intermediate result if any"
  }}
]

End with the final answer."""

    VERIFICATION_PROMPT = """Verify this chain of reasoning:

Question: {question}

Reasoning:
{reasoning}

Answer: {answer}

Check:
1. Is each step logically valid?
2. Does the answer follow from the reasoning?
3. Are there any errors or gaps?

Output JSON:
{{
  "is_valid": true/false,
  "errors": ["any errors found"],
  "confidence": 0.0-1.0,
  "corrected_answer": "if needed"
}}"""

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model
        self._client = None

    def _init_client(self):
        """Initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
                import os
                self._client = OpenAI(api_key=self._api_key or os.getenv("OPENAI_API_KEY"))
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")

    def zero_shot(self, question: str) -> str:
        """
        Create a zero-shot CoT prompt.

        Args:
            question: Question to solve

        Returns:
            Formatted CoT prompt
        """
        return self.ZERO_SHOT_TEMPLATE.format(question=question)

    def few_shot(
        self,
        question: str,
        examples: List[Dict[str, str]]
    ) -> str:
        """
        Create a few-shot CoT prompt with examples.

        Args:
            question: Question to solve
            examples: List of {question, reasoning, answer} dicts

        Returns:
            Formatted CoT prompt
        """
        formatted_examples = []
        for i, ex in enumerate(examples, 1):
            formatted_examples.append(
                f"Example {i}:\n"
                f"Q: {ex.get('question', '')}\n"
                f"Reasoning: {ex.get('reasoning', '')}\n"
                f"A: {ex.get('answer', '')}"
            )

        return self.FEW_SHOT_TEMPLATE.format(
            examples="\n\n".join(formatted_examples),
            question=question
        )

    def generate_reasoning(
        self,
        question: str,
        config: Optional[CoTConfig] = None
    ) -> List[ReasoningStep]:
        """
        Generate reasoning steps for a question.

        Args:
            question: Question to reason about
            config: Generation configuration

        Returns:
            List of ReasoningStep
        """
        config = config or CoTConfig()
        self._init_client()

        prompt = self.REASONING_PROMPT.format(
            num_steps=config.num_steps,
            question=question
        )

        try:
            response = self._client.chat.completions.create(
                model=config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=config.temperature,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            data = json.loads(content)
            items = data if isinstance(data, list) else data.get("steps", [])

            steps = []
            for item in items:
                steps.append(ReasoningStep(
                    step_number=item.get("step", len(steps) + 1),
                    description=item.get("description", ""),
                    reasoning=item.get("reasoning", ""),
                    intermediate_result=item.get("result")
                ))

            return steps

        except Exception as e:
            raise RuntimeError(f"Failed to generate reasoning: {e}")

    def format_reasoning(
        self,
        steps: List[ReasoningStep],
        format_style: str = "numbered"
    ) -> str:
        """
        Format reasoning steps as text.

        Args:
            steps: List of reasoning steps
            format_style: numbered, bullet, or narrative

        Returns:
            Formatted reasoning text
        """
        if format_style == "numbered":
            lines = []
            for step in steps:
                lines.append(f"{step.step_number}. {step.description}")
                lines.append(f"   {step.reasoning}")
                if step.intermediate_result:
                    lines.append(f"   → {step.intermediate_result}")
            return "\n".join(lines)

        elif format_style == "bullet":
            lines = []
            for step in steps:
                lines.append(f"• {step.description}: {step.reasoning}")
                if step.intermediate_result:
                    lines.append(f"  → {step.intermediate_result}")
            return "\n".join(lines)

        elif format_style == "narrative":
            parts = []
            for i, step in enumerate(steps):
                if i == 0:
                    parts.append(f"First, {step.reasoning.lower()}")
                elif i == len(steps) - 1:
                    parts.append(f"Finally, {step.reasoning.lower()}")
                else:
                    parts.append(f"Then, {step.reasoning.lower()}")
            return " ".join(parts)

        return "\n".join(f"{s.step_number}. {s.reasoning}" for s in steps)

    def verify_reasoning(
        self,
        question: str,
        reasoning: str,
        answer: str,
        config: Optional[CoTConfig] = None
    ) -> Dict[str, Any]:
        """
        Verify a chain of reasoning.

        Args:
            question: Original question
            reasoning: The reasoning chain
            answer: The final answer
            config: Configuration

        Returns:
            Verification result with validity and confidence
        """
        config = config or CoTConfig()
        self._init_client()

        prompt = self.VERIFICATION_PROMPT.format(
            question=question,
            reasoning=reasoning,
            answer=answer
        )

        try:
            response = self._client.chat.completions.create(
                model=config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            return json.loads(content)

        except Exception as e:
            return {"is_valid": False, "confidence": 0.0, "error": str(e), "status": "error"}

    def self_consistency(
        self,
        question: str,
        num_paths: int = 5,
        config: Optional[CoTConfig] = None
    ) -> Dict[str, Any]:
        """
        Use self-consistency: sample multiple reasoning paths and vote.

        Args:
            question: Question to solve
            num_paths: Number of reasoning paths to generate
            config: Configuration

        Returns:
            Dict with majority answer and confidence
        """
        config = config or CoTConfig()
        self._init_client()

        answers = []
        reasonings = []

        for _ in range(num_paths):
            prompt = self.zero_shot(question)

            try:
                response = self._client.chat.completions.create(
                    model=config.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7  # Higher temp for diversity
                )

                content = response.choices[0].message.content

                # Extract answer (assuming last line or after "Answer:")
                lines = content.strip().split("\n")
                for line in reversed(lines):
                    if line.strip() and not line.strip().startswith(tuple("0123456789")):
                        answers.append(line.strip())
                        reasonings.append(content)
                        break

            except Exception:
                continue

        # Vote for majority answer
        if not answers:
            return {"answer": "", "confidence": 0.0, "paths": []}

        from collections import Counter
        vote_counts = Counter(answers)
        majority_answer, count = vote_counts.most_common(1)[0]
        confidence = count / len(answers)

        return {
            "answer": majority_answer,
            "confidence": confidence,
            "num_paths": len(answers),
            "vote_distribution": dict(vote_counts),
            "paths": reasonings
        }

    def create_cot_example(
        self,
        question: str,
        answer: str,
        config: Optional[CoTConfig] = None
    ) -> Dict[str, str]:
        """
        Create a CoT example with generated reasoning.

        Args:
            question: Question
            answer: Known correct answer
            config: Configuration

        Returns:
            Dict with question, reasoning, and answer
        """
        steps = self.generate_reasoning(question, config)
        reasoning = self.format_reasoning(steps, "numbered")

        return {
            "question": question,
            "reasoning": reasoning,
            "answer": answer
        }
