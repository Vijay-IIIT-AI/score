"""
Prompt Optimizer - Wraps DeepEval's prompt optimization algorithms.

DeepEval provides DSPy-adapted optimization algorithms:
- GEPA: Genetic-Pareto reflective optimization via execution traces
- MIPROv2: Multi-prompt Instruction Proposal Optimizer
- COPRO: Coordinated Prompt Optimization
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable, Union
from enum import Enum


class OptimizationAlgorithm(Enum):
    """Optimization algorithms available in DeepEval."""
    GEPA = "gepa"  # Genetic-Pareto optimization
    MIPRO = "mipro"  # Multi-prompt Instruction Proposal Optimizer
    COPRO = "copro"  # Coordinated Prompt Optimization


@dataclass
class PromptConfig:
    """Configuration for a prompt to optimize."""
    template: str
    input_variables: List[str] = field(default_factory=list)
    output_format: Optional[str] = None
    few_shot_examples: Optional[List[Dict[str, str]]] = None


@dataclass
class OptimizationConfig:
    """Configuration for prompt optimization."""
    algorithm: OptimizationAlgorithm = OptimizationAlgorithm.GEPA
    model: Optional[Any] = None
    metrics: Optional[List[Any]] = None  # DeepEval metrics to optimize against
    max_iterations: int = 10
    population_size: int = 10  # For genetic algorithms
    async_mode: bool = True


@dataclass
class OptimizationResult:
    """Result of prompt optimization."""
    original_prompt: str
    optimized_prompt: str
    original_score: float
    optimized_score: float
    improvement: float
    iterations: int
    history: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class PromptOptimizerWrapper:
    """
    Wrapper for DeepEval's prompt optimization algorithms.

    Provides access to:
    - GEPA: Genetic-Pareto optimization using execution traces
    - MIPROv2: Multi-prompt Instruction Proposal Optimizer
    - COPRO: Coordinated Prompt Optimization

    These algorithms optimize prompts against DeepEval metrics and test cases.

    Usage:
        from semcoeval.prompts import PromptOptimizerWrapper, OptimizationConfig

        optimizer = PromptOptimizerWrapper(config=OptimizationConfig(
            algorithm=OptimizationAlgorithm.GEPA,
            model=your_model,
            max_iterations=10
        ))

        # Optimize a prompt template
        result = optimizer.optimize(
            prompt_template="Answer the question: {question}",
            test_cases=goldens,  # DeepEval Golden objects
            metrics=[AnswerRelevancyMetric()]
        )

        print(f"Improved by {result.improvement:.1%}")
        print(f"Optimized: {result.optimized_prompt}")
    """

    def __init__(self, config: Optional[OptimizationConfig] = None):
        self.config = config or OptimizationConfig()

    def optimize(
        self,
        prompt_template: str,
        test_cases: List[Any],
        metrics: Optional[List[Any]] = None,
        input_variables: Optional[List[str]] = None,
    ) -> OptimizationResult:
        """
        Optimize a prompt template against test cases and metrics.

        Args:
            prompt_template: The prompt template to optimize
            test_cases: List of DeepEval Golden or LLMTestCase objects
            metrics: DeepEval metrics to optimize against
            input_variables: Variable names in the template

        Returns:
            OptimizationResult with optimized prompt
        """
        metrics = metrics or self.config.metrics or []

        if self.config.algorithm == OptimizationAlgorithm.GEPA:
            return self._optimize_gepa(prompt_template, test_cases, metrics, input_variables)
        elif self.config.algorithm == OptimizationAlgorithm.MIPRO:
            return self._optimize_mipro(prompt_template, test_cases, metrics, input_variables)
        elif self.config.algorithm == OptimizationAlgorithm.COPRO:
            return self._optimize_copro(prompt_template, test_cases, metrics, input_variables)
        else:
            return self._optimize_gepa(prompt_template, test_cases, metrics, input_variables)

    def _optimize_gepa(
        self,
        prompt_template: str,
        test_cases: List[Any],
        metrics: List[Any],
        input_variables: Optional[List[str]],
    ) -> OptimizationResult:
        """Optimize using GEPA (Genetic-Pareto) algorithm."""
        try:
            from deepeval.prompts import Prompt
            from deepeval.prompts.optimizer import PromptOptimizer

            # Create DeepEval Prompt object
            prompt = Prompt(
                template=prompt_template,
                input_variables=input_variables or self._extract_variables(prompt_template)
            )

            # Create optimizer
            optimizer = PromptOptimizer(
                model=self.config.model,
                async_mode=self.config.async_mode,
            )

            # Run optimization
            optimized_prompt = optimizer.optimize(
                prompt=prompt,
                goldens=test_cases,
                metrics=metrics,
                max_iterations=self.config.max_iterations,
            )

            # Calculate scores
            original_score = self._evaluate_prompt(prompt_template, test_cases, metrics)
            optimized_score = self._evaluate_prompt(optimized_prompt.template, test_cases, metrics)

            return OptimizationResult(
                original_prompt=prompt_template,
                optimized_prompt=optimized_prompt.template,
                original_score=original_score,
                optimized_score=optimized_score,
                improvement=optimized_score - original_score,
                iterations=self.config.max_iterations,
                metadata={'algorithm': 'GEPA'}
            )

        except ImportError:
            raise ImportError("DeepEval prompt optimization not available. Ensure deepeval is installed.")

    def _optimize_mipro(
        self,
        prompt_template: str,
        test_cases: List[Any],
        metrics: List[Any],
        input_variables: Optional[List[str]],
    ) -> OptimizationResult:
        """Optimize using MIPROv2 algorithm."""
        try:
            from deepeval.prompts import Prompt
            from deepeval.prompts.optimizer import MIPROOptimizer

            prompt = Prompt(
                template=prompt_template,
                input_variables=input_variables or self._extract_variables(prompt_template)
            )

            optimizer = MIPROOptimizer(
                model=self.config.model,
                async_mode=self.config.async_mode,
            )

            optimized_prompt = optimizer.optimize(
                prompt=prompt,
                goldens=test_cases,
                metrics=metrics,
                max_iterations=self.config.max_iterations,
            )

            original_score = self._evaluate_prompt(prompt_template, test_cases, metrics)
            optimized_score = self._evaluate_prompt(optimized_prompt.template, test_cases, metrics)

            return OptimizationResult(
                original_prompt=prompt_template,
                optimized_prompt=optimized_prompt.template,
                original_score=original_score,
                optimized_score=optimized_score,
                improvement=optimized_score - original_score,
                iterations=self.config.max_iterations,
                metadata={'algorithm': 'MIPROv2'}
            )

        except ImportError:
            # Fallback to GEPA if MIPROv2 not available
            return self._optimize_gepa(prompt_template, test_cases, metrics, input_variables)

    def _optimize_copro(
        self,
        prompt_template: str,
        test_cases: List[Any],
        metrics: List[Any],
        input_variables: Optional[List[str]],
    ) -> OptimizationResult:
        """Optimize using COPRO algorithm."""
        try:
            from deepeval.prompts import Prompt
            from deepeval.prompts.optimizer import COPROOptimizer

            prompt = Prompt(
                template=prompt_template,
                input_variables=input_variables or self._extract_variables(prompt_template)
            )

            optimizer = COPROOptimizer(
                model=self.config.model,
                async_mode=self.config.async_mode,
            )

            optimized_prompt = optimizer.optimize(
                prompt=prompt,
                goldens=test_cases,
                metrics=metrics,
                max_iterations=self.config.max_iterations,
            )

            original_score = self._evaluate_prompt(prompt_template, test_cases, metrics)
            optimized_score = self._evaluate_prompt(optimized_prompt.template, test_cases, metrics)

            return OptimizationResult(
                original_prompt=prompt_template,
                optimized_prompt=optimized_prompt.template,
                original_score=original_score,
                optimized_score=optimized_score,
                improvement=optimized_score - original_score,
                iterations=self.config.max_iterations,
                metadata={'algorithm': 'COPRO'}
            )

        except ImportError:
            # Fallback to GEPA if COPRO not available
            return self._optimize_gepa(prompt_template, test_cases, metrics, input_variables)

    def _extract_variables(self, template: str) -> List[str]:
        """Extract variable names from a template."""
        import re
        return re.findall(r'\{(\w+)\}', template)

    def _evaluate_prompt(
        self,
        prompt_template: str,
        test_cases: List[Any],
        metrics: List[Any]
    ) -> float:
        """Evaluate a prompt against test cases and metrics."""
        if not metrics:
            return 0.0

        total_score = 0.0
        count = 0

        try:
            from deepeval.test_case import LLMTestCase
            from deepeval import evaluate

            for tc in test_cases[:5]:  # Evaluate on subset for speed
                test_case = LLMTestCase(
                    input=tc.input if hasattr(tc, 'input') else str(tc),
                    actual_output="",  # Would need model to generate
                    expected_output=tc.expected_output if hasattr(tc, 'expected_output') else "",
                )

                for metric in metrics:
                    try:
                        metric.measure(test_case)
                        if hasattr(metric, 'score') and metric.score is not None:
                            total_score += metric.score
                            count += 1
                    except Exception:
                        continue

            return total_score / count if count > 0 else 0.0

        except Exception:
            return 0.0


class PromptWrapper:
    """
    Wrapper for DeepEval's Prompt class.

    Provides a structured way to define and manage prompts for optimization.

    Usage:
        prompt = PromptWrapper(
            template="Answer the following question: {question}\\n\\nContext: {context}",
            input_variables=["question", "context"]
        )

        # Format with values
        formatted = prompt.format(question="What is AI?", context="...")
    """

    def __init__(
        self,
        template: str,
        input_variables: Optional[List[str]] = None,
        few_shot_examples: Optional[List[Dict[str, str]]] = None,
    ):
        self.template = template
        self.input_variables = input_variables or self._extract_variables(template)
        self.few_shot_examples = few_shot_examples or []
        self._deepeval_prompt = None

    def _extract_variables(self, template: str) -> List[str]:
        """Extract variable names from template."""
        import re
        return re.findall(r'\{(\w+)\}', template)

    def to_deepeval(self) -> Any:
        """Convert to DeepEval Prompt object."""
        if self._deepeval_prompt is None:
            try:
                from deepeval.prompts import Prompt

                self._deepeval_prompt = Prompt(
                    template=self.template,
                    input_variables=self.input_variables,
                )
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._deepeval_prompt

    def format(self, **kwargs) -> str:
        """Format the template with provided values."""
        return self.template.format(**kwargs)

    def with_few_shot(self) -> str:
        """Get template with few-shot examples prepended."""
        if not self.few_shot_examples:
            return self.template

        examples_str = "\n\n".join([
            f"Input: {ex.get('input', '')}\nOutput: {ex.get('output', '')}"
            for ex in self.few_shot_examples
        ])

        return f"Examples:\n{examples_str}\n\n{self.template}"


# =============================================================================
# Legacy compatibility
# =============================================================================

class PromptOptimizer:
    """
    Legacy interface - wraps PromptOptimizerWrapper for backwards compatibility.

    For new code, use PromptOptimizerWrapper directly.
    """

    def __init__(self, api_key: Optional[str] = None, model: Optional[Any] = None):
        self._wrapper = PromptOptimizerWrapper(OptimizationConfig(model=model))

    def optimize(
        self,
        prompt: str,
        eval_fn: Callable[[str], float],
        config: Optional[Any] = None,
        test_cases: Optional[List[Dict[str, str]]] = None
    ) -> OptimizationResult:
        """
        Optimize a prompt (legacy interface).

        Note: This creates a wrapper around the eval_fn to work with DeepEval's
        metric-based optimization. For best results, use PromptOptimizerWrapper
        directly with DeepEval metrics.
        """
        # Convert test_cases to Golden-like objects
        class MockGolden:
            def __init__(self, data):
                self.input = data.get('input', '')
                self.expected_output = data.get('expected_output', data.get('output', ''))

        goldens = [MockGolden(tc) for tc in (test_cases or [])]

        # Create a custom metric that uses eval_fn
        class CustomMetric:
            def __init__(self, eval_fn):
                self._eval_fn = eval_fn
                self.score = 0.0
                self.success = False
                self.reason = None

            def measure(self, test_case):
                try:
                    prompt = test_case.input if hasattr(test_case, 'input') else str(test_case)
                    self.score = self._eval_fn(prompt)
                    self.success = self.score >= 0.5
                except Exception as e:
                    self.score = 0.0
                    self.success = False
                    self.reason = str(e)

        return self._wrapper.optimize(
            prompt_template=prompt,
            test_cases=goldens,
            metrics=[CustomMetric(eval_fn)],
        )

    def quick_optimize(
        self,
        prompt: str,
        eval_fn: Callable[[str], float]
    ) -> str:
        """Quick optimization (legacy interface)."""
        result = self.optimize(prompt, eval_fn)
        return result.optimized_prompt
