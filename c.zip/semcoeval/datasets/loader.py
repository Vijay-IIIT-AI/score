"""
Dataset Loader - Load datasets from local files for offline evaluation.

Supports JSON, JSONL, and CSV formats for air-gapped environments.
"""

import json
import csv
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Iterator, Union
from enum import Enum


class DatasetFormat(Enum):
    """Supported dataset formats."""
    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"
    AUTO = "auto"


@dataclass
class DatasetMetadata:
    """Metadata about a dataset."""
    name: str
    format: DatasetFormat
    size: int  # Number of samples
    eval_type: str  # model, agent, rag
    category: str
    schema_version: str = "1.0"
    source_file: Optional[str] = None
    subgroups: List[str] = field(default_factory=list)


@dataclass
class DatasetSample:
    """A single sample from a dataset."""
    id: str
    input: Dict[str, Any]
    expected: Dict[str, Any]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_deepeval_test_case(self) -> Dict[str, Any]:
        """Convert to DeepEval LLMTestCase format."""
        return {
            "input": self.input.get("prompt", self.input.get("question", "")),
            "actual_output": None,  # To be filled during evaluation
            "expected_output": self.expected.get("answer", ""),
            "context": self.input.get("context", []),
            "retrieval_context": self.input.get("retrieved_contexts", []),
        }


class DatasetLoader:
    """
    Load datasets from local files for offline evaluation.

    Supports:
    - JSON files (single array or object with 'questions' key)
    - JSONL files (one JSON object per line)
    - CSV files (with header row)

    Usage:
        loader = DatasetLoader()

        # Load from file
        dataset = loader.load("path/to/dataset.json")
        for sample in dataset:
            print(sample.input)

        # Load with filtering
        dataset = loader.load("mmlu.jsonl", subgroup="physics")

        # Stream large files
        for sample in loader.stream("large_dataset.jsonl"):
            process(sample)
    """

    def __init__(self, base_path: Optional[str] = None):
        """
        Initialize the loader.

        Args:
            base_path: Base directory for relative paths
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()

    def detect_format(self, file_path: Union[str, Path]) -> DatasetFormat:
        """Detect format from file extension."""
        path = Path(file_path)
        ext = path.suffix.lower()

        if ext == ".json":
            return DatasetFormat.JSON
        elif ext == ".jsonl":
            return DatasetFormat.JSONL
        elif ext == ".csv":
            return DatasetFormat.CSV
        else:
            raise ValueError(f"Unknown file format: {ext}")

    def load(
        self,
        file_path: Union[str, Path],
        format: DatasetFormat = DatasetFormat.AUTO,
        subgroup: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[DatasetSample]:
        """
        Load a dataset from a file.

        Args:
            file_path: Path to the dataset file
            format: File format (auto-detected if AUTO)
            subgroup: Filter to specific subgroup
            limit: Maximum number of samples to load

        Returns:
            List of DatasetSample objects
        """
        path = self._resolve_path(file_path)

        if format == DatasetFormat.AUTO:
            format = self.detect_format(path)

        if format == DatasetFormat.JSON:
            samples = self._load_json(path)
        elif format == DatasetFormat.JSONL:
            samples = self._load_jsonl(path)
        elif format == DatasetFormat.CSV:
            samples = self._load_csv(path)
        else:
            raise ValueError(f"Unsupported format: {format}")

        # Apply filters
        if subgroup:
            samples = [s for s in samples if s.metadata.get("subgroup") == subgroup]

        if limit:
            samples = samples[:limit]

        return samples

    def stream(
        self,
        file_path: Union[str, Path],
        format: DatasetFormat = DatasetFormat.AUTO,
        subgroup: Optional[str] = None
    ) -> Iterator[DatasetSample]:
        """
        Stream samples from a large file without loading all into memory.

        Best for JSONL format with very large datasets.

        Args:
            file_path: Path to the dataset file
            format: File format
            subgroup: Filter to specific subgroup

        Yields:
            DatasetSample objects one at a time
        """
        path = self._resolve_path(file_path)

        if format == DatasetFormat.AUTO:
            format = self.detect_format(path)

        if format == DatasetFormat.JSONL:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        data = json.loads(line)
                        sample = self._parse_sample(data)
                        if subgroup is None or sample.metadata.get("subgroup") == subgroup:
                            yield sample
        else:
            # For non-streaming formats, fall back to load
            for sample in self.load(path, format, subgroup):
                yield sample

    def get_metadata(self, file_path: Union[str, Path]) -> DatasetMetadata:
        """
        Get metadata about a dataset without loading all samples.

        Args:
            file_path: Path to the dataset file

        Returns:
            DatasetMetadata object
        """
        path = self._resolve_path(file_path)
        format = self.detect_format(path)

        if format == DatasetFormat.JSON:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Check for metadata block
            if isinstance(data, dict) and "metadata" in data:
                meta = data["metadata"]
                questions = data.get("questions", data.get("data", []))
                return DatasetMetadata(
                    name=meta.get("name", path.stem),
                    format=format,
                    size=len(questions),
                    eval_type=meta.get("eval_type", "model"),
                    category=meta.get("category", "General"),
                    schema_version=meta.get("schema_version", "1.0"),
                    source_file=str(path),
                    subgroups=meta.get("subgroups", [])
                )
            else:
                # No metadata, just count items
                items = data if isinstance(data, list) else data.get("questions", [])
                return DatasetMetadata(
                    name=path.stem,
                    format=format,
                    size=len(items),
                    eval_type="model",
                    category="General",
                    source_file=str(path)
                )

        elif format == DatasetFormat.JSONL:
            # Count lines
            count = 0
            subgroups = set()
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        count += 1
                        # Sample first 100 lines for subgroups
                        if count <= 100:
                            data = json.loads(line)
                            if "subgroup" in data:
                                subgroups.add(data["subgroup"])
                            elif "subject" in data:
                                subgroups.add(data["subject"])

            return DatasetMetadata(
                name=path.stem,
                format=format,
                size=count,
                eval_type="model",
                category="General",
                source_file=str(path),
                subgroups=list(subgroups)
            )

        elif format == DatasetFormat.CSV:
            with open(path, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                header = next(reader, [])
                count = sum(1 for _ in reader)

            return DatasetMetadata(
                name=path.stem,
                format=format,
                size=count,
                eval_type="model",
                category="General",
                source_file=str(path)
            )

        raise ValueError(f"Cannot get metadata for format: {format}")

    def list_subgroups(self, file_path: Union[str, Path]) -> List[str]:
        """List all subgroups in a dataset."""
        meta = self.get_metadata(file_path)
        return meta.subgroups

    def _resolve_path(self, file_path: Union[str, Path]) -> Path:
        """Resolve a path relative to base_path if not absolute."""
        path = Path(file_path)
        if not path.is_absolute():
            path = self.base_path / path
        return path

    def _load_json(self, path: Path) -> List[DatasetSample]:
        """Load samples from a JSON file."""
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Handle different JSON structures
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            items = data.get("questions", data.get("data", data.get("samples", [])))
        else:
            raise ValueError("Invalid JSON structure")

        return [self._parse_sample(item) for item in items]

    def _load_jsonl(self, path: Path) -> List[DatasetSample]:
        """Load samples from a JSONL file."""
        samples = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    data = json.loads(line)
                    samples.append(self._parse_sample(data))
        return samples

    def _load_csv(self, path: Path) -> List[DatasetSample]:
        """Load samples from a CSV file."""
        samples = []
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                sample = DatasetSample(
                    id=row.get("id", f"csv-{i}"),
                    input={"prompt": row.get("prompt", row.get("question", row.get("input", "")))},
                    expected={"answer": row.get("answer", row.get("expected", row.get("output", "")))},
                    metadata={k: v for k, v in row.items() if k not in ["id", "prompt", "question", "input", "answer", "expected", "output"]}
                )
                samples.append(sample)
        return samples

    def _parse_sample(self, data: Dict[str, Any]) -> DatasetSample:
        """Parse a sample from raw data."""
        # Handle various dataset formats

        # Standard format
        if "input" in data and "expected" in data:
            return DatasetSample(
                id=data.get("id", ""),
                input=data["input"] if isinstance(data["input"], dict) else {"prompt": data["input"]},
                expected=data["expected"] if isinstance(data["expected"], dict) else {"answer": data["expected"]},
                metadata=data.get("metadata", {})
            )

        # MMLU-style format
        if "question" in data and "answer" in data:
            return DatasetSample(
                id=data.get("id", ""),
                input={
                    "prompt": data["question"],
                    "choices": data.get("choices", data.get("options", [])),
                },
                expected={
                    "answer": data["answer"],
                    "answer_index": data.get("answer_idx", data.get("correct_answer", -1)),
                },
                metadata={
                    "subgroup": data.get("subject", data.get("category", data.get("subgroup", ""))),
                    "difficulty": data.get("difficulty", ""),
                }
            )

        # Simple prompt/completion format
        if "prompt" in data:
            return DatasetSample(
                id=data.get("id", ""),
                input={"prompt": data["prompt"]},
                expected={"answer": data.get("completion", data.get("answer", data.get("output", "")))},
                metadata={}
            )

        # Tool call format
        if "tools" in data or "tool_calls" in data:
            return DatasetSample(
                id=data.get("id", ""),
                input={
                    "prompt": data.get("prompt", data.get("query", "")),
                    "available_tools": data.get("tools", data.get("available_tools", [])),
                },
                expected={
                    "tool_calls": data.get("expected_tools", data.get("tool_calls", [])),
                },
                metadata={"type": "agent"}
            )

        # RAG format
        if "context" in data or "retrieved_contexts" in data:
            return DatasetSample(
                id=data.get("id", ""),
                input={
                    "question": data.get("question", data.get("query", "")),
                    "retrieved_contexts": data.get("context", data.get("retrieved_contexts", [])),
                },
                expected={
                    "answer": data.get("answer", ""),
                    "supporting_context_ids": data.get("supporting_context_ids", []),
                },
                metadata={"type": "rag"}
            )

        # Fallback: use all data as input
        return DatasetSample(
            id=data.get("id", ""),
            input=data,
            expected={},
            metadata={}
        )
