"""
Dataset Converter - Convert between different benchmark dataset formats.
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass

from .loader import DatasetSample, DatasetFormat


@dataclass
class ConversionResult:
    """Result of a dataset conversion."""
    success: bool
    output_path: Optional[str]
    samples_converted: int
    errors: List[str]


class DatasetConverter:
    """
    Convert between different benchmark dataset formats.

    Supports conversions between:
    - Standard SemcoEval format
    - MMLU format
    - HumanEval format
    - BFCL format
    - Custom JSON formats

    Usage:
        converter = DatasetConverter()

        # Convert MMLU to SemcoEval format
        result = converter.convert(
            "mmlu_test.jsonl",
            "mmlu_semcoeval.json",
            source_format="mmlu",
            target_format="semcoeval"
        )

        # Convert to JSONL for streaming
        result = converter.to_jsonl("large_dataset.json", "output.jsonl")
    """

    # Format specifications
    FORMATS = {
        "semcoeval": {
            "structure": "envelope",  # Has metadata wrapper
            "input_key": "input",
            "expected_key": "expected",
            "id_key": "id",
        },
        "mmlu": {
            "structure": "flat",
            "input_key": "question",
            "expected_key": "answer",
            "choices_key": "choices",
            "subject_key": "subject",
        },
        "humaneval": {
            "structure": "flat",
            "input_key": "prompt",
            "expected_key": "canonical_solution",
            "test_key": "test",
            "entry_point_key": "entry_point",
        },
        "bfcl": {
            "structure": "flat",
            "input_key": "question",
            "expected_key": "ground_truth",
            "tools_key": "function",
        },
        "truthfulqa": {
            "structure": "flat",
            "input_key": "question",
            "expected_key": "best_answer",
            "incorrect_key": "incorrect_answers",
        },
        "simple": {
            "structure": "flat",
            "input_key": "prompt",
            "expected_key": "completion",
        },
    }

    def convert(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        source_format: str = "auto",
        target_format: str = "semcoeval",
        eval_type: str = "model",
        category: str = "General"
    ) -> ConversionResult:
        """
        Convert a dataset from one format to another.

        Args:
            input_path: Path to source dataset
            output_path: Path for output dataset
            source_format: Source format name or "auto"
            target_format: Target format name
            eval_type: Evaluation type (model, agent, rag)
            category: Dataset category

        Returns:
            ConversionResult with details
        """
        input_path = Path(input_path)
        output_path = Path(output_path)
        errors = []

        # Load source data
        try:
            with open(input_path, "r", encoding="utf-8") as f:
                if input_path.suffix == ".jsonl":
                    data = [json.loads(line) for line in f if line.strip()]
                else:
                    data = json.load(f)
        except Exception as e:
            return ConversionResult(
                success=False,
                output_path=None,
                samples_converted=0,
                errors=[f"Failed to load source: {e}"]
            )

        # Detect source format if auto
        if source_format == "auto":
            source_format = self._detect_format(data)

        # Get format specs
        source_spec = self.FORMATS.get(source_format, self.FORMATS["simple"])
        target_spec = self.FORMATS.get(target_format, self.FORMATS["semcoeval"])

        # Handle data structure
        if isinstance(data, dict):
            if "questions" in data:
                items = data["questions"]
            elif "data" in data:
                items = data["data"]
            else:
                items = [data]
        else:
            items = data

        # Convert each item
        converted = []
        for i, item in enumerate(items):
            try:
                converted_item = self._convert_item(item, source_spec, target_spec, i)
                converted.append(converted_item)
            except Exception as e:
                errors.append(f"Item {i}: {e}")

        # Build output structure
        if target_format == "semcoeval":
            output_data = {
                "metadata": {
                    "schema_version": "1.0",
                    "name": input_path.stem,
                    "eval_type": eval_type,
                    "category": category,
                    "question_count": len(converted),
                    "source_format": source_format,
                },
                "questions": converted
            }
        else:
            output_data = converted

        # Write output
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(output_path, "w", encoding="utf-8") as f:
                if output_path.suffix == ".jsonl":
                    for item in (output_data["questions"] if isinstance(output_data, dict) else output_data):
                        f.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    json.dump(output_data, f, indent=2, ensure_ascii=False)

            return ConversionResult(
                success=True,
                output_path=str(output_path),
                samples_converted=len(converted),
                errors=errors
            )

        except Exception as e:
            return ConversionResult(
                success=False,
                output_path=None,
                samples_converted=0,
                errors=[f"Failed to write output: {e}"] + errors
            )

    def to_jsonl(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path]
    ) -> ConversionResult:
        """Convert any JSON dataset to JSONL format for streaming."""
        input_path = Path(input_path)
        output_path = Path(output_path)

        try:
            with open(input_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Extract items
            if isinstance(data, dict):
                items = data.get("questions", data.get("data", [data]))
            else:
                items = data

            with open(output_path, "w", encoding="utf-8") as f:
                for item in items:
                    f.write(json.dumps(item, ensure_ascii=False) + "\n")

            return ConversionResult(
                success=True,
                output_path=str(output_path),
                samples_converted=len(items),
                errors=[]
            )

        except Exception as e:
            return ConversionResult(
                success=False,
                output_path=None,
                samples_converted=0,
                errors=[str(e)]
            )

    def merge(
        self,
        input_paths: List[Union[str, Path]],
        output_path: Union[str, Path],
        output_format: str = "semcoeval"
    ) -> ConversionResult:
        """
        Merge multiple datasets into one.

        Args:
            input_paths: List of input file paths
            output_path: Output file path
            output_format: Output format

        Returns:
            ConversionResult
        """
        all_items = []
        errors = []

        for path in input_paths:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    if Path(path).suffix == ".jsonl":
                        items = [json.loads(line) for line in f if line.strip()]
                    else:
                        data = json.load(f)
                        if isinstance(data, dict):
                            items = data.get("questions", data.get("data", []))
                        else:
                            items = data

                # Add source info to metadata
                for item in items:
                    if isinstance(item, dict):
                        item["_source"] = str(path)

                all_items.extend(items)

            except Exception as e:
                errors.append(f"{path}: {e}")

        # Build output
        if output_format == "semcoeval":
            output_data = {
                "metadata": {
                    "schema_version": "1.0",
                    "name": "merged_dataset",
                    "question_count": len(all_items),
                    "source_files": [str(p) for p in input_paths],
                },
                "questions": all_items
            }
        else:
            output_data = all_items

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(output_data, f, indent=2, ensure_ascii=False)

            return ConversionResult(
                success=True,
                output_path=str(output_path),
                samples_converted=len(all_items),
                errors=errors
            )

        except Exception as e:
            return ConversionResult(
                success=False,
                output_path=None,
                samples_converted=0,
                errors=[str(e)] + errors
            )

    def _detect_format(self, data: Any) -> str:
        """Detect the format of dataset data."""
        # Get a sample item
        if isinstance(data, list) and len(data) > 0:
            sample = data[0]
        elif isinstance(data, dict):
            if "questions" in data:
                sample = data["questions"][0] if data["questions"] else {}
            elif "data" in data:
                sample = data["data"][0] if data["data"] else {}
            else:
                sample = data
        else:
            return "simple"

        # Check for format-specific keys
        if "subject" in sample and "choices" in sample:
            return "mmlu"
        if "canonical_solution" in sample or "entry_point" in sample:
            return "humaneval"
        if "function" in sample or "ground_truth" in sample:
            return "bfcl"
        if "best_answer" in sample or "incorrect_answers" in sample:
            return "truthfulqa"
        if "input" in sample and "expected" in sample:
            return "semcoeval"

        return "simple"

    def _convert_item(
        self,
        item: Dict[str, Any],
        source_spec: Dict[str, str],
        target_spec: Dict[str, str],
        index: int
    ) -> Dict[str, Any]:
        """Convert a single item between formats."""

        # Extract input
        input_key = source_spec.get("input_key", "prompt")
        input_value = item.get(input_key, "")

        # Extract expected
        expected_key = source_spec.get("expected_key", "answer")
        expected_value = item.get(expected_key, "")

        # Extract choices if present
        choices_key = source_spec.get("choices_key")
        choices = item.get(choices_key) if choices_key else None

        # Build target format
        if target_spec.get("structure") == "envelope":
            # SemcoEval format
            result = {
                "id": item.get("id", item.get("task_id", f"q-{index:04d}")),
                "type": "model",
                "input": {
                    "prompt": input_value,
                },
                "expected": {
                    "answer": expected_value,
                },
                "evaluation": {
                    "scoring_method": "semantic_similarity",
                }
            }

            # Add choices if present
            if choices:
                result["input"]["choices"] = choices

            # Add subject/category
            subject_key = source_spec.get("subject_key")
            if subject_key and subject_key in item:
                result["metadata"] = {"subgroup": item[subject_key]}

            # Handle special formats
            if "test" in item:  # HumanEval
                result["evaluation"]["test_code"] = item["test"]
                result["evaluation"]["scoring_method"] = "code_execution"

            if "function" in item:  # BFCL
                result["input"]["available_tools"] = item["function"]
                result["type"] = "agent"

        else:
            # Flat format
            target_input_key = target_spec.get("input_key", "prompt")
            target_expected_key = target_spec.get("expected_key", "answer")

            result = {
                "id": item.get("id", f"q-{index:04d}"),
                target_input_key: input_value,
                target_expected_key: expected_value,
            }

            if choices:
                target_choices_key = target_spec.get("choices_key", "choices")
                result[target_choices_key] = choices

        return result
