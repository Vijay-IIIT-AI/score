"""
Golden Dataset - Integration with DeepEval's Golden test case system.
"""

from pathlib import Path
from typing import List, Optional, Dict, Any, Union
from dataclasses import dataclass

from .loader import DatasetLoader, DatasetSample


@dataclass
class GoldenTestCase:
    """
    A golden test case compatible with DeepEval.

    Maps to DeepEval's LLMTestCase parameters:
    - input: The input prompt
    - actual_output: The model's response (filled during evaluation)
    - expected_output: The expected/reference output
    - context: Ground truth context
    - retrieval_context: Retrieved context for RAG
    - tools_called: Tools the model called
    - expected_tools: Tools expected to be called
    - reasoning: Model's reasoning trace
    """
    input: str
    expected_output: Optional[str] = None
    context: Optional[List[str]] = None
    retrieval_context: Optional[List[str]] = None
    expected_tools: Optional[List[Dict[str, Any]]] = None
    additional_metadata: Optional[Dict[str, Any]] = None

    def to_deepeval(self) -> "LLMTestCase":
        """Convert to DeepEval LLMTestCase."""
        try:
            from deepeval.test_case import LLMTestCase

            return LLMTestCase(
                input=self.input,
                actual_output="",  # To be filled during evaluation
                expected_output=self.expected_output,
                context=self.context,
                retrieval_context=self.retrieval_context,
                expected_tools=self.expected_tools,
                additional_metadata=self.additional_metadata,
            )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")


class GoldenDataset:
    """
    Golden Dataset with DeepEval integration.

    Wraps local datasets and provides DeepEval-compatible test cases.

    Usage:
        # Load from file
        dataset = GoldenDataset.from_file("path/to/dataset.json")

        # Get DeepEval test cases
        test_cases = dataset.to_deepeval_test_cases()

        # Use with DeepEval evaluate
        from deepeval import evaluate
        evaluate(test_cases, [metric1, metric2])

        # Filter by subgroup
        physics_cases = dataset.filter(subgroup="physics").to_deepeval_test_cases()
    """

    def __init__(
        self,
        name: str,
        test_cases: List[GoldenTestCase],
        eval_type: str = "model",
        category: str = "General"
    ):
        self.name = name
        self.test_cases = test_cases
        self.eval_type = eval_type
        self.category = category
        self._metadata: Dict[str, Any] = {}

    @classmethod
    def from_file(
        cls,
        file_path: Union[str, Path],
        name: Optional[str] = None,
        subgroup: Optional[str] = None,
        limit: Optional[int] = None
    ) -> "GoldenDataset":
        """
        Load a golden dataset from a file.

        Args:
            file_path: Path to dataset file (JSON, JSONL, or CSV)
            name: Dataset name (defaults to filename)
            subgroup: Filter to specific subgroup
            limit: Maximum number of samples

        Returns:
            GoldenDataset instance
        """
        loader = DatasetLoader()
        samples = loader.load(file_path, subgroup=subgroup, limit=limit)

        test_cases = [cls._sample_to_golden(sample) for sample in samples]

        metadata = loader.get_metadata(file_path)
        dataset_name = name or metadata.name

        return cls(
            name=dataset_name,
            test_cases=test_cases,
            eval_type=metadata.eval_type,
            category=metadata.category
        )

    @classmethod
    def from_samples(
        cls,
        samples: List[DatasetSample],
        name: str = "Custom Dataset",
        eval_type: str = "model"
    ) -> "GoldenDataset":
        """Create a golden dataset from DatasetSample objects."""
        test_cases = [cls._sample_to_golden(sample) for sample in samples]
        return cls(name=name, test_cases=test_cases, eval_type=eval_type)

    @classmethod
    def from_dict_list(
        cls,
        data: List[Dict[str, Any]],
        name: str = "Custom Dataset"
    ) -> "GoldenDataset":
        """
        Create a golden dataset from a list of dictionaries.

        Each dict should have 'input' and optionally 'expected_output', 'context', etc.
        """
        test_cases = []
        for item in data:
            test_case = GoldenTestCase(
                input=item.get("input", item.get("prompt", item.get("question", ""))),
                expected_output=item.get("expected_output", item.get("answer", item.get("output"))),
                context=item.get("context"),
                retrieval_context=item.get("retrieval_context", item.get("retrieved_contexts")),
                expected_tools=item.get("expected_tools", item.get("tools")),
                additional_metadata=item.get("metadata", {})
            )
            test_cases.append(test_case)

        return cls(name=name, test_cases=test_cases)

    @staticmethod
    def _sample_to_golden(sample: DatasetSample) -> GoldenTestCase:
        """Convert a DatasetSample to a GoldenTestCase."""
        input_data = sample.input
        expected_data = sample.expected

        # Extract prompt
        prompt = input_data.get("prompt", input_data.get("question", ""))
        if isinstance(prompt, str):
            input_str = prompt
        else:
            input_str = str(prompt)

        # Handle choices (MMLU-style)
        choices = input_data.get("choices", input_data.get("options", []))
        if choices:
            choice_str = "\n".join(
                f"{chr(65 + i)}. {c}" for i, c in enumerate(choices)
            )
            input_str = f"{input_str}\n\n{choice_str}"

        # Extract expected output
        expected_output = expected_data.get("answer", expected_data.get("output"))
        if expected_output is not None and not isinstance(expected_output, str):
            expected_output = str(expected_output)

        return GoldenTestCase(
            input=input_str,
            expected_output=expected_output,
            context=input_data.get("context"),
            retrieval_context=input_data.get("retrieved_contexts"),
            expected_tools=expected_data.get("tool_calls", expected_data.get("expected_tools")),
            additional_metadata={
                "sample_id": sample.id,
                **sample.metadata
            }
        )

    def to_deepeval_test_cases(self) -> List:
        """Convert all test cases to DeepEval LLMTestCase objects."""
        return [tc.to_deepeval() for tc in self.test_cases]

    def to_deepeval_dataset(self) -> "EvaluationDataset":
        """Convert to DeepEval EvaluationDataset."""
        try:
            from deepeval.dataset import EvaluationDataset

            test_cases = self.to_deepeval_test_cases()
            return EvaluationDataset(test_cases=test_cases)
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")

    def filter(
        self,
        subgroup: Optional[str] = None,
        **metadata_filters
    ) -> "GoldenDataset":
        """
        Filter test cases by metadata.

        Args:
            subgroup: Filter by subgroup name
            **metadata_filters: Additional metadata filters

        Returns:
            New GoldenDataset with filtered test cases
        """
        filtered = []
        for tc in self.test_cases:
            meta = tc.additional_metadata or {}

            # Check subgroup
            if subgroup and meta.get("subgroup") != subgroup:
                continue

            # Check other filters
            match = True
            for key, value in metadata_filters.items():
                if meta.get(key) != value:
                    match = False
                    break

            if match:
                filtered.append(tc)

        return GoldenDataset(
            name=f"{self.name} (filtered)",
            test_cases=filtered,
            eval_type=self.eval_type,
            category=self.category
        )

    def sample(self, n: int, seed: Optional[int] = None) -> "GoldenDataset":
        """
        Random sample of test cases.

        Args:
            n: Number of samples
            seed: Random seed for reproducibility

        Returns:
            New GoldenDataset with sampled test cases
        """
        import random
        if seed is not None:
            random.seed(seed)

        sampled = random.sample(self.test_cases, min(n, len(self.test_cases)))

        return GoldenDataset(
            name=f"{self.name} (sample={n})",
            test_cases=sampled,
            eval_type=self.eval_type,
            category=self.category
        )

    def __len__(self) -> int:
        return len(self.test_cases)

    def __iter__(self):
        return iter(self.test_cases)

    def __getitem__(self, idx: int) -> GoldenTestCase:
        return self.test_cases[idx]
