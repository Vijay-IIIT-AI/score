"""
Basic Evaluation Example

Demonstrates how to use SemcoEval to evaluate a model
on a local dataset.
"""

import os
from pathlib import Path

# Add parent directory to path for imports
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from semcoeval import SemcoEvaluator
from semcoeval.core import EvaluationConfig
from semcoeval.capabilities.validator import ValidationLevel


def main():
    # Initialize the evaluator
    evaluator = SemcoEvaluator()

    # Connect to OpenAI (reads from OPENAI_API_KEY env var)
    if not evaluator.connect_provider("openai"):
        print("Failed to connect to OpenAI. Check your API key.")
        return

    print("Connected to OpenAI!")

    # List available models
    models = evaluator.list_models("openai")
    print(f"\nAvailable models ({len(models)}):")
    for model in models[:5]:
        print(f"  - {model['id']}: context={model['context_window']}")

    # Check model capabilities before running
    validations = evaluator.validate_model(
        "openai",
        "gpt-4o",
        ["AnswerRelevancyMetric", "FaithfulnessMetric", "ToolCorrectnessMetric"]
    )

    print("\nCapability Validation:")
    for v in validations:
        status = "OK" if v.is_valid else "FAIL"
        print(f"  [{status}] {v.metric_name}")
        if v.warnings:
            for w in v.warnings:
                print(f"       Warning: {w}")
        if v.errors:
            for e in v.errors:
                print(f"       Error: {e}")

    # Load a dataset (example with inline data)
    from semcoeval.datasets import GoldenDataset

    dataset = GoldenDataset.from_dict_list([
        {
            "input": "What is the capital of France?",
            "expected_output": "Paris",
            "context": ["Paris is the capital and largest city of France."]
        },
        {
            "input": "What is 2 + 2?",
            "expected_output": "4",
        },
        {
            "input": "Who wrote Romeo and Juliet?",
            "expected_output": "William Shakespeare",
            "context": ["William Shakespeare wrote Romeo and Juliet around 1594-1596."]
        }
    ], name="Quick Test Dataset")

    print(f"\nLoaded dataset: {dataset.name} ({len(dataset)} samples)")

    # Configure the evaluation
    config = EvaluationConfig(
        provider="openai",
        model_id="gpt-4o-mini",  # Using mini for cost efficiency
        metrics=["AnswerRelevancyMetric"],
        validation_level=ValidationLevel.WARN,
        verbose=True
    )

    # Run evaluation
    print("\nRunning evaluation...")
    result = evaluator.evaluate(config, dataset)

    # Print results
    print("\n" + "="*50)
    print("EVALUATION RESULTS")
    print("="*50)
    print(f"Model: {result.provider}:{result.model_id}")
    print(f"Total tests: {result.total_tests}")
    print(f"Passed: {result.passed_tests}")
    print(f"Failed: {result.failed_tests}")
    print(f"Pass rate: {result.pass_rate:.2%}")
    print(f"Overall score: {result.overall_score:.3f}")

    print("\nMetric scores:")
    for metric, score in result.metric_scores.items():
        print(f"  {metric}: {score:.3f}")

    if result.capability_warnings:
        print("\nWarnings:")
        for w in result.capability_warnings:
            print(f"  - {w}")


def example_compare_models():
    """Example: Compare multiple models on the same dataset."""
    evaluator = SemcoEvaluator()

    # Connect to multiple providers
    evaluator.connect_provider("openai")
    evaluator.connect_provider("anthropic")

    # Load dataset
    from semcoeval.datasets import GoldenDataset
    dataset = GoldenDataset.from_dict_list([
        {"input": "Explain quantum entanglement in simple terms.", "expected_output": None},
        {"input": "What causes rainbows?", "expected_output": None},
    ])

    # Compare models
    results = evaluator.compare_models(
        providers_models=[
            {"provider": "openai", "model_id": "gpt-4o-mini"},
            {"provider": "anthropic", "model_id": "claude-3-5-haiku-20241022"},
        ],
        metrics=["AnswerRelevancyMetric"],
        dataset=dataset
    )

    # Generate leaderboard
    leaderboard = evaluator.generate_leaderboard(results)

    print("\nLeaderboard:")
    for entry in leaderboard:
        print(f"  #{entry['rank']} {entry['model']}: {entry['overall_score']:.3f}")


def example_offline_evaluation():
    """Example: Evaluate using offline datasets."""
    evaluator = SemcoEvaluator()

    # Connect to Ollama (local)
    if evaluator.connect_provider("ollama"):
        print("Connected to Ollama!")

        # Load dataset from local file
        # dataset = evaluator.load_dataset("./my_dataset.jsonl", subgroup="physics")

        # For this example, create inline
        from semcoeval.datasets import GoldenDataset
        dataset = GoldenDataset.from_dict_list([
            {"input": "What is Newton's first law?", "expected_output": "An object at rest stays at rest."},
        ])

        config = EvaluationConfig(
            provider="ollama",
            model_id="llama3.2",
            metrics=["AnswerRelevancyMetric"],
        )

        # This runs completely offline!
        result = evaluator.evaluate(config, dataset)
        print(f"Offline evaluation score: {result.overall_score:.3f}")


if __name__ == "__main__":
    main()
