"""
MCP (Model Context Protocol) Evaluation Module.

Provides tools for evaluating MCP server integrations:
- MCPUseMetric: Evaluates correct use of MCP primitives (tools, resources, prompts)
- MCPTaskCompletionMetric: Evaluates task completion using MCP servers
- MultiTurnMCPUseMetric: Evaluates MCP use across conversations

Also includes:
- MCPServer definition helpers
- MCP test case builders
- MCP evaluation utilities
"""

from .server import (
    MCPServerConfig,
    MCPTool,
    MCPResource,
    MCPPrompt,
    create_mcp_server,
)

from .test_case import (
    MCPTestCase,
    MCPConversationalTestCase,
    MCPToolCall,
    MCPResourceCall,
    MCPPromptCall,
)

from .metrics import (
    MCPUseMetricWrapper,
    MCPTaskCompletionMetricWrapper,
    MultiTurnMCPUseMetricWrapper,
)

from .evaluator import MCPEvaluator

__all__ = [
    # Server definitions
    "MCPServerConfig",
    "MCPTool",
    "MCPResource",
    "MCPPrompt",
    "create_mcp_server",
    # Test cases
    "MCPTestCase",
    "MCPConversationalTestCase",
    "MCPToolCall",
    "MCPResourceCall",
    "MCPPromptCall",
    # Metrics
    "MCPUseMetricWrapper",
    "MCPTaskCompletionMetricWrapper",
    "MultiTurnMCPUseMetricWrapper",
    # Evaluator
    "MCPEvaluator",
]
