"""
MCP Evaluator - High-level interface for MCP evaluation.
"""

from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass, field

from .server import MCPServerConfig
from .test_case import MCPTestCase, MCPConversationalTestCase, create_mcp_test_case
from .metrics import (
    MCPUseMetricWrapper,
    MCPTaskCompletionMetricWrapper,
    MultiTurnMCPUseMetricWrapper,
    MCPMetricResult,
)


@dataclass
class MCPEvaluationResult:
    """Result from MCP evaluation."""
    test_case_id: str
    metrics: Dict[str, MCPMetricResult]
    overall_score: float
    passed: bool
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "test_case_id": self.test_case_id,
            "overall_score": self.overall_score,
            "passed": self.passed,
            "metric_scores": {
                name: {
                    "score": result.score,
                    "passed": result.passed,
                    "reason": result.reason,
                }
                for name, result in self.metrics.items()
            },
            "metadata": self.metadata,
        }


@dataclass
class MCPBatchResult:
    """Result from batch MCP evaluation."""
    results: List[MCPEvaluationResult]
    overall_score: float
    pass_rate: float
    metric_averages: Dict[str, float]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "overall_score": self.overall_score,
            "pass_rate": self.pass_rate,
            "metric_averages": self.metric_averages,
            "total_tests": len(self.results),
            "passed_tests": sum(1 for r in self.results if r.passed),
            "results": [r.to_dict() for r in self.results],
        }


class MCPEvaluator:
    """
    High-level evaluator for MCP server integrations.

    Usage:
        evaluator = MCPEvaluator(model=my_model)

        # Evaluate single test case
        test_case = create_mcp_test_case(
            input="Get the weather in NYC",
            actual_output="It's 72°F and sunny in NYC",
            servers=[weather_server_config],
            tools_called=[{"tool_name": "get_weather", "arguments": {"location": "NYC"}}]
        )
        result = evaluator.evaluate(test_case)

        # Evaluate batch
        results = evaluator.evaluate_batch([test_case1, test_case2])
    """

    def __init__(
        self,
        model: Optional[Any] = None,
        threshold: float = 0.5,
        include_reason: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ):
        self.model = model
        self.threshold = threshold
        self.include_reason = include_reason
        self.strict_mode = strict_mode
        self.verbose_mode = verbose_mode

        # Initialize metrics
        self.mcp_use_metric = MCPUseMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )
        self.task_completion_metric = MCPTaskCompletionMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )
        self.multi_turn_metric = MultiTurnMCPUseMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

    def evaluate(
        self,
        test_case: Union[MCPTestCase, MCPConversationalTestCase],
        metrics: Optional[List[str]] = None,
    ) -> MCPEvaluationResult:
        """
        Evaluate a single MCP test case.

        Args:
            test_case: Test case to evaluate
            metrics: List of metrics to run (default: all applicable)

        Returns:
            MCPEvaluationResult
        """
        results = {}
        is_conversational = isinstance(test_case, MCPConversationalTestCase)

        # Determine which metrics to run
        if metrics is None:
            if is_conversational:
                metrics = ["mcp_task_completion", "multi_turn_mcp_use"]
            else:
                metrics = ["mcp_use"]

        # Run each metric
        for metric_name in metrics:
            try:
                if metric_name == "mcp_use" and not is_conversational:
                    results[metric_name] = self.mcp_use_metric.measure(test_case)
                elif metric_name == "mcp_task_completion" and is_conversational:
                    results[metric_name] = self.task_completion_metric.measure(test_case)
                elif metric_name == "multi_turn_mcp_use" and is_conversational:
                    results[metric_name] = self.multi_turn_metric.measure(test_case)
            except Exception as e:
                results[metric_name] = MCPMetricResult(
                    score=0,
                    passed=False,
                    reason=f"Error: {str(e)}"
                )

        # Calculate overall score
        scores = [r.score for r in results.values()]
        overall_score = sum(scores) / len(scores) if scores else 0
        # Fix: Empty results should NOT pass (vacuous truth prevention)
        passed = len(results) > 0 and all(r.passed for r in results.values())

        # Get test case ID
        if hasattr(test_case, 'metadata') and test_case.metadata:
            test_case_id = test_case.metadata.get("id", "unknown")
        else:
            test_case_id = f"mcp-{hash(test_case.input) % 10000:04d}"

        return MCPEvaluationResult(
            test_case_id=test_case_id,
            metrics=results,
            overall_score=overall_score,
            passed=passed,
        )

    def evaluate_batch(
        self,
        test_cases: List[Union[MCPTestCase, MCPConversationalTestCase]],
        metrics: Optional[List[str]] = None,
    ) -> MCPBatchResult:
        """
        Evaluate multiple MCP test cases.

        Args:
            test_cases: List of test cases
            metrics: List of metrics to run

        Returns:
            MCPBatchResult with all results and aggregates
        """
        results = []
        for tc in test_cases:
            result = self.evaluate(tc, metrics)
            results.append(result)

        # Calculate aggregates
        overall_scores = [r.overall_score for r in results]
        overall_score = sum(overall_scores) / len(overall_scores) if overall_scores else 0

        pass_count = sum(1 for r in results if r.passed)
        pass_rate = pass_count / len(results) if results else 0

        # Calculate per-metric averages
        metric_averages = {}
        all_metric_names = set()
        for r in results:
            all_metric_names.update(r.metrics.keys())

        for metric_name in all_metric_names:
            scores = [
                r.metrics[metric_name].score
                for r in results
                if metric_name in r.metrics
            ]
            if scores:
                metric_averages[metric_name] = sum(scores) / len(scores)

        return MCPBatchResult(
            results=results,
            overall_score=overall_score,
            pass_rate=pass_rate,
            metric_averages=metric_averages,
        )

    def evaluate_from_dict(
        self,
        data: Dict[str, Any],
        metrics: Optional[List[str]] = None,
    ) -> MCPEvaluationResult:
        """
        Evaluate from a dictionary definition.

        Args:
            data: Dict with test case data
            metrics: Metrics to run

        Returns:
            MCPEvaluationResult
        """
        test_case = create_mcp_test_case(
            input=data.get("input", ""),
            actual_output=data.get("actual_output", ""),
            servers=data.get("servers", data.get("mcp_servers", [])),
            tools_called=data.get("tools_called", data.get("mcp_tools_called")),
            resources_called=data.get("resources_called", data.get("mcp_resources_called")),
            prompts_called=data.get("prompts_called", data.get("mcp_prompts_called")),
            expected_tools=data.get("expected_tools"),
            expected_output=data.get("expected_output"),
        )
        return self.evaluate(test_case, metrics)

    def evaluate_from_file(
        self,
        file_path: str,
        metrics: Optional[List[str]] = None,
    ) -> MCPBatchResult:
        """Evaluate test cases from a JSON/JSONL file."""
        import json
        from pathlib import Path

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Test file not found: {file_path}")

        test_cases, skipped = self._load_test_cases_from_file(path)

        if not test_cases:
            raise ValueError(f"No valid test cases in {file_path}. Skipped: {len(skipped)}")

        result = self.evaluate_batch(test_cases, metrics)
        if skipped and result.results:
            result.results[0].metadata["skipped_count"] = len(skipped)
        return result

    def _load_test_cases_from_file(self, path) -> tuple:
        """Load test cases from file."""
        import json
        test_cases, skipped = [], []

        if path.suffix == '.jsonl':
            with open(path, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f, 1):
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                        tc = self._create_test_case_from_dict(data)
                        if tc:
                            test_cases.append(tc)
                        else:
                            skipped.append({"line": i, "reason": "missing input"})
                    except json.JSONDecodeError:
                        skipped.append({"line": i, "reason": "invalid JSON"})
        else:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            items = data if isinstance(data, list) else data.get("test_cases", data.get("data", []))
            for i, item in enumerate(items):
                tc = self._create_test_case_from_dict(item)
                if tc:
                    test_cases.append(tc)
                else:
                    skipped.append({"index": i, "reason": "missing input"})

        return test_cases, skipped

    def _create_test_case_from_dict(self, data: Dict) -> Optional[Union[MCPTestCase, MCPConversationalTestCase]]:
        """Create test case from dict, return None if invalid."""
        if not data.get("input"):
            return None
        return create_mcp_test_case(
            input=data.get("input", ""),
            actual_output=data.get("actual_output", ""),
            servers=data.get("servers", data.get("mcp_servers", [])),
            tools_called=data.get("tools_called", data.get("mcp_tools_called")),
            resources_called=data.get("resources_called"),
            prompts_called=data.get("prompts_called"),
            expected_tools=data.get("expected_tools"),
            expected_output=data.get("expected_output"),
        )

