"""
MCP Metrics - Wrappers for DeepEval's MCP evaluation metrics.
"""

from typing import Optional, Union, Any, List
from dataclasses import dataclass

from .test_case import MCPTestCase, MCPConversationalTestCase


@dataclass
class MCPMetricResult:
    """Result from an MCP metric evaluation."""
    score: float
    passed: bool
    reason: Optional[str] = None
    primitive_usage_score: Optional[float] = None
    argument_correctness_score: Optional[float] = None
    task_scores: Optional[List[float]] = None


class MCPUseMetricWrapper:
    """
    Wrapper for DeepEval's MCPUseMetric.

    Evaluates correct use of MCP primitives (tools, resources, prompts).

    Checks:
    - Are the correct primitives being used?
    - Are the arguments correct?

    Usage:
        metric = MCPUseMetricWrapper(threshold=0.7)
        result = metric.measure(test_case)
    """

    def __init__(
        self,
        threshold: float = 0.5,
        model: Optional[Any] = None,
        include_reason: bool = True,
        strict_mode: bool = False,
        async_mode: bool = True,
        verbose_mode: bool = False,
    ):
        self.threshold = threshold
        self.model = model
        self.include_reason = include_reason
        self.strict_mode = strict_mode
        self.async_mode = async_mode
        self.verbose_mode = verbose_mode
        self._metric = None

    def _get_metric(self):
        """Lazily initialize the DeepEval metric."""
        if self._metric is None:
            try:
                from deepeval.metrics import MCPUseMetric

                self._metric = MCPUseMetric(
                    threshold=self.threshold,
                    model=self.model,
                    include_reason=self.include_reason,
                    strict_mode=self.strict_mode,
                    async_mode=self.async_mode,
                    verbose_mode=self.verbose_mode,
                )
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._metric

    def measure(self, test_case: Union[MCPTestCase, Any]) -> MCPMetricResult:
        """
        Measure MCP use correctness (synchronous).

        Args:
            test_case: MCPTestCase or DeepEval LLMTestCase

        Returns:
            MCPMetricResult with score and details
        """
        metric = self._get_metric()

        # Convert to DeepEval format if needed
        if isinstance(test_case, MCPTestCase):
            deepeval_case = test_case.to_deepeval()
        else:
            deepeval_case = test_case

        # Run measurement
        metric.measure(deepeval_case)

        return MCPMetricResult(
            score=metric.score,
            passed=metric.success,
            reason=metric.reason if self.include_reason else None,
        )

    async def a_measure(self, test_case: Union[MCPTestCase, Any]) -> MCPMetricResult:
        """
        Measure MCP use correctness (async).

        Args:
            test_case: MCPTestCase or DeepEval LLMTestCase

        Returns:
            MCPMetricResult with score and details
        """
        metric = self._get_metric()

        # Convert to DeepEval format if needed
        if isinstance(test_case, MCPTestCase):
            deepeval_case = test_case.to_deepeval()
        else:
            deepeval_case = test_case

        # Run async measurement
        await metric.a_measure(deepeval_case)

        return MCPMetricResult(
            score=metric.score,
            passed=metric.success,
            reason=metric.reason if self.include_reason else None,
        )

    @property
    def name(self) -> str:
        return "MCP Use"


class MCPTaskCompletionMetricWrapper:
    """
    Wrapper for DeepEval's MCPTaskCompletionMetric.

    Evaluates whether tasks were completed successfully using MCP servers.

    Usage:
        metric = MCPTaskCompletionMetricWrapper(threshold=0.7)
        result = metric.measure(conversational_test_case)
    """

    def __init__(
        self,
        threshold: float = 0.5,
        model: Optional[Any] = None,
        include_reason: bool = True,
        strict_mode: bool = False,
        async_mode: bool = True,
        verbose_mode: bool = False,
    ):
        self.threshold = threshold
        self.model = model
        self.include_reason = include_reason
        self.strict_mode = strict_mode
        self.async_mode = async_mode
        self.verbose_mode = verbose_mode
        self._metric = None

    def _get_metric(self):
        """Lazily initialize the DeepEval metric."""
        if self._metric is None:
            try:
                from deepeval.metrics import MCPTaskCompletionMetric

                self._metric = MCPTaskCompletionMetric(
                    threshold=self.threshold,
                    model=self.model,
                    include_reason=self.include_reason,
                    strict_mode=self.strict_mode,
                    async_mode=self.async_mode,
                    verbose_mode=self.verbose_mode,
                )
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._metric

    def measure(self, test_case: Union[MCPConversationalTestCase, Any]) -> MCPMetricResult:
        """
        Measure task completion with MCP (synchronous).

        Args:
            test_case: MCPConversationalTestCase or DeepEval ConversationalTestCase

        Returns:
            MCPMetricResult with score and details
        """
        metric = self._get_metric()

        # Convert to DeepEval format if needed
        if isinstance(test_case, MCPConversationalTestCase):
            deepeval_case = test_case.to_deepeval()
        else:
            deepeval_case = test_case

        # Run measurement
        metric.measure(deepeval_case)

        # Extract task scores
        task_scores = None
        if hasattr(metric, 'task_scores') and metric.task_scores:
            task_scores = [ts.score for ts in metric.task_scores]

        return MCPMetricResult(
            score=metric.score,
            passed=metric.success,
            reason=metric.reason if self.include_reason else None,
            task_scores=task_scores,
        )

    async def a_measure(self, test_case: Union[MCPConversationalTestCase, Any]) -> MCPMetricResult:
        """
        Measure task completion with MCP (async).

        Args:
            test_case: MCPConversationalTestCase or DeepEval ConversationalTestCase

        Returns:
            MCPMetricResult with score and details
        """
        metric = self._get_metric()

        # Convert to DeepEval format if needed
        if isinstance(test_case, MCPConversationalTestCase):
            deepeval_case = test_case.to_deepeval()
        else:
            deepeval_case = test_case

        # Run async measurement
        await metric.a_measure(deepeval_case)

        # Extract task scores
        task_scores = None
        if hasattr(metric, 'task_scores') and metric.task_scores:
            task_scores = [ts.score for ts in metric.task_scores]

        return MCPMetricResult(
            score=metric.score,
            passed=metric.success,
            reason=metric.reason if self.include_reason else None,
            task_scores=task_scores,
        )

    @property
    def name(self) -> str:
        return "MCP Task Completion"


class MultiTurnMCPUseMetricWrapper:
    """
    Wrapper for DeepEval's MultiTurnMCPUseMetric.

    Evaluates MCP use across multiple conversation turns.

    Usage:
        metric = MultiTurnMCPUseMetricWrapper(threshold=0.7)
        result = metric.measure(conversational_test_case)
    """

    def __init__(
        self,
        threshold: float = 0.5,
        model: Optional[Any] = None,
        include_reason: bool = True,
        strict_mode: bool = False,
        async_mode: bool = True,
        verbose_mode: bool = False,
    ):
        self.threshold = threshold
        self.model = model
        self.include_reason = include_reason
        self.strict_mode = strict_mode
        self.async_mode = async_mode
        self.verbose_mode = verbose_mode
        self._metric = None

    def _get_metric(self):
        """Lazily initialize the DeepEval metric."""
        if self._metric is None:
            try:
                from deepeval.metrics import MultiTurnMCPUseMetric

                self._metric = MultiTurnMCPUseMetric(
                    threshold=self.threshold,
                    model=self.model,
                    include_reason=self.include_reason,
                    strict_mode=self.strict_mode,
                    async_mode=self.async_mode,
                    verbose_mode=self.verbose_mode,
                )
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._metric

    def measure(self, test_case: Union[MCPConversationalTestCase, Any]) -> MCPMetricResult:
        """
        Measure multi-turn MCP use (synchronous).

        Args:
            test_case: MCPConversationalTestCase or DeepEval ConversationalTestCase

        Returns:
            MCPMetricResult with score and details
        """
        metric = self._get_metric()

        # Convert to DeepEval format if needed
        if isinstance(test_case, MCPConversationalTestCase):
            deepeval_case = test_case.to_deepeval()
        else:
            deepeval_case = test_case

        # Run measurement
        metric.measure(deepeval_case)

        return MCPMetricResult(
            score=metric.score,
            passed=metric.success,
            reason=metric.reason if self.include_reason else None,
        )

    async def a_measure(self, test_case: Union[MCPConversationalTestCase, Any]) -> MCPMetricResult:
        """
        Measure multi-turn MCP use (async).

        Args:
            test_case: MCPConversationalTestCase or DeepEval ConversationalTestCase

        Returns:
            MCPMetricResult with score and details
        """
        metric = self._get_metric()

        # Convert to DeepEval format if needed
        if isinstance(test_case, MCPConversationalTestCase):
            deepeval_case = test_case.to_deepeval()
        else:
            deepeval_case = test_case

        # Run async measurement
        await metric.a_measure(deepeval_case)

        return MCPMetricResult(
            score=metric.score,
            passed=metric.success,
            reason=metric.reason if self.include_reason else None,
        )

    @property
    def name(self) -> str:
        return "Multi-Turn MCP Use"


# Convenience function to get all MCP metrics
def get_mcp_metrics(
    threshold: float = 0.5,
    model: Optional[Any] = None,
    include_reason: bool = True,
) -> dict:
    """
    Get all MCP metrics with shared configuration.

    Returns:
        Dict with metric instances
    """
    return {
        "mcp_use": MCPUseMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
        ),
        "mcp_task_completion": MCPTaskCompletionMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
        ),
        "multi_turn_mcp_use": MultiTurnMCPUseMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
        ),
    }
