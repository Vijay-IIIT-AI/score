"""
MCP Server Configuration - Define MCP servers for evaluation.

The Model Context Protocol (MCP) defines three primitives:
- Tools: Functions the model can call
- Resources: Data the model can access
- Prompts: Pre-defined prompt templates
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class MCPTool:
    """
    An MCP tool definition.

    Attributes:
        name: Tool name
        description: What the tool does
        parameters: JSON schema for parameters
        required_params: List of required parameter names
    """
    name: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    required_params: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
            "required": self.required_params,
        }

    def to_deepeval(self) -> "MCPTool":
        """Convert to DeepEval MCPTool format."""
        try:
            from deepeval.test_case import MCPTool as DeepEvalMCPTool
            return DeepEvalMCPTool(
                name=self.name,
                description=self.description,
                input_schema=self.parameters,
            )
        except ImportError:
            return self


@dataclass
class MCPResource:
    """
    An MCP resource definition.

    Resources are data sources the model can access.

    Attributes:
        uri: Resource URI (e.g., "file:///path/to/file")
        name: Human-readable name
        description: What the resource contains
        mime_type: Content type
    """
    uri: str
    name: str
    description: str = ""
    mime_type: str = "text/plain"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "mimeType": self.mime_type,
        }

    def to_deepeval(self) -> "MCPResource":
        """Convert to DeepEval MCPResource format."""
        try:
            from deepeval.test_case import MCPResource as DeepEvalMCPResource
            return DeepEvalMCPResource(
                uri=self.uri,
                name=self.name,
                description=self.description,
                mime_type=self.mime_type,
            )
        except ImportError:
            return self


@dataclass
class MCPPrompt:
    """
    An MCP prompt template definition.

    Attributes:
        name: Prompt name
        description: What the prompt is for
        arguments: Expected arguments for the prompt
    """
    name: str
    description: str = ""
    arguments: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "arguments": self.arguments,
        }

    def to_deepeval(self) -> "MCPPrompt":
        """Convert to DeepEval MCPPrompt format."""
        try:
            from deepeval.test_case import MCPPrompt as DeepEvalMCPPrompt
            return DeepEvalMCPPrompt(
                name=self.name,
                description=self.description,
                arguments=self.arguments,
            )
        except ImportError:
            return self


@dataclass
class MCPServerConfig:
    """
    Configuration for an MCP server.

    Attributes:
        name: Server name
        description: What the server provides
        tools: Available tools
        resources: Available resources
        prompts: Available prompts
    """
    name: str
    description: str = ""
    tools: List[MCPTool] = field(default_factory=list)
    resources: List[MCPResource] = field(default_factory=list)
    prompts: List[MCPPrompt] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "tools": [t.to_dict() for t in self.tools],
            "resources": [r.to_dict() for r in self.resources],
            "prompts": [p.to_dict() for p in self.prompts],
        }

    def to_deepeval(self) -> "MCPServer":
        """Convert to DeepEval MCPServer format."""
        try:
            from deepeval.test_case import MCPServer
            return MCPServer(
                server_name=self.name,
                available_tools=[t.to_deepeval() for t in self.tools],
                available_resources=[r.to_deepeval() for r in self.resources],
                available_prompts=[p.to_deepeval() for p in self.prompts],
            )
        except ImportError:
            return self


def create_mcp_server(
    name: str,
    tools: Optional[List[Dict[str, Any]]] = None,
    resources: Optional[List[Dict[str, Any]]] = None,
    prompts: Optional[List[Dict[str, Any]]] = None,
    description: str = ""
) -> MCPServerConfig:
    """
    Create an MCP server configuration from dictionaries.

    Args:
        name: Server name
        tools: List of tool definitions
        resources: List of resource definitions
        prompts: List of prompt definitions
        description: Server description

    Returns:
        MCPServerConfig

    Example:
        server = create_mcp_server(
            name="weather",
            tools=[{
                "name": "get_weather",
                "description": "Get current weather",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    }
                }
            }]
        )
    """
    tool_objs = []
    if tools:
        for t in tools:
            tool_objs.append(MCPTool(
                name=t.get("name", ""),
                description=t.get("description", ""),
                parameters=t.get("parameters", t.get("input_schema", {})),
                required_params=t.get("required", []),
            ))

    resource_objs = []
    if resources:
        for r in resources:
            resource_objs.append(MCPResource(
                uri=r.get("uri", ""),
                name=r.get("name", ""),
                description=r.get("description", ""),
                mime_type=r.get("mimeType", r.get("mime_type", "text/plain")),
            ))

    prompt_objs = []
    if prompts:
        for p in prompts:
            prompt_objs.append(MCPPrompt(
                name=p.get("name", ""),
                description=p.get("description", ""),
                arguments=p.get("arguments", []),
            ))

    return MCPServerConfig(
        name=name,
        description=description,
        tools=tool_objs,
        resources=resource_objs,
        prompts=prompt_objs,
    )


# Pre-defined MCP server templates for common use cases
COMMON_MCP_SERVERS = {
    "filesystem": MCPServerConfig(
        name="filesystem",
        description="File system operations",
        tools=[
            MCPTool(
                name="read_file",
                description="Read contents of a file",
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path"}
                    }
                },
                required_params=["path"]
            ),
            MCPTool(
                name="write_file",
                description="Write contents to a file",
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path"},
                        "content": {"type": "string", "description": "File content"}
                    }
                },
                required_params=["path", "content"]
            ),
            MCPTool(
                name="list_directory",
                description="List files in a directory",
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Directory path"}
                    }
                },
                required_params=["path"]
            ),
        ]
    ),
    "web": MCPServerConfig(
        name="web",
        description="Web operations",
        tools=[
            MCPTool(
                name="fetch_url",
                description="Fetch content from a URL",
                parameters={
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "URL to fetch"}
                    }
                },
                required_params=["url"]
            ),
            MCPTool(
                name="search_web",
                description="Search the web",
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"}
                    }
                },
                required_params=["query"]
            ),
        ]
    ),
    "database": MCPServerConfig(
        name="database",
        description="Database operations",
        tools=[
            MCPTool(
                name="query",
                description="Execute a database query",
                parameters={
                    "type": "object",
                    "properties": {
                        "sql": {"type": "string", "description": "SQL query"}
                    }
                },
                required_params=["sql"]
            ),
        ],
        resources=[
            MCPResource(
                uri="db://schema",
                name="Database Schema",
                description="The database schema"
            ),
        ]
    ),
}


def get_common_mcp_server(name: str) -> MCPServerConfig:
    """Get a pre-defined MCP server configuration."""
    if name not in COMMON_MCP_SERVERS:
        raise ValueError(f"Unknown MCP server: {name}. Available: {list(COMMON_MCP_SERVERS.keys())}")
    return COMMON_MCP_SERVERS[name]
