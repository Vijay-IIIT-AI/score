"""
SemcoEvaluator - Main evaluation engine integrating DeepEval with capability validation.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Union, Callable
from pathlib import Path
import json
from datetime import datetime

from ..capabilities.registry import CapabilityRegistry, Capability
from ..capabilities.validator import CapabilityValidator, ValidationLevel, ValidationResult
from ..providers.registry import ProviderRegistry
from ..datasets.golden import GoldenDataset
from .test_case import SemcoTestCase


@dataclass
class EvaluationConfig:
    """Configuration for an evaluation run."""
    # Model settings
    provider: str
    model_id: str

    # Evaluation settings
    metrics: List[str]
    validation_level: ValidationLevel = ValidationLevel.WARN

    # Execution settings
    max_concurrent: int = 5
    timeout_seconds: int = 120
    retry_count: int = 2

    # Output settings
    output_dir: Optional[str] = None
    save_results: bool = True
    verbose: bool = False


@dataclass
class MetricScore:
    """Score for a single metric."""
    metric_name: str
    score: float
    threshold: float
    passed: bool
    reason: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TestCaseResult:
    """Result for a single test case."""
    test_case_id: str
    input: str
    actual_output: str
    expected_output: Optional[str]
    scores: List[MetricScore]
    passed: bool
    error: Optional[str] = None
    latency_ms: float = 0
    tools_called: Optional[List[Any]] = None  # Tools called during agent evaluation


@dataclass
class EvaluationResult:
    """Result of a complete evaluation run."""
    # Identification
    evaluation_id: str
    timestamp: str
    provider: str
    model_id: str

    # Summary
    total_tests: int
    passed_tests: int
    failed_tests: int
    error_tests: int

    # Scores
    metric_scores: Dict[str, float]  # metric_name -> average score
    overall_score: float

    # Capability validation
    capability_warnings: List[str]

    # Details
    test_results: List[TestCaseResult]
    config: EvaluationConfig

    @property
    def pass_rate(self) -> float:
        return self.passed_tests / self.total_tests if self.total_tests > 0 else 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "evaluation_id": self.evaluation_id,
            "timestamp": self.timestamp,
            "provider": self.provider,
            "model_id": self.model_id,
            "summary": {
                "total_tests": self.total_tests,
                "passed_tests": self.passed_tests,
                "failed_tests": self.failed_tests,
                "error_tests": self.error_tests,
                "pass_rate": self.pass_rate,
                "overall_score": self.overall_score,
            },
            "metric_scores": self.metric_scores,
            "capability_warnings": self.capability_warnings,
            "test_results": [
                {
                    "id": tr.test_case_id,
                    "input": tr.input[:200] + "..." if len(tr.input) > 200 else tr.input,
                    "output": tr.actual_output[:200] + "..." if len(tr.actual_output) > 200 else tr.actual_output,
                    "passed": tr.passed,
                    "scores": [
                        {"metric": s.metric_name, "score": s.score, "passed": s.passed}
                        for s in tr.scores
                    ],
                    "error": tr.error,
                }
                for tr in self.test_results
            ],
        }

    def save(self, path: Union[str, Path]):
        """Save results to a JSON file."""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)


class SemcoEvaluator:
    """
    Main evaluation engine for SemcoEval.

    Integrates DeepEval with:
    - Capability validation (ensures model supports required features)
    - Provider abstraction (unified interface across providers)
    - Offline dataset support (local JSON/JSONL/CSV files)

    Usage:
        evaluator = SemcoEvaluator()

        # Connect to a provider
        evaluator.connect_provider("openai", api_key="sk-...")

        # Load a dataset
        dataset = evaluator.load_dataset("path/to/dataset.json")

        # Run evaluation
        result = evaluator.evaluate(
            config=EvaluationConfig(
                provider="openai",
                model_id="gpt-4o",
                metrics=["AnswerRelevancyMetric", "FaithfulnessMetric"]
            ),
            dataset=dataset
        )

        # View results
        print(f"Pass rate: {result.pass_rate:.2%}")
        print(f"Overall score: {result.overall_score:.2f}")
    """

    def __init__(self):
        self.provider_registry = ProviderRegistry()
        self.capability_registry = CapabilityRegistry()
        self.capability_validator = CapabilityValidator(self.capability_registry)
        self._metrics_cache: Dict[str, Any] = {}

    def connect_provider(
        self,
        provider_name: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None
    ) -> bool:
        """
        Connect to a provider.

        Args:
            provider_name: Name of the provider (openai, anthropic, etc.)
            api_key: API key
            base_url: Optional custom base URL

        Returns:
            True if connection successful
        """
        connection = self.provider_registry.connect(provider_name, api_key, base_url)
        return connection.is_connected

    def list_connected_providers(self) -> List[str]:
        """List all connected providers."""
        return self.provider_registry.list_connected_providers()

    def list_models(self, provider: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List available models.

        Args:
            provider: Specific provider to list, or all if None

        Returns:
            List of model info dictionaries
        """
        models = self.provider_registry.list_all_models()
        if provider:
            models = [m for m in models if m.provider == provider]

        return [
            {
                "id": m.id,
                "name": m.name,
                "provider": m.provider,
                "context_window": m.context_window,
                "supports_vision": m.supports_vision,
                "supports_function_calling": m.supports_function_calling,
            }
            for m in models
        ]

    def load_dataset(
        self,
        path: Union[str, Path],
        subgroup: Optional[str] = None,
        limit: Optional[int] = None
    ) -> GoldenDataset:
        """
        Load a dataset from a local file.

        Args:
            path: Path to dataset file (JSON, JSONL, or CSV)
            subgroup: Filter to specific subgroup
            limit: Maximum number of samples

        Returns:
            GoldenDataset ready for evaluation
        """
        return GoldenDataset.from_file(path, subgroup=subgroup, limit=limit)

    def validate_model(
        self,
        provider: str,
        model_id: str,
        metrics: List[str]
    ) -> List[ValidationResult]:
        """
        Validate that a model supports the required capabilities for metrics.

        Args:
            provider: Provider name
            model_id: Model ID
            metrics: List of metric names

        Returns:
            List of ValidationResult for each metric
        """
        return self.capability_validator.validate_batch(provider, model_id, metrics)

    def get_compatible_models(self, metric: str) -> List[Dict[str, str]]:
        """Get all models compatible with a metric."""
        models = self.capability_validator.find_compatible_models(metric)
        return [{"provider": p, "model_id": m} for p, m in models]

    def get_compatible_metrics(self, provider: str, model_id: str) -> List[str]:
        """Get all metrics compatible with a model."""
        return self.capability_validator.find_compatible_metrics(provider, model_id)

    def evaluate(
        self,
        config: EvaluationConfig,
        dataset: GoldenDataset,
        model_callback: Optional[Callable[[str], str]] = None
    ) -> EvaluationResult:
        """
        Run an evaluation.

        Args:
            config: Evaluation configuration
            dataset: Dataset to evaluate on
            model_callback: Optional custom function to call model
                          If not provided, uses DeepEval's model wrapper

        Returns:
            EvaluationResult with all scores and details
        """
        import uuid

        evaluation_id = str(uuid.uuid4())[:8]
        timestamp = datetime.now().isoformat()

        # Validate capabilities
        capability_warnings = []
        validations = self.validate_model(config.provider, config.model_id, config.metrics)
        for v in validations:
            if not v.is_valid:
                if config.validation_level == ValidationLevel.STRICT:
                    raise ValueError(f"Model incompatible with {v.metric_name}: {v.errors}")
                else:
                    capability_warnings.extend(v.errors)
            capability_warnings.extend(v.warnings)

        # Get DeepEval model and metrics
        deepeval_model = self._get_deepeval_model(config.provider, config.model_id)
        deepeval_metrics = self._get_deepeval_metrics(config.metrics, deepeval_model)

        # Convert dataset to DeepEval format
        test_cases = dataset.to_deepeval_test_cases()

        # Run DeepEval evaluation
        try:
            from deepeval import evaluate as deepeval_evaluate
            from deepeval.test_case import LLMTestCase

            # If custom callback, fill in actual outputs first
            if model_callback:
                for tc in test_cases:
                    tc.actual_output = model_callback(tc.input)

            # Run evaluation
            results = deepeval_evaluate(
                test_cases=test_cases,
                metrics=deepeval_metrics,
                run_async=config.max_concurrent > 1,
                verbose_mode=config.verbose
            )

            # Process results
            test_results = self._process_deepeval_results(results, test_cases)

        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
        except Exception as e:
            # Return error result
            return EvaluationResult(
                evaluation_id=evaluation_id,
                timestamp=timestamp,
                provider=config.provider,
                model_id=config.model_id,
                total_tests=len(dataset),
                passed_tests=0,
                failed_tests=0,
                error_tests=len(dataset),
                metric_scores={},
                overall_score=0,
                capability_warnings=capability_warnings + [str(e)],
                test_results=[],
                config=config
            )

        # Calculate summary statistics
        passed = sum(1 for tr in test_results if tr.passed)
        failed = sum(1 for tr in test_results if not tr.passed and not tr.error)
        errors = sum(1 for tr in test_results if tr.error)

        # Calculate metric averages
        metric_scores = {}
        for metric_name in config.metrics:
            scores = [
                s.score for tr in test_results
                for s in tr.scores if s.metric_name == metric_name
            ]
            if scores:
                metric_scores[metric_name] = sum(scores) / len(scores)

        overall = sum(metric_scores.values()) / len(metric_scores) if metric_scores else 0

        result = EvaluationResult(
            evaluation_id=evaluation_id,
            timestamp=timestamp,
            provider=config.provider,
            model_id=config.model_id,
            total_tests=len(dataset),
            passed_tests=passed,
            failed_tests=failed,
            error_tests=errors,
            metric_scores=metric_scores,
            overall_score=overall,
            capability_warnings=capability_warnings,
            test_results=test_results,
            config=config
        )

        # Save results if configured
        if config.save_results and config.output_dir:
            output_path = Path(config.output_dir) / f"eval_{evaluation_id}.json"
            output_path.parent.mkdir(parents=True, exist_ok=True)
            result.save(output_path)

        return result

    def _get_deepeval_model(self, provider: str, model_id: str):
        """Get a DeepEval model instance."""
        return self.provider_registry.get_deepeval_model(provider, model_id)

    def _get_deepeval_metrics(self, metric_names: List[str], model) -> List:
        """Get DeepEval metric instances."""
        from deepeval import metrics as deepeval_metrics

        result = []
        # Create cache key that includes model identity to prevent cross-model contamination
        model_id = id(model)

        for name in metric_names:
            # Cache key includes both metric name AND model to prevent contamination
            cache_key = f"{name}:{model_id}"

            # Check cache with model-specific key
            if cache_key in self._metrics_cache:
                result.append(self._metrics_cache[cache_key])
                continue

            # Get metric class
            metric_class = getattr(deepeval_metrics, name, None)
            if metric_class is None:
                raise ValueError(f"Unknown metric: {name}")

            # Handle special cases for metrics requiring specific parameters
            try:
                if name == "GEval":
                    # GEval requires name and criteria parameters
                    metric = metric_class(
                        name="GEval",
                        criteria="Determine if the actual output correctly answers the input based on the expected output.",
                        model=model
                    )
                else:
                    metric = metric_class(model=model)
            except TypeError:
                # Fallback for metrics that don't accept model parameter
                try:
                    metric = metric_class()
                except TypeError:
                    raise ValueError(f"Cannot instantiate metric {name}: requires additional parameters")

            self._metrics_cache[cache_key] = metric
            result.append(metric)

        return result

    def _process_deepeval_results(self, results, test_cases) -> List[TestCaseResult]:
        """Process DeepEval results into our format."""
        test_results = []

        for i, tc in enumerate(test_cases):
            scores = []
            passed = True

            # Extract scores from results
            # Note: DeepEval result structure varies by version
            if hasattr(results, 'test_results'):
                tc_results = results.test_results[i] if i < len(results.test_results) else None
                if tc_results:
                    for metric_result in tc_results.metrics_data:
                        score = MetricScore(
                            metric_name=metric_result.name,
                            score=metric_result.score or 0,
                            threshold=metric_result.threshold or 0.5,
                            passed=metric_result.success,
                            reason=metric_result.reason
                        )
                        scores.append(score)
                        if not metric_result.success:
                            passed = False

            # Extract tools_called from test case if available
            tools_called = None
            if hasattr(tc, 'tools_called'):
                tools_called = tc.tools_called
            elif tc.additional_metadata and 'tools_called' in tc.additional_metadata:
                tools_called = tc.additional_metadata.get('tools_called')

            test_results.append(TestCaseResult(
                test_case_id=tc.additional_metadata.get("sample_id", f"test-{i}") if tc.additional_metadata else f"test-{i}",
                input=tc.input,
                actual_output=tc.actual_output or "",
                expected_output=tc.expected_output,
                scores=scores,
                passed=passed,
                tools_called=tools_called
            ))

        return test_results

    def compare_models(
        self,
        providers_models: List[Dict[str, str]],
        metrics: List[str],
        dataset: GoldenDataset,
        **kwargs
    ) -> Dict[str, EvaluationResult]:
        """
        Compare multiple models on the same dataset.

        Args:
            providers_models: List of {"provider": ..., "model_id": ...}
            metrics: Metrics to evaluate
            dataset: Dataset to evaluate on
            **kwargs: Additional config options

        Returns:
            Dict mapping "provider:model_id" to EvaluationResult
        """
        results = {}

        for pm in providers_models:
            provider = pm["provider"]
            model_id = pm["model_id"]
            key = f"{provider}:{model_id}"

            config = EvaluationConfig(
                provider=provider,
                model_id=model_id,
                metrics=metrics,
                **kwargs
            )

            results[key] = self.evaluate(config, dataset)

        return results

    def generate_leaderboard(
        self,
        results: Dict[str, EvaluationResult],
        sort_by: str = "overall_score"
    ) -> List[Dict[str, Any]]:
        """
        Generate a leaderboard from multiple evaluation results.

        Args:
            results: Dict of model key to EvaluationResult
            sort_by: Metric to sort by (default: overall_score)

        Returns:
            Sorted list of leaderboard entries
        """
        leaderboard = []

        for model_key, result in results.items():
            entry = {
                "rank": 0,  # Will be filled after sorting
                "model": model_key,
                "provider": result.provider,
                "model_id": result.model_id,
                "overall_score": result.overall_score,
                "pass_rate": result.pass_rate,
                "metric_scores": result.metric_scores,
            }
            leaderboard.append(entry)

        # Sort
        if sort_by == "overall_score":
            leaderboard.sort(key=lambda x: x["overall_score"], reverse=True)
        elif sort_by == "pass_rate":
            leaderboard.sort(key=lambda x: x["pass_rate"], reverse=True)
        elif sort_by in leaderboard[0]["metric_scores"]:
            leaderboard.sort(key=lambda x: x["metric_scores"].get(sort_by, 0), reverse=True)

        # Add ranks
        for i, entry in enumerate(leaderboard):
            entry["rank"] = i + 1

        return leaderboard
