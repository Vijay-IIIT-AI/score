"""
Red Team Module - Wraps DeepEval's RedTeamer for adversarial testing.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable, Union
from enum import Enum


class Vulnerability(Enum):
    """
    Vulnerability types for red teaming (maps to DeepEval's Vulnerability).

    These are RISK CATEGORIES that the model might be vulnerable to.
    """
    # Harmful content
    BIAS = "bias"
    TOXICITY = "toxicity"
    HATE = "hate"
    VIOLENCE = "violence"
    SELF_HARM = "self_harm"
    SEXUAL_CONTENT = "sexual_content"

    # Data leakage
    PII_LEAKAGE = "pii_leakage"
    DATA_LEAKAGE = "data_leakage"
    PROMPT_LEAKAGE = "prompt_leakage"

    # Misinformation
    HALLUCINATION = "hallucination"
    MISINFORMATION = "misinformation"
    UNGROUNDED_CLAIMS = "ungrounded_claims"

    # Safety bypass
    JAILBREAK = "jailbreak"
    HARMFUL_INSTRUCTIONS = "harmful_instructions"
    ILLEGAL_ACTIVITIES = "illegal_activities"

    # Technical
    SQL_INJECTION = "sql_injection"
    SHELL_INJECTION = "shell_injection"
    CODE_INJECTION = "code_injection"

    # Business
    COMPETITOR_MENTION = "competitor_mention"
    OFF_BRAND = "off_brand"
    INTELLECTUAL_PROPERTY = "intellectual_property"


class AttackType(Enum):
    """
    Attack types for red teaming (maps to DeepEval's Attack).

    These are DELIVERY MECHANISMS for testing vulnerabilities.
    """
    # Prompt manipulation
    PROMPT_INJECTION = "prompt_injection"
    JAILBREAK_LINEAR = "jailbreak_linear"
    JAILBREAK_TREE = "jailbreak_tree"
    GRAY_BOX = "gray_box"

    # Multi-turn
    CRESCENDO = "crescendo"
    MULTI_TURN = "multi_turn"

    # Encoding tricks
    ROT13 = "rot13"
    BASE64 = "base64"
    LEETSPEAK = "leetspeak"


@dataclass
class RedTeamConfig:
    """Configuration for red teaming."""
    vulnerabilities: List[Vulnerability] = field(default_factory=lambda: [
        Vulnerability.BIAS,
        Vulnerability.TOXICITY,
        Vulnerability.PII_LEAKAGE,
        Vulnerability.HALLUCINATION,
    ])
    attacks: Optional[List[AttackType]] = None  # None = use all attacks
    num_attacks_per_vulnerability: int = 5
    model: Optional[Any] = None
    async_mode: bool = True


@dataclass
class RedTeamResult:
    """Result from red team evaluation."""
    vulnerability: str
    attack_type: str
    prompt: str
    response: str
    score: float  # 0-1, vulnerability score
    passed: bool  # True if model defended successfully
    reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class RedTeamerWrapper:
    """
    Wrapper for DeepEval's RedTeamer.

    Provides adversarial testing with proper separation of:
    - Vulnerabilities: Risk categories to test (Bias, Toxicity, PII, etc.)
    - Attacks: Delivery mechanisms (Prompt Injection, Jailbreaks, etc.)

    Evaluation uses DeepEval's safety metrics, not simple substring matching.

    Usage:
        from semcoeval.redteam import RedTeamerWrapper, Vulnerability, AttackType

        red_teamer = RedTeamerWrapper(config=RedTeamConfig(
            vulnerabilities=[Vulnerability.BIAS, Vulnerability.TOXICITY],
            attacks=[AttackType.JAILBREAK_LINEAR],
            num_attacks_per_vulnerability=10
        ))

        # Define model callback
        def model_callback(prompt: str) -> str:
            return your_model.generate(prompt)

        # Run red team evaluation
        results = red_teamer.red_team(model_callback=model_callback)

        # Check vulnerability scores
        for result in results:
            print(f"{result.vulnerability}: {result.score:.2f}")
    """

    def __init__(self, config: Optional[RedTeamConfig] = None):
        self.config = config or RedTeamConfig()
        self._red_teamer = None

    def _get_red_teamer(self):
        """Lazily initialize DeepEval RedTeamer."""
        if self._red_teamer is None:
            try:
                from deepeval.red_teaming import RedTeamer

                kwargs = {'async_mode': self.config.async_mode}
                if self.config.model is not None:
                    kwargs['synthesizer_model'] = self.config.model
                    kwargs['evaluation_model'] = self.config.model

                self._red_teamer = RedTeamer(**kwargs)
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._red_teamer

    def _convert_vulnerabilities(self) -> List:
        """Convert our Vulnerability enums to DeepEval's."""
        try:
            from deepeval.red_teaming import Vulnerability as DEVulnerability

            vuln_map = {
                Vulnerability.BIAS: DEVulnerability.BIAS,
                Vulnerability.TOXICITY: DEVulnerability.TOXICITY,
                Vulnerability.HATE: DEVulnerability.HATE,
                Vulnerability.VIOLENCE: DEVulnerability.VIOLENCE,
                Vulnerability.SELF_HARM: DEVulnerability.SELF_HARM,
                Vulnerability.SEXUAL_CONTENT: DEVulnerability.SEXUAL_CONTENT,
                Vulnerability.PII_LEAKAGE: DEVulnerability.PII_LEAKAGE,
                Vulnerability.DATA_LEAKAGE: DEVulnerability.DATA_LEAKAGE,
                Vulnerability.PROMPT_LEAKAGE: DEVulnerability.PROMPT_LEAKAGE,
                Vulnerability.HALLUCINATION: DEVulnerability.HALLUCINATION,
                Vulnerability.MISINFORMATION: DEVulnerability.MISINFORMATION,
                Vulnerability.JAILBREAK: DEVulnerability.JAILBREAK,
                Vulnerability.SQL_INJECTION: DEVulnerability.SQL_INJECTION,
                Vulnerability.SHELL_INJECTION: DEVulnerability.SHELL_INJECTION,
                Vulnerability.CODE_INJECTION: DEVulnerability.CODE_INJECTION,
            }

            result = []
            for v in self.config.vulnerabilities:
                if v in vuln_map:
                    result.append(vuln_map[v])
            return result if result else None
        except (ImportError, AttributeError):
            return None

    def _convert_attacks(self) -> Optional[List]:
        """Convert our AttackType enums to DeepEval's."""
        if self.config.attacks is None:
            return None

        try:
            from deepeval.red_teaming import AttackEnhancement

            attack_map = {
                AttackType.PROMPT_INJECTION: AttackEnhancement.PROMPT_INJECTION,
                AttackType.JAILBREAK_LINEAR: AttackEnhancement.JAILBREAK_LINEAR,
                AttackType.JAILBREAK_TREE: AttackEnhancement.JAILBREAK_TREE,
                AttackType.GRAY_BOX: AttackEnhancement.GRAY_BOX,
                AttackType.CRESCENDO: AttackEnhancement.CRESCENDO,
                AttackType.MULTI_TURN: AttackEnhancement.MULTI_TURN,
                AttackType.ROT13: AttackEnhancement.ROT13,
                AttackType.BASE64: AttackEnhancement.BASE64,
                AttackType.LEETSPEAK: AttackEnhancement.LEETSPEAK,
            }

            result = []
            for a in self.config.attacks:
                if a in attack_map:
                    result.append(attack_map[a])
            return result if result else None
        except (ImportError, AttributeError):
            return None

    def red_team(
        self,
        model_callback: Callable[[str], str],
        purpose: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> List[RedTeamResult]:
        """
        Run red team evaluation against a model.

        Args:
            model_callback: Function that takes prompt and returns model response
            purpose: Description of what the model is supposed to do
            system_prompt: The system prompt used by the model

        Returns:
            List of RedTeamResult with vulnerability scores
        """
        red_teamer = self._get_red_teamer()

        # Convert enums
        vulnerabilities = self._convert_vulnerabilities()
        attacks = self._convert_attacks()

        # Build kwargs
        kwargs = {
            'model_callback': model_callback,
            'attacks_per_vulnerability': self.config.num_attacks_per_vulnerability,
        }

        if vulnerabilities:
            kwargs['vulnerabilities'] = vulnerabilities
        if attacks:
            kwargs['attack_enhancements'] = attacks
        if purpose:
            kwargs['purpose'] = purpose
        if system_prompt:
            kwargs['system_prompt'] = system_prompt

        # Run red teaming
        results = red_teamer.scan(**kwargs)

        # Convert to our result format
        return self._convert_results(results)

    def _convert_results(self, deepeval_results) -> List[RedTeamResult]:
        """Convert DeepEval results to our format."""
        converted = []

        # DeepEval returns different result structures
        if hasattr(deepeval_results, 'vulnerability_scores'):
            for vuln, score in deepeval_results.vulnerability_scores.items():
                converted.append(RedTeamResult(
                    vulnerability=str(vuln),
                    attack_type="combined",
                    prompt="",
                    response="",
                    score=score,
                    passed=score < 0.5,
                    reason=f"Vulnerability score: {score:.2f}"
                ))

        if hasattr(deepeval_results, 'results'):
            for r in deepeval_results.results:
                converted.append(RedTeamResult(
                    vulnerability=str(getattr(r, 'vulnerability', 'unknown')),
                    attack_type=str(getattr(r, 'attack_enhancement', 'unknown')),
                    prompt=getattr(r, 'input', ''),
                    response=getattr(r, 'actual_output', ''),
                    score=getattr(r, 'score', 0.0),
                    passed=getattr(r, 'success', True),
                    reason=getattr(r, 'reason', None)
                ))

        return converted

    def generate_attacks(
        self,
        purpose: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Generate attack prompts without running evaluation.

        Args:
            purpose: Description of what the model is supposed to do
            system_prompt: The system prompt used by the model

        Returns:
            List of attack dictionaries with prompt and metadata
        """
        red_teamer = self._get_red_teamer()

        vulnerabilities = self._convert_vulnerabilities()
        attacks = self._convert_attacks()

        kwargs = {
            'attacks_per_vulnerability': self.config.num_attacks_per_vulnerability,
        }

        if vulnerabilities:
            kwargs['vulnerabilities'] = vulnerabilities
        if attacks:
            kwargs['attack_enhancements'] = attacks
        if purpose:
            kwargs['purpose'] = purpose
        if system_prompt:
            kwargs['system_prompt'] = system_prompt

        # Generate attacks
        attack_list = red_teamer.generate_attacks(**kwargs)

        return [
            {
                'prompt': a.input if hasattr(a, 'input') else str(a),
                'vulnerability': str(getattr(a, 'vulnerability', 'unknown')),
                'attack_type': str(getattr(a, 'attack_enhancement', 'unknown')),
            }
            for a in attack_list
        ]


# =============================================================================
# Safety Metrics Wrappers
# =============================================================================

class ToxicityMetricWrapper:
    """Wrapper for DeepEval's ToxicityMetric."""

    def __init__(
        self,
        threshold: float = 0.5,
        model: Optional[Any] = None,
        include_reason: bool = True,
        async_mode: bool = True,
    ):
        self.threshold = threshold
        self.model = model
        self.include_reason = include_reason
        self.async_mode = async_mode
        self._metric = None

    def _get_metric(self):
        if self._metric is None:
            try:
                from deepeval.metrics import ToxicityMetric

                kwargs = {
                    'threshold': self.threshold,
                    'include_reason': self.include_reason,
                    'async_mode': self.async_mode,
                }
                if self.model:
                    kwargs['model'] = self.model

                self._metric = ToxicityMetric(**kwargs)
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._metric

    def measure(self, test_case) -> Dict[str, Any]:
        """Measure toxicity of a response."""
        metric = self._get_metric()
        metric.measure(test_case)
        return {
            'score': metric.score,
            'passed': metric.success,
            'reason': metric.reason if self.include_reason else None,
        }


class BiasMetricWrapper:
    """Wrapper for DeepEval's BiasMetric."""

    def __init__(
        self,
        threshold: float = 0.5,
        model: Optional[Any] = None,
        include_reason: bool = True,
        async_mode: bool = True,
    ):
        self.threshold = threshold
        self.model = model
        self.include_reason = include_reason
        self.async_mode = async_mode
        self._metric = None

    def _get_metric(self):
        if self._metric is None:
            try:
                from deepeval.metrics import BiasMetric

                kwargs = {
                    'threshold': self.threshold,
                    'include_reason': self.include_reason,
                    'async_mode': self.async_mode,
                }
                if self.model:
                    kwargs['model'] = self.model

                self._metric = BiasMetric(**kwargs)
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._metric

    def measure(self, test_case) -> Dict[str, Any]:
        """Measure bias in a response."""
        metric = self._get_metric()
        metric.measure(test_case)
        return {
            'score': metric.score,
            'passed': metric.success,
            'reason': metric.reason if self.include_reason else None,
        }


class HallucinationMetricWrapper:
    """Wrapper for DeepEval's HallucinationMetric."""

    def __init__(
        self,
        threshold: float = 0.5,
        model: Optional[Any] = None,
        include_reason: bool = True,
        async_mode: bool = True,
    ):
        self.threshold = threshold
        self.model = model
        self.include_reason = include_reason
        self.async_mode = async_mode
        self._metric = None

    def _get_metric(self):
        if self._metric is None:
            try:
                from deepeval.metrics import HallucinationMetric

                kwargs = {
                    'threshold': self.threshold,
                    'include_reason': self.include_reason,
                    'async_mode': self.async_mode,
                }
                if self.model:
                    kwargs['model'] = self.model

                self._metric = HallucinationMetric(**kwargs)
            except ImportError:
                raise ImportError("DeepEval not installed. Run: pip install deepeval")
        return self._metric

    def measure(self, test_case) -> Dict[str, Any]:
        """Measure hallucination in a response."""
        metric = self._get_metric()
        metric.measure(test_case)
        return {
            'score': metric.score,
            'passed': metric.success,
            'reason': metric.reason if self.include_reason else None,
        }


def get_safety_metrics(
    threshold: float = 0.5,
    model: Optional[Any] = None,
    include_reason: bool = True,
) -> Dict[str, Any]:
    """Get all safety metrics with shared configuration."""
    return {
        'toxicity': ToxicityMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
        ),
        'bias': BiasMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
        ),
        'hallucination': HallucinationMetricWrapper(
            threshold=threshold,
            model=model,
            include_reason=include_reason,
        ),
    }
