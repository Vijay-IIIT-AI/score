"""
Red Teaming Module - Wraps DeepEval's RedTeamer for adversarial testing.

Provides:
- RedTeamerWrapper: Wraps DeepEval's red teaming with proper vulnerability/attack separation
- Safety metrics: ToxicityMetric, BiasMetric, HallucinationMetric wrappers
"""

from .attacks import (
    # DeepEval wrappers (recommended)
    RedTeamerWrapper,
    RedTeamConfig,
    RedTeamResult,
    Vulnerability,
    AttackType,
    # Safety metric wrappers
    ToxicityMetricWrapper,
    BiasMetricWrapper,
    HallucinationMetricWrapper,
    get_safety_metrics,
)

from .scanner import (
    VulnerabilityScanner,
    VulnerabilityReport,
    VulnerabilityFinding,
    SeverityLevel,
)

from .evaluator import (
    RedTeamEvaluator,
    RedTeamEvaluatorConfig,
    RedTeamEvaluatorResult,
    get_vulnerability_test_prompts,
)

__all__ = [
    # DeepEval wrappers (recommended)
    "RedTeamerWrapper",
    "RedTeamConfig",
    "RedTeamResult",
    "Vulnerability",
    "AttackType",
    # Safety metric wrappers
    "ToxicityMetricWrapper",
    "BiasMetricWrapper",
    "HallucinationMetricWrapper",
    "get_safety_metrics",
    # Scanner
    "VulnerabilityScanner",
    "VulnerabilityReport",
    "VulnerabilityFinding",
    "SeverityLevel",
    # Evaluator
    "RedTeamEvaluator",
    "RedTeamEvaluatorConfig",
    "RedTeamEvaluatorResult",
    "get_vulnerability_test_prompts",
]
