"""
Configuration utilities for SemcoEval.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional


DEFAULT_CONFIG = {
    "providers": {
        "openai": {
            "api_key_env": "OPENAI_API_KEY",
            "base_url": None,
        },
        "anthropic": {
            "api_key_env": "ANTHROPIC_API_KEY",
            "base_url": None,
        },
        "google": {
            "api_key_env": "GOOGLE_API_KEY",
            "base_url": None,
        },
        "deepseek": {
            "api_key_env": "DEEPSEEK_API_KEY",
            "base_url": "https://api.deepseek.com",
        },
        "ollama": {
            "api_key_env": None,
            "base_url": "http://localhost:11434",
        },
        "openrouter": {
            "api_key_env": "OPENROUTER_API_KEY",
            "base_url": "https://openrouter.ai/api/v1",
        },
    },
    "evaluation": {
        "default_metrics": ["AnswerRelevancyMetric"],
        "max_concurrent": 5,
        "timeout_seconds": 120,
        "retry_count": 2,
    },
    "datasets": {
        "base_path": "./datasets",
        "cache_dir": "./.semcoeval_cache",
    },
    "output": {
        "results_dir": "./results",
        "reports_dir": "./reports",
    },
}


def get_config_path() -> Path:
    """Get the default config file path."""
    # Check for environment variable
    if "SEMCOEVAL_CONFIG" in os.environ:
        return Path(os.environ["SEMCOEVAL_CONFIG"])

    # Check for local config
    local_config = Path.cwd() / "semcoeval.json"
    if local_config.exists():
        return local_config

    # Check for user config
    user_config = Path.home() / ".semcoeval" / "config.json"
    if user_config.exists():
        return user_config

    return local_config  # Default to local


def load_config(path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load configuration from file.

    Args:
        path: Path to config file. If None, uses default locations.

    Returns:
        Configuration dictionary
    """
    config_path = Path(path) if path else get_config_path()

    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            user_config = json.load(f)

        # Merge with defaults
        return _deep_merge(DEFAULT_CONFIG.copy(), user_config)

    return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any], path: Optional[str] = None):
    """
    Save configuration to file.

    Args:
        config: Configuration dictionary
        path: Path to save to. If None, uses default location.
    """
    config_path = Path(path) if path else get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def get_api_key(provider: str, config: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """
    Get API key for a provider from environment.

    Args:
        provider: Provider name
        config: Optional config dict

    Returns:
        API key or None
    """
    if config is None:
        config = load_config()

    provider_config = config.get("providers", {}).get(provider, {})
    env_var = provider_config.get("api_key_env")

    if env_var:
        return os.environ.get(env_var)

    return None


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """Deep merge two dictionaries."""
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value

    return result
