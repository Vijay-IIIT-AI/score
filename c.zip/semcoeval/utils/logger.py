"""
Logging utilities for SemcoEval.
"""

import logging
import sys
from typing import Optional


def get_logger(name: str = "semcoeval") -> logging.Logger:
    """Get a logger instance."""
    return logging.getLogger(name)


def setup_logging(
    level: int = logging.INFO,
    format_string: Optional[str] = None,
    log_file: Optional[str] = None
):
    """
    Set up logging for SemcoEval.

    Args:
        level: Logging level (default: INFO)
        format_string: Custom format string
        log_file: Optional file to log to
    """
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Create formatter
    formatter = logging.Formatter(format_string)

    # Get root logger
    logger = logging.getLogger("semcoeval")
    logger.setLevel(level)

    # Remove existing handlers
    logger.handlers.clear()

    # Add console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # Add file handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger
