"""
LangGraph Agent Wrapper - Integration with LangGraph for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class LangGraphAgentWrapper(BaseAgentWrapper):
    """
    LangGraph agent wrapper for DeepEval evaluation.

    LangGraph provides stateful, multi-actor applications with cycles.

    Usage:
        config = AgentConfig(model="gpt-4o")
        wrapper = LangGraphAgentWrapper(config)
        wrapper.initialize()
        trace = wrapper.run("Research and summarize AI trends")
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self._graph = None
        self._compiled_graph = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.LANGGRAPH

    @property
    def name(self) -> str:
        return "LangGraph"

    def initialize(self) -> bool:
        """Initialize LangGraph agent."""
        try:
            from langgraph.prebuilt import create_react_agent
            from langchain_openai import ChatOpenAI

            # Create LLM
            llm = ChatOpenAI(
                model=self.config.model,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )

            # Convert tools
            tools = self._convert_tools()

            # Create ReAct agent graph
            self._compiled_graph = create_react_agent(
                llm,
                tools=tools
            )

            return True
        except ImportError as e:
            raise ImportError(f"LangGraph not installed: {e}. Run: pip install langgraph langchain-openai")
        except Exception:
            return False

    def _convert_tools(self) -> List[Any]:
        """Convert AgentTools to LangChain tools."""
        langchain_tools = []

        try:
            from langchain_core.tools import StructuredTool

            for tool in self.config.tools:
                if tool.func:
                    lc_tool = StructuredTool.from_function(
                        func=tool.func,
                        name=tool.name,
                        description=tool.description
                    )
                    langchain_tools.append(lc_tool)
        except ImportError:
            pass

        return langchain_tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the LangGraph agent."""
        if not self._compiled_graph:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize agent"
                )

        start_time = time.time()
        actions = []
        intermediate_steps = []

        try:
            # Run the graph
            result = self._compiled_graph.invoke(
                {"messages": [("human", input_text)]},
                **kwargs
            )

            # Extract output from messages
            messages = result.get("messages", [])
            output = ""
            if messages:
                last_message = messages[-1]
                output = last_message.content if hasattr(last_message, 'content') else str(last_message)

            # Extract tool calls from messages
            for msg in messages:
                if hasattr(msg, 'tool_calls') and msg.tool_calls:
                    for tool_call in msg.tool_calls:
                        actions.append(AgentAction(
                            tool_name=tool_call.get("name", "unknown"),
                            tool_input=tool_call.get("args", {}),
                        ))

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                intermediate_steps=intermediate_steps,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_graph(graph: Any, config: Optional[AgentConfig] = None) -> "LangGraphAgentWrapper":
        """Create wrapper from existing LangGraph."""
        wrapper = LangGraphAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._compiled_graph = graph
        return wrapper
