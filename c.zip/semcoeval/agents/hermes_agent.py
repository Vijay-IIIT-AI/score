"""
Hermes Agent Wrapper - Integration with Nous Research Hermes models.

Hermes uses XML-based tool calling format:
<tool_call>
{"name": "tool_name", "arguments": {"arg": "value"}}
</tool_call>

Supports Hermes 3 (Llama 3.1 based) and future versions.
"""

import re
import json
import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class HermesAgentWrapper(BaseAgentWrapper):
    """
    Hermes agent wrapper for tool-calling evaluation.

    Hermes models use XML-tagged JSON for tool calls:
    <tool_call>{"name": "func", "arguments": {...}}</tool_call>

    Usage:
        config = AgentConfig(
            model="NousResearch/Hermes-3-Llama-3.1-8B",
            tools=[...],
            system_prompt="You are a helpful assistant."
        )
        wrapper = HermesAgentWrapper(config)
        wrapper.initialize()
        trace = wrapper.run("What's the weather in Tokyo?")
    """

    # Hermes tool call format
    TOOL_CALL_PATTERN = re.compile(
        r'<tool_call>\s*(\{.*?\})\s*</tool_call>',
        re.DOTALL
    )

    # Hermes system prompt template for tool use
    TOOL_SYSTEM_PROMPT = """You are a function calling AI model. You are provided with function signatures within <tools></tools> XML tags. You may call one or more functions to assist with the user query. Don't make assumptions about what values to plug into functions. Here are the available tools:

<tools>
{tool_definitions}
</tools>

For each function call return a json object with function name and arguments within <tool_call></tool_call> XML tags as follows:
<tool_call>
{{"name": "<function-name>", "arguments": <args-dict>}}
</tool_call>"""

    def __init__(
        self,
        config: AgentConfig,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None
    ):
        super().__init__(config)
        self._api_key = api_key
        self._base_url = base_url or "https://openrouter.ai/api/v1"
        self._client = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.CUSTOM

    @property
    def name(self) -> str:
        return "Hermes"

    def initialize(self) -> bool:
        """Initialize HTTP client for Hermes API calls."""
        try:
            import httpx
            self._client = httpx.Client(timeout=60.0)
            return True
        except ImportError:
            raise ImportError("httpx not installed. Run: pip install httpx")

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def _build_tool_definitions(self) -> str:
        """Build XML tool definitions for Hermes prompt."""
        definitions = []
        for tool in self.config.tools:
            tool_def = {
                "name": tool.name,
                "description": tool.description,
                "parameters": {
                    "type": "object",
                    "properties": tool.parameters,
                    "required": tool.required_params
                }
            }
            definitions.append(json.dumps(tool_def, indent=2))
        return "\n".join(definitions)

    def _build_system_prompt(self) -> str:
        """Build system prompt with tool definitions."""
        if not self.config.tools:
            return self.config.system_prompt or "You are a helpful assistant."

        tool_defs = self._build_tool_definitions()
        base_prompt = self.TOOL_SYSTEM_PROMPT.format(tool_definitions=tool_defs)

        if self.config.system_prompt:
            base_prompt = f"{base_prompt}\n\n{self.config.system_prompt}"

        return base_prompt

    def _extract_tool_calls(self, response: str) -> List[Dict[str, Any]]:
        """Extract tool calls from Hermes response."""
        tool_calls = []

        for match in self.TOOL_CALL_PATTERN.finditer(response):
            try:
                call_json = match.group(1)
                call_data = json.loads(call_json)
                tool_calls.append(call_data)
            except json.JSONDecodeError:
                continue

        return tool_calls

    def _execute_tool(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute a tool by name."""
        for tool in self.config.tools:
            if tool.name == tool_name and tool.func:
                try:
                    return tool.func(**args)
                except Exception as e:
                    return {"error": str(e)}
        return {"error": f"Tool '{tool_name}' not found"}

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the Hermes agent."""
        if not self._client:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize client"
                )

        import os
        start_time = time.time()
        actions = []
        messages = []

        try:
            # Build messages
            system_prompt = self._build_system_prompt()
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": input_text}
            ]

            # Agent loop
            iteration = 0
            final_output = ""

            while iteration < self.config.max_iterations:
                iteration += 1

                # Call the model
                response = self._client.post(
                    f"{self._base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self._api_key or os.getenv('OPENROUTER_API_KEY')}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.config.model,
                        "messages": messages,
                        "temperature": self.config.temperature,
                        "max_tokens": self.config.max_tokens
                    }
                )

                if response.status_code != 200:
                    return AgentTrace(
                        input=input_text,
                        output="",
                        success=False,
                        error=f"API error: {response.status_code}"
                    )

                data = response.json()
                content = data["choices"][0]["message"]["content"]

                # Extract tool calls
                tool_calls = self._extract_tool_calls(content)

                if tool_calls:
                    # Process tool calls
                    messages.append({"role": "assistant", "content": content})

                    tool_results = []
                    for call in tool_calls:
                        tool_name = call.get("name", "")
                        tool_args = call.get("arguments", {})

                        # Execute tool
                        result = self._execute_tool(tool_name, tool_args)

                        actions.append(AgentAction(
                            tool_name=tool_name,
                            tool_input=tool_args,
                            tool_output=result
                        ))

                        tool_results.append({
                            "tool": tool_name,
                            "result": result
                        })

                    # Add tool results to conversation
                    results_str = json.dumps(tool_results, indent=2)
                    messages.append({
                        "role": "user",
                        "content": f"Tool results:\n{results_str}\n\nPlease provide your response based on these results."
                    })
                else:
                    # No tool calls - this is the final response
                    # Remove any tool_call tags if present
                    final_output = re.sub(r'<tool_call>.*?</tool_call>', '', content, flags=re.DOTALL).strip()
                    break

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=final_output,
                actions=actions,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )


# Hermes model configurations
HERMES_MODELS = {
    "hermes-3-llama-3.1-8b": {
        "id": "nousresearch/hermes-3-llama-3.1-8b",
        "context_window": 128000,
        "supports_tools": True
    },
    "hermes-3-llama-3.1-70b": {
        "id": "nousresearch/hermes-3-llama-3.1-70b",
        "context_window": 128000,
        "supports_tools": True
    },
    "hermes-3-llama-3.1-405b": {
        "id": "nousresearch/hermes-3-llama-3.1-405b",
        "context_window": 128000,
        "supports_tools": True
    },
}


def create_hermes_agent(
    model: str = "nousresearch/hermes-3-llama-3.1-8b",
    tools: Optional[List[AgentTool]] = None,
    api_key: Optional[str] = None,
    **kwargs
) -> HermesAgentWrapper:
    """
    Create a Hermes agent with the specified configuration.

    Args:
        model: Hermes model ID
        tools: List of tools available to the agent
        api_key: API key for OpenRouter
        **kwargs: Additional config options

    Returns:
        Configured HermesAgentWrapper

    Example:
        agent = create_hermes_agent(
            tools=[
                AgentTool(name="search", description="Search the web", func=search_fn)
            ]
        )
        result = agent.run("Search for AI news")
    """
    config = AgentConfig(
        model=model,
        tools=tools or [],
        **kwargs
    )
    wrapper = HermesAgentWrapper(config, api_key=api_key)
    wrapper.initialize()
    return wrapper
