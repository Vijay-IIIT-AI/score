"""
Base Agent Framework - Abstract interface for agent framework integrations.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable
from enum import Enum


class AgentFramework(Enum):
    """Supported agent frameworks."""
    LANGCHAIN = "langchain"
    LANGGRAPH = "langgraph"
    LLAMAINDEX = "llamaindex"
    CREWAI = "crewai"
    OPENAI_AGENTS = "openai_agents"
    ANTHROPIC = "anthropic"
    GOOGLE_ADK = "google_adk"
    PYDANTIC_AI = "pydantic_ai"
    AGENTCORE = "agentcore"
    STRANDS = "strands"
    HUGGINGFACE = "huggingface"
    CUSTOM = "custom"


@dataclass
class AgentTool:
    """Definition of a tool available to an agent."""
    name: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    required_params: List[str] = field(default_factory=list)
    func: Optional[Callable] = None


@dataclass
class AgentAction:
    """An action taken by an agent."""
    tool_name: str
    tool_input: Dict[str, Any]
    tool_output: Any = None
    timestamp: Optional[str] = None
    reasoning: Optional[str] = None


@dataclass
class AgentTrace:
    """Complete trace of an agent execution."""
    input: str
    output: str
    actions: List[AgentAction] = field(default_factory=list)
    intermediate_steps: List[Dict[str, Any]] = field(default_factory=list)
    total_tokens: int = 0
    total_cost: float = 0.0
    duration_ms: int = 0
    success: bool = True
    error: Optional[str] = None


@dataclass
class AgentConfig:
    """Configuration for an agent."""
    model: str
    temperature: float = 0.0
    max_tokens: int = 4096
    system_prompt: Optional[str] = None
    tools: List[AgentTool] = field(default_factory=list)
    max_iterations: int = 10
    timeout_seconds: int = 120
    verbose: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseAgentWrapper(ABC):
    """
    Abstract base class for agent framework wrappers.

    Provides a unified interface for different agent frameworks
    to enable consistent evaluation with DeepEval.
    """

    def __init__(self, config: AgentConfig):
        self.config = config
        self._agent = None
        self._tools = []

    @property
    @abstractmethod
    def framework(self) -> AgentFramework:
        """Return the agent framework type."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the agent framework name."""
        pass

    @abstractmethod
    def initialize(self) -> bool:
        """
        Initialize the agent with the given config.

        Returns:
            True if initialization successful
        """
        pass

    @abstractmethod
    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        pass

    @abstractmethod
    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """
        Run the agent with the given input.

        Args:
            input_text: The input prompt/task for the agent
            **kwargs: Additional framework-specific arguments

        Returns:
            AgentTrace with complete execution trace
        """
        pass

    def get_deepeval_trace(self, trace: AgentTrace) -> Dict[str, Any]:
        """
        Convert agent trace to DeepEval-compatible format.

        Returns dict compatible with DeepEval's ConversationalTestCase
        or AgenticTestCase.
        """
        return {
            "input": trace.input,
            "actual_output": trace.output,
            "retrieval_context": [],
            "tools_called": [
                {
                    "name": action.tool_name,
                    "input": action.tool_input,
                    "output": action.tool_output
                }
                for action in trace.actions
            ],
            "intermediate_steps": trace.intermediate_steps,
            "metadata": {
                "framework": self.name,
                "total_tokens": trace.total_tokens,
                "total_cost": trace.total_cost,
                "duration_ms": trace.duration_ms,
                "success": trace.success,
                "error": trace.error
            }
        }

    def create_test_case(self, trace: AgentTrace, expected_output: Optional[str] = None):
        """Create a DeepEval test case from an agent trace."""
        try:
            from deepeval.test_case import ConversationalTestCase, LLMTestCase

            if trace.actions:
                # Use ConversationalTestCase for multi-step agent traces
                return ConversationalTestCase(
                    turns=[
                        LLMTestCase(
                            input=trace.input,
                            actual_output=trace.output,
                            expected_output=expected_output,
                            tools_called=[
                                {
                                    "name": a.tool_name,
                                    "input": a.tool_input,
                                    "output": a.tool_output
                                }
                                for a in trace.actions
                            ]
                        )
                    ]
                )
            else:
                # Simple LLMTestCase for single-turn
                return LLMTestCase(
                    input=trace.input,
                    actual_output=trace.output,
                    expected_output=expected_output
                )
        except ImportError:
            raise ImportError("DeepEval not installed. Run: pip install deepeval")
