"""
Google ADK Agent Wrapper - Integration with Google Agent Development Kit for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class GoogleADKAgentWrapper(BaseAgentWrapper):
    """
    Google Agent Development Kit (ADK) wrapper for DeepEval evaluation.

    Google ADK provides tools for building AI agents with Gemini.

    Usage:
        config = AgentConfig(model="gemini-2.0-flash")
        wrapper = GoogleADKAgentWrapper(config)
        wrapper.add_tool(AgentTool(
            name="search",
            description="Search for information",
            func=search_func
        ))
        wrapper.initialize()
        trace = wrapper.run("Find information about quantum computing")
    """

    def __init__(self, config: AgentConfig, api_key: Optional[str] = None):
        super().__init__(config)
        self._api_key = api_key
        self._model = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.GOOGLE_ADK

    @property
    def name(self) -> str:
        return "Google ADK"

    def initialize(self) -> bool:
        """Initialize Google Generative AI model."""
        try:
            import google.generativeai as genai
            import os

            genai.configure(api_key=self._api_key or os.getenv("GOOGLE_API_KEY"))

            # Build tools for the model
            tools = self._build_tools()

            self._model = genai.GenerativeModel(
                model_name=self.config.model,
                tools=tools if tools else None,
                system_instruction=self.config.system_prompt
            )

            return True
        except ImportError as e:
            raise ImportError(f"Google GenAI not installed: {e}. Run: pip install google-generativeai")
        except Exception:
            return False

    def _build_tools(self) -> List[Any]:
        """Build Google GenAI tools from AgentTools."""
        if not self.config.tools:
            return []

        try:
            import google.generativeai as genai

            function_declarations = []
            for tool in self.config.tools:
                func_decl = genai.protos.FunctionDeclaration(
                    name=tool.name,
                    description=tool.description,
                    parameters=genai.protos.Schema(
                        type=genai.protos.Type.OBJECT,
                        properties={
                            k: genai.protos.Schema(type=genai.protos.Type.STRING)
                            for k in tool.parameters.keys()
                        },
                        required=tool.required_params
                    )
                )
                function_declarations.append(func_decl)

            return [genai.protos.Tool(function_declarations=function_declarations)]
        except Exception:
            return []

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the Google ADK agent."""
        if not self._model:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize model"
                )

        start_time = time.time()
        actions = []
        total_tokens = 0

        try:
            # Start chat
            chat = self._model.start_chat()
            response = chat.send_message(input_text)

            iteration = 0
            while iteration < self.config.max_iterations:
                # Check for function calls
                function_calls = []
                for part in response.parts:
                    if hasattr(part, 'function_call') and part.function_call:
                        function_calls.append(part.function_call)

                if not function_calls:
                    # No function calls, we have the final response
                    break

                # Execute function calls
                function_responses = []
                for fc in function_calls:
                    tool_name = fc.name
                    tool_args = dict(fc.args)

                    tool_output = self._execute_tool(tool_name, tool_args)

                    actions.append(AgentAction(
                        tool_name=tool_name,
                        tool_input=tool_args,
                        tool_output=tool_output
                    ))

                    function_responses.append({
                        "name": tool_name,
                        "response": {"result": str(tool_output)}
                    })

                # Send function responses back
                import google.generativeai as genai
                response = chat.send_message(
                    genai.protos.Content(
                        parts=[
                            genai.protos.Part(
                                function_response=genai.protos.FunctionResponse(
                                    name=fr["name"],
                                    response=fr["response"]
                                )
                            )
                            for fr in function_responses
                        ]
                    )
                )

                iteration += 1

            # Extract final text
            output = response.text if hasattr(response, 'text') else str(response)

            # Get token counts
            if hasattr(response, 'usage_metadata'):
                total_tokens = (
                    response.usage_metadata.prompt_token_count +
                    response.usage_metadata.candidates_token_count
                )

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                total_tokens=total_tokens,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    def _execute_tool(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute a tool by name."""
        for tool in self.config.tools:
            if tool.name == tool_name and tool.func:
                try:
                    return tool.func(**args)
                except Exception as e:
                    return f"Error: {e}"
        return f"Tool '{tool_name}' not found"
