"""
HuggingFace Agent Wrapper - Integration with HuggingFace Transformers Agents for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class HuggingFaceAgentWrapper(BaseAgentWrapper):
    """
    HuggingFace Transformers Agents wrapper for DeepEval evaluation.

    Supports HuggingFace's agent framework with tools.

    Usage:
        config = AgentConfig(model="Qwen/Qwen2.5-72B-Instruct")
        wrapper = HuggingFaceAgentWrapper(config)
        wrapper.add_tool(AgentTool(
            name="image_generator",
            description="Generate images from text",
            func=generate_image
        ))
        wrapper.initialize()
        trace = wrapper.run("Create an image of a sunset")
    """

    def __init__(
        self,
        config: AgentConfig,
        hf_token: Optional[str] = None,
        use_local: bool = False
    ):
        super().__init__(config)
        self._hf_token = hf_token
        self._use_local = use_local
        self._hf_agent = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.HUGGINGFACE

    @property
    def name(self) -> str:
        return "HuggingFace Agents"

    def initialize(self) -> bool:
        """Initialize HuggingFace agent."""
        try:
            from transformers import ReactCodeAgent, HfApiModel, Tool
            import os

            # Create model
            hf_token = self._hf_token or os.getenv("HF_TOKEN")

            if self._use_local:
                # Use local model (requires transformers with torch)
                from transformers import AutoModelForCausalLM, AutoTokenizer

                model = AutoModelForCausalLM.from_pretrained(
                    self.config.model,
                    device_map="auto"
                )
                tokenizer = AutoTokenizer.from_pretrained(self.config.model)
                llm_engine = (model, tokenizer)
            else:
                # Use HF Inference API
                llm_engine = HfApiModel(
                    model_id=self.config.model,
                    token=hf_token
                )

            # Build tools
            tools = self._build_tools()

            # Create agent
            self._hf_agent = ReactCodeAgent(
                tools=tools,
                llm_engine=llm_engine,
                max_iterations=self.config.max_iterations,
                verbose=self.config.verbose
            )

            return True
        except ImportError as e:
            raise ImportError(f"Transformers not installed: {e}. Run: pip install transformers[agents]")
        except Exception:
            return False

    def _build_tools(self) -> List[Any]:
        """Build HuggingFace tools from AgentTools."""
        hf_tools = []

        try:
            from transformers import Tool

            for agent_tool in self.config.tools:
                if agent_tool.func:
                    # Capture current tool in closure via default argument
                    tool_name = agent_tool.name
                    tool_desc = agent_tool.description
                    tool_params = agent_tool.parameters
                    tool_func = agent_tool.func

                    class CustomTool(Tool):
                        name = tool_name
                        description = tool_desc
                        inputs = tool_params
                        output_type = "text"

                        def __init__(self, func=tool_func):
                            super().__init__()
                            self._func = func

                        def forward(self, **kwargs):
                            return self._func(**kwargs)

                    hf_tools.append(CustomTool())
        except ImportError:
            pass

        return hf_tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the HuggingFace agent."""
        if not self._hf_agent:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize agent"
                )

        start_time = time.time()
        actions = []
        intermediate_steps = []

        try:
            # Run agent
            result = self._hf_agent.run(input_text, **kwargs)
            output = str(result)

            # Extract logs/steps if available
            if hasattr(self._hf_agent, 'logs'):
                for log in self._hf_agent.logs:
                    if hasattr(log, 'tool_call'):
                        tc = log.tool_call
                        actions.append(AgentAction(
                            tool_name=tc.get("tool", "unknown"),
                            tool_input=tc.get("input", {}),
                            tool_output=tc.get("output")
                        ))
                    intermediate_steps.append(str(log))

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                intermediate_steps=[{"step": s} for s in intermediate_steps],
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_agent(agent: Any, config: Optional[AgentConfig] = None) -> "HuggingFaceAgentWrapper":
        """Create wrapper from existing HuggingFace agent."""
        wrapper = HuggingFaceAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._hf_agent = agent
        return wrapper
