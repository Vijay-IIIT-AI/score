"""
PydanticAI Agent Wrapper - Integration with PydanticAI for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional, Type
from dataclasses import dataclass
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class PydanticAIAgentWrapper(BaseAgentWrapper):
    """
    PydanticAI agent wrapper for DeepEval evaluation.

    PydanticAI provides type-safe agent development with Pydantic models.

    Usage:
        from pydantic import BaseModel

        class WeatherResponse(BaseModel):
            temperature: float
            conditions: str

        config = AgentConfig(model="openai:gpt-4o")
        wrapper = PydanticAIAgentWrapper(config, result_type=WeatherResponse)
        wrapper.initialize()
        trace = wrapper.run("What's the weather?")
    """

    def __init__(
        self,
        config: AgentConfig,
        result_type: Optional[Type] = None,
        deps_type: Optional[Type] = None
    ):
        super().__init__(config)
        self._result_type = result_type
        self._deps_type = deps_type
        self._pydantic_agent = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.PYDANTIC_AI

    @property
    def name(self) -> str:
        return "PydanticAI"

    def initialize(self) -> bool:
        """Initialize PydanticAI agent."""
        try:
            from pydantic_ai import Agent

            # Create agent
            self._pydantic_agent = Agent(
                self.config.model,
                result_type=self._result_type,
                deps_type=self._deps_type,
                system_prompt=self.config.system_prompt or "You are a helpful assistant."
            )

            # Register tools
            for tool in self.config.tools:
                if tool.func:
                    self._register_tool(tool)

            return True
        except ImportError as e:
            raise ImportError(f"PydanticAI not installed: {e}. Run: pip install pydantic-ai")
        except Exception:
            return False

    def _register_tool(self, tool: AgentTool) -> None:
        """Register a tool with PydanticAI agent."""
        if self._pydantic_agent and tool.func:
            # Use decorator to register tool
            self._pydantic_agent.tool(tool.func)

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)
        if self._pydantic_agent and tool.func:
            self._register_tool(tool)

    def run(self, input_text: str, deps: Any = None, **kwargs) -> AgentTrace:
        """Run the PydanticAI agent."""
        if not self._pydantic_agent:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize agent"
                )

        start_time = time.time()
        actions = []
        total_tokens = 0

        try:
            # Run agent synchronously
            result = self._pydantic_agent.run_sync(
                input_text,
                deps=deps
            )

            # Extract output
            if hasattr(result, 'data'):
                output = str(result.data)
            else:
                output = str(result)

            # Extract tool calls from result
            if hasattr(result, 'all_messages'):
                for msg in result.all_messages():
                    if hasattr(msg, 'parts'):
                        for part in msg.parts:
                            if hasattr(part, 'tool_name'):
                                actions.append(AgentAction(
                                    tool_name=part.tool_name,
                                    tool_input=part.args if hasattr(part, 'args') else {},
                                    tool_output=part.content if hasattr(part, 'content') else None
                                ))

            # Get usage info
            if hasattr(result, 'usage'):
                total_tokens = result.usage().total_tokens if callable(result.usage) else 0

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                total_tokens=total_tokens,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_agent(agent: Any, config: Optional[AgentConfig] = None) -> "PydanticAIAgentWrapper":
        """Create wrapper from existing PydanticAI agent."""
        wrapper = PydanticAIAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._pydantic_agent = agent
        return wrapper
