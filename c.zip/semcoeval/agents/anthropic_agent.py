"""
Anthropic Agent Wrapper - Integration with Anthropic Claude for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class AnthropicAgentWrapper(BaseAgentWrapper):
    """
    Anthropic Claude agent wrapper for DeepEval evaluation.

    Supports Claude's native tool use capability.

    Usage:
        config = AgentConfig(model="claude-sonnet-4-20250514")
        wrapper = AnthropicAgentWrapper(config)
        wrapper.add_tool(AgentTool(
            name="get_weather",
            description="Get weather for a location",
            parameters={"location": {"type": "string"}},
            required_params=["location"],
            func=get_weather
        ))
        wrapper.initialize()
        trace = wrapper.run("What's the weather in Paris?")
    """

    def __init__(self, config: AgentConfig, api_key: Optional[str] = None):
        super().__init__(config)
        self._client = None
        self._api_key = api_key

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.ANTHROPIC

    @property
    def name(self) -> str:
        return "Anthropic Claude"

    def initialize(self) -> bool:
        """Initialize Anthropic client."""
        try:
            from anthropic import Anthropic
            import os

            self._client = Anthropic(
                api_key=self._api_key or os.getenv("ANTHROPIC_API_KEY")
            )
            return True
        except ImportError as e:
            raise ImportError(f"Anthropic not installed: {e}. Run: pip install anthropic")
        except Exception:
            return False

    def _build_tools_schema(self) -> List[Dict[str, Any]]:
        """Build Anthropic tools schema from AgentTools."""
        tools = []
        for tool in self.config.tools:
            tool_schema = {
                "name": tool.name,
                "description": tool.description,
                "input_schema": {
                    "type": "object",
                    "properties": tool.parameters,
                    "required": tool.required_params
                }
            }
            tools.append(tool_schema)
        return tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the Anthropic agent with tool calling."""
        if not self._client:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize client"
                )

        start_time = time.time()
        actions = []
        messages = [{"role": "user", "content": input_text}]
        total_tokens = 0

        try:
            # Build tools
            tools = self._build_tools_schema() if self.config.tools else None

            # Agent loop
            iteration = 0
            output = ""

            while iteration < self.config.max_iterations:
                # Call the model
                response = self._client.messages.create(
                    model=self.config.model,
                    max_tokens=self.config.max_tokens,
                    system=self.config.system_prompt or "You are a helpful assistant.",
                    messages=messages,
                    tools=tools
                )

                total_tokens += response.usage.input_tokens + response.usage.output_tokens

                # Check stop reason
                if response.stop_reason == "tool_use":
                    # Extract tool use blocks
                    assistant_content = response.content
                    messages.append({"role": "assistant", "content": assistant_content})

                    tool_results = []
                    for block in assistant_content:
                        if block.type == "tool_use":
                            tool_name = block.name
                            tool_input = block.input

                            # Execute tool
                            tool_output = self._execute_tool(tool_name, tool_input)

                            actions.append(AgentAction(
                                tool_name=tool_name,
                                tool_input=tool_input,
                                tool_output=tool_output
                            ))

                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": str(tool_output)
                            })

                    messages.append({"role": "user", "content": tool_results})
                    iteration += 1
                else:
                    # End turn - extract text response
                    for block in response.content:
                        if hasattr(block, 'text'):
                            output = block.text
                            break
                    break

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                total_tokens=total_tokens,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    def _execute_tool(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute a tool by name."""
        for tool in self.config.tools:
            if tool.name == tool_name and tool.func:
                try:
                    return tool.func(**args)
                except Exception as e:
                    return f"Error: {e}"
        return f"Tool '{tool_name}' not found"
