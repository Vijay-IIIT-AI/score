"""
Docker Sandbox for Agent Execution - Fully offline, no cloud dependencies.

Provides isolated execution environment for agent tools using local Docker.

Features:
- No internet required (air-gapped compatible)
- Network isolation (--network=none)
- Resource limits (CPU, memory, timeout)
- Pre-built images for common languages
- File system isolation
- Automatic cleanup

Usage:
    sandbox = DockerSandbox()

    # Execute code
    result = sandbox.execute_code("print('Hello!')", language="python")

    # Execute shell command
    result = sandbox.execute_shell("ls -la")

    # Run with custom image
    result = sandbox.execute_code(code, image="python:3.11-slim")
"""

import os
import subprocess
import tempfile
import shutil
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from pathlib import Path
from enum import Enum
import threading


class SandboxLanguage(Enum):
    """Supported languages for code execution."""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    BASH = "bash"
    RUBY = "ruby"
    GO = "go"
    RUST = "rust"


# Default Docker images for each language (can be pre-pulled for offline use)
DEFAULT_IMAGES = {
    SandboxLanguage.PYTHON: "python:3.11-slim",
    SandboxLanguage.JAVASCRIPT: "node:20-slim",
    SandboxLanguage.BASH: "alpine:latest",
    SandboxLanguage.RUBY: "ruby:3.2-slim",
    SandboxLanguage.GO: "golang:1.21-alpine",
    SandboxLanguage.RUST: "rust:1.75-slim",
}

# File extensions for each language
LANGUAGE_EXTENSIONS = {
    SandboxLanguage.PYTHON: ".py",
    SandboxLanguage.JAVASCRIPT: ".js",
    SandboxLanguage.BASH: ".sh",
    SandboxLanguage.RUBY: ".rb",
    SandboxLanguage.GO: ".go",
    SandboxLanguage.RUST: ".rs",
}

# Run commands for each language
LANGUAGE_COMMANDS = {
    SandboxLanguage.PYTHON: "python",
    SandboxLanguage.JAVASCRIPT: "node",
    SandboxLanguage.BASH: "sh",
    SandboxLanguage.RUBY: "ruby",
    SandboxLanguage.GO: "go run",
    SandboxLanguage.RUST: "rustc -o /tmp/prog && /tmp/prog",
}


@dataclass
class SandboxConfig:
    """Configuration for sandbox execution."""
    # Resource limits
    memory_limit: str = "256m"  # e.g., "256m", "1g"
    cpu_limit: float = 1.0  # Number of CPUs
    timeout_seconds: int = 30  # Max execution time
    pids_limit: int = 64  # Prevent fork bombs

    # Network
    network_enabled: bool = False  # Disable network by default (air-gapped)

    # File system
    read_only_root: bool = True  # Make root filesystem read-only
    working_dir: str = "/workspace"

    # Cleanup
    auto_remove: bool = True  # Remove container after execution

    # Custom image
    custom_image: Optional[str] = None

    # Security hardening
    run_as_user: str = "1000:1000"  # Run as non-root user
    drop_capabilities: bool = True  # Drop all Linux capabilities
    no_new_privileges: bool = True  # Prevent privilege escalation


@dataclass
class SandboxResult:
    """Result from sandbox execution."""
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: int
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class DockerSandbox:
    """
    Docker-based sandbox for safe code execution.

    Works completely offline with pre-pulled images.

    Usage:
        # Basic usage
        sandbox = DockerSandbox()
        result = sandbox.execute_code("print('Hello!')", language="python")

        # With custom config
        config = SandboxConfig(memory_limit="512m", timeout_seconds=60)
        sandbox = DockerSandbox(config)

        # Execute shell commands
        result = sandbox.execute_shell("echo $PATH")

        # With file access
        sandbox.copy_to_sandbox("/local/file.txt", "/workspace/file.txt")
        result = sandbox.execute_code("open('file.txt').read()")
    """

    def __init__(self, config: Optional[SandboxConfig] = None):
        self.config = config or SandboxConfig()
        self._verify_docker()

    def _verify_docker(self) -> bool:
        """Verify Docker is installed and running."""
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            raise RuntimeError(
                "Docker not available. Please install Docker and ensure it's running."
            )

    def pull_images_for_offline(self, languages: Optional[List[SandboxLanguage]] = None):
        """
        Pre-pull images for offline use.

        Run this while connected to internet to prepare for air-gapped use.

        Args:
            languages: Languages to pull images for. None = all.
        """
        if languages is None:
            languages = list(SandboxLanguage)

        for lang in languages:
            image = DEFAULT_IMAGES.get(lang)
            if image:
                print(f"Pulling {image}...")
                subprocess.run(
                    ["docker", "pull", image],
                    capture_output=True
                )
                print(f"  Done: {image}")

    def list_available_images(self) -> List[str]:
        """List locally available Docker images."""
        result = subprocess.run(
            ["docker", "images", "--format", "{{.Repository}}:{{.Tag}}"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return [img.strip() for img in result.stdout.strip().split("\n") if img.strip()]
        return []

    def execute_code(
        self,
        code: str,
        language: Union[str, SandboxLanguage] = SandboxLanguage.PYTHON,
        files: Optional[Dict[str, str]] = None,
        env_vars: Optional[Dict[str, str]] = None
    ) -> SandboxResult:
        """
        Execute code in a sandboxed container.

        Args:
            code: Code to execute
            language: Programming language
            files: Additional files to include {filename: content}
            env_vars: Environment variables

        Returns:
            SandboxResult with stdout, stderr, exit code
        """
        if isinstance(language, str):
            language = SandboxLanguage(language.lower())

        image = self.config.custom_image or DEFAULT_IMAGES.get(language)
        if not image:
            return SandboxResult(
                success=False,
                stdout="",
                stderr=f"Unsupported language: {language}",
                exit_code=1,
                execution_time_ms=0,
                error=f"No image configured for {language}"
            )

        # Create temp directory for code
        temp_dir = tempfile.mkdtemp(prefix="sandbox_")

        try:
            # Write code to file
            ext = LANGUAGE_EXTENSIONS.get(language, ".txt")
            code_file = os.path.join(temp_dir, f"main{ext}")
            with open(code_file, "w", encoding="utf-8") as f:
                f.write(code)

            # Write additional files
            if files:
                for filename, content in files.items():
                    filepath = os.path.join(temp_dir, filename)
                    os.makedirs(os.path.dirname(filepath), exist_ok=True)
                    with open(filepath, "w", encoding="utf-8") as f:
                        f.write(content)

            # Build command
            run_cmd = LANGUAGE_COMMANDS.get(language, "python")

            # Build docker command with security hardening
            docker_cmd = [
                "docker", "run",
                "--rm" if self.config.auto_remove else "",
                f"--memory={self.config.memory_limit}",
                f"--cpus={self.config.cpu_limit}",
                f"--pids-limit={self.config.pids_limit}",  # Prevent fork bombs
                f"-v", f"{temp_dir}:{self.config.working_dir}:ro",
                f"-w", self.config.working_dir,
            ]

            # Security hardening: run as non-root user
            if self.config.run_as_user:
                docker_cmd.extend(["--user", self.config.run_as_user])

            # Security hardening: drop all capabilities
            if self.config.drop_capabilities:
                docker_cmd.append("--cap-drop=ALL")

            # Security hardening: prevent privilege escalation
            if self.config.no_new_privileges:
                docker_cmd.append("--security-opt=no-new-privileges")

            # Network isolation
            if not self.config.network_enabled:
                docker_cmd.append("--network=none")

            # Read-only root
            if self.config.read_only_root:
                docker_cmd.extend(["--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m"])

            # Environment variables
            if env_vars:
                for key, value in env_vars.items():
                    docker_cmd.extend(["-e", f"{key}={value}"])

            # Add image and command
            docker_cmd = [c for c in docker_cmd if c]  # Remove empty strings
            docker_cmd.extend([image, "sh", "-c", f"{run_cmd} main{ext}"])

            # Execute with timeout
            start_time = time.time()
            try:
                result = subprocess.run(
                    docker_cmd,
                    capture_output=True,
                    text=True,
                    timeout=self.config.timeout_seconds
                )
                execution_time = int((time.time() - start_time) * 1000)

                return SandboxResult(
                    success=result.returncode == 0,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    exit_code=result.returncode,
                    execution_time_ms=execution_time
                )

            except subprocess.TimeoutExpired:
                return SandboxResult(
                    success=False,
                    stdout="",
                    stderr=f"Execution timed out after {self.config.timeout_seconds}s",
                    exit_code=-1,
                    execution_time_ms=self.config.timeout_seconds * 1000,
                    error="Timeout"
                )

        finally:
            # Cleanup temp directory
            shutil.rmtree(temp_dir, ignore_errors=True)

    def execute_shell(
        self,
        command: str,
        image: str = "alpine:latest",
        env_vars: Optional[Dict[str, str]] = None
    ) -> SandboxResult:
        """
        Execute a shell command in sandbox.

        Args:
            command: Shell command to execute
            image: Docker image to use
            env_vars: Environment variables

        Returns:
            SandboxResult
        """
        docker_cmd = [
            "docker", "run", "--rm",
            f"--memory={self.config.memory_limit}",
            f"--cpus={self.config.cpu_limit}",
            f"--pids-limit={self.config.pids_limit}",
        ]

        # Security hardening
        if self.config.run_as_user:
            docker_cmd.extend(["--user", self.config.run_as_user])
        if self.config.drop_capabilities:
            docker_cmd.append("--cap-drop=ALL")
        if self.config.no_new_privileges:
            docker_cmd.append("--security-opt=no-new-privileges")

        if not self.config.network_enabled:
            docker_cmd.append("--network=none")

        if env_vars:
            for key, value in env_vars.items():
                docker_cmd.extend(["-e", f"{key}={value}"])

        docker_cmd.extend([image, "sh", "-c", command])

        start_time = time.time()
        try:
            result = subprocess.run(
                docker_cmd,
                capture_output=True,
                text=True,
                timeout=self.config.timeout_seconds
            )
            execution_time = int((time.time() - start_time) * 1000)

            return SandboxResult(
                success=result.returncode == 0,
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.returncode,
                execution_time_ms=execution_time
            )

        except subprocess.TimeoutExpired:
            return SandboxResult(
                success=False,
                stdout="",
                stderr=f"Execution timed out after {self.config.timeout_seconds}s",
                exit_code=-1,
                execution_time_ms=self.config.timeout_seconds * 1000,
                error="Timeout"
            )


class SandboxSession:
    """
    Persistent sandbox session for multi-step agent execution.

    Keeps a container running for multiple commands (like SWE-bench).

    Usage:
        with SandboxSession() as session:
            session.execute("pip install requests")
            result = session.execute("python script.py")
            session.write_file("/workspace/data.json", '{"key": "value"}')
            content = session.read_file("/workspace/output.txt")
    """

    def __init__(
        self,
        image: str = "python:3.11-slim",
        config: Optional[SandboxConfig] = None
    ):
        self.image = image
        self.config = config or SandboxConfig()
        self.container_id: Optional[str] = None
        self._temp_dir: Optional[str] = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()

    def start(self):
        """Start the sandbox container with security hardening."""
        self._temp_dir = tempfile.mkdtemp(prefix="sandbox_session_")

        docker_cmd = [
            "docker", "run", "-d",
            f"--memory={self.config.memory_limit}",
            f"--cpus={self.config.cpu_limit}",
            f"--pids-limit={self.config.pids_limit}",
            "-v", f"{self._temp_dir}:{self.config.working_dir}",
            "-w", self.config.working_dir,
        ]

        # Security hardening
        if self.config.run_as_user:
            docker_cmd.extend(["--user", self.config.run_as_user])
        if self.config.drop_capabilities:
            docker_cmd.append("--cap-drop=ALL")
        if self.config.no_new_privileges:
            docker_cmd.append("--security-opt=no-new-privileges")

        if not self.config.network_enabled:
            docker_cmd.append("--network=none")

        docker_cmd.extend([self.image, "tail", "-f", "/dev/null"])

        result = subprocess.run(docker_cmd, capture_output=True, text=True)
        if result.returncode == 0:
            self.container_id = result.stdout.strip()[:12]
        else:
            raise RuntimeError(f"Failed to start container: {result.stderr}")

    def stop(self):
        """Stop and remove the container."""
        if self.container_id:
            subprocess.run(
                ["docker", "stop", self.container_id],
                capture_output=True
            )
            subprocess.run(
                ["docker", "rm", "-f", self.container_id],
                capture_output=True
            )
            self.container_id = None

        if self._temp_dir:
            shutil.rmtree(self._temp_dir, ignore_errors=True)

    def execute(self, command: str, timeout: Optional[int] = None) -> SandboxResult:
        """Execute a command in the running container."""
        if not self.container_id:
            raise RuntimeError("Session not started")

        effective_timeout = timeout or self.config.timeout_seconds
        wrapped_command = f"timeout -k 5 {effective_timeout} sh -c {self._shell_quote(command)}"
        docker_cmd = ["docker", "exec", self.container_id, "sh", "-c", wrapped_command]

        start_time = time.time()
        try:
            result = subprocess.run(
                docker_cmd,
                capture_output=True,
                text=True,
                timeout=effective_timeout + 10
            )
            execution_time = int((time.time() - start_time) * 1000)

            if result.returncode == 124:
                return SandboxResult(
                    success=False, stdout=result.stdout, stderr="Command timed out",
                    exit_code=-1, execution_time_ms=execution_time, error="Timeout"
                )

            return SandboxResult(
                success=result.returncode == 0, stdout=result.stdout, stderr=result.stderr,
                exit_code=result.returncode, execution_time_ms=execution_time
            )

        except subprocess.TimeoutExpired:
            self._kill_container_processes()
            return SandboxResult(
                success=False, stdout="", stderr="Timeout",
                exit_code=-1, execution_time_ms=(effective_timeout + 10) * 1000, error="Timeout"
            )

    def _kill_container_processes(self):
        """Kill orphaned processes in container."""
        if not self.container_id:
            return
        try:
            subprocess.run(
                ["docker", "exec", self.container_id, "pkill", "-9", "-f", ".*"],
                capture_output=True, timeout=5
            )
        except Exception:
            pass

    @staticmethod
    def _shell_quote(s: str) -> str:
        """Quote string for shell."""
        return "'" + s.replace("'", "'\"'\"'") + "'"

    def write_file(self, path: str, content: str):
        """Write a file in the container workspace."""
        if not self._temp_dir:
            raise RuntimeError("Session not started")

        local_path = self._resolve_safe_path(path)
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        with open(local_path, "w", encoding="utf-8") as f:
            f.write(content)

    def read_file(self, path: str) -> str:
        """Read a file from the container workspace."""
        if not self._temp_dir:
            raise RuntimeError("Session not started")

        local_path = self._resolve_safe_path(path)
        if os.path.exists(local_path):
            with open(local_path, "r", encoding="utf-8") as f:
                return f.read()
        return ""

    def _resolve_safe_path(self, path: str) -> str:
        """Resolve path safely within sandbox directory."""
        relative_path = path.replace(self.config.working_dir, "").lstrip("/\\")
        temp_dir_resolved = Path(self._temp_dir).resolve()
        target_path = (temp_dir_resolved / relative_path).resolve()

        try:
            target_path.relative_to(temp_dir_resolved)
        except ValueError:
            raise PermissionError(f"Path traversal blocked: {path}")

        return str(target_path)


# Integration with Agent Runner
class SandboxedToolExecutor:
    """
    Execute agent tools in a Docker sandbox.

    Replaces MockToolExecutor for real execution.

    Usage:
        executor = SandboxedToolExecutor()

        # Register a tool
        executor.register_tool("run_python", lambda code: sandbox.execute_code(code))

        # Execute
        result = executor.execute("run_python", {"code": "print(1+1)"})
    """

    def __init__(self, config: Optional[SandboxConfig] = None):
        self.sandbox = DockerSandbox(config)
        self._tools: Dict[str, callable] = {}
        self._register_default_tools()

    def _register_default_tools(self):
        """Register common agent tools."""
        self._tools["execute_python"] = self._execute_python
        self._tools["execute_bash"] = self._execute_bash
        self._tools["execute_javascript"] = self._execute_javascript
        self._tools["read_file"] = self._read_file
        self._tools["write_file"] = self._write_file

    def _execute_python(self, code: str) -> Dict[str, Any]:
        result = self.sandbox.execute_code(code, language="python")
        return {
            "success": result.success,
            "output": result.stdout,
            "error": result.stderr if not result.success else None
        }

    def _execute_bash(self, command: str) -> Dict[str, Any]:
        result = self.sandbox.execute_shell(command)
        return {
            "success": result.success,
            "output": result.stdout,
            "error": result.stderr if not result.success else None
        }

    def _execute_javascript(self, code: str) -> Dict[str, Any]:
        result = self.sandbox.execute_code(code, language="javascript")
        return {
            "success": result.success,
            "output": result.stdout,
            "error": result.stderr if not result.success else None
        }

    def _read_file(self, path: str) -> Dict[str, Any]:
        # Note: This would need a session-based sandbox for file persistence
        return {"error": "Use SandboxSession for file operations"}

    def _write_file(self, path: str, content: str) -> Dict[str, Any]:
        return {"error": "Use SandboxSession for file operations"}

    def register_tool(self, name: str, func: callable):
        """Register a custom tool."""
        self._tools[name] = func

    def execute(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute a tool by name."""
        if tool_name not in self._tools:
            return {"error": f"Unknown tool: {tool_name}"}

        try:
            func = self._tools[tool_name]
            # Handle different argument formats
            if len(args) == 1:
                return func(list(args.values())[0])
            return func(**args)
        except Exception as e:
            return {"error": str(e)}

    def list_tools(self) -> List[str]:
        """List available tools."""
        return list(self._tools.keys())


def prepare_offline_sandbox():
    """
    Prepare sandbox for offline/air-gapped use.

    Run this while connected to internet:
        python -c "from semcoeval.agents.sandbox import prepare_offline_sandbox; prepare_offline_sandbox()"
    """
    print("Preparing Docker images for offline use...")
    sandbox = DockerSandbox()
    sandbox.pull_images_for_offline()
    print("\nDone! Available images:")
    for img in sandbox.list_available_images():
        print(f"  - {img}")
    print("\nYou can now use the sandbox offline.")
