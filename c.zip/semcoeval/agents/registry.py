"""
Agent Framework Registry - Central registry for managing agent framework integrations.
"""

from typing import Dict, List, Optional, Type, Any
from .base import BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool, AgentTrace


class AgentRegistry:
    """
    Central registry for managing agent framework wrappers.

    Usage:
        registry = AgentRegistry()

        # Create an agent
        config = AgentConfig(model="gpt-4o")
        agent = registry.create_agent("langchain", config)

        # Add tools
        agent.add_tool(AgentTool(name="search", description="Search", func=search_fn))

        # Run agent
        trace = agent.run("Find information about AI")

        # Create DeepEval test case
        test_case = agent.create_test_case(trace)
    """

    def __init__(self):
        self._agent_classes: Dict[str, Type[BaseAgentWrapper]] = {}
        self._register_defaults()

    def _register_defaults(self):
        """Register default agent framework classes."""
        from .langchain_agent import LangChainAgentWrapper
        from .langgraph_agent import LangGraphAgentWrapper
        from .llamaindex_agent import LlamaIndexAgentWrapper
        from .crewai_agent import CrewAIAgentWrapper
        from .openai_agent import OpenAIAgentWrapper
        from .anthropic_agent import AnthropicAgentWrapper
        from .google_adk_agent import GoogleADKAgentWrapper
        from .pydantic_agent import PydanticAIAgentWrapper
        from .strands_agent import StrandsAgentWrapper
        from .huggingface_agent import HuggingFaceAgentWrapper
        from .hermes_agent import HermesAgentWrapper

        self.register("langchain", LangChainAgentWrapper)
        self.register("langgraph", LangGraphAgentWrapper)
        self.register("llamaindex", LlamaIndexAgentWrapper)
        self.register("crewai", CrewAIAgentWrapper)
        self.register("openai", OpenAIAgentWrapper)
        self.register("anthropic", AnthropicAgentWrapper)
        self.register("google_adk", GoogleADKAgentWrapper)
        self.register("pydantic_ai", PydanticAIAgentWrapper)
        self.register("strands", StrandsAgentWrapper)
        self.register("huggingface", HuggingFaceAgentWrapper)
        self.register("hermes", HermesAgentWrapper)

    def register(self, name: str, agent_class: Type[BaseAgentWrapper]):
        """Register an agent framework class."""
        self._agent_classes[name] = agent_class

    def list_frameworks(self) -> List[str]:
        """List all registered agent frameworks."""
        return list(self._agent_classes.keys())

    def get_framework_class(self, name: str) -> Optional[Type[BaseAgentWrapper]]:
        """Get the agent class for a framework."""
        return self._agent_classes.get(name)

    def create_agent(
        self,
        framework: str,
        config: AgentConfig,
        **kwargs
    ) -> BaseAgentWrapper:
        """
        Create an agent wrapper for the specified framework.

        Args:
            framework: Name of the agent framework
            config: Agent configuration
            **kwargs: Additional framework-specific arguments

        Returns:
            Initialized agent wrapper
        """
        agent_class = self._agent_classes.get(framework)
        if not agent_class:
            raise ValueError(f"Unknown agent framework: {framework}. "
                           f"Available: {self.list_frameworks()}")

        return agent_class(config, **kwargs)

    def wrap_existing(
        self,
        framework: str,
        agent: Any,
        config: Optional[AgentConfig] = None
    ) -> BaseAgentWrapper:
        """
        Wrap an existing agent instance for evaluation.

        Args:
            framework: Name of the agent framework
            agent: Existing agent instance
            config: Optional agent configuration

        Returns:
            Wrapped agent
        """
        agent_class = self._agent_classes.get(framework)
        if not agent_class:
            raise ValueError(f"Unknown agent framework: {framework}")

        if hasattr(agent_class, 'from_agent'):
            return agent_class.from_agent(agent, config)
        elif hasattr(agent_class, 'from_agent_executor'):
            return agent_class.from_agent_executor(agent, config)
        elif hasattr(agent_class, 'from_crew'):
            return agent_class.from_crew(agent, config)
        elif hasattr(agent_class, 'from_graph'):
            return agent_class.from_graph(agent, config)
        else:
            wrapper = agent_class(config or AgentConfig(model="unknown"))
            wrapper._agent = agent
            return wrapper


def evaluate_agent(
    agent: BaseAgentWrapper,
    test_inputs: List[str],
    expected_outputs: Optional[List[str]] = None,
    metrics: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Evaluate an agent on multiple test inputs.

    Args:
        agent: Agent wrapper to evaluate
        test_inputs: List of test input prompts
        expected_outputs: Optional list of expected outputs
        metrics: Optional list of DeepEval metric names to use

    Returns:
        List of evaluation results
    """
    results = []

    for i, input_text in enumerate(test_inputs):
        # Run agent
        trace = agent.run(input_text)

        expected = expected_outputs[i] if expected_outputs and i < len(expected_outputs) else None

        # Create test case
        test_case = agent.create_test_case(trace, expected)

        result = {
            "input": input_text,
            "output": trace.output,
            "expected": expected,
            "success": trace.success,
            "actions": [
                {"tool": a.tool_name, "input": a.tool_input, "output": a.tool_output}
                for a in trace.actions
            ],
            "duration_ms": trace.duration_ms,
            "test_case": test_case
        }

        # Run metrics if specified
        if metrics and trace.success:
            result["metrics"] = _run_metrics(test_case, metrics)

        results.append(result)

    return results


def _run_metrics(test_case: Any, metric_names: List[str]) -> Dict[str, Any]:
    """Run DeepEval metrics on a test case."""
    scores = {}

    try:
        from deepeval import evaluate
        from deepeval import metrics as deepeval_metrics

        # Comprehensive metric map with common aliases
        metric_map = {
            # Core metrics
            "answer_relevancy": "AnswerRelevancyMetric",
            "faithfulness": "FaithfulnessMetric",
            "contextual_relevancy": "ContextualRelevancyMetric",
            "contextual_precision": "ContextualPrecisionMetric",
            "contextual_recall": "ContextualRecallMetric",
            # Tool/Agent metrics
            "tool_correctness": "ToolCorrectnessMetric",
            "tool_use": "ToolUseMetric",
            "argument_correctness": "ArgumentCorrectnessMetric",
            # RAG metrics
            "hallucination": "HallucinationMetric",
            "summarization": "SummarizationMetric",
            # Safety metrics
            "bias": "BiasMetric",
            "toxicity": "ToxicityMetric",
            # General
            "g_eval": "GEval",
            "knowledge_retention": "KnowledgeRetentionMetric",
            # JSON
            "json_correctness": "JsonCorrectnessMetric",
            # Image
            "image_coherence": "ImageCoherenceMetric",
            "image_helpfulness": "ImageHelpfulnessMetric",
            "text_to_image": "TextToImageMetric",
        }

        metrics = []
        for name in metric_names:
            # Check alias first, then try direct class name
            class_name = metric_map.get(name.lower(), name)

            # Try to get metric class from deepeval
            metric_class = getattr(deepeval_metrics, class_name, None)
            if metric_class is None:
                # Try with "Metric" suffix
                metric_class = getattr(deepeval_metrics, f"{class_name}Metric", None)

            if metric_class:
                try:
                    metrics.append(metric_class())
                except TypeError:
                    # Some metrics require parameters, skip them
                    pass

        if metrics:
            results = evaluate([test_case], metrics)
            for metric in metrics:
                scores[metric.__class__.__name__] = getattr(metric, 'score', None)

    except ImportError:
        scores["error"] = "DeepEval not installed"
    except Exception as e:
        scores["error"] = str(e)

    return scores
