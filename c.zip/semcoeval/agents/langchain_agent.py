"""
LangChain Agent Wrapper - Integration with LangChain agents for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class LangChainAgentWrapper(BaseAgentWrapper):
    """
    LangChain agent wrapper for DeepEval evaluation.

    Supports:
    - LangChain agents (AgentExecutor)
    - LangChain tools
    - LangChain callbacks for tracing

    Usage:
        config = AgentConfig(model="gpt-4o", temperature=0)
        wrapper = LangChainAgentWrapper(config)

        # Add tools
        wrapper.add_tool(AgentTool(
            name="search",
            description="Search the web",
            func=search_function
        ))

        # Initialize and run
        wrapper.initialize()
        trace = wrapper.run("What is the weather in SF?")
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self._llm = None
        self._langchain_tools = []

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.LANGCHAIN

    @property
    def name(self) -> str:
        return "LangChain"

    def initialize(self) -> bool:
        """Initialize LangChain agent."""
        try:
            from langchain_openai import ChatOpenAI
            from langchain.agents import AgentExecutor, create_tool_calling_agent
            from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

            # Create LLM
            self._llm = ChatOpenAI(
                model=self.config.model,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )

            # Create prompt
            system_prompt = self.config.system_prompt or "You are a helpful assistant."
            prompt = ChatPromptTemplate.from_messages([
                ("system", system_prompt),
                ("human", "{input}"),
                MessagesPlaceholder(variable_name="agent_scratchpad"),
            ])

            # Convert tools
            self._langchain_tools = self._convert_tools()

            if self._langchain_tools:
                # Create agent with tools
                agent = create_tool_calling_agent(
                    self._llm,
                    self._langchain_tools,
                    prompt
                )
                self._agent = AgentExecutor(
                    agent=agent,
                    tools=self._langchain_tools,
                    verbose=self.config.verbose,
                    max_iterations=self.config.max_iterations,
                    return_intermediate_steps=True
                )
            else:
                # No tools, use LLM directly
                self._agent = self._llm

            return True
        except ImportError as e:
            raise ImportError(f"LangChain not installed: {e}. Run: pip install langchain langchain-openai")
        except Exception:
            return False

    def _convert_tools(self) -> List[Any]:
        """Convert AgentTools to LangChain tools."""
        langchain_tools = []

        try:
            from langchain_core.tools import StructuredTool

            for tool in self.config.tools:
                if tool.func:
                    lc_tool = StructuredTool.from_function(
                        func=tool.func,
                        name=tool.name,
                        description=tool.description
                    )
                    langchain_tools.append(lc_tool)
        except ImportError:
            pass

        return langchain_tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the LangChain agent."""
        if not self._agent:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize agent"
                )

        start_time = time.time()
        actions = []
        intermediate_steps = []

        try:
            from langchain.agents import AgentExecutor

            if isinstance(self._agent, AgentExecutor):
                # Agent with tools
                result = self._agent.invoke(
                    {"input": input_text},
                    **kwargs
                )
                output = result.get("output", "")

                # Extract actions from intermediate steps
                for step in result.get("intermediate_steps", []):
                    if len(step) >= 2:
                        action, observation = step[0], step[1]
                        actions.append(AgentAction(
                            tool_name=action.tool,
                            tool_input=action.tool_input if isinstance(action.tool_input, dict) else {"input": action.tool_input},
                            tool_output=observation
                        ))
                        intermediate_steps.append({
                            "action": action.tool,
                            "input": action.tool_input,
                            "output": observation
                        })
            else:
                # Direct LLM call
                result = self._agent.invoke(input_text)
                output = result.content if hasattr(result, 'content') else str(result)

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                intermediate_steps=intermediate_steps,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_agent_executor(agent_executor: Any, config: Optional[AgentConfig] = None) -> "LangChainAgentWrapper":
        """Create wrapper from existing AgentExecutor."""
        wrapper = LangChainAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._agent = agent_executor
        return wrapper
