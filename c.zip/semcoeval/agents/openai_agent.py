"""
OpenAI Agents Wrapper - Integration with OpenAI Agents SDK for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class OpenAIAgentWrapper(BaseAgentWrapper):
    """
    OpenAI Agents SDK wrapper for DeepEval evaluation.

    Supports OpenAI's native agent SDK with tool calling.

    Usage:
        config = AgentConfig(model="gpt-4o")
        wrapper = OpenAIAgentWrapper(config)
        wrapper.add_tool(AgentTool(
            name="get_weather",
            description="Get weather for a location",
            func=get_weather
        ))
        wrapper.initialize()
        trace = wrapper.run("What's the weather in Tokyo?")
    """

    def __init__(self, config: AgentConfig, api_key: Optional[str] = None):
        super().__init__(config)
        self._client = None
        self._api_key = api_key

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.OPENAI_AGENTS

    @property
    def name(self) -> str:
        return "OpenAI Agents"

    def initialize(self) -> bool:
        """Initialize OpenAI client."""
        try:
            from openai import OpenAI
            import os

            self._client = OpenAI(
                api_key=self._api_key or os.getenv("OPENAI_API_KEY")
            )
            return True
        except ImportError as e:
            raise ImportError(f"OpenAI not installed: {e}. Run: pip install openai")
        except Exception:
            return False

    def _build_tools_schema(self) -> List[Dict[str, Any]]:
        """Build OpenAI tools schema from AgentTools."""
        tools = []
        for tool in self.config.tools:
            tool_schema = {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": {
                        "type": "object",
                        "properties": tool.parameters,
                        "required": tool.required_params
                    }
                }
            }
            tools.append(tool_schema)
        return tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the OpenAI agent with tool calling."""
        if not self._client:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize client"
                )

        start_time = time.time()
        actions = []
        messages = []
        total_tokens = 0

        try:
            # Build initial messages
            if self.config.system_prompt:
                messages.append({"role": "system", "content": self.config.system_prompt})
            messages.append({"role": "user", "content": input_text})

            # Build tools
            tools = self._build_tools_schema() if self.config.tools else None

            # Agent loop
            iteration = 0
            while iteration < self.config.max_iterations:
                # Call the model
                response = self._client.chat.completions.create(
                    model=self.config.model,
                    messages=messages,
                    tools=tools,
                    temperature=self.config.temperature,
                    max_tokens=self.config.max_tokens
                )

                total_tokens += response.usage.total_tokens if response.usage else 0
                message = response.choices[0].message

                # Check for tool calls
                if message.tool_calls:
                    messages.append(message)

                    for tool_call in message.tool_calls:
                        # Find and execute the tool
                        tool_name = tool_call.function.name
                        tool_args = tool_call.function.arguments

                        import json
                        try:
                            args_dict = json.loads(tool_args)
                        except:
                            args_dict = {"input": tool_args}

                        # Execute tool
                        tool_output = self._execute_tool(tool_name, args_dict)

                        actions.append(AgentAction(
                            tool_name=tool_name,
                            tool_input=args_dict,
                            tool_output=tool_output
                        ))

                        # Add tool response to messages
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": str(tool_output)
                        })

                    iteration += 1
                else:
                    # No tool calls, we have the final response
                    output = message.content or ""
                    break
            else:
                output = message.content or "" if message else ""

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                total_tokens=total_tokens,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    def _execute_tool(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute a tool by name."""
        for tool in self.config.tools:
            if tool.name == tool_name and tool.func:
                try:
                    return tool.func(**args)
                except Exception as e:
                    return f"Error: {e}"
        return f"Tool '{tool_name}' not found"
