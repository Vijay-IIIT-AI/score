"""
Agent Runner - Auto-execute agents with dataset-driven tool configuration.

Supports two evaluation modes:
1. AST Matching (like BFCL) - Validates tool call syntax without execution
2. Mock Execution - Runs tools with mock responses from dataset

Usage:
    runner = AgentRunner()

    # Load dataset with tool definitions
    results = runner.run(
        dataset_path="agent_benchmark.json",
        framework="openai",  # or langgraph, anthropic, etc.
        model="gpt-4o",
        mode="ast"  # or "mock_execution"
    )
"""

import json
import os
import re
import ast
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union, Callable
from pathlib import Path
from enum import Enum
import time


class EvaluationMode(Enum):
    """How to evaluate agent tool calls."""
    AST_MATCH = "ast"  # BFCL-style: check syntax only
    MOCK_EXECUTE = "mock"  # Execute with mock responses
    DOCKER_EXECUTE = "docker"  # Execute in Docker sandbox
    LIVE_EXECUTE = "live"  # Execute with real tools (if provided)


@dataclass
class ToolDefinition:
    """Tool definition from dataset."""
    name: str
    description: str
    parameters: Dict[str, Any]
    required_params: List[str] = field(default_factory=list)
    mock_responses: Dict[str, Any] = field(default_factory=dict)
    default_response: Any = None


@dataclass
class AgentTestCase:
    """Test case for agent evaluation."""
    id: str
    input: str
    expected_tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    expected_output_contains: List[str] = field(default_factory=list)
    expected_output: Optional[str] = None
    max_turns: int = 5
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolCallResult:
    """Result of a single tool call evaluation."""
    tool_name: str
    expected_args: Dict[str, Any]
    actual_args: Dict[str, Any]
    name_match: bool
    args_match: bool
    ast_valid: bool
    execution_result: Optional[Any] = None


@dataclass
class AgentTestResult:
    """Result of evaluating a single test case."""
    test_id: str
    input: str
    actual_output: str
    expected_output: Optional[str]
    tool_calls: List[ToolCallResult]
    tool_call_accuracy: float
    output_match: bool
    passed: bool
    latency_ms: int
    error: Optional[str] = None


@dataclass
class AgentBenchmarkResult:
    """Result of running a full agent benchmark."""
    dataset_name: str
    framework: str
    model: str
    mode: str
    total_tests: int
    passed_tests: int
    tool_call_accuracy: float
    output_accuracy: float
    avg_latency_ms: float
    test_results: List[AgentTestResult]
    timestamp: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "dataset_name": self.dataset_name,
            "framework": self.framework,
            "model": self.model,
            "mode": self.mode,
            "summary": {
                "total_tests": self.total_tests,
                "passed_tests": self.passed_tests,
                "pass_rate": self.passed_tests / self.total_tests if self.total_tests > 0 else 0,
                "tool_call_accuracy": self.tool_call_accuracy,
                "output_accuracy": self.output_accuracy,
                "avg_latency_ms": self.avg_latency_ms,
            },
            "timestamp": self.timestamp,
        }


class AgentDatasetLoader:
    """Load agent evaluation datasets."""

    @staticmethod
    def load(path: Union[str, Path]) -> Dict[str, Any]:
        """Load dataset from JSON file."""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def parse_tools(data: Dict[str, Any]) -> List[ToolDefinition]:
        """Parse tool definitions from dataset."""
        tools = []
        for tool_data in data.get("tools", []):
            tools.append(ToolDefinition(
                name=tool_data.get("name", ""),
                description=tool_data.get("description", ""),
                parameters=tool_data.get("parameters", {}),
                required_params=tool_data.get("required", []),
                mock_responses=tool_data.get("mock_responses", {}),
                default_response=tool_data.get("default_response", {"status": "success"})
            ))
        return tools

    @staticmethod
    def parse_test_cases(data: Dict[str, Any]) -> List[AgentTestCase]:
        """Parse test cases from dataset."""
        cases = []
        for i, tc_data in enumerate(data.get("test_cases", [])):
            cases.append(AgentTestCase(
                id=tc_data.get("id", f"test_{i}"),
                input=tc_data.get("input", ""),
                expected_tool_calls=tc_data.get("expected_tool_calls", []),
                expected_output_contains=tc_data.get("expected_output_contains", []),
                expected_output=tc_data.get("expected_output"),
                max_turns=tc_data.get("max_turns", 5),
                metadata=tc_data.get("metadata", {})
            ))
        return cases


class ToolCallValidator:
    """Validate tool calls using AST matching (BFCL-style)."""

    @staticmethod
    def validate_ast(tool_call_str: str) -> bool:
        """Check if tool call is valid AST."""
        try:
            # Try to parse as Python function call
            ast.parse(tool_call_str)
            return True
        except SyntaxError:
            pass

        # Try to parse as JSON
        try:
            json.loads(tool_call_str)
            return True
        except json.JSONDecodeError:
            pass

        return False

    @staticmethod
    def extract_tool_calls(response: str) -> List[Dict[str, Any]]:
        """Extract tool calls from model response."""
        tool_calls = []

        # Pattern 1: OpenAI function calling format
        # Already structured, handled by wrapper

        # Pattern 2: Hermes XML format <tool_call>...</tool_call>
        hermes_pattern = r'<tool_call>\s*(\{.*?\})\s*</tool_call>'
        for match in re.finditer(hermes_pattern, response, re.DOTALL):
            try:
                call_data = json.loads(match.group(1))
                tool_calls.append(call_data)
            except json.JSONDecodeError:
                pass

        # Pattern 3: JSON function call format
        json_pattern = r'\{\s*"name"\s*:\s*"([^"]+)".*?"arguments"\s*:\s*(\{[^}]+\})'
        for match in re.finditer(json_pattern, response, re.DOTALL):
            try:
                tool_calls.append({
                    "name": match.group(1),
                    "arguments": json.loads(match.group(2))
                })
            except json.JSONDecodeError:
                pass

        return tool_calls

    @staticmethod
    def compare_tool_calls(
        expected: List[Dict[str, Any]],
        actual: List[Dict[str, Any]]
    ) -> List[ToolCallResult]:
        """Compare expected vs actual tool calls."""
        results = []

        for i, exp in enumerate(expected):
            exp_name = exp.get("name", exp.get("tool_name", ""))
            exp_args = exp.get("args", exp.get("arguments", {}))

            if i < len(actual):
                act = actual[i]
                act_name = act.get("name", act.get("tool_name", ""))
                act_args = act.get("args", act.get("arguments", {}))

                # Compare
                name_match = exp_name == act_name
                args_match = ToolCallValidator._compare_args(exp_args, act_args)

                results.append(ToolCallResult(
                    tool_name=exp_name,
                    expected_args=exp_args,
                    actual_args=act_args,
                    name_match=name_match,
                    args_match=args_match,
                    ast_valid=True
                ))
            else:
                # Missing tool call
                results.append(ToolCallResult(
                    tool_name=exp_name,
                    expected_args=exp_args,
                    actual_args={},
                    name_match=False,
                    args_match=False,
                    ast_valid=False
                ))

        return results

    @staticmethod
    def _compare_args(expected: Dict, actual: Dict) -> bool:
        """Compare arguments, allowing for flexible matching."""
        for key, exp_val in expected.items():
            if key not in actual:
                return False
            act_val = actual[key]

            # Flexible string matching
            if isinstance(exp_val, str) and isinstance(act_val, str):
                if exp_val.lower() not in act_val.lower() and act_val.lower() not in exp_val.lower():
                    return False
            elif exp_val != act_val:
                return False

        return True


class MockToolExecutor:
    """Execute tools with mock responses from dataset."""

    def __init__(self, tools: List[ToolDefinition]):
        self.tools = {t.name: t for t in tools}

    def execute(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute tool with mock response."""
        tool = self.tools.get(tool_name)
        if not tool:
            return {"error": f"Tool '{tool_name}' not found"}

        # Check for specific mock response
        for key, response in tool.mock_responses.items():
            # Check if key matches any argument value
            for arg_val in args.values():
                if isinstance(arg_val, str) and key.lower() in arg_val.lower():
                    return response

        # Return default response
        return tool.default_response or {"status": "success", "args": args}

    def create_tool_functions(self) -> Dict[str, Callable]:
        """Create callable functions for each tool."""
        functions = {}
        for name, tool in self.tools.items():
            # Create closure for each tool
            def make_func(t):
                def func(**kwargs):
                    return self.execute(t.name, kwargs)
                func.__name__ = t.name
                func.__doc__ = t.description
                return func
            functions[name] = make_func(tool)
        return functions


class DockerToolExecutor:
    """Execute tools in Docker sandbox - for real code execution."""

    # Pre-built images with common libraries for each agent type
    AGENT_IMAGES = {
        "hermes": "semcoeval/hermes-agent:latest",
        "default": "semcoeval/agent-base:latest",
    }

    # Dockerfile templates for building agent images
    DOCKERFILES = {
        "hermes": """
FROM python:3.11-slim
RUN pip install --no-cache-dir \\
    requests httpx aiohttp \\
    numpy pandas \\
    beautifulsoup4 lxml \\
    pyyaml toml \\
    python-dotenv \\
    transformers torch --index-url https://download.pytorch.org/whl/cpu
WORKDIR /workspace
""",
        "default": """
FROM python:3.11-slim
RUN pip install --no-cache-dir \\
    requests httpx aiohttp \\
    numpy pandas matplotlib \\
    beautifulsoup4 lxml \\
    pyyaml toml json5 \\
    python-dotenv
WORKDIR /workspace
""",
    }

    def __init__(self, tools: List[ToolDefinition], agent_type: str = "default"):
        self.tools = {t.name: t for t in tools}
        self.agent_type = agent_type
        self._sandbox = None
        self._session = None

    def _get_sandbox(self):
        """Get or create sandbox instance."""
        if self._sandbox is None:
            from .sandbox import DockerSandbox, SandboxConfig
            config = SandboxConfig(
                memory_limit="512m",
                cpu_limit=2.0,
                timeout_seconds=60,
                network_enabled=False
            )
            self._sandbox = DockerSandbox(config)
        return self._sandbox

    def execute(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Execute tool in Docker sandbox."""
        tool = self.tools.get(tool_name)
        if not tool:
            return {"error": f"Tool '{tool_name}' not found"}

        sandbox = self._get_sandbox()

        # Handle common tool types
        if tool_name in ["execute_python", "run_python", "python"]:
            code = args.get("code", args.get("script", ""))
            result = sandbox.execute_code(code, language="python")
            return {
                "success": result.success,
                "output": result.stdout,
                "error": result.stderr if not result.success else None
            }

        elif tool_name in ["execute_bash", "run_bash", "bash", "shell"]:
            command = args.get("command", args.get("cmd", ""))
            result = sandbox.execute_shell(command)
            return {
                "success": result.success,
                "output": result.stdout,
                "error": result.stderr if not result.success else None
            }

        elif tool_name in ["execute_javascript", "run_js", "javascript", "node"]:
            code = args.get("code", args.get("script", ""))
            result = sandbox.execute_code(code, language="javascript")
            return {
                "success": result.success,
                "output": result.stdout,
                "error": result.stderr if not result.success else None
            }

        elif tool_name in ["calculate", "calculator", "math"]:
            expr = args.get("expression", args.get("expr", ""))
            if not self._validate_math_expression(expr):
                return {"result": None, "error": "Invalid expression"}
            code = self._generate_safe_math_code(expr)
            result = sandbox.execute_code(code, language="python")
            return {
                "result": result.stdout.strip() if result.success else None,
                "error": result.stderr if not result.success else None
            }

        else:
            for key, response in tool.mock_responses.items():
                for arg_val in args.values():
                    if isinstance(arg_val, str) and key.lower() in arg_val.lower():
                        return response
            return tool.default_response or {"status": "executed", "args": args}

    @staticmethod
    def _validate_math_expression(expr: str) -> bool:
        """Validate expression contains only safe math characters."""
        import re
        if not re.match(r'^[\d\s\+\-\*\/\(\)\.\^]+$', expr):
            return False
        dangerous = ['__', 'import', 'eval', 'exec', 'open', 'os.', 'subprocess', 'system']
        return not any(p in expr.lower() for p in dangerous)

    @staticmethod
    def _generate_safe_math_code(expr: str) -> str:
        """Generate safe AST-based math evaluation code."""
        safe_expr = expr.replace('^', '**')
        return f'''
import ast, operator
SAFE_OPS = {{
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.USub: operator.neg,
    ast.UAdd: operator.pos, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv,
}}
def safe_eval(node):
    if isinstance(node, ast.Expression): return safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)): return node.value
    if isinstance(node, ast.BinOp):
        op = SAFE_OPS.get(type(node.op))
        if op: return op(safe_eval(node.left), safe_eval(node.right))
    if isinstance(node, ast.UnaryOp):
        op = SAFE_OPS.get(type(node.op))
        if op: return op(safe_eval(node.operand))
    raise ValueError("Invalid expression")
print(safe_eval(ast.parse({repr(safe_expr)}, mode='eval')))
'''

    def create_tool_functions(self) -> Dict[str, Callable]:
        """Create callable functions for each tool."""
        functions = {}
        for name, tool in self.tools.items():
            def make_func(t):
                def func(**kwargs):
                    return self.execute(t.name, kwargs)
                func.__name__ = t.name
                func.__doc__ = t.description
                return func
            functions[name] = make_func(tool)
        return functions

    @classmethod
    def build_image(cls, agent_type: str = "default", tag: Optional[str] = None):
        """Build Docker image for agent type."""
        import subprocess
        import tempfile

        dockerfile = cls.DOCKERFILES.get(agent_type, cls.DOCKERFILES["default"])
        tag = tag or cls.AGENT_IMAGES.get(agent_type, "semcoeval/agent-base:latest")

        with tempfile.TemporaryDirectory() as tmpdir:
            dockerfile_path = os.path.join(tmpdir, "Dockerfile")
            with open(dockerfile_path, "w") as f:
                f.write(dockerfile)

            result = subprocess.run(
                ["docker", "build", "-t", tag, tmpdir],
                capture_output=True,
                text=True
            )
            return result.returncode == 0, result.stdout + result.stderr

    @classmethod
    def prepare_all_images(cls):
        """Build all agent images for offline use."""
        print("Building agent Docker images...")
        for agent_type in cls.DOCKERFILES.keys():
            print(f"  Building {agent_type}...")
            success, output = cls.build_image(agent_type)
            status = "OK" if success else "FAILED"
            print(f"    [{status}]")
        print("Done.")


class AgentRunner:
    """
    Run agent evaluations with dataset-driven configuration.

    Supports multiple frameworks and evaluation modes.

    Usage:
        runner = AgentRunner()

        # Run with AST matching (no execution)
        result = runner.run(
            dataset_path="benchmark.json",
            framework="openai",
            model="gpt-4o",
            mode="ast"
        )

        # Run with mock execution
        result = runner.run(
            dataset_path="benchmark.json",
            framework="langgraph",
            model="gpt-4o",
            mode="mock"
        )
    """

    SUPPORTED_FRAMEWORKS = [
        "openai", "anthropic", "langgraph", "langchain",
        "llamaindex", "crewai", "google_adk", "pydantic_ai",
        "strands", "huggingface", "hermes"
    ]

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self._validator = ToolCallValidator()

    def run(
        self,
        dataset_path: Union[str, Path],
        framework: str,
        model: str,
        mode: Union[str, EvaluationMode] = EvaluationMode.AST_MATCH,
        max_concurrent: int = 1,
        verbose: bool = False
    ) -> AgentBenchmarkResult:
        """
        Run agent benchmark.

        Args:
            dataset_path: Path to agent dataset JSON
            framework: Agent framework to use
            model: Model ID (e.g., gpt-4o, claude-3-5-sonnet)
            mode: Evaluation mode (ast, mock, live)
            max_concurrent: Concurrent test execution
            verbose: Print progress

        Returns:
            AgentBenchmarkResult with all scores
        """
        if isinstance(mode, str):
            mode = EvaluationMode(mode)

        # Load dataset
        loader = AgentDatasetLoader()
        data = loader.load(dataset_path)
        tools = loader.parse_tools(data)
        test_cases = loader.parse_test_cases(data)

        dataset_name = data.get("metadata", {}).get("name", Path(dataset_path).stem)

        if verbose:
            print(f"Loaded {len(test_cases)} test cases with {len(tools)} tools")
            print(f"Mode: {mode.value}")

        # Create executor based on mode
        if mode == EvaluationMode.DOCKER_EXECUTE:
            executor = DockerToolExecutor(tools, agent_type="default")
            if verbose:
                print("Using Docker sandbox for execution")
        else:
            executor = MockToolExecutor(tools)

        # Create agent wrapper
        agent = self._create_agent(framework, model, tools, executor)

        # Run tests
        test_results = []
        for i, tc in enumerate(test_cases):
            if verbose:
                print(f"Running test {i+1}/{len(test_cases)}: {tc.id}")

            result = self._run_single_test(agent, tc, mode, executor)
            test_results.append(result)

        # Calculate metrics
        passed = sum(1 for r in test_results if r.passed)
        tool_accuracies = [r.tool_call_accuracy for r in test_results]
        output_matches = sum(1 for r in test_results if r.output_match)
        latencies = [r.latency_ms for r in test_results]

        from datetime import datetime

        return AgentBenchmarkResult(
            dataset_name=dataset_name,
            framework=framework,
            model=model,
            mode=mode.value,
            total_tests=len(test_cases),
            passed_tests=passed,
            tool_call_accuracy=sum(tool_accuracies) / len(tool_accuracies) if tool_accuracies else 0,
            output_accuracy=output_matches / len(test_results) if test_results else 0,
            avg_latency_ms=sum(latencies) / len(latencies) if latencies else 0,
            test_results=test_results,
            timestamp=datetime.now().isoformat()
        )

    def _create_agent(
        self,
        framework: str,
        model: str,
        tools: List[ToolDefinition],
        executor  # MockToolExecutor or DockerToolExecutor
    ):
        """Create agent wrapper for specified framework."""
        from .base import AgentConfig, AgentTool

        # Convert tools
        agent_tools = []
        tool_functions = executor.create_tool_functions()

        for tool in tools:
            agent_tools.append(AgentTool(
                name=tool.name,
                description=tool.description,
                parameters=tool.parameters,
                required_params=tool.required_params,
                func=tool_functions.get(tool.name)
            ))

        config = AgentConfig(
            model=model,
            tools=agent_tools,
            temperature=0,
            max_iterations=10
        )

        # Create framework-specific wrapper
        if framework == "openai":
            from .openai_agent import OpenAIAgentWrapper
            return OpenAIAgentWrapper(config, api_key=self.api_key)

        elif framework == "anthropic":
            from .anthropic_agent import AnthropicAgentWrapper
            return AnthropicAgentWrapper(config, api_key=self.api_key)

        elif framework == "langgraph":
            from .langgraph_agent import LangGraphAgentWrapper
            return LangGraphAgentWrapper(config)

        elif framework == "langchain":
            from .langchain_agent import LangChainAgentWrapper
            return LangChainAgentWrapper(config)

        elif framework == "llamaindex":
            from .llamaindex_agent import LlamaIndexAgentWrapper
            return LlamaIndexAgentWrapper(config)

        elif framework == "crewai":
            from .crewai_agent import CrewAIAgentWrapper
            return CrewAIAgentWrapper(config)

        elif framework == "google_adk":
            from .google_adk_agent import GoogleADKAgentWrapper
            return GoogleADKAgentWrapper(config)

        elif framework == "pydantic_ai":
            from .pydantic_agent import PydanticAIAgentWrapper
            return PydanticAIAgentWrapper(config)

        elif framework == "huggingface":
            from .huggingface_agent import HuggingFaceAgentWrapper
            return HuggingFaceAgentWrapper(config)

        elif framework == "strands":
            from .strands_agent import StrandsAgentWrapper
            return StrandsAgentWrapper(config)

        elif framework == "hermes":
            from .hermes_agent import HermesAgentWrapper
            return HermesAgentWrapper(config, api_key=self.api_key)

        else:
            raise ValueError(f"Unknown framework: {framework}. Supported: {self.SUPPORTED_FRAMEWORKS}")

    def _run_single_test(
        self,
        agent,
        test_case: AgentTestCase,
        mode: EvaluationMode,
        executor  # MockToolExecutor or DockerToolExecutor
    ) -> AgentTestResult:
        """Run a single test case."""
        start_time = time.time()

        try:
            # Initialize and run agent
            agent.initialize()
            trace = agent.run(test_case.input)

            latency_ms = int((time.time() - start_time) * 1000)

            # Extract actual tool calls from trace
            actual_tool_calls = [
                {"name": a.tool_name, "arguments": a.tool_input}
                for a in trace.actions
            ]

            # Compare tool calls
            tool_results = self._validator.compare_tool_calls(
                test_case.expected_tool_calls,
                actual_tool_calls
            )

            # Calculate tool call accuracy
            if tool_results:
                correct = sum(1 for r in tool_results if r.name_match and r.args_match)
                tool_accuracy = correct / len(tool_results)
            else:
                tool_accuracy = 1.0 if not test_case.expected_tool_calls else 0.0

            # Check output
            output_match = self._check_output(
                trace.output,
                test_case.expected_output,
                test_case.expected_output_contains
            )

            # Determine if passed
            passed = tool_accuracy >= 0.8 and output_match

            return AgentTestResult(
                test_id=test_case.id,
                input=test_case.input,
                actual_output=trace.output,
                expected_output=test_case.expected_output,
                tool_calls=tool_results,
                tool_call_accuracy=tool_accuracy,
                output_match=output_match,
                passed=passed,
                latency_ms=latency_ms
            )

        except Exception as e:
            return AgentTestResult(
                test_id=test_case.id,
                input=test_case.input,
                actual_output="",
                expected_output=test_case.expected_output,
                tool_calls=[],
                tool_call_accuracy=0,
                output_match=False,
                passed=False,
                latency_ms=int((time.time() - start_time) * 1000),
                error=str(e)
            )

    def _check_output(
        self,
        actual: str,
        expected: Optional[str],
        expected_contains: List[str]
    ) -> bool:
        """Check if output matches expectations."""
        if not actual:
            return False

        actual_lower = actual.lower()

        # Check exact match
        if expected and expected.lower() in actual_lower:
            return True

        # Check contains
        if expected_contains:
            return all(kw.lower() in actual_lower for kw in expected_contains)

        # If no expected output specified, consider it a match
        if not expected and not expected_contains:
            return True

        return False

    @staticmethod
    def create_sample_dataset(output_path: Union[str, Path]):
        """Create a sample agent benchmark dataset."""
        sample = {
            "metadata": {
                "name": "Sample Agent Benchmark",
                "version": "1.0",
                "type": "agent"
            },
            "tools": [
                {
                    "name": "get_weather",
                    "description": "Get current weather for a location",
                    "parameters": {
                        "location": {"type": "string", "description": "City name"}
                    },
                    "required": ["location"],
                    "mock_responses": {
                        "tokyo": {"temp": 25, "condition": "sunny", "humidity": 60},
                        "paris": {"temp": 18, "condition": "cloudy", "humidity": 75},
                        "london": {"temp": 15, "condition": "rainy", "humidity": 85}
                    },
                    "default_response": {"temp": 20, "condition": "unknown"}
                },
                {
                    "name": "calculate",
                    "description": "Perform mathematical calculations",
                    "parameters": {
                        "expression": {"type": "string", "description": "Math expression"}
                    },
                    "required": ["expression"],
                    "mock_responses": {},
                    "default_response": {"result": "calculated"}
                },
                {
                    "name": "search_web",
                    "description": "Search the web for information",
                    "parameters": {
                        "query": {"type": "string", "description": "Search query"}
                    },
                    "required": ["query"],
                    "mock_responses": {
                        "ai": {"results": ["AI news", "AI research", "AI tools"]},
                        "weather": {"results": ["Weather forecast", "Climate data"]}
                    },
                    "default_response": {"results": ["Result 1", "Result 2"]}
                }
            ],
            "test_cases": [
                {
                    "id": "weather_1",
                    "input": "What's the weather in Tokyo?",
                    "expected_tool_calls": [
                        {"name": "get_weather", "args": {"location": "Tokyo"}}
                    ],
                    "expected_output_contains": ["25", "sunny"]
                },
                {
                    "id": "weather_2",
                    "input": "Tell me the weather in Paris and London",
                    "expected_tool_calls": [
                        {"name": "get_weather", "args": {"location": "Paris"}},
                        {"name": "get_weather", "args": {"location": "London"}}
                    ],
                    "expected_output_contains": ["paris", "london"]
                },
                {
                    "id": "calc_1",
                    "input": "What is 15 * 24?",
                    "expected_tool_calls": [
                        {"name": "calculate", "args": {"expression": "15 * 24"}}
                    ],
                    "expected_output_contains": ["360"]
                },
                {
                    "id": "multi_tool_1",
                    "input": "Search for AI news and then calculate 100 + 50",
                    "expected_tool_calls": [
                        {"name": "search_web", "args": {"query": "AI news"}},
                        {"name": "calculate", "args": {"expression": "100 + 50"}}
                    ],
                    "expected_output_contains": ["150"]
                }
            ]
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(sample, f, indent=2)

        return output_path


# Convenience function
def run_agent_benchmark(
    dataset_path: str,
    framework: str,
    model: str,
    mode: str = "ast",
    api_key: Optional[str] = None,
    verbose: bool = True
) -> AgentBenchmarkResult:
    """
    Run an agent benchmark.

    Args:
        dataset_path: Path to agent dataset JSON
        framework: Agent framework (openai, langgraph, anthropic, etc.)
        model: Model ID
        mode: Evaluation mode (ast, mock, live)
        api_key: Optional API key
        verbose: Print progress

    Returns:
        AgentBenchmarkResult

    Example:
        result = run_agent_benchmark(
            "my_benchmark.json",
            framework="openai",
            model="gpt-4o",
            mode="mock"
        )
        print(f"Pass rate: {result.passed_tests}/{result.total_tests}")
    """
    runner = AgentRunner(api_key=api_key)
    return runner.run(
        dataset_path=dataset_path,
        framework=framework,
        model=model,
        mode=mode,
        verbose=verbose
    )
