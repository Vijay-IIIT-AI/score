"""
Strands Agent Wrapper - Integration with AWS Strands Agents for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class StrandsAgentWrapper(BaseAgentWrapper):
    """
    AWS Strands Agents wrapper for DeepEval evaluation.

    Strands is AWS's SDK for building AI agents.

    Usage:
        config = AgentConfig(model="anthropic.claude-3-5-sonnet-20241022-v2:0")
        wrapper = StrandsAgentWrapper(config)
        wrapper.add_tool(AgentTool(
            name="calculator",
            description="Perform calculations",
            func=calc_func
        ))
        wrapper.initialize()
        trace = wrapper.run("Calculate 15% tip on $85")
    """

    def __init__(
        self,
        config: AgentConfig,
        region_name: Optional[str] = None
    ):
        super().__init__(config)
        self._region_name = region_name or "us-east-1"
        self._strands_agent = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.STRANDS

    @property
    def name(self) -> str:
        return "AWS Strands"

    def initialize(self) -> bool:
        """Initialize Strands agent."""
        try:
            from strands import Agent
            from strands.models import BedrockModel

            # Create Bedrock model
            model = BedrockModel(
                model_id=self.config.model,
                region_name=self._region_name
            )

            # Build tools
            tools = self._build_tools()

            # Create agent
            self._strands_agent = Agent(
                model=model,
                tools=tools,
                system_prompt=self.config.system_prompt
            )

            return True
        except ImportError as e:
            raise ImportError(f"Strands not installed: {e}. Run: pip install strands-agents")
        except Exception:
            return False

    def _build_tools(self) -> List[Any]:
        """Build Strands tools from AgentTools."""
        strands_tools = []

        try:
            from strands.tools import tool

            for agent_tool in self.config.tools:
                if agent_tool.func:
                    # Decorate function as Strands tool
                    decorated = tool(
                        name=agent_tool.name,
                        description=agent_tool.description
                    )(agent_tool.func)
                    strands_tools.append(decorated)
        except ImportError:
            pass

        return strands_tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the Strands agent."""
        if not self._strands_agent:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize agent"
                )

        start_time = time.time()
        actions = []
        total_tokens = 0

        try:
            # Run agent
            response = self._strands_agent(input_text)
            output = str(response)

            # Extract tool calls if available
            if hasattr(response, 'tool_calls'):
                for tc in response.tool_calls:
                    actions.append(AgentAction(
                        tool_name=tc.name if hasattr(tc, 'name') else "unknown",
                        tool_input=tc.input if hasattr(tc, 'input') else {},
                        tool_output=tc.output if hasattr(tc, 'output') else None
                    ))

            # Get token usage
            if hasattr(response, 'usage'):
                total_tokens = response.usage.total_tokens if hasattr(response.usage, 'total_tokens') else 0

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                total_tokens=total_tokens,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_agent(agent: Any, config: Optional[AgentConfig] = None) -> "StrandsAgentWrapper":
        """Create wrapper from existing Strands agent."""
        wrapper = StrandsAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._strands_agent = agent
        return wrapper
