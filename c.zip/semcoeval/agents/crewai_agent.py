"""
CrewAI Agent Wrapper - Integration with CrewAI for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class CrewAIAgentWrapper(BaseAgentWrapper):
    """
    CrewAI agent wrapper for DeepEval evaluation.

    CrewAI enables multi-agent collaboration with role-based agents.

    Usage:
        config = AgentConfig(model="gpt-4o")
        wrapper = CrewAIAgentWrapper(config)
        wrapper.set_crew_config(
            agents=[
                {"role": "Researcher", "goal": "Find information"},
                {"role": "Writer", "goal": "Write content"}
            ],
            tasks=[
                {"description": "Research AI trends", "agent": "Researcher"},
                {"description": "Write a summary", "agent": "Writer"}
            ]
        )
        wrapper.initialize()
        trace = wrapper.run("Create a report on AI trends")
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self._crew = None
        self._agents_config: List[Dict[str, Any]] = []
        self._tasks_config: List[Dict[str, Any]] = []

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.CREWAI

    @property
    def name(self) -> str:
        return "CrewAI"

    def set_crew_config(
        self,
        agents: List[Dict[str, Any]],
        tasks: List[Dict[str, Any]]
    ) -> None:
        """
        Set the crew configuration.

        Args:
            agents: List of agent configs with 'role', 'goal', 'backstory'
            tasks: List of task configs with 'description', 'agent', 'expected_output'
        """
        self._agents_config = agents
        self._tasks_config = tasks

    def initialize(self) -> bool:
        """Initialize CrewAI crew."""
        try:
            from crewai import Agent, Task, Crew, Process
            from langchain_openai import ChatOpenAI

            # Create LLM
            llm = ChatOpenAI(
                model=self.config.model,
                temperature=self.config.temperature
            )

            # Create agents
            agents = {}
            for agent_cfg in self._agents_config:
                agent = Agent(
                    role=agent_cfg.get("role", "Assistant"),
                    goal=agent_cfg.get("goal", "Help the user"),
                    backstory=agent_cfg.get("backstory", ""),
                    llm=llm,
                    tools=self._convert_tools(),
                    verbose=self.config.verbose
                )
                agents[agent_cfg.get("role")] = agent

            # Create tasks
            tasks = []
            for task_cfg in self._tasks_config:
                agent_role = task_cfg.get("agent")
                agent = agents.get(agent_role, list(agents.values())[0] if agents else None)

                if agent:
                    task = Task(
                        description=task_cfg.get("description", ""),
                        expected_output=task_cfg.get("expected_output", "A complete response"),
                        agent=agent
                    )
                    tasks.append(task)

            # Create crew
            self._crew = Crew(
                agents=list(agents.values()),
                tasks=tasks,
                process=Process.sequential,
                verbose=self.config.verbose
            )

            return True
        except ImportError as e:
            raise ImportError(f"CrewAI not installed: {e}. Run: pip install crewai")
        except Exception:
            return False

    def _convert_tools(self) -> List[Any]:
        """Convert AgentTools to CrewAI tools."""
        crewai_tools = []

        try:
            from crewai_tools import tool

            for agent_tool in self.config.tools:
                if agent_tool.func:
                    # Wrap function as CrewAI tool
                    decorated = tool(agent_tool.func)
                    crewai_tools.append(decorated)
        except ImportError:
            pass

        return crewai_tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the CrewAI crew."""
        if not self._crew:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize crew"
                )

        start_time = time.time()
        actions = []
        intermediate_steps = []

        try:
            # Kickoff the crew
            result = self._crew.kickoff(inputs={"input": input_text})
            output = str(result)

            # Extract task outputs as intermediate steps
            if hasattr(result, 'tasks_output'):
                for task_output in result.tasks_output:
                    intermediate_steps.append({
                        "task": task_output.description if hasattr(task_output, 'description') else "task",
                        "output": str(task_output)
                    })

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                intermediate_steps=intermediate_steps,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_crew(crew: Any, config: Optional[AgentConfig] = None) -> "CrewAIAgentWrapper":
        """Create wrapper from existing CrewAI Crew."""
        wrapper = CrewAIAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._crew = crew
        return wrapper
