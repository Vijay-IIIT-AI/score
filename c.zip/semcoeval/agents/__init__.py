"""
Agent Framework Integrations for SemcoEval.

Provides unified wrappers for evaluating AI agents built with various frameworks.
"""

from .base import (
    BaseAgentWrapper,
    AgentFramework,
    AgentConfig,
    AgentTool,
    AgentAction,
    AgentTrace
)

from .langchain_agent import LangChainAgentWrapper
from .langgraph_agent import LangGraphAgentWrapper
from .llamaindex_agent import LlamaIndexAgentWrapper
from .crewai_agent import CrewAIAgentWrapper
from .openai_agent import OpenAIAgentWrapper
from .anthropic_agent import AnthropicAgentWrapper
from .google_adk_agent import GoogleADKAgentWrapper
from .pydantic_agent import PydanticAIAgentWrapper
from .strands_agent import StrandsAgentWrapper
from .huggingface_agent import HuggingFaceAgentWrapper
from .hermes_agent import HermesAgentWrapper, create_hermes_agent, HERMES_MODELS

from .registry import AgentRegistry, evaluate_agent
from .runner import (
    AgentRunner,
    AgentDatasetLoader,
    AgentTestCase,
    AgentTestResult,
    AgentBenchmarkResult,
    EvaluationMode,
    ToolDefinition,
    MockToolExecutor,
    DockerToolExecutor,
    run_agent_benchmark,
)
from .sandbox import (
    DockerSandbox,
    SandboxSession,
    SandboxConfig,
    SandboxResult,
    SandboxLanguage,
    SandboxedToolExecutor,
    prepare_offline_sandbox,
)

__all__ = [
    # Base classes
    "BaseAgentWrapper",
    "AgentFramework",
    "AgentConfig",
    "AgentTool",
    "AgentAction",
    "AgentTrace",
    # Agent wrappers
    "LangChainAgentWrapper",
    "LangGraphAgentWrapper",
    "LlamaIndexAgentWrapper",
    "CrewAIAgentWrapper",
    "OpenAIAgentWrapper",
    "AnthropicAgentWrapper",
    "GoogleADKAgentWrapper",
    "PydanticAIAgentWrapper",
    "StrandsAgentWrapper",
    "HuggingFaceAgentWrapper",
    "HermesAgentWrapper",
    "create_hermes_agent",
    "HERMES_MODELS",
    # Registry
    "AgentRegistry",
    "evaluate_agent",
    # Runner (auto-execute agents from datasets)
    "AgentRunner",
    "AgentDatasetLoader",
    "AgentTestCase",
    "AgentTestResult",
    "AgentBenchmarkResult",
    "EvaluationMode",
    "ToolDefinition",
    "MockToolExecutor",
    "DockerToolExecutor",
    "run_agent_benchmark",
    # Sandbox (offline Docker execution)
    "DockerSandbox",
    "SandboxSession",
    "SandboxConfig",
    "SandboxResult",
    "SandboxLanguage",
    "SandboxedToolExecutor",
    "prepare_offline_sandbox",
]
