"""
LlamaIndex Agent Wrapper - Integration with LlamaIndex agents for DeepEval.
"""

import time
from typing import Any, Dict, List, Optional
from .base import (
    BaseAgentWrapper, AgentFramework, AgentConfig, AgentTool,
    AgentAction, AgentTrace
)


class LlamaIndexAgentWrapper(BaseAgentWrapper):
    """
    LlamaIndex agent wrapper for DeepEval evaluation.

    Supports:
    - LlamaIndex ReActAgent
    - LlamaIndex tools and query engines
    - RAG-enhanced agents

    Usage:
        config = AgentConfig(model="gpt-4o")
        wrapper = LlamaIndexAgentWrapper(config)
        wrapper.initialize()
        trace = wrapper.run("What are the main themes in the document?")
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self._llm = None

    @property
    def framework(self) -> AgentFramework:
        return AgentFramework.LLAMAINDEX

    @property
    def name(self) -> str:
        return "LlamaIndex"

    def initialize(self) -> bool:
        """Initialize LlamaIndex agent."""
        try:
            from llama_index.llms.openai import OpenAI
            from llama_index.core.agent import ReActAgent

            # Create LLM
            self._llm = OpenAI(
                model=self.config.model,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )

            # Convert and set up tools
            tools = self._convert_tools()

            if tools:
                self._agent = ReActAgent.from_tools(
                    tools,
                    llm=self._llm,
                    verbose=self.config.verbose,
                    max_iterations=self.config.max_iterations
                )
            else:
                # No tools, agent will use LLM directly
                self._agent = ReActAgent.from_tools(
                    [],
                    llm=self._llm,
                    verbose=self.config.verbose
                )

            return True
        except ImportError as e:
            raise ImportError(f"LlamaIndex not installed: {e}. Run: pip install llama-index llama-index-llms-openai")
        except Exception:
            return False

    def _convert_tools(self) -> List[Any]:
        """Convert AgentTools to LlamaIndex tools."""
        llamaindex_tools = []

        try:
            from llama_index.core.tools import FunctionTool

            for tool in self.config.tools:
                if tool.func:
                    li_tool = FunctionTool.from_defaults(
                        fn=tool.func,
                        name=tool.name,
                        description=tool.description
                    )
                    llamaindex_tools.append(li_tool)
        except ImportError:
            pass

        return llamaindex_tools

    def add_tool(self, tool: AgentTool) -> None:
        """Add a tool to the agent."""
        self.config.tools.append(tool)

    def run(self, input_text: str, **kwargs) -> AgentTrace:
        """Run the LlamaIndex agent."""
        if not self._agent:
            if not self.initialize():
                return AgentTrace(
                    input=input_text,
                    output="",
                    success=False,
                    error="Failed to initialize agent"
                )

        start_time = time.time()
        actions = []
        intermediate_steps = []

        try:
            # Run agent
            response = self._agent.chat(input_text)
            output = str(response)

            # Extract tool calls from response sources
            if hasattr(response, 'sources'):
                for source in response.sources:
                    if hasattr(source, 'tool_name'):
                        actions.append(AgentAction(
                            tool_name=source.tool_name,
                            tool_input=source.raw_input if hasattr(source, 'raw_input') else {},
                            tool_output=source.raw_output if hasattr(source, 'raw_output') else None
                        ))

            duration_ms = int((time.time() - start_time) * 1000)

            return AgentTrace(
                input=input_text,
                output=output,
                actions=actions,
                intermediate_steps=intermediate_steps,
                duration_ms=duration_ms,
                success=True
            )

        except Exception as e:
            return AgentTrace(
                input=input_text,
                output="",
                duration_ms=int((time.time() - start_time) * 1000),
                success=False,
                error=str(e)
            )

    @staticmethod
    def from_agent(agent: Any, config: Optional[AgentConfig] = None) -> "LlamaIndexAgentWrapper":
        """Create wrapper from existing LlamaIndex agent."""
        wrapper = LlamaIndexAgentWrapper(config or AgentConfig(model="unknown"))
        wrapper._agent = agent
        return wrapper
