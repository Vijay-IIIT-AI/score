"""
Test Visual Builder (Condition Metric) - All operators, gates, and error handling
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import create_condition_metric, ConditionMetric
from deepeval.test_case import LLMTestCase, ToolCall


def test_all_operators():
    """Test all operators work correctly"""
    print("\n" + "="*60)
    print("TEST: All Operators")
    print("="*60)

    tc = LLMTestCase(
        input="What is the capital of France?",
        actual_output="Paris is the capital of France.",
        expected_output="Paris",
        context=["France is a country in Europe."],
        retrieval_context=["Paris is the largest city in France."]
    )

    operators = [
        ("contains", "actual_output", "Paris", True),
        ("contains", "actual_output", "London", False),
        ("not_contains", "actual_output", "London", True),
        ("not_contains", "actual_output", "Paris", False),
        ("equals", "expected_output", "Paris", True),
        ("equals", "expected_output", "London", False),
        ("starts_with", "actual_output", "Paris", True),
        ("starts_with", "actual_output", "London", False),
        ("ends_with", "actual_output", "France.", True),
        ("ends_with", "actual_output", "London.", False),
        ("length_gt", "actual_output", "10", True),
        ("length_gt", "actual_output", "100", False),
        ("length_lt", "actual_output", "100", True),
        ("length_lt", "actual_output", "10", False),
        ("regex", "actual_output", r"capital.*France", True),
        ("regex", "actual_output", r"capital.*Germany", False),
    ]

    all_pass = True
    for op, field, value, expected in operators:
        metric = create_condition_metric(
            name=f"Test_{op}",
            rules=[{"field": field, "operator": op, "value": value}]
        )
        score = metric.measure(tc)
        passed = (score == 1.0) == expected
        status = "OK" if passed else "FAIL"
        print(f"  {op}({field}, '{value}'): score={score}, expected={expected} - {status}")
        if not passed:
            all_pass = False

    return all_pass


def test_and_gate():
    """Test AND gate logic"""
    print("\n" + "="*60)
    print("TEST: AND Gate")
    print("="*60)

    tc = LLMTestCase(
        input="Question",
        actual_output="Paris is the capital of France.",
        expected_output="Paris"
    )

    # Both true -> should pass
    metric1 = create_condition_metric(
        name="AND_BothTrue",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "contains", "value": "France"}
        ],
        gates=["AND"]
    )
    score1 = metric1.measure(tc)
    print(f"  AND(Paris, France): score={score1} (expected 1.0)")

    # First true, second false -> should fail
    metric2 = create_condition_metric(
        name="AND_OneFalse",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "contains", "value": "London"}
        ],
        gates=["AND"]
    )
    score2 = metric2.measure(tc)
    print(f"  AND(Paris, London): score={score2} (expected 0.0)")

    # Both false -> should fail
    metric3 = create_condition_metric(
        name="AND_BothFalse",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Berlin"},
            {"field": "actual_output", "operator": "contains", "value": "London"}
        ],
        gates=["AND"]
    )
    score3 = metric3.measure(tc)
    print(f"  AND(Berlin, London): score={score3} (expected 0.0)")

    return score1 == 1.0 and score2 == 0.0 and score3 == 0.0


def test_or_gate():
    """Test OR gate logic"""
    print("\n" + "="*60)
    print("TEST: OR Gate")
    print("="*60)

    tc = LLMTestCase(
        input="Question",
        actual_output="Paris is the capital of France.",
        expected_output="Paris"
    )

    # Both true -> should pass
    metric1 = create_condition_metric(
        name="OR_BothTrue",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "contains", "value": "France"}
        ],
        gates=["OR"]
    )
    score1 = metric1.measure(tc)
    print(f"  OR(Paris, France): score={score1} (expected 1.0)")

    # First true, second false -> should pass
    metric2 = create_condition_metric(
        name="OR_OneFalse",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "contains", "value": "London"}
        ],
        gates=["OR"]
    )
    score2 = metric2.measure(tc)
    print(f"  OR(Paris, London): score={score2} (expected 1.0)")

    # First false, second true -> should pass
    metric3 = create_condition_metric(
        name="OR_FirstFalse",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "London"},
            {"field": "actual_output", "operator": "contains", "value": "Paris"}
        ],
        gates=["OR"]
    )
    score3 = metric3.measure(tc)
    print(f"  OR(London, Paris): score={score3} (expected 1.0)")

    # Both false -> should fail
    metric4 = create_condition_metric(
        name="OR_BothFalse",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Berlin"},
            {"field": "actual_output", "operator": "contains", "value": "London"}
        ],
        gates=["OR"]
    )
    score4 = metric4.measure(tc)
    print(f"  OR(Berlin, London): score={score4} (expected 0.0)")

    return score1 == 1.0 and score2 == 1.0 and score3 == 1.0 and score4 == 0.0


def test_mixed_gates():
    """Test mixed AND/OR gates"""
    print("\n" + "="*60)
    print("TEST: Mixed Gates (A AND B OR C)")
    print("="*60)

    tc = LLMTestCase(
        input="Question",
        actual_output="Paris is the capital of France.",
        expected_output="Paris"
    )

    # (Paris AND France) OR London = (T AND T) OR F = T
    metric1 = create_condition_metric(
        name="Mixed1",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "contains", "value": "France"},
            {"field": "actual_output", "operator": "contains", "value": "London"}
        ],
        gates=["AND", "OR"]
    )
    score1 = metric1.measure(tc)
    print(f"  (Paris AND France) OR London: score={score1} (expected 1.0)")

    # (Paris AND London) OR France = (T AND F) OR T = T
    metric2 = create_condition_metric(
        name="Mixed2",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "contains", "value": "London"},
            {"field": "actual_output", "operator": "contains", "value": "France"}
        ],
        gates=["AND", "OR"]
    )
    score2 = metric2.measure(tc)
    print(f"  (Paris AND London) OR France: score={score2} (expected 1.0)")

    # (Berlin AND London) OR Tokyo = (F AND F) OR F = F
    metric3 = create_condition_metric(
        name="Mixed3",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Berlin"},
            {"field": "actual_output", "operator": "contains", "value": "London"},
            {"field": "actual_output", "operator": "contains", "value": "Tokyo"}
        ],
        gates=["AND", "OR"]
    )
    score3 = metric3.measure(tc)
    print(f"  (Berlin AND London) OR Tokyo: score={score3} (expected 0.0)")

    return score1 == 1.0 and score2 == 1.0 and score3 == 0.0


def test_all_fields():
    """Test all available fields"""
    print("\n" + "="*60)
    print("TEST: All Fields")
    print("="*60)

    tc = LLMTestCase(
        input="What is Python?",
        actual_output="Python is a programming language.",
        expected_output="programming language",
        context=["Python was created by Guido."],
        retrieval_context=["Python is high-level.", "Python is interpreted."],
        tools_called=[ToolCall(name="search", input_parameters={"q": "python"})],
        expected_tools=[ToolCall(name="search")]
    )

    fields = [
        ("input", "contains", "Python", True),
        ("actual_output", "contains", "programming", True),
        ("expected_output", "contains", "language", True),
        ("context", "contains", "Guido", True),
        ("retrieval_context", "contains", "high-level", True),
        ("tools_called", "contains", "search", True),
        ("expected_tools", "contains", "search", True),
    ]

    all_pass = True
    for field, op, value, expected in fields:
        metric = create_condition_metric(
            name=f"Field_{field}",
            rules=[{"field": field, "operator": op, "value": value}]
        )
        score = metric.measure(tc)
        passed = (score == 1.0) == expected
        status = "OK" if passed else "FAIL"
        print(f"  {field}.{op}('{value}'): score={score} - {status}")
        if not passed:
            all_pass = False

    return all_pass


def test_compare_to_field():
    """Test comparing fields to each other"""
    print("\n" + "="*60)
    print("TEST: Compare Fields")
    print("="*60)

    # Output contains expected
    tc1 = LLMTestCase(
        input="Question",
        actual_output="The answer is Paris",
        expected_output="Paris"
    )

    metric1 = create_condition_metric(
        name="OutputContainsExpected",
        rules=[{"field": "actual_output", "operator": "contains", "value": "expected_output", "compare_to_field": True}]
    )
    score1 = metric1.measure(tc1)
    print(f"  actual_output contains [expected_output]: score={score1} (expected 1.0)")

    # Output does NOT contain expected
    tc2 = LLMTestCase(
        input="Question",
        actual_output="The answer is London",
        expected_output="Paris"
    )
    score2 = metric1.measure(tc2)
    print(f"  'London' contains [Paris]: score={score2} (expected 0.0)")

    return score1 == 1.0 and score2 == 0.0


def test_error_handling_empty_rules():
    """Test error handling - empty rules"""
    print("\n" + "="*60)
    print("TEST: Error Handling - Empty Rules")
    print("="*60)

    tc = LLMTestCase(input="test", actual_output="test")

    metric = create_condition_metric(name="EmptyRules", rules=[])
    score = metric.measure(tc)
    print(f"  Empty rules: score={score}, reason='{metric.reason}'")

    return score == 0.0 and "No rules" in metric.reason


def test_error_handling_missing_field():
    """Test error handling - missing/empty field values"""
    print("\n" + "="*60)
    print("TEST: Error Handling - Missing Fields")
    print("="*60)

    tc = LLMTestCase(
        input="test",
        actual_output=None,  # Missing output
        expected_output=None
    )

    metric = create_condition_metric(
        name="MissingField",
        rules=[{"field": "actual_output", "operator": "contains", "value": "test"}]
    )
    score = metric.measure(tc)
    print(f"  Missing actual_output: score={score} (expected 0.0)")

    return score == 0.0


def test_error_handling_invalid_regex():
    """Test error handling - invalid regex pattern"""
    print("\n" + "="*60)
    print("TEST: Error Handling - Invalid Regex")
    print("="*60)

    tc = LLMTestCase(input="test", actual_output="test output")

    metric = create_condition_metric(
        name="InvalidRegex",
        rules=[{"field": "actual_output", "operator": "regex", "value": "[invalid(regex"}]
    )
    score = metric.measure(tc)
    print(f"  Invalid regex '[invalid(regex': score={score} (expected 0.0)")

    return score == 0.0


def test_error_handling_invalid_length():
    """Test error handling - invalid length value"""
    print("\n" + "="*60)
    print("TEST: Error Handling - Invalid Length Value")
    print("="*60)

    tc = LLMTestCase(input="test", actual_output="test output")

    metric = create_condition_metric(
        name="InvalidLength",
        rules=[{"field": "actual_output", "operator": "length_gt", "value": "not_a_number"}]
    )
    score = metric.measure(tc)
    print(f"  length_gt 'not_a_number': score={score} (expected 0.0)")

    return score == 0.0


def test_threshold():
    """Test threshold behavior"""
    print("\n" + "="*60)
    print("TEST: Threshold")
    print("="*60)

    tc = LLMTestCase(input="test", actual_output="Paris")

    # With threshold=1.0, score must be 1.0 to succeed
    metric1 = create_condition_metric(
        name="Threshold1",
        rules=[{"field": "actual_output", "operator": "contains", "value": "Paris"}],
        threshold=1.0
    )
    metric1.measure(tc)
    print(f"  Score=1.0, Threshold=1.0: success={metric1.success} (expected True)")

    # Failing rule with threshold
    metric2 = create_condition_metric(
        name="Threshold2",
        rules=[{"field": "actual_output", "operator": "contains", "value": "London"}],
        threshold=0.5
    )
    metric2.measure(tc)
    print(f"  Score=0.0, Threshold=0.5: success={metric2.success} (expected False)")

    return metric1.success == True and metric2.success == False


def test_rag_specific():
    """Test RAG-specific conditions"""
    print("\n" + "="*60)
    print("TEST: RAG Specific Conditions")
    print("="*60)

    tc = LLMTestCase(
        input="What causes rain?",
        actual_output="Rain is caused by water vapor condensing.",
        retrieval_context=[
            "The water cycle involves evaporation and condensation.",
            "Clouds form when water vapor cools."
        ]
    )

    # Check output grounded in context
    metric = create_condition_metric(
        name="RAGGrounded",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "water"},
            {"field": "retrieval_context", "operator": "contains", "value": "water"},
            {"field": "retrieval_context", "operator": "length_gt", "value": "50"}
        ],
        gates=["AND", "AND"]
    )
    score = metric.measure(tc)
    print(f"  RAG grounding check: score={score}")
    print(f"  Reason: {metric.reason}")

    return score == 1.0


def test_agent_specific():
    """Test Agent-specific conditions"""
    print("\n" + "="*60)
    print("TEST: Agent Specific Conditions")
    print("="*60)

    tc = LLMTestCase(
        input="Search for weather",
        actual_output="Weather is sunny",
        tools_called=[
            ToolCall(name="weather_api", input_parameters={"city": "Tokyo"}),
            ToolCall(name="format_response", input_parameters={})
        ],
        expected_tools=[
            ToolCall(name="weather_api")
        ]
    )

    # Check correct tool was called
    metric = create_condition_metric(
        name="AgentToolCheck",
        rules=[
            {"field": "tools_called", "operator": "contains", "value": "weather_api"},
            {"field": "actual_output", "operator": "length_gt", "value": "5"}
        ],
        gates=["AND"]
    )
    score = metric.measure(tc)
    print(f"  Agent tool check: score={score}")
    print(f"  Reason: {metric.reason}")

    return score == 1.0


def run_all_tests():
    """Run all visual builder tests"""
    print("="*60)
    print("VISUAL BUILDER (CONDITION METRIC) TESTS")
    print("="*60)

    tests = [
        ("All Operators", test_all_operators),
        ("AND Gate", test_and_gate),
        ("OR Gate", test_or_gate),
        ("Mixed Gates", test_mixed_gates),
        ("All Fields", test_all_fields),
        ("Compare Fields", test_compare_to_field),
        ("Empty Rules", test_error_handling_empty_rules),
        ("Missing Fields", test_error_handling_missing_field),
        ("Invalid Regex", test_error_handling_invalid_regex),
        ("Invalid Length", test_error_handling_invalid_length),
        ("Threshold", test_threshold),
        ("RAG Specific", test_rag_specific),
        ("Agent Specific", test_agent_specific),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
