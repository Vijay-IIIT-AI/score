"""
Test Limits and Validation for Condition Metrics
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import (
    create_condition_metric,
    MetricValidationError,
    MAX_RULES,
    MAX_VALUE_LENGTH,
    MAX_NAME_LENGTH,
    VALID_FIELDS,
)
from deepeval.test_case import LLMTestCase


def test_max_rules_limit():
    """Test MAX_RULES limit"""
    print("\n" + "="*60)
    print(f"TEST: MAX_RULES limit ({MAX_RULES})")
    print("="*60)

    # Create rules exceeding limit
    rules = [{"field": "actual_output", "operator": "contains", "value": f"test{i}"} for i in range(MAX_RULES + 1)]

    try:
        metric = create_condition_metric(name="TooManyRules", rules=rules)
        print("  FAIL - Should have raised error")
        return False
    except MetricValidationError as e:
        print(f"  Error: {e}")
        return "Maximum" in str(e) and str(MAX_RULES) in str(e)
    except Exception as e:
        print(f"  Unexpected: {type(e).__name__}: {e}")
        return False


def test_max_rules_at_limit():
    """Test exactly at MAX_RULES limit"""
    print("\n" + "="*60)
    print(f"TEST: Exactly {MAX_RULES} rules (should work)")
    print("="*60)

    rules = [{"field": "actual_output", "operator": "contains", "value": f"test{i}"} for i in range(MAX_RULES)]
    gates = ["AND"] * (MAX_RULES - 1) if MAX_RULES > 1 else []

    try:
        metric = create_condition_metric(name="AtLimit", rules=rules, gates=gates)
        tc = LLMTestCase(input="test", actual_output="test0 test1 test2 test3 test4")
        score = metric.measure(tc)
        print(f"  Created: {metric.__name__}, score={score}")
        return True
    except Exception as e:
        print(f"  Error: {type(e).__name__}: {e}")
        return False


def test_max_value_length():
    """Test MAX_VALUE_LENGTH limit"""
    print("\n" + "="*60)
    print(f"TEST: MAX_VALUE_LENGTH limit ({MAX_VALUE_LENGTH})")
    print("="*60)

    long_value = "x" * (MAX_VALUE_LENGTH + 1)

    try:
        metric = create_condition_metric(
            name="LongValue",
            rules=[{"field": "actual_output", "operator": "contains", "value": long_value}]
        )
        print("  FAIL - Should have raised error")
        return False
    except MetricValidationError as e:
        print(f"  Error: {e}")
        return "exceeds" in str(e).lower()
    except Exception as e:
        print(f"  Unexpected: {type(e).__name__}: {e}")
        return False


def test_max_name_length():
    """Test MAX_NAME_LENGTH limit"""
    print("\n" + "="*60)
    print(f"TEST: MAX_NAME_LENGTH limit ({MAX_NAME_LENGTH})")
    print("="*60)

    long_name = "M" * (MAX_NAME_LENGTH + 1)

    try:
        metric = create_condition_metric(
            name=long_name,
            rules=[{"field": "actual_output", "operator": "contains", "value": "test"}]
        )
        print("  FAIL - Should have raised error")
        return False
    except MetricValidationError as e:
        print(f"  Error: {e}")
        return "exceeds" in str(e).lower()
    except Exception as e:
        print(f"  Unexpected: {type(e).__name__}: {e}")
        return False


def test_invalid_field():
    """Test invalid field name"""
    print("\n" + "="*60)
    print("TEST: Invalid field name")
    print("="*60)

    try:
        metric = create_condition_metric(
            name="InvalidField",
            rules=[{"field": "nonexistent_field", "operator": "contains", "value": "test"}]
        )
        print("  FAIL - Should have raised error")
        return False
    except MetricValidationError as e:
        print(f"  Error: {e}")
        return "invalid field" in str(e).lower()
    except Exception as e:
        print(f"  Unexpected: {type(e).__name__}: {e}")
        return False


def test_valid_fields():
    """Test all valid fields work"""
    print("\n" + "="*60)
    print(f"TEST: All valid fields ({len(VALID_FIELDS)})")
    print("="*60)

    all_pass = True
    for field in VALID_FIELDS:
        try:
            metric = create_condition_metric(
                name=f"Test{field}",
                rules=[{"field": field, "operator": "length_gt", "value": "0"}]
            )
            print(f"  {field}: OK")
        except Exception as e:
            print(f"  {field}: FAIL - {e}")
            all_pass = False

    return all_pass


def test_empty_name():
    """Test empty metric name"""
    print("\n" + "="*60)
    print("TEST: Empty metric name")
    print("="*60)

    try:
        metric = create_condition_metric(
            name="",
            rules=[{"field": "actual_output", "operator": "contains", "value": "test"}]
        )
        print("  FAIL - Should have raised error")
        return False
    except MetricValidationError as e:
        print(f"  Error: {e}")
        return "name" in str(e).lower()
    except Exception as e:
        print(f"  Unexpected: {type(e).__name__}: {e}")
        return False


def test_invalid_threshold():
    """Test invalid threshold values"""
    print("\n" + "="*60)
    print("TEST: Invalid threshold")
    print("="*60)

    tests = [
        (-0.1, "negative"),
        (1.5, "greater than 1"),
        ("not_a_number", "string"),
    ]

    all_pass = True
    for threshold, desc in tests:
        try:
            metric = create_condition_metric(
                name="Test",
                rules=[{"field": "actual_output", "operator": "contains", "value": "test"}],
                threshold=threshold
            )
            print(f"  {desc}: FAIL - Should have raised error")
            all_pass = False
        except MetricValidationError as e:
            print(f"  {desc}: OK - {e}")
        except Exception as e:
            print(f"  {desc}: OK - {type(e).__name__}")

    return all_pass


def test_missing_rule_keys():
    """Test missing required keys in rules"""
    print("\n" + "="*60)
    print("TEST: Missing rule keys")
    print("="*60)

    tests = [
        ({"operator": "contains", "value": "test"}, "missing field"),
        ({"field": "actual_output", "value": "test"}, "missing operator"),
        ({"field": "actual_output", "operator": "contains"}, "missing value"),
    ]

    all_pass = True
    for rule, desc in tests:
        try:
            metric = create_condition_metric(name="Test", rules=[rule])
            print(f"  {desc}: FAIL - Should have raised error")
            all_pass = False
        except MetricValidationError as e:
            print(f"  {desc}: OK - {e}")
        except Exception as e:
            print(f"  {desc}: OK - {type(e).__name__}")

    return all_pass


def run_all_tests():
    """Run all limit tests"""
    print("="*60)
    print("LIMIT VALIDATION TESTS")
    print("="*60)

    tests = [
        ("Max Rules Limit", test_max_rules_limit),
        ("Max Rules At Limit", test_max_rules_at_limit),
        ("Max Value Length", test_max_value_length),
        ("Max Name Length", test_max_name_length),
        ("Invalid Field", test_invalid_field),
        ("Valid Fields", test_valid_fields),
        ("Empty Name", test_empty_name),
        ("Invalid Threshold", test_invalid_threshold),
        ("Missing Rule Keys", test_missing_rule_keys),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
