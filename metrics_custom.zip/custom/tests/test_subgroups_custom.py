"""
Test HuggingFace subgroups/configs and custom data files
"""

import os
import sys
import json
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom.tests.test_config import HF_DATASETS

from custom import (
    SKIP_LLM_VALIDATION,
    load_from_huggingface,
    list_hf_configs,
    list_hf_splits,
    get_hf_info,
    load_data,
    ColumnMapping,
    convert_to_test_cases,
    DatasetBuilder,
    create_condition_metric,
    create_code_metric,
)


def test_hf_subgroups():
    """Test HuggingFace dataset with multiple configs"""
    print("\n" + "="*60)
    print("TEST: HuggingFace Subgroups/Configs")
    print("="*60)

    cfg = HF_DATASETS["subgroups"]
    dataset_name = cfg["name"]

    try:
        configs = list_hf_configs(dataset_name)
        print(f"  Configs: {len(configs)} available")

        info = get_hf_info(dataset_name)
        print(f"  Splits: {list(info['splits'].keys())[:3]}...")

        data = load_from_huggingface(dataset_name, config="mrpc", split="train", limit=5)
        print(f"  MRPC loaded: {len(data)} rows")

        data2 = load_from_huggingface(dataset_name, config="sst2", split="train", limit=5)
        print(f"  SST2 loaded: {len(data2)} rows")

        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_custom_json():
    """Test custom JSON data"""
    print("\n" + "="*60)
    print("TEST: Custom JSON Data")
    print("="*60)

    data = [
        {"query": "What is Python?", "response": "A programming language.", "context": ["Created by Guido."]}
    ]

    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False, encoding='utf-8') as f:
        json.dump(data, f)
        path = f.name

    try:
        loaded = load_data(path)
        print(f"  Loaded: {len(loaded)} rows")

        mapping = ColumnMapping(input_col="query", actual_output_col="response", context_col="context")
        test_cases = convert_to_test_cases(loaded, mapping)
        print(f"  Test cases: {len(test_cases)}")

        return True
    finally:
        os.unlink(path)


def test_custom_csv():
    """Test custom CSV data"""
    print("\n" + "="*60)
    print("TEST: Custom CSV Data")
    print("="*60)

    csv_content = "question,answer,expected\nWhat is 2+2?,4,4\nCapital of France?,Paris,Paris\n"

    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as f:
        f.write(csv_content)
        path = f.name

    try:
        loaded = load_data(path)
        print(f"  Loaded: {len(loaded)} rows")

        mapping = ColumnMapping(input_col="question", actual_output_col="answer", expected_output_col="expected")
        test_cases = convert_to_test_cases(loaded, mapping)
        print(f"  Test cases: {len(test_cases)}")

        return True
    finally:
        os.unlink(path)


def test_custom_jsonl():
    """Test custom JSONL data"""
    print("\n" + "="*60)
    print("TEST: Custom JSONL Data")
    print("="*60)

    jsonl = '{"input": "Translate hello", "output": "Bonjour", "tools": [{"name": "translator"}]}'

    with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False, encoding='utf-8') as f:
        f.write(jsonl)
        path = f.name

    try:
        loaded = load_data(path)
        print(f"  Loaded: {len(loaded)} rows")

        mapping = ColumnMapping(input_col="input", actual_output_col="output", tools_called_col="tools")
        test_cases = convert_to_test_cases(loaded, mapping)
        print(f"  Test cases: {len(test_cases)}")
        print(f"  Tools: {[t.name for t in test_cases[0].tools_called] if test_cases[0].tools_called else []}")

        return True
    finally:
        os.unlink(path)


def test_custom_rag():
    """Test custom RAG data"""
    print("\n" + "="*60)
    print("TEST: Custom RAG Data")
    print("="*60)

    data = [{"question": "Rain?", "answer": "Water condensation.", "docs": ["Water cycle."]}]

    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False, encoding='utf-8') as f:
        json.dump(data, f)
        path = f.name

    try:
        loaded = load_data(path)
        mapping = ColumnMapping(input_col="question", actual_output_col="answer", retrieval_context_col="docs")
        test_cases = convert_to_test_cases(loaded, mapping)

        print(f"  Test cases: {len(test_cases)}")
        print(f"  Context: {test_cases[0].retrieval_context}")

        return True
    finally:
        os.unlink(path)


def test_dataset_builder():
    """Test DatasetBuilder"""
    print("\n" + "="*60)
    print("TEST: DatasetBuilder")
    print("="*60)

    builder = DatasetBuilder()
    builder.add_case(input="LLM", actual_output="4", expected_output="4")
    builder.add_case(input="RAG", actual_output="Answer", retrieval_context=["Doc"])
    builder.add_case(input="Agent", actual_output="Done", tools_called=[{"name": "tool"}])

    test_cases = builder.build()
    print(f"  Total: {len(test_cases)} cases (LLM, RAG, Agent)")

    return True


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("SUBGROUPS & CUSTOM DATA TESTS")
    print("="*60)

    tests = [
        ("HF Subgroups", test_hf_subgroups),
        ("Custom JSON", test_custom_json),
        ("Custom CSV", test_custom_csv),
        ("Custom JSONL", test_custom_jsonl),
        ("Custom RAG", test_custom_rag),
        ("DatasetBuilder", test_dataset_builder),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
