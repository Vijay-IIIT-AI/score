"""
Run all tests for DeepEval Custom Extensions
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


def run_all_tests():
    """Run all test suites"""
    print("="*60)
    print("DEEPEVAL CUSTOM - FULL TEST SUITE")
    print("="*60)

    from custom.tests import test_all
    from custom.tests import test_hf_all
    from custom.tests import test_subgroups_custom
    from custom.tests import test_templates

    suites = [
        ("Basic Tests", test_all.run_all_tests),
        ("HuggingFace Tests", test_hf_all.run_all_tests),
        ("Subgroups & Custom Data", test_subgroups_custom.run_all_tests),
        ("Template Flow", test_templates.run_all_tests),
    ]

    for name, run_fn in suites:
        print(f"\n{'#'*60}")
        print(f"# {name}")
        print(f"{'#'*60}")
        try:
            run_fn()
        except Exception as e:
            print(f"\nSUITE ERROR: {e}")

    print("\n" + "="*60)
    print("ALL TEST SUITES COMPLETED")
    print("="*60)


if __name__ == "__main__":
    run_all_tests()
