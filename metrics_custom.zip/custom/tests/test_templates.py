"""
Test Excel template generation and loading
"""

import os
import sys
import json
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import (
    generate_template_xlsx,
    generate_all_templates,
    load_from_template,
    load_template_as_dataset,
)


def test_generate_templates():
    """Test generating templates"""
    print("\n" + "="*60)
    print("TEST: Generate Templates")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        for eval_type in ['llm', 'rag', 'agent']:
            path = os.path.join(tmpdir, f'{eval_type}.xlsx')
            generate_template_xlsx(eval_type, path)
            print(f"  {eval_type.upper()}: {os.path.getsize(path)} bytes")

    return True


def test_generate_all():
    """Test generate all templates"""
    print("\n" + "="*60)
    print("TEST: Generate All Templates")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        paths = generate_all_templates(tmpdir)
        print(f"  Generated: {len(paths)} templates")

    return len(paths) == 4


def test_llm_template_flow():
    """Test LLM template flow"""
    print("\n" + "="*60)
    print("TEST: LLM Template Flow")
    print("="*60)

    try:
        import openpyxl

        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, 'llm.xlsx')
            generate_template_xlsx('llm', path)

            wb = openpyxl.load_workbook(path)
            ws = wb.active
            for row in range(2, 6):
                for col in range(1, 6):
                    ws.cell(row=row, column=col, value=None)

            ws.cell(row=2, column=1, value='What is 2+2?')
            ws.cell(row=2, column=2, value='4')
            ws.cell(row=2, column=3, value='4')

            filled = os.path.join(tmpdir, 'filled.xlsx')
            wb.save(filled)

            test_cases, eval_type = load_from_template(filled)
            print(f"  Detected: {eval_type}")
            print(f"  Loaded: {len(test_cases)} cases")

            return eval_type == 'llm'
    except ImportError:
        print("  openpyxl not installed")
        return True


def test_rag_template_flow():
    """Test RAG template flow"""
    print("\n" + "="*60)
    print("TEST: RAG Template Flow")
    print("="*60)

    try:
        import openpyxl

        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, 'rag.xlsx')
            generate_template_xlsx('rag', path)

            wb = openpyxl.load_workbook(path)
            ws = wb.active
            for row in range(2, 6):
                for col in range(1, 8):
                    ws.cell(row=row, column=col, value=None)

            ws.cell(row=2, column=1, value='Question?')
            ws.cell(row=2, column=2, value='Answer')
            ws.cell(row=2, column=4, value=json.dumps(['Context doc']))

            filled = os.path.join(tmpdir, 'filled.xlsx')
            wb.save(filled)

            test_cases, eval_type = load_from_template(filled)
            print(f"  Detected: {eval_type}")
            print(f"  Context: {test_cases[0].retrieval_context if test_cases else 'None'}")

            return eval_type == 'rag'
    except ImportError:
        print("  openpyxl not installed")
        return True


def test_agent_template_flow():
    """Test Agent template flow"""
    print("\n" + "="*60)
    print("TEST: Agent Template Flow")
    print("="*60)

    try:
        import openpyxl

        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, 'agent.xlsx')
            generate_template_xlsx('agent', path)

            wb = openpyxl.load_workbook(path)
            ws = wb.active
            for row in range(2, 6):
                for col in range(1, 8):
                    ws.cell(row=row, column=col, value=None)

            ws.cell(row=2, column=1, value='Task')
            ws.cell(row=2, column=2, value='Done')
            ws.cell(row=2, column=4, value=json.dumps([{'name': 'tool'}]))

            filled = os.path.join(tmpdir, 'filled.xlsx')
            wb.save(filled)

            test_cases, eval_type = load_from_template(filled)
            print(f"  Detected: {eval_type}")
            print(f"  Tools: {[t.name for t in test_cases[0].tools_called] if test_cases and test_cases[0].tools_called else []}")

            return eval_type == 'agent'
    except ImportError:
        print("  openpyxl not installed")
        return True


def test_load_as_dataset():
    """Test load as EvaluationDataset"""
    print("\n" + "="*60)
    print("TEST: Load as EvaluationDataset")
    print("="*60)

    try:
        import openpyxl

        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, 'llm.xlsx')
            generate_template_xlsx('llm', path)

            wb = openpyxl.load_workbook(path)
            ws = wb.active
            for row in range(2, 6):
                for col in range(1, 6):
                    ws.cell(row=row, column=col, value=None)
            ws.cell(row=2, column=1, value='Input')
            ws.cell(row=2, column=2, value='Output')

            filled = os.path.join(tmpdir, 'filled.xlsx')
            wb.save(filled)

            dataset, eval_type = load_template_as_dataset(filled)
            print(f"  Type: {type(dataset).__name__}")
            print(f"  Cases: {len(dataset.test_cases)}")

            return type(dataset).__name__ == 'EvaluationDataset'
    except ImportError:
        print("  openpyxl not installed")
        return True


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("TEMPLATE FLOW TESTS")
    print("="*60)

    tests = [
        ("Generate Templates", test_generate_templates),
        ("Generate All", test_generate_all),
        ("LLM Template Flow", test_llm_template_flow),
        ("RAG Template Flow", test_rag_template_flow),
        ("Agent Template Flow", test_agent_template_flow),
        ("Load as Dataset", test_load_as_dataset),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
