"""
Test-specific configuration
Can be removed along with tests folder
"""

# =============================================================================
# HUGGINGFACE TEST DATASETS
# =============================================================================

HF_DATASETS = {
    "llm": {
        "name": "openai/gsm8k",
        "config": "main",
        "split": "test",
        "limit": 5,
    },
    "rag": {
        "name": "rajpurkar/squad",
        "config": None,
        "split": "validation",
        "limit": 5,
    },
    "subgroups": {
        "name": "nyu-mll/glue",
        "configs": ["mrpc", "sst2", "cola"],
        "limit": 5,
    },
}

# =============================================================================
# TEST SETTINGS
# =============================================================================

DEFAULT_LIMIT = 5
