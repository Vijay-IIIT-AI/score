"""
Tests for DeepEval Custom Extensions
"""
