"""
Test Error Handling - Invalid inputs, wrong parameters, edge cases
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import create_condition_metric, create_code_metric, ConditionMetric
from custom.metrics import Operator, Gate, Rule
from deepeval.test_case import LLMTestCase


def test_invalid_operator():
    """Test invalid operator name"""
    print("\n" + "="*60)
    print("TEST: Invalid Operator")
    print("="*60)

    try:
        metric = create_condition_metric(
            name="InvalidOp",
            rules=[{"field": "actual_output", "operator": "invalid_op", "value": "test"}]
        )
        print("  FAIL - Should have raised error")
        return False
    except ValueError as e:
        print(f"  Error raised: {type(e).__name__}")
        print(f"  Message: {e}")
        return "invalid_op" in str(e).lower() or "not a valid" in str(e).lower()
    except Exception as e:
        print(f"  Error raised: {type(e).__name__}: {e}")
        return True


def test_invalid_field_name():
    """Test invalid field name - should fail at creation"""
    print("\n" + "="*60)
    print("TEST: Invalid Field Name")
    print("="*60)

    try:
        metric = create_condition_metric(
            name="InvalidField",
            rules=[{"field": "nonexistent_field", "operator": "contains", "value": "test"}]
        )
        print("  FAIL - Should have raised error")
        return False
    except Exception as e:
        print(f"  Error: {type(e).__name__}: {e}")
        return "invalid field" in str(e).lower()


def test_missing_required_keys():
    """Test missing required keys in rule dict"""
    print("\n" + "="*60)
    print("TEST: Missing Required Keys")
    print("="*60)

    # Missing 'field'
    try:
        metric = create_condition_metric(
            name="MissingField",
            rules=[{"operator": "contains", "value": "test"}]
        )
        tc = LLMTestCase(input="test", actual_output="test")
        metric.measure(tc)
        print("  Missing 'field': Handled (no crash)")
        result1 = True
    except KeyError as e:
        print(f"  Missing 'field': KeyError raised - {e}")
        result1 = True
    except Exception as e:
        print(f"  Missing 'field': {type(e).__name__} - {e}")
        result1 = True

    # Missing 'operator'
    try:
        metric = create_condition_metric(
            name="MissingOp",
            rules=[{"field": "actual_output", "value": "test"}]
        )
        tc = LLMTestCase(input="test", actual_output="test")
        metric.measure(tc)
        print("  Missing 'operator': Handled (no crash)")
        result2 = True
    except KeyError as e:
        print(f"  Missing 'operator': KeyError raised - {e}")
        result2 = True
    except Exception as e:
        print(f"  Missing 'operator': {type(e).__name__} - {e}")
        result2 = True

    # Missing 'value'
    try:
        metric = create_condition_metric(
            name="MissingValue",
            rules=[{"field": "actual_output", "operator": "contains"}]
        )
        tc = LLMTestCase(input="test", actual_output="test")
        metric.measure(tc)
        print("  Missing 'value': Handled (no crash)")
        result3 = True
    except KeyError as e:
        print(f"  Missing 'value': KeyError raised - {e}")
        result3 = True
    except Exception as e:
        print(f"  Missing 'value': {type(e).__name__} - {e}")
        result3 = True

    return result1 and result2 and result3


def test_none_values():
    """Test None values in test case"""
    print("\n" + "="*60)
    print("TEST: None Values in Test Case")
    print("="*60)

    # DeepEval requires input to be string, so test with empty/None actual_output
    tc = LLMTestCase(
        input="test input",
        actual_output=None,
        expected_output=None,
        context=None,
        retrieval_context=None
    )

    metric = create_condition_metric(
        name="NoneValues",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "test"},
            {"field": "expected_output", "operator": "length_gt", "value": "0"}
        ],
        gates=["AND"]
    )

    try:
        score = metric.measure(tc)
        print(f"  Score: {score}")
        print(f"  Reason: {metric.reason}")
        print(f"  Success: {metric.success}")
        return score == 0.0  # Should fail gracefully
    except Exception as e:
        print(f"  ERROR: {type(e).__name__}: {e}")
        return False


def test_empty_string_values():
    """Test empty string values"""
    print("\n" + "="*60)
    print("TEST: Empty String Values")
    print("="*60)

    tc = LLMTestCase(
        input="",
        actual_output="",
        expected_output=""
    )

    metric = create_condition_metric(
        name="EmptyStrings",
        rules=[
            {"field": "actual_output", "operator": "equals", "value": ""},
            {"field": "input", "operator": "length_lt", "value": "1"}
        ],
        gates=["AND"]
    )

    score = metric.measure(tc)
    print(f"  Score: {score}")
    print(f"  Reason: {metric.reason}")

    # Empty equals empty should be True, length < 1 should be True
    return score == 1.0


def test_invalid_gate():
    """Test invalid gate name"""
    print("\n" + "="*60)
    print("TEST: Invalid Gate")
    print("="*60)

    try:
        metric = create_condition_metric(
            name="InvalidGate",
            rules=[
                {"field": "actual_output", "operator": "contains", "value": "a"},
                {"field": "actual_output", "operator": "contains", "value": "b"}
            ],
            gates=["INVALID_GATE"]
        )
        print("  FAIL - Should have raised error")
        return False
    except ValueError as e:
        print(f"  Error raised: {type(e).__name__}")
        print(f"  Message: {e}")
        return True
    except Exception as e:
        print(f"  Error raised: {type(e).__name__}: {e}")
        return True


def test_wrong_type_rules():
    """Test wrong type for rules parameter"""
    print("\n" + "="*60)
    print("TEST: Wrong Type for Rules")
    print("="*60)

    # String instead of list
    try:
        metric = create_condition_metric(
            name="WrongType",
            rules="not a list"
        )
        print("  String rules: Should have failed")
        result1 = False
    except (TypeError, AttributeError) as e:
        print(f"  String rules: {type(e).__name__} raised")
        result1 = True
    except Exception as e:
        print(f"  String rules: {type(e).__name__}: {e}")
        result1 = True

    # None instead of list
    try:
        metric = create_condition_metric(
            name="NoneRules",
            rules=None
        )
        tc = LLMTestCase(input="test", actual_output="test")
        score = metric.measure(tc)
        print(f"  None rules: score={score}, handled gracefully")
        result2 = True
    except (TypeError, AttributeError) as e:
        print(f"  None rules: {type(e).__name__} raised")
        result2 = True
    except Exception as e:
        print(f"  None rules: {type(e).__name__}: {e}")
        result2 = True

    return result1 and result2


def test_special_characters():
    """Test special characters in values"""
    print("\n" + "="*60)
    print("TEST: Special Characters")
    print("="*60)

    tc = LLMTestCase(
        input="Test with special chars: <script>alert('xss')</script>",
        actual_output="Output with $pecial ch@rs & symbols! \"quotes\" 'apostrophes'"
    )

    # Test various special characters
    tests = [
        ("contains", "<script>", True),
        ("contains", "\"quotes\"", True),
        ("contains", "'apostrophes'", True),
        ("contains", "&", True),
        ("regex", r"\$pecial", True),
        ("regex", r"ch@rs", True),
    ]

    all_pass = True
    for op, value, expected in tests:
        try:
            field = "input" if "<script>" in value else "actual_output"
            metric = create_condition_metric(
                name="SpecialChars",
                rules=[{"field": field, "operator": op, "value": value}]
            )
            score = metric.measure(tc)
            passed = (score == 1.0) == expected
            print(f"  {op}('{value[:20]}...'): score={score} - {'OK' if passed else 'FAIL'}")
            if not passed:
                all_pass = False
        except Exception as e:
            print(f"  {op}('{value[:20]}...'): ERROR - {e}")
            all_pass = False

    return all_pass


def test_unicode_values():
    """Test unicode/international characters"""
    print("\n" + "="*60)
    print("TEST: Unicode Values")
    print("="*60)

    tc = LLMTestCase(
        input="Hello World Japanese",
        actual_output="Response with special chars"
    )

    # Test with safe ASCII for Windows console, but verify unicode works internally
    tests = [
        ("input", "contains", "Hello", True),
        ("actual_output", "contains", "special", True),
        ("input", "regex", r"Hello.*World", True),
    ]

    all_pass = True
    for field, op, value, expected in tests:
        try:
            metric = create_condition_metric(
                name="Unicode",
                rules=[{"field": field, "operator": op, "value": value}]
            )
            score = metric.measure(tc)
            passed = (score == 1.0) == expected
            print(f"  {field}.{op}('{value}'): score={score} - {'OK' if passed else 'FAIL'}")
            if not passed:
                all_pass = False
        except Exception as e:
            print(f"  {field}.{op}('{value}'): ERROR - {e}")
            all_pass = False

    # Test actual unicode handling (without printing unicode to console)
    try:
        tc_unicode = LLMTestCase(input="test", actual_output="Cafe \u00e9 na\u00efve")
        metric = create_condition_metric(
            name="UnicodeInternal",
            rules=[{"field": "actual_output", "operator": "contains", "value": "Cafe"}]
        )
        score = metric.measure(tc_unicode)
        print(f"  Unicode internal test: score={score} - {'OK' if score == 1.0 else 'FAIL'}")
        if score != 1.0:
            all_pass = False
    except Exception as e:
        print(f"  Unicode internal test: ERROR - {e}")
        all_pass = False

    return all_pass


def test_very_long_strings():
    """Test very long strings"""
    print("\n" + "="*60)
    print("TEST: Very Long Strings")
    print("="*60)

    long_output = "A" * 100000  # 100KB of text
    tc = LLMTestCase(
        input="test",
        actual_output=long_output
    )

    metric = create_condition_metric(
        name="LongString",
        rules=[
            {"field": "actual_output", "operator": "length_gt", "value": "50000"},
            {"field": "actual_output", "operator": "contains", "value": "AAA"}
        ],
        gates=["AND"]
    )

    try:
        score = metric.measure(tc)
        print(f"  100KB string: score={score}")
        print(f"  Handled without crash: OK")
        return score == 1.0
    except Exception as e:
        print(f"  ERROR: {e}")
        return False


def test_code_metric_syntax_error():
    """Test code metric with syntax error"""
    print("\n" + "="*60)
    print("TEST: Code Metric Syntax Error")
    print("="*60)

    bad_code = '''
class BadMetric(BaseMetric):
    def __init__(self)
        self.threshold = 0.5  # Missing colon above
'''

    try:
        metric = create_code_metric(bad_code, skip_validation=True)
        print("  FAIL - Should have raised SyntaxError")
        return False
    except SyntaxError as e:
        print(f"  SyntaxError raised: {e}")
        return True
    except Exception as e:
        print(f"  {type(e).__name__} raised: {e}")
        return True


def test_code_metric_runtime_error():
    """Test code metric with runtime error"""
    print("\n" + "="*60)
    print("TEST: Code Metric Runtime Error")
    print("="*60)

    bad_code = '''
class BadMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "BadMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        # This will cause ZeroDivisionError
        result = 1 / 0
        self.score = result
        self.reason = "ok"
        self.success = True
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case)
'''

    try:
        metric = create_code_metric(bad_code, skip_validation=True)
        tc = LLMTestCase(input="test", actual_output="test")
        metric.measure(tc)
        print("  FAIL - Should have raised ZeroDivisionError")
        return False
    except ZeroDivisionError as e:
        print(f"  ZeroDivisionError raised: {e}")
        return True
    except Exception as e:
        print(f"  {type(e).__name__} raised: {e}")
        return True


def test_code_metric_missing_method():
    """Test code metric missing required method"""
    print("\n" + "="*60)
    print("TEST: Code Metric Missing Method")
    print("="*60)

    # Missing measure() method
    bad_code = '''
class IncompleteMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5

    @property
    def __name__(self):
        return "IncompleteMetric"

    # Missing measure() method!
'''

    try:
        metric = create_code_metric(bad_code, skip_validation=True)
        tc = LLMTestCase(input="test", actual_output="test")
        metric.measure(tc)
        print("  FAIL - Should have raised error")
        return False
    except (TypeError, AttributeError, NotImplementedError) as e:
        print(f"  {type(e).__name__} raised: {e}")
        return True
    except Exception as e:
        print(f"  {type(e).__name__} raised: {e}")
        return True


def run_all_tests():
    """Run all error handling tests"""
    print("="*60)
    print("ERROR HANDLING TESTS")
    print("="*60)

    tests = [
        ("Invalid Operator", test_invalid_operator),
        ("Invalid Field Name", test_invalid_field_name),
        ("Missing Required Keys", test_missing_required_keys),
        ("None Values", test_none_values),
        ("Empty String Values", test_empty_string_values),
        ("Invalid Gate", test_invalid_gate),
        ("Wrong Type Rules", test_wrong_type_rules),
        ("Special Characters", test_special_characters),
        ("Unicode Values", test_unicode_values),
        ("Very Long Strings", test_very_long_strings),
        ("Code Syntax Error", test_code_metric_syntax_error),
        ("Code Runtime Error", test_code_metric_runtime_error),
        ("Code Missing Method", test_code_metric_missing_method),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  UNEXPECTED ERROR: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
