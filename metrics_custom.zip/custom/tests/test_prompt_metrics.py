"""
Test Prompt-Based Metrics
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import (
    PromptMetric,
    create_prompt_metric,
    get_prompt_template,
    MetricValidationError,
    PROMPT_TEMPLATES,
    PROMPT_PLACEHOLDERS,
    PLACEHOLDER_NAMES,
    MAX_PROMPT_LENGTH,
    MAX_NAME_LENGTH,
    get_placeholders_for_ui,
    get_templates_for_ui,
    get_templates_by_category,
    validate_prompt_placeholders,
)
from deepeval.test_case import LLMTestCase, ToolCall


def test_available_templates():
    """Test that all prompt templates are available"""
    print("\n" + "="*60)
    print("TEST: Available Prompt Templates")
    print("="*60)

    expected = ["quality", "relevancy", "faithfulness", "helpfulness", "safety", "tool_selection"]

    all_pass = True
    for name in expected:
        try:
            template = get_prompt_template(name)
            print(f"  {name}: OK ({len(template)} chars)")
        except Exception as e:
            print(f"  {name}: FAIL - {e}")
            all_pass = False

    return all_pass


def test_placeholders_for_ui():
    """Test UI placeholder info"""
    print("\n" + "="*60)
    print("TEST: Placeholders for UI")
    print("="*60)

    # Test all placeholders
    all_placeholders = get_placeholders_for_ui()
    print(f"  All placeholders: {len(all_placeholders)}")

    # Test filtered by eval type
    tests = [
        ("llm", 3, ["input", "actual_output", "expected_output"]),
        ("rag", 5, ["input", "actual_output", "expected_output", "context", "retrieval_context"]),
        ("agent", 5, ["input", "actual_output", "expected_output", "tools_called", "expected_tools"]),
    ]

    all_pass = True
    for eval_type, expected_count, expected_names in tests:
        placeholders = get_placeholders_for_ui(eval_type)
        names = [p["name"] for p in placeholders]
        passed = len(placeholders) == expected_count and set(names) == set(expected_names)
        print(f"  {eval_type}: {names} - {'OK' if passed else 'FAIL'}")
        if not passed:
            all_pass = False

    return all_pass


def test_templates_for_ui():
    """Test UI template info"""
    print("\n" + "="*60)
    print("TEST: Templates for UI")
    print("="*60)

    templates = get_templates_for_ui()
    print(f"  Total templates: {len(templates)}")

    all_pass = True
    for t in templates:
        has_all = all(k in t for k in ["name", "label", "description", "category", "uses_placeholders"])
        print(f"  {t['name']}: {t['label']} ({t['category']}) - {'OK' if has_all else 'FAIL'}")
        if not has_all:
            all_pass = False

    return all_pass


def test_templates_by_category():
    """Test filtering templates by category"""
    print("\n" + "="*60)
    print("TEST: Templates by Category")
    print("="*60)

    categories = ["llm", "rag", "agent"]
    all_pass = True

    for cat in categories:
        templates = get_templates_by_category(cat)
        names = [t["name"] for t in templates]
        print(f"  {cat}: {names}")
        if not templates:
            print(f"    FAIL - no templates for {cat}")
            all_pass = False

    return all_pass


def test_validate_prompt():
    """Test prompt validation"""
    print("\n" + "="*60)
    print("TEST: Validate Prompt Placeholders")
    print("="*60)

    tests = [
        ("Valid: {input} {actual_output}", True, ["input", "actual_output"], []),
        ("Unknown: {input} {foobar}", False, ["input"], ["foobar"]),
        ("No placeholders", True, [], []),
    ]

    all_pass = True
    for prompt, exp_valid, exp_used, exp_unknown in tests:
        result = validate_prompt_placeholders(prompt)
        passed = (
            result["valid"] == exp_valid and
            set(result["used_placeholders"]) == set(exp_used) and
            set(result["unknown_placeholders"]) == set(exp_unknown)
        )
        print(f"  '{prompt[:30]}...': {'OK' if passed else 'FAIL'}")
        if not passed:
            print(f"    Got: {result}")
            all_pass = False

    return all_pass


def test_create_prompt_metric():
    """Test creating a prompt metric"""
    print("\n" + "="*60)
    print("TEST: Create Prompt Metric")
    print("="*60)

    prompt = """Is this response good?
Question: {input}
Answer: {actual_output}

Rate 0.0-1.0. JSON: {{"score": <float>, "reason": "<text>"}}"""

    try:
        metric = create_prompt_metric(
            name="QualityCheck",
            prompt_template=prompt,
            threshold=0.7
        )
        print(f"  Created: {metric.__name__}")
        print(f"  Threshold: {metric.threshold}")
        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_prompt_metric_build():
    """Test prompt building with placeholders"""
    print("\n" + "="*60)
    print("TEST: Prompt Building")
    print("="*60)

    prompt = "Input: {input}, Output: {actual_output}, Expected: {expected_output}"

    metric = create_prompt_metric(name="Test", prompt_template=prompt)
    tc = LLMTestCase(
        input="What is 2+2?",
        actual_output="4",
        expected_output="4"
    )

    built = metric._build_prompt(tc)
    print(f"  Template: {prompt}")
    print(f"  Built: {built}")

    return "What is 2+2?" in built and "4" in built


def test_prompt_with_all_fields():
    """Test prompt with all available fields"""
    print("\n" + "="*60)
    print("TEST: All Fields in Prompt")
    print("="*60)

    prompt = """
Input: {input}
Output: {actual_output}
Expected: {expected_output}
Context: {context}
Retrieval: {retrieval_context}
Tools: {tools_called}
Expected Tools: {expected_tools}
"""

    metric = create_prompt_metric(name="AllFields", prompt_template=prompt)
    tc = LLMTestCase(
        input="test question",
        actual_output="test answer",
        expected_output="expected answer",
        context=["context1", "context2"],
        retrieval_context=["doc1", "doc2"],
        tools_called=[ToolCall(name="search", input_parameters={"q": "test"})],
        expected_tools=[ToolCall(name="search")]
    )

    built = metric._build_prompt(tc)
    print(f"  Built prompt length: {len(built)} chars")

    checks = [
        ("input", "test question" in built),
        ("actual_output", "test answer" in built),
        ("expected_output", "expected answer" in built),
        ("context", "context1" in built),
        ("retrieval_context", "doc1" in built),
        ("tools_called", "search" in built),
    ]

    all_pass = True
    for field, passed in checks:
        print(f"  {field}: {'OK' if passed else 'FAIL'}")
        if not passed:
            all_pass = False

    return all_pass


def test_validation_errors():
    """Test validation errors"""
    print("\n" + "="*60)
    print("TEST: Validation Errors")
    print("="*60)

    tests = [
        ("empty name", {"name": "", "prompt_template": "test"}),
        ("long name", {"name": "x" * (MAX_NAME_LENGTH + 1), "prompt_template": "test"}),
        ("empty prompt", {"name": "Test", "prompt_template": ""}),
        ("long prompt", {"name": "Test", "prompt_template": "x" * (MAX_PROMPT_LENGTH + 1)}),
        ("invalid threshold", {"name": "Test", "prompt_template": "test", "threshold": 1.5}),
    ]

    all_pass = True
    for desc, kwargs in tests:
        try:
            metric = create_prompt_metric(**kwargs)
            print(f"  {desc}: FAIL - should have raised error")
            all_pass = False
        except MetricValidationError as e:
            print(f"  {desc}: OK - {e}")
        except Exception as e:
            print(f"  {desc}: OK - {type(e).__name__}")

    return all_pass


def test_invalid_template_name():
    """Test invalid template name"""
    print("\n" + "="*60)
    print("TEST: Invalid Template Name")
    print("="*60)

    try:
        template = get_prompt_template("nonexistent")
        print("  FAIL - should have raised error")
        return False
    except ValueError as e:
        print(f"  OK - {e}")
        return True
    except Exception as e:
        print(f"  Unexpected: {type(e).__name__}: {e}")
        return False


def run_all_tests():
    """Run all prompt metric tests"""
    print("="*60)
    print("PROMPT-BASED METRIC TESTS")
    print("="*60)

    tests = [
        ("Available Templates", test_available_templates),
        ("Placeholders for UI", test_placeholders_for_ui),
        ("Templates for UI", test_templates_for_ui),
        ("Templates by Category", test_templates_by_category),
        ("Validate Prompt", test_validate_prompt),
        ("Create Prompt Metric", test_create_prompt_metric),
        ("Prompt Building", test_prompt_metric_build),
        ("All Fields", test_prompt_with_all_fields),
        ("Validation Errors", test_validation_errors),
        ("Invalid Template Name", test_invalid_template_name),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
