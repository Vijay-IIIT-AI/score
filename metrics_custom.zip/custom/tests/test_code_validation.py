"""
Test code validation for custom metrics
Tests both valid code and security blocking
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import create_code_metric, get_code_template, CODE_TEMPLATES
from deepeval.test_case import LLMTestCase, ToolCall


def test_valid_llm_metric():
    """Test valid LLM metric code"""
    print("\n" + "="*60)
    print("TEST: Valid LLM Metric")
    print("="*60)

    code = '''
class LLMQualityMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "LLMQualityMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        output = test_case.actual_output or ""
        expected = test_case.expected_output or ""

        if not output:
            self.score = 0.0
            self.reason = "No output"
        elif expected and expected.lower() in output.lower():
            self.score = 1.0
            self.reason = "Expected found in output"
        else:
            self.score = 0.5
            self.reason = "Partial match"

        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case)
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        tc = LLMTestCase(input='What is 2+2?', actual_output='The answer is 4', expected_output='4')
        score = metric.measure(tc)
        print(f"  Created: {metric.__name__}")
        print(f"  Score: {score}, Reason: {metric.reason}")
        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_valid_rag_metric():
    """Test valid RAG metric code"""
    print("\n" + "="*60)
    print("TEST: Valid RAG Metric")
    print("="*60)

    code = '''
class RAGFaithfulnessMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "RAGFaithfulnessMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not test_case.retrieval_context:
            self.score = 0.0
            self.reason = "No context provided"
            self.success = False
            return self.score

        context = " ".join(str(c) for c in test_case.retrieval_context).lower()
        output = (test_case.actual_output or "").lower()

        output_words = set(w for w in output.split() if len(w) > 3)
        context_words = set(w for w in context.split() if len(w) > 3)

        if not output_words:
            self.score = 0.0
            self.reason = "No significant words"
        else:
            overlap = len(output_words & context_words)
            self.score = min(1.0, overlap / len(output_words))
            self.reason = f"Overlap: {overlap}/{len(output_words)}"

        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case)
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        tc = LLMTestCase(
            input='What causes rain?',
            actual_output='Rain is caused by water vapor condensing in clouds.',
            retrieval_context=['Water cycle involves evaporation and condensation.']
        )
        score = metric.measure(tc)
        print(f"  Created: {metric.__name__}")
        print(f"  Score: {score:.2f}, Reason: {metric.reason}")
        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_valid_agent_metric():
    """Test valid Agent metric code"""
    print("\n" + "="*60)
    print("TEST: Valid Agent Metric")
    print("="*60)

    code = '''
class AgentToolMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.8
        self.async_mode = False

    @property
    def __name__(self):
        return "AgentToolMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        tools_called = test_case.tools_called or []
        expected_tools = test_case.expected_tools or []

        if not expected_tools:
            self.score = 1.0
            self.reason = "No expected tools"
            self.success = True
            return self.score

        if not tools_called:
            self.score = 0.0
            self.reason = "No tools called"
            self.success = False
            return self.score

        called_names = {t.name for t in tools_called}
        expected_names = {t.name for t in expected_tools}

        correct = called_names & expected_names
        precision = len(correct) / len(called_names) if called_names else 0
        recall = len(correct) / len(expected_names) if expected_names else 0

        self.score = (precision + recall) / 2
        self.reason = f"P:{precision:.2f} R:{recall:.2f}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case)
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        tc = LLMTestCase(
            input='Search weather',
            actual_output='25C sunny',
            tools_called=[ToolCall(name='weather_api', input_parameters={'city': 'Tokyo'})],
            expected_tools=[ToolCall(name='weather_api')]
        )
        score = metric.measure(tc)
        print(f"  Created: {metric.__name__}")
        print(f"  Score: {score:.2f}, Reason: {metric.reason}")
        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_code_templates():
    """Test built-in code templates"""
    print("\n" + "="*60)
    print("TEST: Code Templates")
    print("="*60)

    for eval_type in ['llm', 'rag', 'agent']:
        try:
            template = get_code_template(eval_type)
            metric = create_code_metric(template, skip_validation=True)
            print(f"  {eval_type.upper()}: {metric.__name__} - OK")
        except Exception as e:
            print(f"  {eval_type.upper()}: FAIL - {e}")
            return False
    return True


def test_block_os_import():
    """Test blocking os import"""
    print("\n" + "="*60)
    print("TEST: Block os import")
    print("="*60)

    code = '''
import os
class BadMetric(BaseMetric):
    def measure(self, test_case, *args, **kwargs):
        os.system("echo hacked")
        return 1.0
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        print("  FAIL - Should have blocked")
        return False
    except Exception as e:
        print(f"  Blocked: {type(e).__name__}")
        return True


def test_block_file_access():
    """Test blocking file access"""
    print("\n" + "="*60)
    print("TEST: Block file access")
    print("="*60)

    code = '''
class BadMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "BadMetric"

    def measure(self, test_case, *args, **kwargs):
        f = open("/etc/passwd")
        data = f.read()
        f.close()
        self.score = 1.0
        self.reason = "ok"
        self.success = True
        return self.score

    async def a_measure(self, test_case, *args, **kwargs):
        return self.measure(test_case)
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        tc = LLMTestCase(input='test', actual_output='test')
        metric.measure(tc)
        print("  FAIL - Should have blocked")
        return False
    except Exception as e:
        print(f"  Blocked: {type(e).__name__}")
        return True


def test_block_subprocess():
    """Test blocking subprocess"""
    print("\n" + "="*60)
    print("TEST: Block subprocess")
    print("="*60)

    code = '''
import subprocess
class BadMetric(BaseMetric):
    def measure(self, test_case, *args, **kwargs):
        subprocess.run(["ls"])
        return 1.0
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        print("  FAIL - Should have blocked")
        return False
    except Exception as e:
        print(f"  Blocked: {type(e).__name__}")
        return True


def test_block_eval():
    """Test blocking eval with __import__"""
    print("\n" + "="*60)
    print("TEST: Block eval/__import__")
    print("="*60)

    code = '''
class BadMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "BadMetric"

    def measure(self, test_case, *args, **kwargs):
        evil = __import__("os")
        self.score = 1.0
        self.reason = "ok"
        self.success = True
        return self.score

    async def a_measure(self, test_case, *args, **kwargs):
        return self.measure(test_case)
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        tc = LLMTestCase(input='test', actual_output='test')
        metric.measure(tc)
        print("  FAIL - Should have blocked")
        return False
    except Exception as e:
        print(f"  Blocked: {type(e).__name__}")
        return True


def test_missing_inheritance():
    """Test blocking code without BaseMetric"""
    print("\n" + "="*60)
    print("TEST: Missing BaseMetric inheritance")
    print("="*60)

    code = '''
class NotAMetric:
    def measure(self, test_case):
        return 1.0
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        print("  FAIL - Should have blocked")
        return False
    except ValueError as e:
        print(f"  Blocked: {e}")
        return True


def test_block_exec():
    """Test blocking exec()"""
    print("\n" + "="*60)
    print("TEST: Block exec()")
    print("="*60)

    code = '''
class BadMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "BadMetric"

    def measure(self, test_case, *args, **kwargs):
        exec("import os; os.system('whoami')")
        self.score = 1.0
        self.reason = "ok"
        self.success = True
        return self.score

    async def a_measure(self, test_case, *args, **kwargs):
        return self.measure(test_case)
'''
    try:
        metric = create_code_metric(code, skip_validation=True)
        tc = LLMTestCase(input='test', actual_output='test')
        metric.measure(tc)
        print("  FAIL - Should have blocked")
        return False
    except Exception as e:
        print(f"  Blocked: {type(e).__name__}")
        return True


def run_all_tests():
    """Run all code validation tests"""
    print("="*60)
    print("CODE VALIDATION TESTS")
    print("="*60)

    tests = [
        ("Valid LLM Metric", test_valid_llm_metric),
        ("Valid RAG Metric", test_valid_rag_metric),
        ("Valid Agent Metric", test_valid_agent_metric),
        ("Code Templates", test_code_templates),
        ("Block os import", test_block_os_import),
        ("Block file access", test_block_file_access),
        ("Block subprocess", test_block_subprocess),
        ("Block eval/__import__", test_block_eval),
        ("Block exec()", test_block_exec),
        ("Missing inheritance", test_missing_inheritance),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
