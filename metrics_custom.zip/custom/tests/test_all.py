"""
Test all custom DeepEval extensions
LLM, RAG, Agent - Metrics, Dataset, Templates
"""

import os
import sys

# Add parent paths
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom import (
    SKIP_LLM_VALIDATION,
    ExactMatchMetric,
    ContainsKeywordsMetric,
    ToolCorrectnessMetric,
    AgentLoopDetectionMetric,
    create_condition_metric,
    create_code_metric,
    get_code_template,
    ColumnMapping,
    DatasetBuilder,
    convert_to_test_cases,
    generate_template_xlsx,
)

from deepeval.test_case import LLMTestCase, ToolCall


def test_llm_metrics():
    """Test LLM evaluation metrics"""
    print("\n" + "="*60)
    print("TEST: LLM Metrics")
    print("="*60)

    test_case = LLMTestCase(
        input="What is the capital of France?",
        actual_output="The capital of France is Paris.",
        expected_output="Paris"
    )

    metric = ExactMatchMetric(threshold=1.0, case_sensitive=False)
    score = metric.measure(test_case)
    print(f"\n[ExactMatchMetric]")
    print(f"  Score: {score}, Reason: {metric.reason}")

    metric2 = ContainsKeywordsMetric(keywords=["Paris", "capital", "France"], threshold=0.6)
    score2 = metric2.measure(test_case)
    print(f"\n[ContainsKeywordsMetric]")
    print(f"  Score: {score2}, Reason: {metric2.reason}")

    condition_metric = create_condition_metric(
        name="OutputQuality",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "Paris"},
            {"field": "actual_output", "operator": "length_gt", "value": "10"}
        ],
        gates=["AND"]
    )
    score3 = condition_metric.measure(test_case)
    print(f"\n[ConditionMetric]")
    print(f"  Score: {score3}, Reason: {condition_metric.reason}")

    return True


def test_rag_metrics():
    """Test RAG evaluation metrics"""
    print("\n" + "="*60)
    print("TEST: RAG Metrics")
    print("="*60)

    test_case = LLMTestCase(
        input="What are the symptoms of flu?",
        actual_output="Common flu symptoms include fever, cough, body aches, and fatigue.",
        retrieval_context=[
            "Influenza symptoms: high fever, persistent cough, muscle aches, extreme fatigue.",
            "The flu is caused by influenza viruses."
        ]
    )

    rag_metric = create_condition_metric(
        name="RAGRelevance",
        rules=[
            {"field": "actual_output", "operator": "contains", "value": "fever"},
            {"field": "retrieval_context", "operator": "contains", "value": "influenza"}
        ],
        gates=["AND"]
    )
    score = rag_metric.measure(test_case)
    print(f"\n[RAG ConditionMetric]")
    print(f"  Score: {score}, Reason: {rag_metric.reason}")

    return True


def test_agent_metrics():
    """Test Agent evaluation metrics"""
    print("\n" + "="*60)
    print("TEST: Agent Metrics")
    print("="*60)

    test_case = LLMTestCase(
        input="Search for weather in Tokyo",
        actual_output="The weather in Tokyo is sunny, 25C.",
        tools_called=[ToolCall(name="weather_search", input_parameters={"city": "Tokyo"})],
        expected_tools=[ToolCall(name="weather_search")]
    )

    metric = ToolCorrectnessMetric(threshold=0.8)
    score = metric.measure(test_case)
    print(f"\n[ToolCorrectnessMetric]")
    print(f"  Score: {score}, Reason: {metric.reason}")

    loop_metric = AgentLoopDetectionMetric(max_repetitions=3, threshold=0.8)
    score2 = loop_metric.measure(test_case)
    print(f"\n[AgentLoopDetectionMetric]")
    print(f"  Score: {score2}, Reason: {loop_metric.reason}")

    return True


def test_code_templates():
    """Test code templates"""
    print("\n" + "="*60)
    print("TEST: Code Templates")
    print("="*60)

    for eval_type in ["llm", "rag", "agent"]:
        template = get_code_template(eval_type)
        print(f"\n[{eval_type.upper()} Template]")
        print(f"  Length: {len(template)} chars")
        print(f"  Has BaseMetric: {'BaseMetric' in template}")

    return True


def test_code_metric_creation():
    """Test creating metric from code"""
    print("\n" + "="*60)
    print("TEST: Code Metric Creation")
    print("="*60)

    code = '''
class TestMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.5
        self.async_mode = False

    @property
    def __name__(self):
        return "TestMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        output = test_case.actual_output or ""
        self.score = 1.0 if len(output) > 10 else 0.0
        self.reason = f"Output length: {len(output)}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case)
'''

    metric = create_code_metric(code, skip_validation=SKIP_LLM_VALIDATION)
    print(f"\n[Created Metric]")
    print(f"  Name: {metric.__name__}, Threshold: {metric.threshold}")

    test_case = LLMTestCase(input="Test", actual_output="This is a test response.")
    score = metric.measure(test_case)
    print(f"  Score: {score}, Reason: {metric.reason}")

    return True


def test_dataset_builder():
    """Test DatasetBuilder"""
    print("\n" + "="*60)
    print("TEST: DatasetBuilder")
    print("="*60)

    builder = DatasetBuilder()
    builder.add_case(input="What is 2+2?", actual_output="4", expected_output="4")
    builder.add_case(input="Rain?", actual_output="Water.", retrieval_context=["Water cycle."])
    builder.add_case(input="Calc", actual_output="50", tools_called=[{"name": "calc"}])

    test_cases = builder.build()
    print(f"\n[DatasetBuilder]")
    print(f"  Total cases: {len(test_cases)}")

    return True


def test_column_mapping():
    """Test column mapping"""
    print("\n" + "="*60)
    print("TEST: Column Mapping")
    print("="*60)

    data = [{"q": "What?", "a": "Answer", "gt": "Expected"}]
    mapping = ColumnMapping(input_col="q", actual_output_col="a", expected_output_col="gt")
    test_cases = convert_to_test_cases(data, mapping)

    print(f"\n[Column Mapping]")
    print(f"  Test cases: {len(test_cases)}")

    return True


def test_excel_template():
    """Test Excel template"""
    print("\n" + "="*60)
    print("TEST: Excel Template")
    print("="*60)

    import tempfile

    for eval_type in ["llm", "rag", "agent"]:
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
            path = f.name
        try:
            generate_template_xlsx(eval_type, path)
            size = os.path.getsize(path)
            print(f"  {eval_type.upper()}: {size} bytes - OK")
        finally:
            if os.path.exists(path):
                os.unlink(path)

    return True


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("CUSTOM DEEPEVAL - TEST SUITE")
    print("="*60)

    tests = [
        ("LLM Metrics", test_llm_metrics),
        ("RAG Metrics", test_rag_metrics),
        ("Agent Metrics", test_agent_metrics),
        ("Code Templates", test_code_templates),
        ("Code Metric Creation", test_code_metric_creation),
        ("Dataset Builder", test_dataset_builder),
        ("Column Mapping", test_column_mapping),
        ("Excel Templates", test_excel_template),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"\n  ERROR: {e}")
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
