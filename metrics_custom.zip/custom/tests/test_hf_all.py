"""
Test with HuggingFace datasets - LLM, RAG, Agent
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from custom.tests.test_config import HF_DATASETS

from custom import (
    SKIP_LLM_VALIDATION,
    load_from_huggingface,
    ColumnMapping,
    convert_to_test_cases,
    DatasetBuilder,
    ToolCorrectnessMetric,
    create_condition_metric,
    create_code_metric,
    get_code_template,
)

from deepeval.test_case import LLMTestCase, ToolCall


def test_hf_llm_dataset():
    """Test LLM evaluation with HuggingFace dataset"""
    print("\n" + "="*60)
    print("TEST: HuggingFace LLM Dataset")
    print("="*60)

    cfg = HF_DATASETS["llm"]
    try:
        data = load_from_huggingface(cfg["name"], config=cfg["config"], split=cfg["split"], limit=cfg["limit"])
        print(f"  Loaded: {len(data)} rows")
        print(f"  Columns: {list(data[0].keys())}")

        mapping = ColumnMapping(input_col="question", actual_output_col="answer", expected_output_col="answer")
        test_cases = convert_to_test_cases(data, mapping)
        print(f"  Test cases: {len(test_cases)}")

        if test_cases:
            metric = create_condition_metric(name="HasAnswer", rules=[{"field": "actual_output", "operator": "length_gt", "value": "5"}])
            score = metric.measure(test_cases[0])
            print(f"  Metric score: {score}")

        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_hf_rag_dataset():
    """Test RAG evaluation with HuggingFace dataset"""
    print("\n" + "="*60)
    print("TEST: HuggingFace RAG Dataset")
    print("="*60)

    cfg = HF_DATASETS["rag"]
    try:
        data = load_from_huggingface(cfg["name"], split=cfg["split"], limit=cfg["limit"])
        print(f"  Loaded: {len(data)} rows")

        test_cases = []
        for row in data[:5]:
            answers = row.get("answers", {})
            answer_text = answers.get("text", [""])[0] if isinstance(answers, dict) else str(answers)
            tc = LLMTestCase(input=row["question"], actual_output=answer_text, retrieval_context=[row["context"]])
            test_cases.append(tc)

        print(f"  Test cases: {len(test_cases)}")

        if test_cases:
            rag_code = '''
class RAGMetric(BaseMetric):
    def __init__(self):
        self.threshold = 0.3
        self.async_mode = False

    @property
    def __name__(self):
        return "RAGMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not test_case.retrieval_context or not test_case.actual_output:
            self.score = 0.0
            self.reason = "Missing data"
            self.success = False
            return self.score
        context = " ".join(str(c) for c in test_case.retrieval_context).lower()
        output_words = set(test_case.actual_output.lower().split())
        overlap = len([w for w in output_words if w in context])
        self.score = min(1.0, overlap / max(len(output_words), 1))
        self.reason = f"Overlap: {overlap}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case)
'''
            metric = create_code_metric(rag_code, skip_validation=SKIP_LLM_VALIDATION)
            score = metric.measure(test_cases[0])
            print(f"  RAG metric score: {score}")

        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False


def test_hf_agent_dataset():
    """Test Agent evaluation"""
    print("\n" + "="*60)
    print("TEST: Agent Dataset")
    print("="*60)

    builder = DatasetBuilder()
    builder.add_case(
        input="Weather in Paris?",
        actual_output="22C sunny.",
        tools_called=[{"name": "weather_api", "input_parameters": {"city": "Paris"}}],
        expected_tools=[{"name": "weather_api"}]
    )
    builder.add_case(
        input="Book flight to Tokyo",
        actual_output="Booked.",
        tools_called=[{"name": "flight_booking"}],
        expected_tools=[{"name": "flight_booking"}]
    )

    test_cases = builder.build()
    print(f"  Test cases: {len(test_cases)}")

    for i, tc in enumerate(test_cases):
        metric = ToolCorrectnessMetric(threshold=0.8)
        score = metric.measure(tc)
        print(f"  Case {i}: score={score}")

    return True


def test_code_templates():
    """Test code templates"""
    print("\n" + "="*60)
    print("TEST: Code Templates")
    print("="*60)

    for eval_type in ["llm", "rag", "agent"]:
        template = get_code_template(eval_type)
        metric = create_code_metric(template, skip_validation=SKIP_LLM_VALIDATION)
        print(f"  {eval_type.upper()}: {metric.__name__} - OK")

    return True


def test_condition_operators():
    """Test condition operators"""
    print("\n" + "="*60)
    print("TEST: Condition Operators")
    print("="*60)

    tc = LLMTestCase(input="Question?", actual_output="Paris is the capital.", expected_output="Paris")

    ops = [("contains", "Paris"), ("not_contains", "London"), ("length_gt", "10"), ("regex", r"capital")]
    for op, val in ops:
        metric = create_condition_metric(name=f"Test_{op}", rules=[{"field": "actual_output", "operator": op, "value": val}])
        score = metric.measure(tc)
        print(f"  {op}: {score}")

    return True


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("HUGGINGFACE TESTS")
    print("="*60)

    tests = [
        ("HF LLM Dataset", test_hf_llm_dataset),
        ("HF RAG Dataset", test_hf_rag_dataset),
        ("Agent Dataset", test_hf_agent_dataset),
        ("Code Templates", test_code_templates),
        ("Condition Operators", test_condition_operators),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append((name, "ERROR"))

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    for name, status in results:
        icon = "[OK]" if status == "PASS" else "[FAIL]"
        print(f"  {icon} {name}: {status}")

    passed = sum(1 for _, s in results if s == "PASS")
    print(f"\n  Total: {passed}/{len(tests)} passed")


if __name__ == "__main__":
    run_all_tests()
