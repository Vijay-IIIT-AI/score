"""
Condition-based Metric (Visual Builder)
"""

from typing import List, Dict, Any, Union
from enum import Enum
import json
import re

from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

from .config import MAX_RULES, MAX_VALUE_LENGTH, MAX_NAME_LENGTH, VALID_FIELDS
from .base import MetricValidationError


class Operator(Enum):
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    EQUALS = "equals"
    STARTS_WITH = "starts_with"
    ENDS_WITH = "ends_with"
    LENGTH_GT = "length_gt"
    LENGTH_LT = "length_lt"
    REGEX = "regex"


class Gate(Enum):
    AND = "AND"
    OR = "OR"


class Rule:
    def __init__(self, field: str, operator: Union[str, Operator], value: str, compare_to_field: bool = False):
        self.field = field
        self.operator = Operator(operator) if isinstance(operator, str) else operator
        self.value = value
        self.compare_to_field = compare_to_field


def _get_field_value(test_case: LLMTestCase, field_name: str) -> str:
    field_map = {
        "input": test_case.input or "",
        "actual_output": test_case.actual_output or "",
        "expected_output": test_case.expected_output or "",
        "context": " ".join(test_case.context or []),
        "retrieval_context": " ".join([str(c) for c in (test_case.retrieval_context or [])]),
        "tools_called": json.dumps([t.model_dump() for t in (test_case.tools_called or [])]),
        "expected_tools": json.dumps([t.model_dump() for t in (test_case.expected_tools or [])]),
    }
    return str(field_map.get(field_name, ""))


def _evaluate_rule(rule: Rule, test_case: LLMTestCase) -> bool:
    field_value = _get_field_value(test_case, rule.field)
    compare_value = _get_field_value(test_case, rule.value) if rule.compare_to_field else rule.value

    if rule.operator == Operator.CONTAINS:
        return compare_value.lower() in field_value.lower()
    elif rule.operator == Operator.NOT_CONTAINS:
        return compare_value.lower() not in field_value.lower()
    elif rule.operator == Operator.EQUALS:
        return field_value.lower().strip() == compare_value.lower().strip()
    elif rule.operator == Operator.STARTS_WITH:
        return field_value.lower().startswith(compare_value.lower())
    elif rule.operator == Operator.ENDS_WITH:
        return field_value.lower().endswith(compare_value.lower())
    elif rule.operator == Operator.LENGTH_GT:
        try:
            return len(field_value) > int(compare_value)
        except ValueError:
            return False
    elif rule.operator == Operator.LENGTH_LT:
        try:
            return len(field_value) < int(compare_value)
        except ValueError:
            return False
    elif rule.operator == Operator.REGEX:
        try:
            return bool(re.search(compare_value, field_value, re.IGNORECASE))
        except re.error:
            return False
    return False


class ConditionMetric(BaseMetric):
    """Condition-based metric using Visual Builder rules"""

    def __init__(self, name: str, rules: List[Dict[str, Any]], gates: List[str] = None, threshold: float = 1.0):
        if not name or not isinstance(name, str):
            raise MetricValidationError("Metric name is required and must be a string")
        if len(name) > MAX_NAME_LENGTH:
            raise MetricValidationError(f"Metric name exceeds {MAX_NAME_LENGTH} characters")

        if not isinstance(rules, list):
            raise MetricValidationError("Rules must be a list")
        if len(rules) > MAX_RULES:
            raise MetricValidationError(f"Maximum {MAX_RULES} rules allowed, got {len(rules)}")

        if not isinstance(threshold, (int, float)) or threshold < 0 or threshold > 1:
            raise MetricValidationError("Threshold must be a number between 0 and 1")

        validated_rules = []
        for i, r in enumerate(rules):
            if not isinstance(r, dict):
                raise MetricValidationError(f"Rule {i} must be a dictionary")

            if "field" not in r:
                raise MetricValidationError(f"Rule {i}: missing 'field' key")
            if "operator" not in r:
                raise MetricValidationError(f"Rule {i}: missing 'operator' key")
            if "value" not in r:
                raise MetricValidationError(f"Rule {i}: missing 'value' key")

            field = r["field"]
            if field not in VALID_FIELDS:
                raise MetricValidationError(f"Rule {i}: invalid field '{field}'. Valid: {VALID_FIELDS}")

            value = str(r["value"])
            if len(value) > MAX_VALUE_LENGTH:
                raise MetricValidationError(f"Rule {i}: value exceeds {MAX_VALUE_LENGTH} characters")

            validated_rules.append(Rule(field, r["operator"], value, r.get("compare_to_field", False)))

        if gates is not None:
            if not isinstance(gates, list):
                raise MetricValidationError("Gates must be a list")
            if len(gates) > len(rules) - 1:
                raise MetricValidationError(f"Too many gates: max {len(rules) - 1} for {len(rules)} rules")

        self._name = name
        self.threshold = threshold
        self.async_mode = False
        self.rules = validated_rules
        self.gates = [Gate(g) for g in (gates or [])]

    @property
    def __name__(self):
        return self._name

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not self.rules:
            self.score = 0.0
            self.reason = "No rules defined"
            self.success = False
            return self.score

        results = [_evaluate_rule(rule, test_case) for rule in self.rules]

        if not self.gates:
            final_result = all(results)
        else:
            final_result = results[0]
            for i, result in enumerate(results[1:]):
                gate = self.gates[i] if i < len(self.gates) else Gate.AND
                final_result = (final_result and result) if gate == Gate.AND else (final_result or result)

        self.score = 1.0 if final_result else 0.0
        rule_strs = []
        for i, rule in enumerate(self.rules):
            val = f"[{rule.value}]" if rule.compare_to_field else rule.value
            rule_strs.append(f"{rule.field} {rule.operator.value} {val}")
            if i < len(self.gates):
                rule_strs.append(self.gates[i].value)
        self.reason = " ".join(rule_strs) + f" -> {'PASS' if final_result else 'FAIL'}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)


def create_condition_metric(name: str, rules: List[Dict], gates: List[str] = None, threshold: float = 1.0) -> ConditionMetric:
    """Create condition metric from UI data"""
    return ConditionMetric(name=name, rules=rules, gates=gates, threshold=threshold)
