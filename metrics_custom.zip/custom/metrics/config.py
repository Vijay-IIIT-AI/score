"""
Configuration for Metrics
"""

# Limits
MAX_RULES = 5
MAX_VALUE_LENGTH = 500
MAX_NAME_LENGTH = 50
MAX_CODE_LENGTH = 10000
MAX_PROMPT_LENGTH = 2000

# Valid fields for condition metrics
VALID_FIELDS = {
    "input",
    "actual_output",
    "expected_output",
    "context",
    "retrieval_context",
    "tools_called",
    "expected_tools",
}

# Testing flag
SKIP_LLM_VALIDATION = True
