"""
Prompt-based Metric (User-defined prompts)
"""

import json
from typing import List

from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

from .config import MAX_NAME_LENGTH, MAX_PROMPT_LENGTH
from .base import MetricValidationError
from .prompts import (
    get_template_content,
    LLM_JUDGE_PROMPT,
    FAITHFULNESS_PROMPT,
    ANSWER_RELEVANCY_PROMPT,
)


class PromptMetric(BaseMetric):
    """User-defined prompt-based metric"""

    def __init__(self, name: str, prompt_template: str, threshold: float = 0.7, model: str = None):
        if not name or not isinstance(name, str):
            raise MetricValidationError("Metric name is required")
        if len(name) > MAX_NAME_LENGTH:
            raise MetricValidationError(f"Name exceeds {MAX_NAME_LENGTH} characters")

        if not prompt_template or not isinstance(prompt_template, str):
            raise MetricValidationError("Prompt template is required")
        if len(prompt_template) > MAX_PROMPT_LENGTH:
            raise MetricValidationError(f"Prompt exceeds {MAX_PROMPT_LENGTH} characters")

        if not isinstance(threshold, (int, float)) or threshold < 0 or threshold > 1:
            raise MetricValidationError("Threshold must be between 0 and 1")

        self._name = name
        self.prompt_template = prompt_template
        self.threshold = threshold
        self._model = model
        self.async_mode = True

    @property
    def __name__(self):
        return self._name

    def _build_prompt(self, test_case: LLMTestCase) -> str:
        import json as _json
        return self.prompt_template.format(
            input=test_case.input or "",
            actual_output=test_case.actual_output or "",
            expected_output=test_case.expected_output or "N/A",
            context=" ".join(test_case.context or []),
            retrieval_context=" ".join([str(c) for c in (test_case.retrieval_context or [])]),
            tools_called=_json.dumps([t.model_dump() for t in (test_case.tools_called or [])]),
            expected_tools=_json.dumps([t.model_dump() for t in (test_case.expected_tools or [])]),
        )

    def _parse_response(self, response: str):
        try:
            if "```" in response:
                response = response.split("```")[1].lstrip("json\n")
            start, end = response.find('{'), response.rfind('}') + 1
            result = json.loads(response[start:end])
            self.score = float(result.get("score", 0.0))
            self.reason = result.get("reason", "")
        except:
            self.score, self.reason = 0.0, "Parse error"
        self.success = self.is_successful()

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        try:
            res, _ = model.generate(self._build_prompt(test_case))
            self._parse_response(res)
        except Exception as e:
            self.score, self.reason, self.success = 0.0, str(e), False
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        try:
            res, _ = await model.a_generate(self._build_prompt(test_case))
            self._parse_response(res)
        except Exception as e:
            self.score, self.reason, self.success = 0.0, str(e), False
        return self.score


def get_prompt_template(template_name: str) -> str:
    """Get a built-in prompt template by name"""
    return get_template_content(template_name)


def create_prompt_metric(name: str, prompt_template: str, threshold: float = 0.7, model: str = None) -> PromptMetric:
    """Create a prompt-based metric from user-defined prompt"""
    return PromptMetric(name=name, prompt_template=prompt_template, threshold=threshold, model=model)


# =============================================================================
# BUILT-IN LLM METRICS
# =============================================================================

class LLMJudgeMetric(BaseMetric):
    def __init__(self, criteria: str, threshold: float = 0.7, model: str = None):
        self.criteria = criteria
        self.threshold = threshold
        self._model = model
        self.async_mode = True

    @property
    def __name__(self):
        return "LLMJudge"

    def _build_prompt(self, test_case: LLMTestCase) -> str:
        return LLM_JUDGE_PROMPT.format(
            criteria=self.criteria,
            input=test_case.input,
            actual_output=test_case.actual_output,
            expected_output=test_case.expected_output or "N/A"
        )

    def _parse_response(self, response: str):
        try:
            result = json.loads(response)
            self.score = float(result.get("score", 0.0))
            self.reason = result.get("reason", "")
        except:
            self.score, self.reason = 0.0, "Parse error"
        self.success = self.is_successful()

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        res, _ = model.generate(self._build_prompt(test_case))
        self._parse_response(res)
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        res, _ = await model.a_generate(self._build_prompt(test_case))
        self._parse_response(res)
        return self.score


class FaithfulnessMetric(BaseMetric):
    def __init__(self, threshold: float = 0.7, model: str = None):
        self.threshold = threshold
        self._model = model
        self.async_mode = True

    @property
    def __name__(self):
        return "Faithfulness"

    def _build_prompt(self, test_case: LLMTestCase) -> str:
        ctx = "\n".join([str(c) for c in test_case.retrieval_context])
        return FAITHFULNESS_PROMPT.format(context=ctx, actual_output=test_case.actual_output)

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not test_case.retrieval_context:
            self.score, self.reason, self.success = 0.0, "No context", False
            return self.score
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        try:
            res, _ = model.generate(self._build_prompt(test_case))
            result = json.loads(res)
            self.score = float(result.get("score", 0.0))
            self.reason = result.get("reason", "")
        except:
            self.score, self.reason = 0.0, "Parse error"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not test_case.retrieval_context:
            self.score, self.reason, self.success = 0.0, "No context", False
            return self.score
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        try:
            res, _ = await model.a_generate(self._build_prompt(test_case))
            result = json.loads(res)
            self.score = float(result.get("score", 0.0))
            self.reason = result.get("reason", "")
        except:
            self.score, self.reason = 0.0, "Parse error"
        self.success = self.is_successful()
        return self.score


class AnswerRelevancyMetric(BaseMetric):
    def __init__(self, threshold: float = 0.7, model: str = None):
        self.threshold = threshold
        self._model = model
        self.async_mode = True

    @property
    def __name__(self):
        return "AnswerRelevancy"

    def _build_prompt(self, test_case: LLMTestCase) -> str:
        return ANSWER_RELEVANCY_PROMPT.format(input=test_case.input, actual_output=test_case.actual_output)

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        try:
            res, _ = model.generate(self._build_prompt(test_case))
            result = json.loads(res)
            self.score = float(result.get("score", 0.0))
            self.reason = result.get("reason", "")
        except:
            self.score, self.reason = 0.0, "Parse error"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        from deepeval.models import GPTModel
        model = GPTModel(model=self._model) if self._model else GPTModel()
        try:
            res, _ = await model.a_generate(self._build_prompt(test_case))
            result = json.loads(res)
            self.score = float(result.get("score", 0.0))
            self.reason = result.get("reason", "")
        except:
            self.score, self.reason = 0.0, "Parse error"
        self.success = self.is_successful()
        return self.score
