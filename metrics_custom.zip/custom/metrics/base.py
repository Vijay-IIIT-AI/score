"""
Base classes and simple metrics
"""

from typing import List
from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase


class MetricValidationError(Exception):
    """Raised when metric validation fails"""
    pass


class CodeValidationError(Exception):
    """Raised when code validation fails"""
    pass


# =============================================================================
# SIMPLE METRICS (No LLM required)
# =============================================================================

class ExactMatchMetric(BaseMetric):
    def __init__(self, threshold: float = 1.0, case_sensitive: bool = False):
        self.threshold = threshold
        self.case_sensitive = case_sensitive
        self.async_mode = False

    @property
    def __name__(self):
        return "ExactMatch"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not test_case.expected_output:
            self.score, self.reason = 0.0, "No expected output"
        else:
            actual = test_case.actual_output or ""
            expected = test_case.expected_output
            if not self.case_sensitive:
                actual, expected = actual.lower().strip(), expected.lower().strip()
            self.score = 1.0 if actual == expected else 0.0
            self.reason = "Match" if self.score == 1.0 else "No match"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)


class ContainsKeywordsMetric(BaseMetric):
    def __init__(self, keywords: List[str], threshold: float = 0.8):
        self.keywords = [k.lower() for k in keywords]
        self.threshold = threshold
        self.async_mode = False

    @property
    def __name__(self):
        return "ContainsKeywords"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        output = (test_case.actual_output or "").lower()
        found = sum(1 for kw in self.keywords if kw in output)
        self.score = found / len(self.keywords) if self.keywords else 0.0
        self.reason = f"Found {found}/{len(self.keywords)} keywords"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)


class ToolCorrectnessMetric(BaseMetric):
    def __init__(self, threshold: float = 0.8, check_args: bool = True):
        self.threshold = threshold
        self.check_args = check_args
        self.async_mode = False

    @property
    def __name__(self):
        return "ToolCorrectness"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        if not test_case.expected_tools:
            self.score, self.reason = 1.0, "No expected tools"
        elif not test_case.tools_called:
            self.score, self.reason = 0.0, "No tools called"
        else:
            called = {t.name for t in test_case.tools_called}
            expected = {t.name for t in test_case.expected_tools}
            correct = called & expected
            self.score = len(correct) / len(expected) if expected else 0.0
            self.reason = f"Correct: {correct}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)


class AgentLoopDetectionMetric(BaseMetric):
    def __init__(self, max_repetitions: int = 3, threshold: float = 0.8):
        self.max_repetitions = max_repetitions
        self.threshold = threshold
        self.async_mode = False

    @property
    def __name__(self):
        return "AgentLoopDetection"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        tools = test_case.tools_called or []
        if len(tools) < 2:
            self.score, self.reason = 1.0, "Not enough calls"
        else:
            seq = [t.name for t in tools]
            reps = sum(1 for i in range(1, len(seq)) if seq[i] == seq[i-1])
            self.score = 1.0 - (reps / (len(seq) - 1))
            self.reason = f"{reps} repetitions" if reps >= self.max_repetitions else "No loops"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)
