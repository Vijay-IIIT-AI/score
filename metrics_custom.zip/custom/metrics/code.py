"""
Code-based Metric (Custom Python code)
"""

from typing import List, Dict, Any, Optional, Union
import json
import re

from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase, ToolCall

from .base import CodeValidationError
from .prompts import CODE_VALIDATION_PROMPT


# =============================================================================
# CODE TEMPLATES
# =============================================================================

CODE_TEMPLATES = {
    "llm": '''class LLMMetric(BaseMetric):
    """LLM Evaluation Metric Template"""

    def __init__(self, threshold: float = 0.7):
        self.threshold = threshold
        self.async_mode = False

    @property
    def __name__(self):
        return "LLMMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        # Available: test_case.input, test_case.actual_output, test_case.expected_output

        if not test_case.actual_output:
            self.score = 0.0
            self.reason = "No output"
        else:
            self.score = 1.0
            self.reason = "Output present"

        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)
''',

    "rag": '''class RAGMetric(BaseMetric):
    """RAG Evaluation Metric Template"""

    def __init__(self, threshold: float = 0.7):
        self.threshold = threshold
        self.async_mode = False

    @property
    def __name__(self):
        return "RAGMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        # Available: test_case.input, test_case.actual_output, test_case.retrieval_context

        if not test_case.retrieval_context:
            self.score = 0.0
            self.reason = "No retrieval context"
            self.success = False
            return self.score

        context_text = " ".join(str(c) for c in test_case.retrieval_context)
        output = test_case.actual_output or ""

        context_words = set(context_text.lower().split())
        output_words = set(output.lower().split())
        overlap = len(context_words & output_words)

        self.score = min(1.0, overlap / 10) if output_words else 0.0
        self.reason = f"Word overlap: {overlap}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)
''',

    "agent": '''class AgentMetric(BaseMetric):
    """Agent Evaluation Metric Template"""

    def __init__(self, threshold: float = 0.8):
        self.threshold = threshold
        self.async_mode = False

    @property
    def __name__(self):
        return "AgentMetric"

    def measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        # Available: test_case.input, test_case.actual_output,
        #            test_case.tools_called, test_case.expected_tools

        tools_called = test_case.tools_called or []
        expected_tools = test_case.expected_tools or []

        if not expected_tools:
            self.score = 1.0
            self.reason = "No expected tools defined"
            self.success = True
            return self.score

        if not tools_called:
            self.score = 0.0
            self.reason = "No tools called"
            self.success = False
            return self.score

        called_names = {t.name for t in tools_called}
        expected_names = {t.name for t in expected_tools}

        correct = len(called_names & expected_names)
        self.score = correct / len(expected_names) if expected_names else 0.0
        self.reason = f"Correct tools: {correct}/{len(expected_names)}"
        self.success = self.is_successful()
        return self.score

    async def a_measure(self, test_case: LLMTestCase, *args, **kwargs) -> float:
        return self.measure(test_case, *args, **kwargs)
'''
}


def get_code_template(eval_type: str) -> str:
    """Get code template for evaluation type"""
    if eval_type not in CODE_TEMPLATES:
        raise ValueError(f"Unknown type: {eval_type}. Use: llm, rag, agent")
    return CODE_TEMPLATES[eval_type]


# =============================================================================
# SAFE EXECUTION SANDBOX
# =============================================================================

def _get_safe_builtins():
    """Get restricted builtins for code execution"""
    base = __builtins__ if isinstance(__builtins__, dict) else vars(__builtins__)
    return {
        "__build_class__": base["__build_class__"],
        "__name__": "custom_metric",
        "property": property,
        "staticmethod": staticmethod,
        "classmethod": classmethod,
        "super": super,
        "isinstance": isinstance,
        "issubclass": issubclass,
        "hasattr": hasattr,
        "getattr": getattr,
        "len": len,
        "str": str,
        "int": int,
        "float": float,
        "bool": bool,
        "list": list,
        "dict": dict,
        "set": set,
        "tuple": tuple,
        "min": min,
        "max": max,
        "sum": sum,
        "abs": abs,
        "round": round,
        "sorted": sorted,
        "enumerate": enumerate,
        "zip": zip,
        "range": range,
        "True": True,
        "False": False,
        "None": None,
        "Exception": Exception,
        "ValueError": ValueError,
        "TypeError": TypeError,
    }


def _get_safe_namespace():
    """Get safe namespace for code execution"""
    return {
        "__builtins__": _get_safe_builtins(),
        "BaseMetric": BaseMetric,
        "LLMTestCase": LLMTestCase,
        "ToolCall": ToolCall,
        "json": json,
        "re": re,
        "List": List,
        "Dict": Dict,
        "Any": Any,
        "Optional": Optional,
        "Union": Union,
    }


def _execute_and_find_metric(code: str) -> BaseMetric:
    """Execute code and find metric class"""
    safe_ns = _get_safe_namespace()
    exec(code, safe_ns)
    for obj in safe_ns.values():
        if isinstance(obj, type) and issubclass(obj, BaseMetric) and obj != BaseMetric:
            return obj()
    raise ValueError("No valid BaseMetric subclass found in code")


# =============================================================================
# CODE VALIDATION
# =============================================================================

def _parse_validation_response(response: str) -> tuple[bool, List[str]]:
    """Parse LLM validation response"""
    response = response.strip()
    if "```" in response:
        response = response.split("```")[1].lstrip("json\n")
    start, end = response.find('{'), response.rfind('}') + 1
    result = json.loads(response[start:end])
    return result.get("valid", False), result.get("issues", [])


def validate_code(code: str, model: str = None) -> tuple[bool, List[str]]:
    """Validate code using LLM for security analysis"""
    from deepeval.models import GPTModel
    llm = GPTModel(model=model) if model else GPTModel()
    try:
        res, _ = llm.generate(CODE_VALIDATION_PROMPT.format(code=code))
        return _parse_validation_response(res)
    except Exception as e:
        return False, [f"Validation error: {str(e)}"]


async def validate_code_async(code: str, model: str = None) -> tuple[bool, List[str]]:
    """Async version of validate_code"""
    from deepeval.models import GPTModel
    llm = GPTModel(model=model) if model else GPTModel()
    try:
        res, _ = await llm.a_generate(CODE_VALIDATION_PROMPT.format(code=code))
        return _parse_validation_response(res)
    except Exception as e:
        return False, [f"Validation error: {str(e)}"]


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def create_code_metric(code: str, model: str = None, skip_validation: bool = False) -> BaseMetric:
    """Create metric from Python code string"""
    if not skip_validation:
        is_valid, issues = validate_code(code, model=model)
        if not is_valid:
            raise CodeValidationError(f"Code validation failed: {'; '.join(issues)}")
    return _execute_and_find_metric(code)


async def create_code_metric_async(code: str, model: str = None, skip_validation: bool = False) -> BaseMetric:
    """Async version of create_code_metric"""
    if not skip_validation:
        is_valid, issues = await validate_code_async(code, model=model)
        if not is_valid:
            raise CodeValidationError(f"Code validation failed: {'; '.join(issues)}")
    return _execute_and_find_metric(code)
