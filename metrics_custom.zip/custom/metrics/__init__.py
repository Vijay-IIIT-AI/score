"""
Custom Metrics for LLM, Agent, and RAG Evaluation
"""

from .config import (
    MAX_RULES,
    MAX_VALUE_LENGTH,
    MAX_NAME_LENGTH,
    MAX_CODE_LENGTH,
    MAX_PROMPT_LENGTH,
    VALID_FIELDS,
    SKIP_LLM_VALIDATION,
)

from .base import (
    MetricValidationError,
    CodeValidationError,
    ExactMatchMetric,
    ContainsKeywordsMetric,
    ToolCorrectnessMetric,
    AgentLoopDetectionMetric,
)

from .condition import (
    ConditionMetric,
    Operator,
    Gate,
    Rule,
    create_condition_metric,
)

from .prompt import (
    PromptMetric,
    LLMJudgeMetric,
    FaithfulnessMetric,
    AnswerRelevancyMetric,
    create_prompt_metric,
    get_prompt_template,
)

from .code import (
    CODE_TEMPLATES,
    create_code_metric,
    create_code_metric_async,
    get_code_template,
    validate_code,
    validate_code_async,
)

from .prompts import (
    PROMPT_TEMPLATES,
    PROMPT_PLACEHOLDERS,
    PLACEHOLDER_NAMES,
    get_placeholders_for_ui,
    get_templates_for_ui,
    get_templates_by_category,
    validate_prompt_placeholders,
)

__all__ = [
    # Config
    "MAX_RULES",
    "MAX_VALUE_LENGTH",
    "MAX_NAME_LENGTH",
    "MAX_CODE_LENGTH",
    "MAX_PROMPT_LENGTH",
    "VALID_FIELDS",
    "SKIP_LLM_VALIDATION",
    # Errors
    "MetricValidationError",
    "CodeValidationError",
    # Simple Metrics
    "ExactMatchMetric",
    "ContainsKeywordsMetric",
    "ToolCorrectnessMetric",
    "AgentLoopDetectionMetric",
    # Condition Metric (Visual Builder)
    "ConditionMetric",
    "Operator",
    "Gate",
    "Rule",
    "create_condition_metric",
    # Prompt Metric
    "PromptMetric",
    "LLMJudgeMetric",
    "FaithfulnessMetric",
    "AnswerRelevancyMetric",
    "create_prompt_metric",
    "get_prompt_template",
    # Code Metric
    "CODE_TEMPLATES",
    "create_code_metric",
    "create_code_metric_async",
    "get_code_template",
    "validate_code",
    "validate_code_async",
    # Prompts/UI
    "PROMPT_TEMPLATES",
    "PROMPT_PLACEHOLDERS",
    "PLACEHOLDER_NAMES",
    "get_placeholders_for_ui",
    "get_templates_for_ui",
    "get_templates_by_category",
    "validate_prompt_placeholders",
]
