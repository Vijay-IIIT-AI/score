"""
Custom DeepEval Extensions
- Metrics (condition-based, prompt-based, code-based)
- Dataset loading (local files, HuggingFace Hub)
- Excel templates
"""

# =============================================================================
# METRICS
# =============================================================================

from .metrics import (
    # Config
    MAX_RULES,
    MAX_VALUE_LENGTH,
    MAX_NAME_LENGTH,
    MAX_CODE_LENGTH,
    MAX_PROMPT_LENGTH,
    VALID_FIELDS,
    SKIP_LLM_VALIDATION,
    # Errors
    MetricValidationError,
    CodeValidationError,
    # Simple Metrics
    ExactMatchMetric,
    ContainsKeywordsMetric,
    ToolCorrectnessMetric,
    AgentLoopDetectionMetric,
    # Condition Metric (Visual Builder)
    ConditionMetric,
    Operator,
    Gate,
    Rule,
    create_condition_metric,
    # Prompt Metric
    PromptMetric,
    LLMJudgeMetric,
    FaithfulnessMetric,
    AnswerRelevancyMetric,
    create_prompt_metric,
    get_prompt_template,
    # Code Metric
    CODE_TEMPLATES,
    create_code_metric,
    create_code_metric_async,
    get_code_template,
    validate_code,
    validate_code_async,
    # Prompts/UI
    PROMPT_TEMPLATES,
    PROMPT_PLACEHOLDERS,
    PLACEHOLDER_NAMES,
    get_placeholders_for_ui,
    get_templates_for_ui,
    get_templates_by_category,
    validate_prompt_placeholders,
)

# =============================================================================
# DATASET
# =============================================================================

from .dataset import (
    # Loaders
    load_data,
    load_from_huggingface,
    list_hf_configs,
    list_hf_splits,
    get_hf_info,
    # Mapping
    ColumnMapping,
    GuardrailConfig,
    ETLResult,
    StandaloneETL,
    convert_to_test_cases,
    create_etl_team,
    run_etl_pipeline,
    load_dataset,
    load_with_mapping,
    # Templates
    generate_template_xlsx,
    generate_all_templates,
    load_from_template,
    load_template_as_dataset,
    # Builder
    DatasetBuilder,
)

__all__ = [
    # Metrics - Config
    "MAX_RULES",
    "MAX_VALUE_LENGTH",
    "MAX_NAME_LENGTH",
    "MAX_CODE_LENGTH",
    "MAX_PROMPT_LENGTH",
    "VALID_FIELDS",
    "SKIP_LLM_VALIDATION",
    # Metrics - Errors
    "MetricValidationError",
    "CodeValidationError",
    # Metrics - Simple
    "ExactMatchMetric",
    "ContainsKeywordsMetric",
    "ToolCorrectnessMetric",
    "AgentLoopDetectionMetric",
    # Metrics - Condition (Visual Builder)
    "ConditionMetric",
    "Operator",
    "Gate",
    "Rule",
    "create_condition_metric",
    # Metrics - Prompt
    "PromptMetric",
    "LLMJudgeMetric",
    "FaithfulnessMetric",
    "AnswerRelevancyMetric",
    "create_prompt_metric",
    "get_prompt_template",
    # Metrics - Code
    "CODE_TEMPLATES",
    "create_code_metric",
    "create_code_metric_async",
    "get_code_template",
    "validate_code",
    "validate_code_async",
    # Metrics - Prompts/UI
    "PROMPT_TEMPLATES",
    "PROMPT_PLACEHOLDERS",
    "PLACEHOLDER_NAMES",
    "get_placeholders_for_ui",
    "get_templates_for_ui",
    "get_templates_by_category",
    "validate_prompt_placeholders",
    # Dataset - Loaders
    "load_data",
    "load_from_huggingface",
    "list_hf_configs",
    "list_hf_splits",
    "get_hf_info",
    # Dataset - Mapping
    "ColumnMapping",
    "GuardrailConfig",
    "ETLResult",
    "StandaloneETL",
    "convert_to_test_cases",
    "create_etl_team",
    "run_etl_pipeline",
    "load_dataset",
    "load_with_mapping",
    # Dataset - Templates
    "generate_template_xlsx",
    "generate_all_templates",
    "load_from_template",
    "load_template_as_dataset",
    # Dataset - Builder
    "DatasetBuilder",
]
