"""
Dataset Builder for manual test case creation
"""

from typing import List, Dict

from deepeval.dataset import EvaluationDataset
from deepeval.test_case import LLMTestCase

from .mapping import _parse_tools


class DatasetBuilder:
    """Build datasets manually for LLM, RAG, Agent evaluation"""

    def __init__(self):
        self.test_cases: List[LLMTestCase] = []

    def add_case(
        self,
        input: str,
        actual_output: str,
        expected_output: str = None,
        context: List[str] = None,
        retrieval_context: List[str] = None,
        tools_called: List[Dict] = None,
        expected_tools: List[Dict] = None
    ) -> "DatasetBuilder":
        self.test_cases.append(LLMTestCase(
            input=input,
            actual_output=actual_output,
            expected_output=expected_output,
            context=context,
            retrieval_context=retrieval_context,
            tools_called=_parse_tools(tools_called),
            expected_tools=_parse_tools(expected_tools)
        ))
        return self

    def build(self) -> List[LLMTestCase]:
        return self.test_cases

    def build_dataset(self) -> EvaluationDataset:
        ds = EvaluationDataset()
        ds.test_cases = self.test_cases
        return ds

    def __len__(self):
        return len(self.test_cases)
