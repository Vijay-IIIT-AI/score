"""
Dataset Loading for DeepEval
Supports: Local files, HuggingFace Hub, Excel templates
"""

from .loader import (
    load_data,
    load_from_huggingface,
    list_hf_configs,
    list_hf_splits,
    get_hf_info,
)

from .mapping import (
    ColumnMapping,
    GuardrailConfig,
    ETLResult,
    StandaloneETL,
    convert_to_test_cases,
    create_etl_team,
    run_mapping_agents,
    run_mapping_agents_sync,
    run_etl_pipeline,
    load_dataset,
    load_with_mapping,
)

from .templates import (
    TEMPLATES,
    generate_template_xlsx,
    generate_all_templates,
    generate_template_csv,
    load_from_template,
    load_template_as_dataset,
)

from .builder import DatasetBuilder

__all__ = [
    # Loaders
    "load_data",
    "load_from_huggingface",
    "list_hf_configs",
    "list_hf_splits",
    "get_hf_info",
    # Mapping
    "ColumnMapping",
    "GuardrailConfig",
    "ETLResult",
    "StandaloneETL",
    "convert_to_test_cases",
    "create_etl_team",
    "run_mapping_agents",
    "run_mapping_agents_sync",
    "run_etl_pipeline",
    "load_dataset",
    "load_with_mapping",
    # Templates
    "TEMPLATES",
    "generate_template_xlsx",
    "generate_all_templates",
    "generate_template_csv",
    "load_from_template",
    "load_template_as_dataset",
    # Builder
    "DatasetBuilder",
]
