"""
Dataset Loaders for local files and HuggingFace Hub
"""

from typing import List, Dict, Any, Optional
from pathlib import Path
import json


def load_data(file_path: str, **kwargs) -> List[Dict]:
    """Load data from local file (auto-detect format)"""
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == '.json':
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ['data', 'records', 'items', 'rows', 'results']:
                if key in data and isinstance(data[key], list):
                    return data[key]
            return [data]
        return []

    if suffix == '.jsonl':
        records = []
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    records.append(json.loads(line.strip()))
        return records

    if suffix in ['.csv', '.tsv']:
        import csv
        delimiter = '\t' if suffix == '.tsv' else kwargs.get('delimiter', ',')
        with open(file_path, 'r', encoding='utf-8') as f:
            return [dict(row) for row in csv.DictReader(f, delimiter=delimiter)]

    if suffix == '.parquet':
        try:
            import pyarrow.parquet as pq
            return pq.read_table(file_path).to_pandas().to_dict('records')
        except ImportError:
            import pandas as pd
            return pd.read_parquet(file_path).to_dict('records')

    if suffix in ['.arrow', '.feather']:
        import pyarrow as pa
        with pa.memory_map(file_path, 'r') as source:
            return pa.ipc.open_file(source).read_all().to_pandas().to_dict('records')

    if suffix in ['.xlsx', '.xls']:
        import pandas as pd
        return pd.read_excel(file_path, sheet_name=kwargs.get('sheet_name', 0)).to_dict('records')

    raise ValueError(f"Unsupported format: {suffix}")


def load_from_huggingface(
    dataset_name: str,
    config: Optional[str] = None,
    split: Optional[str] = None,
    streaming: bool = False,
    limit: int = None,
    **kwargs
) -> List[Dict]:
    """Load data from Hugging Face Hub"""
    try:
        from datasets import load_dataset as hf_load
    except ImportError:
        raise ImportError("pip install datasets")

    args = [dataset_name]
    if config:
        args.append(config)

    load_kwargs = {**kwargs}
    if split:
        load_kwargs["split"] = split
    if streaming:
        load_kwargs["streaming"] = True

    ds = hf_load(*args, **load_kwargs)

    if streaming:
        max_rows = limit or 1000
        return [dict(row) for i, row in enumerate(ds) if i < max_rows]

    if hasattr(ds, 'keys'):
        records = []
        for split_name in ds.keys():
            for row in ds[split_name]:
                r = dict(row)
                r['_split'] = split_name
                records.append(r)
                if limit and len(records) >= limit:
                    return records
        return records

    records = [dict(row) for row in ds]
    if limit:
        records = records[:limit]
    return records


def list_hf_configs(dataset_name: str) -> List[str]:
    """List available configs for a HuggingFace dataset"""
    try:
        from datasets import get_dataset_config_names
        return get_dataset_config_names(dataset_name)
    except:
        return ["default"]


def list_hf_splits(dataset_name: str, config: Optional[str] = None) -> List[str]:
    """List available splits for a HuggingFace dataset"""
    try:
        from datasets import get_dataset_split_names
        return get_dataset_split_names(dataset_name, config_name=config)
    except:
        return ["train"]


def get_hf_info(dataset_name: str) -> Dict[str, Any]:
    """Get HuggingFace dataset info (configs, splits, schema)"""
    try:
        from datasets import get_dataset_config_names, get_dataset_split_names, load_dataset_builder
    except ImportError:
        raise ImportError("pip install datasets")

    try:
        configs = get_dataset_config_names(dataset_name)
    except:
        configs = ["default"]

    info = {"name": dataset_name, "configs": configs, "splits": {}, "features": {}}

    for cfg in configs[:3]:
        try:
            cfg_name = cfg if cfg != "default" else None
            info["splits"][cfg] = get_dataset_split_names(dataset_name, config_name=cfg_name)
            builder = load_dataset_builder(dataset_name, cfg_name)
            if hasattr(builder, 'info') and builder.info.features:
                info["features"][cfg] = list(builder.info.features.keys())
        except:
            pass

    return info
