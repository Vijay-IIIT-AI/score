"""
Column Mapping and ETL Agents
"""

from typing import List, Dict, Optional
from dataclasses import dataclass, field
from pathlib import Path
import json
import asyncio

from deepeval.test_case import LLMTestCase, ToolCall

from .loader import load_data, load_from_huggingface


@dataclass
class ColumnMapping:
    input_col: str
    actual_output_col: str
    expected_output_col: Optional[str] = None
    context_col: Optional[str] = None
    retrieval_context_col: Optional[str] = None
    tools_called_col: Optional[str] = None
    expected_tools_col: Optional[str] = None


@dataclass
class GuardrailConfig:
    max_retries: int = 3
    max_rounds: int = 10
    required_fields: List[str] = field(default_factory=lambda: ["input_col", "actual_output_col"])
    min_confidence: float = 0.7
    sample_size: int = 3


@dataclass
class ETLResult:
    success: bool
    test_cases: List = None
    mapping: Dict = None
    error: str = None


# =============================================================================
# CONVERSION
# =============================================================================

def _parse_tools(tools_data) -> Optional[List[ToolCall]]:
    if not tools_data:
        return None
    if isinstance(tools_data, str):
        try:
            tools_data = json.loads(tools_data)
        except:
            return None
    if isinstance(tools_data, list):
        result = []
        for t in tools_data:
            if isinstance(t, dict):
                result.append(ToolCall(
                    name=t.get("name", ""),
                    input_parameters=t.get("input_parameters", t.get("input")),
                    output=t.get("output")
                ))
        return result or None
    return None


def _parse_list(val) -> Optional[List[str]]:
    if isinstance(val, list):
        return [str(v) for v in val]
    if isinstance(val, str) and val:
        try:
            parsed = json.loads(val)
            return [str(v) for v in parsed] if isinstance(parsed, list) else [val]
        except:
            return [val]
    return None


def convert_to_test_cases(data: List[Dict], mapping: ColumnMapping) -> List[LLMTestCase]:
    """Convert raw data to LLMTestCase using mapping"""
    cases = []
    for row in data:
        input_val = row.get(mapping.input_col, "")
        if not input_val:
            continue

        cases.append(LLMTestCase(
            input=str(input_val),
            actual_output=str(row.get(mapping.actual_output_col, "")) or None,
            expected_output=str(row.get(mapping.expected_output_col)) if mapping.expected_output_col and row.get(mapping.expected_output_col) else None,
            context=_parse_list(row.get(mapping.context_col)) if mapping.context_col else None,
            retrieval_context=_parse_list(row.get(mapping.retrieval_context_col)) if mapping.retrieval_context_col else None,
            tools_called=_parse_tools(row.get(mapping.tools_called_col)) if mapping.tools_called_col else None,
            expected_tools=_parse_tools(row.get(mapping.expected_tools_col)) if mapping.expected_tools_col else None
        ))
    return cases


# =============================================================================
# AUTOGEN ETL TEAM
# =============================================================================

def create_etl_team(model: str = "gpt-4o-mini", api_key: str = None, guardrails: GuardrailConfig = None):
    """Create AutoGen ETL team (Mapper, Verifier, Executor)"""
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat
    from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
    from autogen_ext.models.openai import OpenAIChatCompletionClient

    guardrails = guardrails or GuardrailConfig()
    client_kwargs = {"model": model}
    if api_key:
        client_kwargs["api_key"] = api_key
    model_client = OpenAIChatCompletionClient(**client_kwargs)

    mapper = AssistantAgent(
        name="Mapper",
        model_client=model_client,
        system_message="""Data Mapping Expert. Analyze columns and sample data to map to evaluation fields.

        Target fields:
        - input_col: User query/question/prompt (REQUIRED)
        - actual_output_col: LLM/agent response (REQUIRED)
        - expected_output_col: Ground truth (optional)
        - context_col: Background context (optional)
        - retrieval_context_col: Retrieved docs for RAG (optional)
        - tools_called_col: Agent tool calls (optional)
        - expected_tools_col: Expected tools (optional)

        Respond with JSON:
        {"input_col": "<col>", "actual_output_col": "<col>", ...}

        Then say "MAPPING_COMPLETE"."""
    )

    verifier = AssistantAgent(
        name="Verifier",
        model_client=model_client,
        system_message="""Data Validation Expert. Verify column mapping is correct.

        If valid: {"valid": true} then "VERIFIED"
        If invalid: {"valid": false, "issues": [...]} then "NEEDS_REVISION"."""
    )

    executor = AssistantAgent(
        name="Executor",
        model_client=model_client,
        system_message="""Confirm mapping ready. When you see "VERIFIED", say "EXECUTE_READY"."""
    )

    termination = TextMentionTermination("EXECUTE_READY") | MaxMessageTermination(guardrails.max_rounds)
    team = RoundRobinGroupChat(participants=[mapper, verifier, executor], termination_condition=termination)

    return team, mapper, verifier, executor


async def run_mapping_agents(
    columns: List[str],
    sample: List[Dict],
    eval_type: str = "llm",
    model: str = "gpt-4o-mini",
    api_key: str = None,
    guardrails: GuardrailConfig = None
) -> Dict:
    """Run AutoGen agents to map columns"""
    from autogen_agentchat.ui import Console

    team, _, _, _ = create_etl_team(model, api_key, guardrails)

    task = f"""Map columns to evaluation fields.
            Evaluation Type: {eval_type}
            Columns: {columns}
            Sample: {json.dumps(sample[:3], indent=2, default=str)}"""

    result = await Console(team.run_stream(task=task))

    for msg in result.messages:
        if hasattr(msg, 'content') and '{' in str(msg.content):
            try:
                content = str(msg.content)
                start, end = content.find('{'), content.rfind('}') + 1
                if start >= 0 and end > start:
                    mapping = json.loads(content[start:end])
                    if "input_col" in mapping:
                        return mapping
            except:
                continue
    return None


def run_mapping_agents_sync(
    columns: List[str],
    sample: List[Dict],
    eval_type: str = "llm",
    model: str = "gpt-4o-mini",
    api_key: str = None,
    guardrails: GuardrailConfig = None
) -> Dict:
    """Sync wrapper for run_mapping_agents"""
    return asyncio.run(run_mapping_agents(columns, sample, eval_type, model, api_key, guardrails))


# =============================================================================
# STANDALONE ETL (No AutoGen)
# =============================================================================

class StandaloneETL:
    """Standalone ETL using DeepEval's GPTModel (no AutoGen)"""

    def __init__(self, model: str = None, guardrails: GuardrailConfig = None):
        self.model = model
        self.guardrails = guardrails or GuardrailConfig()
        self._llm = None

    def _get_llm(self):
        if not self._llm:
            from deepeval.models import GPTModel
            self._llm = GPTModel(model=self.model) if self.model else GPTModel()
        return self._llm

    def map_columns(self, columns: List[str], sample: List[Dict], eval_type: str) -> Dict:
        prompt = f"""Map columns to evaluation fields for {eval_type} evaluation.

            Columns: {columns}
            Sample: {json.dumps(sample[:3], indent=2, default=str)}

            Return ONLY JSON:
            {{"input_col": "...", "actual_output_col": "...", "expected_output_col": null, "context_col": null, "retrieval_context_col": null, "tools_called_col": null, "expected_tools_col": null}}"""

        for _ in range(self.guardrails.max_retries):
            try:
                res, _ = self._get_llm().generate(prompt)
                response = res.strip()
                if "```" in response:
                    response = response.split("```")[1].lstrip("json\n")
                start, end = response.find('{'), response.rfind('}') + 1
                mapping = json.loads(response[start:end])
                for req in self.guardrails.required_fields:
                    if not mapping.get(req):
                        raise ValueError(f"Missing: {req}")
                return mapping
            except:
                continue
        raise ValueError("Mapping failed")

    def run(self, file_path: str, eval_type: str = "llm") -> ETLResult:
        try:
            data = load_data(file_path)
            columns = list(data[0].keys())
            mapping_dict = self.map_columns(columns, data[:self.guardrails.sample_size], eval_type)

            mapping = ColumnMapping(
                input_col=mapping_dict.get("input_col", ""),
                actual_output_col=mapping_dict.get("actual_output_col", ""),
                expected_output_col=mapping_dict.get("expected_output_col"),
                context_col=mapping_dict.get("context_col"),
                retrieval_context_col=mapping_dict.get("retrieval_context_col"),
                tools_called_col=mapping_dict.get("tools_called_col"),
                expected_tools_col=mapping_dict.get("expected_tools_col")
            )

            return ETLResult(success=True, test_cases=convert_to_test_cases(data, mapping), mapping=mapping_dict)
        except Exception as e:
            return ETLResult(success=False, error=str(e))


# =============================================================================
# MAIN LOADING FUNCTIONS
# =============================================================================

def run_etl_pipeline(
    file_path: str,
    eval_type: str = "llm",
    model: str = "gpt-4o-mini",
    api_key: str = None,
    guardrails: GuardrailConfig = None
) -> ETLResult:
    """Run full ETL pipeline with AutoGen agents"""
    guardrails = guardrails or GuardrailConfig()

    try:
        data = load_data(file_path)
        if not data:
            return ETLResult(success=False, error="Empty dataset")
    except Exception as e:
        return ETLResult(success=False, error=str(e))

    columns = list(data[0].keys())
    sample = data[:guardrails.sample_size]

    mapping_dict = run_mapping_agents_sync(columns, sample, eval_type, model, api_key, guardrails)
    if not mapping_dict:
        return ETLResult(success=False, error="Agent mapping failed")

    for req in guardrails.required_fields:
        if not mapping_dict.get(req):
            return ETLResult(success=False, error=f"Missing: {req}")

    mapping = ColumnMapping(
        input_col=mapping_dict.get("input_col", ""),
        actual_output_col=mapping_dict.get("actual_output_col", ""),
        expected_output_col=mapping_dict.get("expected_output_col"),
        context_col=mapping_dict.get("context_col"),
        retrieval_context_col=mapping_dict.get("retrieval_context_col"),
        tools_called_col=mapping_dict.get("tools_called_col"),
        expected_tools_col=mapping_dict.get("expected_tools_col")
    )

    return ETLResult(success=True, test_cases=convert_to_test_cases(data, mapping), mapping=mapping_dict)


def load_dataset(
    source: str,
    config: Optional[str] = None,
    split: Optional[str] = None,
    eval_type: str = "llm",
    model: str = "gpt-4o-mini",
    use_autogen: bool = False,
    **kwargs
) -> ETLResult:
    """Load dataset with LLM-based column mapping"""
    if Path(source).exists():
        data = load_data(source, **kwargs)
    else:
        data = load_from_huggingface(source, config=config, split=split, **kwargs)

    if not data:
        raise ValueError(f"No data from {source}")

    columns = list(data[0].keys())
    sample = data[:5]

    if use_autogen:
        mapping_dict = run_mapping_agents_sync(columns, sample, eval_type, model, None, GuardrailConfig())
    else:
        etl = StandaloneETL(model=model, guardrails=GuardrailConfig())
        mapping_dict = etl.map_columns(columns, sample, eval_type)

    if not mapping_dict:
        raise ValueError("Mapping failed")

    mapping = ColumnMapping(
        input_col=mapping_dict.get("input_col", ""),
        actual_output_col=mapping_dict.get("actual_output_col", ""),
        expected_output_col=mapping_dict.get("expected_output_col"),
        context_col=mapping_dict.get("context_col"),
        retrieval_context_col=mapping_dict.get("retrieval_context_col"),
        tools_called_col=mapping_dict.get("tools_called_col"),
        expected_tools_col=mapping_dict.get("expected_tools_col")
    )

    return ETLResult(
        success=True,
        test_cases=convert_to_test_cases(data, mapping),
        mapping=mapping_dict
    )


def load_with_mapping(
    source: str,
    mapping: ColumnMapping,
    config: Optional[str] = None,
    split: Optional[str] = None,
    **kwargs
) -> List[LLMTestCase]:
    """Load dataset with explicit column mapping (no agent needed)"""
    if Path(source).exists():
        data = load_data(source, **kwargs)
    else:
        data = load_from_huggingface(source, config=config, split=split, **kwargs)

    return convert_to_test_cases(data, mapping)
