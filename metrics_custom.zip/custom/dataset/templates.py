"""
Excel Templates for DeepEval Datasets
"""

from typing import List, Dict
from pathlib import Path


TEMPLATES = {
    "llm": {
        "name": "LLM Evaluation",
        "description": "For evaluating LLM responses (accuracy, quality, etc.)",
        "columns": [
            {"name": "input", "description": "User query/question/prompt", "required": True, "example": "What is the capital of France?"},
            {"name": "actual_output", "description": "LLM response to evaluate", "required": True, "example": "The capital of France is Paris."},
            {"name": "expected_output", "description": "Ground truth/expected answer", "required": False, "example": "Paris"},
            {"name": "context", "description": "Background context (if any)", "required": False, "example": ""},
            {"name": "tags", "description": "Labels for filtering (comma-separated)", "required": False, "example": "geography,easy"},
        ]
    },
    "agent": {
        "name": "Agent Evaluation",
        "description": "For evaluating AI agents (tool usage, task completion)",
        "columns": [
            {"name": "input", "description": "Task/instruction for the agent", "required": True, "example": "Search for weather in Tokyo"},
            {"name": "actual_output", "description": "Agent's final response", "required": True, "example": "The weather in Tokyo is 25C and sunny."},
            {"name": "expected_output", "description": "Expected final answer", "required": False, "example": "Weather information for Tokyo"},
            {"name": "tools_called", "description": "Tools used (JSON array)", "required": True, "example": '[{"name": "search", "input_parameters": {"query": "Tokyo weather"}}]'},
            {"name": "expected_tools", "description": "Expected tools (JSON array)", "required": False, "example": '[{"name": "search"}]'},
            {"name": "tags", "description": "Labels for filtering", "required": False, "example": "weather,api"},
        ]
    },
    "rag": {
        "name": "RAG Evaluation",
        "description": "For evaluating Retrieval-Augmented Generation (faithfulness, relevancy)",
        "columns": [
            {"name": "input", "description": "User query/question", "required": True, "example": "What are the symptoms of flu?"},
            {"name": "actual_output", "description": "RAG system response", "required": True, "example": "Common flu symptoms include fever, cough, and fatigue."},
            {"name": "expected_output", "description": "Expected answer", "required": False, "example": "Fever, cough, body aches, fatigue"},
            {"name": "retrieval_context", "description": "Retrieved documents (JSON array)", "required": True, "example": '["Flu symptoms: fever, cough, fatigue, body aches.", "The flu is caused by influenza virus."]'},
            {"name": "context", "description": "Additional context", "required": False, "example": ""},
            {"name": "tags", "description": "Labels for filtering", "required": False, "example": "medical,symptoms"},
        ]
    },
    "all": {
        "name": "Combined Evaluation",
        "description": "Universal template supporting LLM, Agent, and RAG",
        "columns": [
            {"name": "eval_type", "description": "Type: llm, agent, or rag", "required": True, "example": "llm"},
            {"name": "input", "description": "User query/task", "required": True, "example": "What is 2+2?"},
            {"name": "actual_output", "description": "System response", "required": True, "example": "4"},
            {"name": "expected_output", "description": "Expected answer", "required": False, "example": "4"},
            {"name": "context", "description": "Background context", "required": False, "example": ""},
            {"name": "retrieval_context", "description": "Retrieved docs (JSON array, for RAG)", "required": False, "example": ""},
            {"name": "tools_called", "description": "Tools used (JSON array, for Agent)", "required": False, "example": ""},
            {"name": "expected_tools", "description": "Expected tools (JSON array, for Agent)", "required": False, "example": ""},
            {"name": "tags", "description": "Labels for filtering", "required": False, "example": "math,easy"},
        ]
    }
}


def generate_template_xlsx(eval_type: str, output_path: str, num_sample_rows: int = 3):
    """Generate Excel template for specified evaluation type"""
    try:
        import pandas as pd
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.comments import Comment
    except ImportError:
        raise ImportError("Install: pip install pandas openpyxl")

    if eval_type not in TEMPLATES:
        raise ValueError(f"Unknown type: {eval_type}. Use: llm, agent, rag, all")

    template = TEMPLATES[eval_type]
    columns = [col["name"] for col in template["columns"]]

    sample_data = []
    for i in range(num_sample_rows):
        row = {col["name"]: col["example"] for col in template["columns"]}
        if i > 0:
            row["input"] = f"Example question {i+1}"
            row["actual_output"] = f"Example answer {i+1}"
        sample_data.append(row)

    df = pd.DataFrame(sample_data)
    df.to_excel(output_path, index=False, sheet_name="Data")

    wb = load_workbook(output_path)
    ws = wb.active

    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    required_fill = PatternFill(start_color="FFC000", end_color="FFC000", fill_type="solid")
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )

    for col_idx, col_info in enumerate(template["columns"], 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = required_fill if col_info["required"] else header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border
        cell.comment = Comment(
            f"{col_info['description']}\n\nRequired: {'Yes' if col_info['required'] else 'No'}\n\nExample: {col_info['example']}",
            "Template"
        )
        ws.column_dimensions[cell.column_letter].width = max(15, len(col_info["name"]) + 5)

    instructions = wb.create_sheet("Instructions")
    instructions["A1"] = f"Template: {template['name']}"
    instructions["A1"].font = Font(bold=True, size=14)
    instructions["A3"] = template["description"]
    instructions["A5"] = "Column Descriptions:"
    instructions["A5"].font = Font(bold=True)

    row = 6
    for col_info in template["columns"]:
        req = "REQUIRED" if col_info["required"] else "optional"
        instructions[f"A{row}"] = f"- {col_info['name']} ({req}): {col_info['description']}"
        row += 1

    instructions[f"A{row + 1}"] = "Notes:"
    instructions[f"A{row + 1}"].font = Font(bold=True)
    instructions[f"A{row + 2}"] = "- Yellow headers = Required fields"
    instructions[f"A{row + 3}"] = "- Blue headers = Optional fields"
    instructions[f"A{row + 4}"] = "- JSON arrays should be valid JSON (use double quotes)"

    wb.save(output_path)
    return output_path


def generate_all_templates(output_dir: str = "."):
    """Generate all template files"""
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    files = []
    for eval_type in ["llm", "agent", "rag", "all"]:
        file_path = output_path / f"template_{eval_type}.xlsx"
        generate_template_xlsx(eval_type, str(file_path))
        files.append(str(file_path))

    return files


def generate_template_csv(eval_type: str, output_path: str):
    """Generate CSV template (simpler alternative to XLSX)"""
    import csv

    if eval_type not in TEMPLATES:
        raise ValueError(f"Unknown type: {eval_type}")

    template = TEMPLATES[eval_type]

    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        headers = [col["name"] for col in template["columns"]]
        writer.writerow(headers)
        examples = [col["example"] for col in template["columns"]]
        writer.writerow(examples)

    return output_path


def load_from_template(file_path: str) -> tuple:
    """Load data from a filled template"""
    from .loader import load_data
    from .mapping import ColumnMapping, convert_to_test_cases

    data = load_data(file_path)
    if not data:
        raise ValueError("Empty template")

    columns = list(data[0].keys())

    if "eval_type" in columns:
        eval_type = data[0].get("eval_type", "llm")
    elif "tools_called" in columns and any(row.get("tools_called") for row in data):
        eval_type = "agent"
    elif "retrieval_context" in columns and any(row.get("retrieval_context") for row in data):
        eval_type = "rag"
    else:
        eval_type = "llm"

    mapping = ColumnMapping(
        input_col="input",
        actual_output_col="actual_output",
        expected_output_col="expected_output" if "expected_output" in columns else None,
        context_col="context" if "context" in columns else None,
        retrieval_context_col="retrieval_context" if "retrieval_context" in columns else None,
        tools_called_col="tools_called" if "tools_called" in columns else None,
        expected_tools_col="expected_tools" if "expected_tools" in columns else None
    )

    test_cases = convert_to_test_cases(data, mapping)
    return test_cases, eval_type


def load_template_as_dataset(file_path: str):
    """Load template and return EvaluationDataset"""
    from deepeval.dataset import EvaluationDataset

    test_cases, eval_type = load_from_template(file_path)
    dataset = EvaluationDataset()
    dataset.test_cases = test_cases
    return dataset, eval_type
