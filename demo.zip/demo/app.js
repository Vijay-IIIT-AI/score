// SemcoEval Demo - Frontend Logic

// State
let currentPage = 'dashboard';
let currentStep = 1;
let uploadedFile = null;
let parsedData = null;
let detectedColumns = [];
let selectedEvalType = 'model';
let selectedMetricType = 'visual';
let uploadEvalType = 'model';  // Separate state for upload page

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initMetricForm();
    initUploadForm();
    initDropzone();
    updateRuleFieldOptions();  // Set initial field options based on default eval type
    updateRulePreview();
});

// Navigation
function initNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            showPage(page);
        });
    });
}

function showPage(page) {
    currentPage = page;

    // Update nav
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });

    // Update pages
    document.querySelectorAll('.page').forEach(p => {
        p.classList.toggle('active', p.id === `page-${page}`);
    });

    // Reset upload steps when showing upload page
    if (page === 'upload') {
        goToStep(1);
    }
}

// Metric Form
function initMetricForm() {
    // Metric card click handlers
    document.querySelectorAll('.metric-card').forEach(card => {
        card.addEventListener('click', () => {
            const radio = card.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        });
    });

    // Rule change handlers for live preview
    document.getElementById('rules-container').addEventListener('change', updateRulePreview);
    document.getElementById('rules-container').addEventListener('input', updateRulePreview);
}

// Rule counter
let ruleCount = 1;

// Add a new rule with gate
function addRule() {
    ruleCount++;
    const gate = document.getElementById('gate-type').value;
    const container = document.getElementById('rules-container');

    // Get field options based on current eval type
    const fields = fieldsByEvalType[selectedEvalType];
    const fieldOptionsHtml = fields.map(f => `<option value="${f.value}">${f.label}</option>`).join('');

    const ruleHtml = `
        <div class="gate-badge">${gate}</div>
        <div class="rule-item" data-rule="${ruleCount}">
            <div class="rule-fields">
                <select class="rule-field-select">
                    ${fieldOptionsHtml}
                </select>
                <select class="rule-operator">
                    <option value="contains">contains</option>
                    <option value="not_contains">not contains</option>
                    <option value="equals">equals</option>
                    <option value="starts_with">starts with</option>
                    <option value="ends_with">ends with</option>
                    <option value="length_gt">length ></option>
                    <option value="length_lt">length <</option>
                    <option value="regex">regex match</option>
                </select>
                <select class="rule-compare-type" onchange="toggleValueInput(this)">
                    <option value="literal">Literal Value</option>
                    <option value="field">Compare to Field</option>
                </select>
                <input type="text" class="rule-value rule-value-literal" placeholder="enter value">
                <select class="rule-value rule-value-field hidden">
                    ${fieldOptionsHtml}
                </select>
                <button class="btn-icon btn-remove-rule" onclick="removeRule(this)" title="Remove">×</button>
            </div>
        </div>
    `;

    container.insertAdjacentHTML('beforeend', ruleHtml);
    updateRulePreview();
}

// Toggle between literal value input and field dropdown
function toggleValueInput(select) {
    const ruleItem = select.closest('.rule-item');
    const literalInput = ruleItem.querySelector('.rule-value-literal');
    const fieldSelect = ruleItem.querySelector('.rule-value-field');

    if (select.value === 'literal') {
        literalInput.classList.remove('hidden');
        fieldSelect.classList.add('hidden');
    } else {
        literalInput.classList.add('hidden');
        fieldSelect.classList.remove('hidden');
    }
    updateRulePreview();
}

// Remove a rule
function removeRule(btn) {
    const ruleItem = btn.closest('.rule-item');
    const prevSibling = ruleItem.previousElementSibling;

    // Remove the gate badge if it exists
    if (prevSibling && prevSibling.classList.contains('gate-badge')) {
        prevSibling.remove();
    }

    ruleItem.remove();
    updateRulePreview();
}

// Update the rule preview text
function updateRulePreview() {
    const container = document.getElementById('rules-container');
    const rules = container.querySelectorAll('.rule-item');
    const gates = container.querySelectorAll('.gate-badge');

    let preview = '';
    let gateIndex = 0;

    rules.forEach((rule, index) => {
        const field = rule.querySelector('.rule-field-select').value;
        const operator = rule.querySelector('.rule-operator').value;
        const compareType = rule.querySelector('.rule-compare-type')?.value || 'literal';

        let value;
        if (compareType === 'field') {
            const fieldSelect = rule.querySelector('.rule-value-field');
            value = fieldSelect ? fieldSelect.value : 'field';
        } else {
            const literalInput = rule.querySelector('.rule-value-literal');
            value = literalInput && literalInput.value ? `"${literalInput.value}"` : '"value"';
        }

        const operatorText = {
            'contains': 'contains',
            'not_contains': 'not contains',
            'equals': '==',
            'starts_with': 'starts with',
            'ends_with': 'ends with',
            'length_gt': 'length >',
            'length_lt': 'length <',
            'regex': 'matches'
        }[operator];

        if (index > 0 && gates[gateIndex]) {
            preview += ` ${gates[gateIndex].textContent} `;
            gateIndex++;
        }

        preview += `${field} ${operatorText} ${value}`;
    });

    document.getElementById('rule-preview-text').textContent = preview || 'No rules defined';
}

// Field options for each eval type
const fieldsByEvalType = {
    model: [
        { value: 'input', label: 'input' },
        { value: 'actual_output', label: 'actual_output' },
        { value: 'expected_output', label: 'expected_output' },
        { value: 'context', label: 'context' }
    ],
    agent: [
        { value: 'input', label: 'input' },
        { value: 'actual_output', label: 'actual_output' },
        { value: 'expected_output', label: 'expected_output' },
        { value: 'tools_called', label: 'tools_called' },
        { value: 'expected_tools', label: 'expected_tools' }
    ],
    rag: [
        { value: 'input', label: 'input' },
        { value: 'actual_output', label: 'actual_output' },
        { value: 'expected_output', label: 'expected_output' },
        { value: 'retrieval_context', label: 'retrieval_context' },
        { value: 'context', label: 'context' }
    ]
};

// Switch between Model / Agent / RAG
function switchEvalType(type) {
    selectedEvalType = type;

    // Update button states
    document.getElementById('btn-eval-model').classList.toggle('active', type === 'model');
    document.getElementById('btn-eval-agent').classList.toggle('active', type === 'agent');
    document.getElementById('btn-eval-rag').classList.toggle('active', type === 'rag');

    // Update metric templates
    document.getElementById('metrics-model').classList.toggle('active', type === 'model');
    document.getElementById('metrics-agent').classList.toggle('active', type === 'agent');
    document.getElementById('metrics-rag').classList.toggle('active', type === 'rag');

    // Update field dropdowns in rule builder
    updateRuleFieldOptions();
}

// Update field options in all rule dropdowns
function updateRuleFieldOptions() {
    const fields = fieldsByEvalType[selectedEvalType];
    const optionsHtml = fields.map(f => `<option value="${f.value}">${f.label}</option>`).join('');

    // Update the main field selectors
    document.querySelectorAll('.rule-field-select').forEach(select => {
        const currentValue = select.value;
        select.innerHTML = optionsHtml;
        if (fields.some(f => f.value === currentValue)) {
            select.value = currentValue;
        }
    });

    // Update the "compare to field" dropdowns as well
    document.querySelectorAll('.rule-value-field').forEach(select => {
        const currentValue = select.value;
        select.innerHTML = optionsHtml;
        if (fields.some(f => f.value === currentValue)) {
            select.value = currentValue;
        }
    });

    updateRulePreview();
}

// Switch between Visual Builder / Code Editor
function switchMetricType(type) {
    selectedMetricType = type;

    // Update button states
    document.getElementById('btn-visual').classList.toggle('active', type === 'visual');
    document.getElementById('btn-code').classList.toggle('active', type === 'code');

    // Show/hide builder sections
    document.getElementById('visual-builder').classList.toggle('active', type === 'visual');
    document.getElementById('code-editor').classList.toggle('active', type === 'code');
}

function loadTemplate() {
    const templates = {
        model: `from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

class KeywordMatchMetric(BaseMetric):
    """Model evaluation: keyword matching"""

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def measure(self, test_case: LLMTestCase) -> float:
        output = test_case.actual_output.lower()
        expected = test_case.expected_output.lower()

        if expected in output:
            self.score = 1.0
        else:
            keywords = expected.split()
            matches = sum(1 for k in keywords if k in output)
            self.score = matches / len(keywords) if keywords else 0.0

        self.success = self.score >= self.threshold
        return self.score

    async def a_measure(self, test_case: LLMTestCase) -> float:
        return self.measure(test_case)

    def is_successful(self) -> bool:
        return self.success

    @property
    def __name__(self):
        return "Keyword Match"`,
        agent: `from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

class ToolAccuracyMetric(BaseMetric):
    """Agent evaluation: tool call accuracy"""

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def measure(self, test_case: LLMTestCase) -> float:
        expected = test_case.expected_tools or []
        actual = test_case.tools_called or []

        if not expected:
            self.score = 1.0
        else:
            expected_names = {t.name for t in expected}
            actual_names = {t.name for t in actual}
            matches = len(expected_names & actual_names)
            self.score = matches / len(expected_names)

        self.success = self.score >= self.threshold
        return self.score

    async def a_measure(self, test_case: LLMTestCase) -> float:
        return self.measure(test_case)

    def is_successful(self) -> bool:
        return self.success

    @property
    def __name__(self):
        return "Tool Accuracy"`,
        rag: `from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

class FaithfulnessMetric(BaseMetric):
    """RAG evaluation: faithfulness to context"""

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def measure(self, test_case: LLMTestCase) -> float:
        output = test_case.actual_output.lower()
        contexts = test_case.retrieval_context or []

        context_text = ' '.join(contexts).lower()
        words = output.split()[:20]
        grounded = sum(1 for w in words if w in context_text)

        self.score = grounded / len(words) if words else 0.0
        self.success = self.score >= self.threshold
        return self.score

    async def a_measure(self, test_case: LLMTestCase) -> float:
        return self.measure(test_case)

    def is_successful(self) -> bool:
        return self.success

    @property
    def __name__(self):
        return "Faithfulness"`
    };

    document.getElementById('metric-code').value = templates[selectedEvalType];
}

function validateMetric() {
    const dataset = document.getElementById('validation-dataset').value;
    if (!dataset) {
        showToast('Please select a dataset', 'error');
        return;
    }

    // Get selected metric type
    const selectedMetric = document.querySelector(`#metrics-${selectedEvalType} input[type="radio"]:checked`)?.value || 'exact_match';
    const threshold = parseFloat(document.getElementById('rule-threshold').value) || 0.5;

    // Simulate validation with eval-type specific data
    let sampleResults = [];

    if (selectedEvalType === 'model') {
        sampleResults = [
            { input: 'Capital of France?', output: 'Paris', expected: 'Paris', score: 1.0, passed: true },
            { input: 'Who wrote Hamlet?', output: 'Shakespeare wrote it', expected: 'William Shakespeare', score: 0.5, passed: false },
            { input: 'What is H2O?', output: 'H2O is water', expected: 'Water', score: 1.0, passed: true },
            { input: 'Largest planet?', output: 'Jupiter is the largest', expected: 'Jupiter', score: 1.0, passed: true },
            { input: 'Year WW2 ended?', output: '1946', expected: '1945', score: 0.0, passed: false },
        ];
    } else if (selectedEvalType === 'rag') {
        sampleResults = [
            { input: 'Return policy?', output: 'Returns within 30 days', expected: '30 days', score: 1.0, passed: true },
            { input: 'Reset password?', output: 'Click forgot password link', expected: 'Forgot password', score: 1.0, passed: true },
            { input: 'Shipping time?', output: '2 weeks delivery', expected: '5-7 days', score: 0.2, passed: false },
            { input: 'Contact support?', output: 'Email support@company.com', expected: 'support@company.com', score: 1.0, passed: true },
        ];
    } else {
        sampleResults = [
            { input: 'Weather in SF?', output: 'get_weather called', expected: 'get_weather', score: 1.0, passed: true },
            { input: 'Search AI news', output: 'web_search called', expected: 'web_search', score: 1.0, passed: true },
            { input: 'Send email', output: 'calculator called', expected: 'send_email', score: 0.0, passed: false },
            { input: 'Book flight', output: 'book_flight called', expected: 'book_flight', score: 1.0, passed: true },
        ];
    }

    // Apply threshold
    sampleResults = sampleResults.map(r => ({
        ...r,
        passed: r.score >= threshold
    }));

    const tbody = document.getElementById('validation-rows');
    tbody.innerHTML = sampleResults.map((r, i) => `
        <tr>
            <td>${i + 1}</td>
            <td>${truncate(r.input, 25)}</td>
            <td>${truncate(r.output, 25)}</td>
            <td>${truncate(r.expected, 15)}</td>
            <td>${r.score.toFixed(2)}</td>
            <td class="${r.passed ? 'status-pass' : 'status-fail'}">${r.passed ? 'PASS' : 'FAIL'}</td>
        </tr>
    `).join('');

    const avgScore = sampleResults.reduce((a, r) => a + r.score, 0) / sampleResults.length;
    const passRate = sampleResults.filter(r => r.passed).length / sampleResults.length * 100;

    document.getElementById('avg-score').textContent = avgScore.toFixed(2);
    document.getElementById('pass-rate').textContent = passRate.toFixed(0) + '%';

    document.getElementById('validation-results').classList.remove('hidden');
    showToast(`Validated with ${selectedMetric} metric`, 'success');
}

function saveMetric() {
    const name = document.getElementById('metric-name').value;
    if (!name) {
        showToast('Please enter a metric name', 'error');
        return;
    }

    // Add to dashboard list
    const tbody = document.getElementById('metrics-list');
    const type = selectedMetricType === 'visual' ? 'Visual' : 'Code';
    const badgeClass = selectedMetricType === 'visual' ? '' : 'badge-code';
    const today = new Date().toISOString().split('T')[0];

    tbody.innerHTML += `
        <tr>
            <td>${name}</td>
            <td><span class="badge ${badgeClass}">${type}</span></td>
            <td>${today}</td>
            <td><button class="btn-icon" title="Delete" onclick="this.closest('tr').remove()">x</button></td>
        </tr>
    `;

    showToast('Metric saved successfully', 'success');
    showPage('dashboard');
}

// Upload Form
function initUploadForm() {
    // Nothing needed here - using onclick handlers
}

// Switch upload eval type
function switchUploadType(type) {
    uploadEvalType = type;

    // Update button states
    document.getElementById('btn-upload-model').classList.toggle('active', type === 'model');
    document.getElementById('btn-upload-agent').classList.toggle('active', type === 'agent');
    document.getElementById('btn-upload-rag').classList.toggle('active', type === 'rag');

    // Update mapping section
    updateMappingSection();
}

function initDropzone() {
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('file-input');

    dropzone.addEventListener('click', () => fileInput.click());

    dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
    });

    dropzone.addEventListener('dragleave', () => {
        dropzone.classList.remove('dragover');
    });

    dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file) handleFile(file);
    });

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) handleFile(file);
    });
}

function handleFile(file) {
    const validExtensions = ['.json', '.csv', '.parquet', '.arrow'];
    const ext = '.' + file.name.split('.').pop().toLowerCase();

    if (!validExtensions.includes(ext)) {
        showToast('Invalid file format. Use JSON, CSV, Parquet, or Arrow.', 'error');
        return;
    }

    uploadedFile = file;

    // Show file info
    document.getElementById('file-info').classList.remove('hidden');
    document.querySelector('.file-name').textContent = file.name;
    document.querySelector('.file-size').textContent = formatFileSize(file.size);
    document.getElementById('btn-process').disabled = false;
}

function clearFile() {
    uploadedFile = null;
    document.getElementById('file-info').classList.add('hidden');
    document.getElementById('file-input').value = '';
    document.getElementById('btn-process').disabled = true;
}

function processFile() {
    if (!uploadedFile) return;

    // Simulate file processing
    showToast('Processing file...', 'success');

    // Generate sample parsed data based on file type
    setTimeout(() => {
        parsedData = generateSampleData();
        detectedColumns = Object.keys(parsedData[0]);
        goToStep(2);
    }, 500);
}

function generateSampleData() {
    // Sample data based on upload eval type (simulating loaded file)
    if (uploadEvalType === 'model') {
        return [
            { input: 'What is the capital of France?', expected_output: 'Paris' },
            { input: 'Who wrote Romeo and Juliet?', expected_output: 'William Shakespeare' },
            { input: 'What is the chemical symbol for water?', expected_output: 'H2O' },
            { input: 'What year did World War II end?', expected_output: '1945' },
            { input: 'What is the largest planet?', expected_output: 'Jupiter' },
        ];
    } else if (uploadEvalType === 'rag') {
        return [
            { input: 'What is the return policy?', expected_output: '30 days with receipt', retrieval_context: 'Returns within 30 days with receipt.' },
            { input: 'How do I reset my password?', expected_output: 'Click forgot password', retrieval_context: 'Click Forgot Password on login page.' },
            { input: 'What are shipping options?', expected_output: 'Standard and Express', retrieval_context: 'Standard (5-7 days) and Express (1-2 days).' },
        ];
    } else {
        return [
            { input: 'Get weather in San Francisco', expected_output: 'Sunny 68°F', expected_tools: '[{"name":"get_weather"}]' },
            { input: 'Search for AI news', expected_output: 'Latest AI articles', expected_tools: '[{"name":"web_search"}]' },
            { input: 'Send email to john@test.com', expected_output: 'Email sent', expected_tools: '[{"name":"send_email"}]' },
        ];
    }
}

function goToStep(step) {
    currentStep = step;

    // Update steps indicator
    document.querySelectorAll('.step').forEach((s, i) => {
        s.classList.remove('active', 'completed');
        if (i + 1 < step) s.classList.add('completed');
        if (i + 1 === step) s.classList.add('active');
    });

    // Show current step content
    document.querySelectorAll('.upload-step').forEach((s, i) => {
        s.classList.toggle('active', i + 1 === step);
    });

    // Step-specific logic
    if (step === 2 && parsedData) {
        renderPreviewTable();
    }
    if (step === 3) {
        updateMappingSection();
        populateMappingDropdowns();
    }
    if (step === 4) {
        renderTransformPreview();
    }
}

function renderPreviewTable() {
    const thead = document.getElementById('preview-header');
    const tbody = document.getElementById('preview-body');

    // Header
    thead.innerHTML = '<tr>' + detectedColumns.map(col => `<th>${col}</th>`).join('') + '</tr>';

    // Body (first 5 rows)
    tbody.innerHTML = parsedData.slice(0, 5).map(row =>
        '<tr>' + detectedColumns.map(col => `<td>${truncate(row[col], 40)}</td>`).join('') + '</tr>'
    ).join('');

    // Total rows
    document.getElementById('total-rows').textContent = parsedData.length;

    // Column chips
    const chips = document.getElementById('column-chips');
    chips.innerHTML = detectedColumns.map(col =>
        `<span class="column-chip">${col} <span class="type">(string)</span></span>`
    ).join('');
}

function updateMappingSection() {
    document.querySelectorAll('.mapping-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(`mapping-${uploadEvalType}`).classList.add('active');
}

function populateMappingDropdowns() {
    const options = '<option value="">-- Select column --</option>' +
        detectedColumns.map(col => `<option value="${col}">${col}</option>`).join('');

    document.querySelectorAll('.mapping-source').forEach(select => {
        select.innerHTML = options;
    });
}

function autoMapFields() {
    showToast('AI is analyzing columns...', 'success');

    // Simulate AI mapping based on DeepEval LLMTestCase fields
    setTimeout(() => {
        // Smart mapping based on common column names
        const columnMappings = {};
        detectedColumns.forEach(col => {
            const lower = col.toLowerCase();
            if (lower.includes('input') || lower.includes('question') || lower.includes('prompt')) {
                columnMappings['input'] = col;
            }
            if (lower.includes('expected') || lower.includes('answer') || lower.includes('output')) {
                columnMappings['expected_output'] = col;
            }
            if (lower.includes('context') || lower.includes('retrieval')) {
                columnMappings['retrieval_context'] = col;
            }
            if (lower.includes('tool')) {
                columnMappings['expected_tools'] = col;
            }
        });

        // Apply to current mapping section only
        document.querySelectorAll(`#mapping-${uploadEvalType} .mapping-source`).forEach(select => {
            const target = select.dataset.target;
            if (columnMappings[target]) {
                select.value = columnMappings[target];
            }
        });

        showToast('Columns mapped automatically', 'success');
    }, 800);
}

function previewTransform() {
    // Validate required mappings based on DeepEval LLMTestCase
    const requiredFields = uploadEvalType === 'model'
        ? ['input', 'expected_output']
        : uploadEvalType === 'agent'
        ? ['input', 'expected_tools']
        : ['input', 'retrieval_context', 'expected_output'];

    const mappings = {};
    let valid = true;

    document.querySelectorAll(`#mapping-${uploadEvalType} .mapping-source`).forEach(select => {
        const target = select.dataset.target;
        mappings[target] = select.value;
        if (requiredFields.includes(target) && !select.value) {
            valid = false;
        }
    });

    if (!valid) {
        showToast('Please map all required fields', 'error');
        return;
    }

    goToStep(4);
}

function renderTransformPreview() {
    const mappings = {};
    document.querySelectorAll(`#mapping-${uploadEvalType} .mapping-source`).forEach(select => {
        if (select.value) {
            mappings[select.dataset.target] = select.value;
        }
    });

    // Transform first row as DeepEval LLMTestCase format
    const row = parsedData[0];
    const transformed = {
        input: mappings['input'] ? row[mappings['input']] : null,
        actual_output: null,  // Will be filled at runtime
        expected_output: mappings['expected_output'] ? row[mappings['expected_output']] : null
    };

    // Add optional fields based on eval type
    if (uploadEvalType === 'rag' && mappings['retrieval_context']) {
        transformed.retrieval_context = [row[mappings['retrieval_context']]];
    }
    if (uploadEvalType === 'agent' && mappings['expected_tools']) {
        transformed.expected_tools = row[mappings['expected_tools']];
    }
    if (mappings['context']) {
        transformed.context = [row[mappings['context']]];
    }

    document.getElementById('transform-preview').textContent = JSON.stringify(transformed, null, 2);
    document.getElementById('summary-rows').textContent = parsedData.length;
    document.getElementById('summary-type').textContent = uploadEvalType.charAt(0).toUpperCase() + uploadEvalType.slice(1);
    document.getElementById('summary-valid').textContent = parsedData.length;
    document.getElementById('summary-errors').textContent = '0';
}

function saveDataset() {
    const name = document.getElementById('dataset-name').value;
    if (!name) {
        showToast('Please enter a dataset name', 'error');
        return;
    }

    // Add to dashboard list
    const tbody = document.getElementById('datasets-list');
    const badgeClass = `badge-${uploadEvalType}`;

    tbody.innerHTML += `
        <tr>
            <td>${name}</td>
            <td><span class="badge ${badgeClass}">${uploadEvalType.charAt(0).toUpperCase() + uploadEvalType.slice(1)}</span></td>
            <td>${parsedData.length}</td>
            <td><button class="btn-icon" title="Delete" onclick="this.closest('tr').remove()">x</button></td>
        </tr>
    `;

    showToast('Dataset saved successfully', 'success');
    showPage('dashboard');
}

// Utilities
function truncate(str, len) {
    if (!str) return '';
    str = String(str);
    return str.length > len ? str.slice(0, len) + '...' : str;
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = 'toast ' + type;

    setTimeout(() => {
        toast.classList.add('hidden');
    }, 3000);
}
