# SemcoEval Demo - Technical Specification

## Overview

This document explains how users can:
1. Create custom evaluation metrics
2. Upload and map custom datasets

---

## 1. Custom Metrics

### What is a Custom Metric?

A metric is a rule that checks if the model's output is good or bad.

**Example:**
- "Does the answer contain the word 'Paris'?" → Score: 1 (yes) or 0 (no)
- "Is the answer length more than 50 characters?" → Score: 1 (yes) or 0 (no)

### Two Ways to Create Metrics

#### Option A: Visual Builder (No Code)

User selects from dropdowns:

```
Field: [actual_output]
Condition: [contains]
Value: [Paris]
Threshold: [0.8]
```

The system converts this to a rule internally.

**Supported Conditions:**
| Condition | Description | Example |
|-----------|-------------|---------|
| contains | Text includes a word | output contains "Paris" |
| not_contains | Text does not include | output not_contains "error" |
| equals | Exact match | output equals expected |
| length_gt | Character count greater than | output length > 50 |
| length_lt | Character count less than | output length < 500 |
| score_gt | Numeric score greater than | score > 0.8 |
| regex_match | Matches pattern | output matches "[0-9]+" |

#### Option B: Code Template

User writes Python code extending DeepEval's BaseMetric:

```python
from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

class CustomMetric(BaseMetric):
    """
    LLMTestCase fields:
    - input: the question (str)
    - actual_output: model's answer (str)
    - expected_output: correct answer (str)
    - retrieval_context: retrieved docs (list[str])
    - tools_called: tools used (list[ToolCall])
    - expected_tools: expected tools (list[ToolCall])
    """

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def measure(self, test_case: LLMTestCase) -> float:
        if test_case.expected_output in test_case.actual_output:
            self.score = 1.0
        else:
            self.score = 0.0
        self.success = self.score >= self.threshold
        return self.score

    async def a_measure(self, test_case: LLMTestCase) -> float:
        return self.measure(test_case)

    def is_successful(self) -> bool:
        return self.success

    @property
    def __name__(self):
        return "Custom Metric"
```

### Metric Validation

Before saving, user must:
1. Select a sample dataset
2. Run metric on 3-5 sample rows
3. See preview of scores
4. Confirm and save

---

## 2. Custom Dataset Upload

### Supported File Formats

| Format | Extension | Notes |
|--------|-----------|-------|
| JSON | .json | Recommended |
| CSV | .csv | Common |
| Parquet | .parquet | Large datasets |
| Arrow | .arrow | Fast loading |

### ETL Flow (Extract, Transform, Load)

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Upload    │ --> │   Preview   │ --> │    Map      │ --> │   Confirm   │
│    File     │     │   Columns   │     │   Fields    │     │   & Save    │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
```

### Step 1: Upload File

User uploads file (drag & drop or click).

### Step 2: Preview Columns

System shows:
- Detected columns
- Sample data (first 5 rows)
- Data types

**Example Preview:**

| Column Name | Type | Sample Value |
|-------------|------|--------------|
| question | string | "What is the capital?" |
| answer | string | "Paris" |
| context | string | "France is a country..." |

### Step 3: Map Fields

User maps source columns to DeepEval LLMTestCase fields.

**For Model Evaluation:**
```
Source Column    -->    Target Field
─────────────────────────────────────
question         -->    input
answer           -->    expected_output
extra_context    -->    context (optional)
```

**For Agent Evaluation:**
```
Source Column    -->    Target Field
─────────────────────────────────────
task             -->    input
tools_json       -->    expected_tools
final_answer     -->    expected_output (optional)
```

**For RAG Evaluation:**
```
Source Column    -->    Target Field
─────────────────────────────────────
question         -->    input
context          -->    retrieval_context
answer           -->    expected_output
```

### Step 4: Confirm & Save

User sees final preview in target format and confirms.

---

## 3. Data Formats (DeepEval LLMTestCase)

### Model Evaluation Format

```python
from deepeval.test_case import LLMTestCase

test_case = LLMTestCase(
    input="What is the capital of France?",
    actual_output="Paris is the capital of France.",
    expected_output="Paris",
    context=["France is a country in Europe."]  # optional
)
```

### Agent Evaluation Format

```python
from deepeval.test_case import LLMTestCase, ToolCall

test_case = LLMTestCase(
    input="Get weather in Tokyo",
    actual_output="The weather in Tokyo is sunny.",
    tools_called=[
        ToolCall(name="get_weather", input_parameters={"location": "Tokyo"})
    ],
    expected_tools=[
        ToolCall(name="get_weather")
    ]
)
```

### RAG Evaluation Format

```python
from deepeval.test_case import LLMTestCase

test_case = LLMTestCase(
    input="What is the return policy?",
    actual_output="Returns are accepted within 30 days.",
    expected_output="30 days",
    retrieval_context=["Returns within 30 days with receipt."]
)
```

---

## 4. API Endpoints

### Metrics API

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/metrics | List saved metrics |
| POST | /api/metrics | Create new metric |
| POST | /api/metrics/validate | Test metric on sample data |
| DELETE | /api/metrics/{id} | Delete metric |

### Dataset API

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/upload | Upload file |
| GET | /api/preview/{file_id} | Preview columns |
| POST | /api/transform | Apply mapping |
| POST | /api/save | Save dataset |

---

## 5. Tech Stack

| Component | Technology |
|-----------|------------|
| Frontend | HTML, CSS, JavaScript |
| Backend | Python Flask |
| File Parsing | Pandas, PyArrow |
| Storage | Local filesystem |

---

## 6. File Structure

```
demo/
├── main.py           # Flask routes
├── utils.py          # Helper functions
├── config.py         # Settings
├── requirements.txt  # Dependencies
├── index.html        # Main UI
├── styles.css        # Styling
├── app.js            # Frontend logic
└── sample_data/      # Sample files
    ├── model_eval.csv
    └── rag_eval.parquet
```

---

## 7. How It Works (Summary)

### Custom Metric Flow

1. User opens "Create Metric" page
2. Selects: Visual Builder or Code Editor
3. Defines the rule
4. Selects sample dataset to test
5. Clicks "Validate" to see scores
6. If OK, clicks "Save"
7. Metric is now available for evaluations

### Dataset Upload Flow

1. User opens "Upload Dataset" page
2. Drags file or clicks to upload
3. System shows column preview
4. User maps columns to target fields
5. Clicks "Preview Result"
6. If OK, clicks "Save Dataset"
7. Dataset is now available for evaluations

---

## 8. UI Screens

### Screen 1: Dashboard
- List of saved metrics
- List of saved datasets
- Quick actions: Create Metric, Upload Dataset

### Screen 2: Create Metric
- Toggle: Visual Builder / Code Editor
- Visual: Dropdowns for field, condition, value
- Code: Text area with template
- Test section: Select dataset, run validation
- Save button

### Screen 3: Upload Dataset
- Drop zone for file
- Preview table
- Mapping interface (dropdowns)
- Result preview
- Save button

---

## 9. Error Handling

| Error | User Message |
|-------|--------------|
| Invalid file format | "Please upload JSON, CSV, Parquet, or Arrow file" |
| Empty file | "File is empty" |
| Missing required columns | "Please map all required fields" |
| Invalid metric code | "Code error: {error message}" |
| Validation failed | "Metric returned invalid scores" |

---

## 10. Security Notes

- File uploads limited to 50MB
- Only allowed extensions: .json, .csv, .parquet, .arrow
- Code execution in sandbox (limited functions)
- No database writes without validation
